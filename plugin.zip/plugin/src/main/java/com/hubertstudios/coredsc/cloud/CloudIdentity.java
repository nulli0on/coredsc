package com.hubertstudios.coredsc.cloud;

import com.hubertstudios.coredsc.CoreDSCPlugin;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.PosixFilePermission;
import java.security.KeyFactory;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.EnumSet;
import java.util.Objects;
import java.util.Properties;
import java.util.UUID;

/** Persistent Ed25519 identity. The private key never leaves the plugin data directory. */
public final class CloudIdentity {
    private static final Base64.Encoder ENCODER = Base64.getUrlEncoder().withoutPadding();
    private static final Base64.Decoder DECODER = Base64.getUrlDecoder();

    private final UUID instanceId;
    private final PublicKey publicKey;
    private final PrivateKey privateKey;

    private CloudIdentity(UUID instanceId, PublicKey publicKey, PrivateKey privateKey) {
        this.instanceId = Objects.requireNonNull(instanceId, "instanceId");
        this.publicKey = Objects.requireNonNull(publicKey, "publicKey");
        this.privateKey = Objects.requireNonNull(privateKey, "privateKey");
    }

    public static CloudIdentity loadOrCreate(CoreDSCPlugin plugin) throws Exception {
        Objects.requireNonNull(plugin, "plugin");
        Path stateDirectory = plugin.getDataFolder().toPath().resolve("state").toAbsolutePath().normalize();
        Path identityFile = stateDirectory.resolve("cloud-identity.properties");
        Files.createDirectories(stateDirectory);
        if (Files.isRegularFile(identityFile)) {
            return read(identityFile);
        }

        var generator = KeyPairGenerator.getInstance("Ed25519");
        var pair = generator.generateKeyPair();
        var identity = new CloudIdentity(UUID.randomUUID(), pair.getPublic(), pair.getPrivate());
        identity.write(identityFile);
        plugin.getLogger().info("[Cloud] Created local Ed25519 instance identity "
                + identity.instanceId + ". The private key remains in plugins/CoreDSC/state/.");
        return identity;
    }

    public UUID instanceId() {
        return instanceId;
    }

    public String publicKeyBase64() {
        return ENCODER.encodeToString(publicKey.getEncoded());
    }

    public String sign(String canonicalMessage) throws Exception {
        Signature signer = Signature.getInstance("Ed25519");
        signer.initSign(privateKey);
        signer.update(canonicalMessage.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        return ENCODER.encodeToString(signer.sign());
    }

    private static CloudIdentity read(Path file) throws Exception {
        Properties properties = new Properties();
        try (InputStream input = Files.newInputStream(file)) {
            properties.load(input);
        }
        String version = properties.getProperty("format", "");
        if (!version.equals("1")) {
            throw new IOException("Unsupported cloud identity format in " + file);
        }
        UUID instanceId = UUID.fromString(required(properties, "instance-id"));
        KeyFactory factory = KeyFactory.getInstance("Ed25519");
        PublicKey publicKey = factory.generatePublic(new X509EncodedKeySpec(
                DECODER.decode(required(properties, "public-key"))));
        PrivateKey privateKey = factory.generatePrivate(new PKCS8EncodedKeySpec(
                DECODER.decode(required(properties, "private-key"))));
        CloudIdentity identity = new CloudIdentity(instanceId, publicKey, privateKey);

        // Detect truncated/mismatched key files before accepting remote work.
        String probe = "coredsc-identity-self-test:" + instanceId;
        Signature verifier = Signature.getInstance("Ed25519");
        verifier.initVerify(publicKey);
        verifier.update(probe.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        if (!verifier.verify(DECODER.decode(identity.sign(probe)))) {
            throw new IOException("Cloud identity public/private keys do not match in " + file);
        }
        return identity;
    }

    private void write(Path file) throws Exception {
        Properties properties = new Properties();
        properties.setProperty("format", "1");
        properties.setProperty("instance-id", instanceId.toString());
        properties.setProperty("public-key", ENCODER.encodeToString(publicKey.getEncoded()));
        properties.setProperty("private-key", ENCODER.encodeToString(privateKey.getEncoded()));
        Path temporary = Files.createTempFile(file.getParent(), ".cloud-identity-", ".tmp");
        try {
            try (OutputStream output = Files.newOutputStream(temporary)) {
                properties.store(output, "CoreDSC local cloud identity - keep this file private");
            }
            restrict(temporary);
            try {
                Files.move(temporary, file, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temporary, file);
            }
            restrict(file);
        } finally {
            Files.deleteIfExists(temporary);
        }
    }

    private static void restrict(Path file) {
        try {
            Files.setPosixFilePermissions(file, EnumSet.of(
                    PosixFilePermission.OWNER_READ,
                    PosixFilePermission.OWNER_WRITE));
        } catch (UnsupportedOperationException | IOException ignored) {
            // Windows/non-POSIX hosts use their native ACLs. The file remains
            // inside the server owner's existing private plugin directory.
        }
    }

    private static String required(Properties properties, String key) throws IOException {
        String value = properties.getProperty(key);
        if (value == null || value.isBlank()) throw new IOException("Cloud identity is missing " + key);
        return value.trim();
    }
}
