package com.hubertstudios.coredsc.cloud;

import java.nio.charset.StandardCharsets;
import java.util.Objects;

/**
 * Byte-oriented protocol limits shared by inbound and outbound cloud messages.
 */
final class CloudProtocolLimits {
    static final int MAXIMUM_MESSAGE_BYTES = 1_048_576;

    private CloudProtocolLimits() {
    }

    static int utf8Length(CharSequence value) {
        Objects.requireNonNull(value, "value");
        return value.toString().getBytes(StandardCharsets.UTF_8).length;
    }

    static boolean exceedsMessageLimit(CharSequence value) {
        return utf8Length(value) > MAXIMUM_MESSAGE_BYTES;
    }
}
