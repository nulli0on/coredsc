package com.hubertstudios.coredsc.cloud;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Base64;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

final class CloudMediaStoreTest {
    @TempDir
    Path temporaryDirectory;

    @Test
    void storesValidatedContentByDigestAndResolvesOnlyGeneratedReferences() throws Exception {
        CloudMediaStore store = new CloudMediaStore(temporaryDirectory.resolve("media"));
        byte[] png = new byte[] {
                (byte) 0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
                0x00, 0x01, 0x02, 0x03
        };
        Map<String, Object> installed = store.install(Map.of(
                "mimeType", "image/png",
                "extension", "png",
                "dataBase64", Base64.getEncoder().encodeToString(png)));

        String reference = String.valueOf(installed.get("reference"));
        assertTrue(CloudMediaStore.isReference(reference));
        CloudMediaStore.MediaFile media = store.resolve(reference).orElseThrow();
        assertArrayEquals(png, Files.readAllBytes(media.path()));
        assertTrue(media.attachmentName().endsWith(".png"));

        Map<String, Object> duplicate = store.install(Map.of(
                "mimeType", "image/png",
                "extension", "png",
                "dataBase64", Base64.getEncoder().encodeToString(png)));
        assertEquals(reference, duplicate.get("reference"));
        try (var files = Files.list(temporaryDirectory.resolve("media"))) {
            assertEquals(1L, files.count());
        }
    }

    @Test
    void rejectsInvalidBase64TypeMismatchAndOversizedContent() {
        CloudMediaStore store = new CloudMediaStore(temporaryDirectory.resolve("media"));
        byte[] png = new byte[] {
                (byte) 0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a
        };
        String encoded = Base64.getEncoder().encodeToString(png);

        assertThrows(IllegalArgumentException.class, () -> store.install(Map.of(
                "mimeType", "image/jpeg", "extension", "jpg", "dataBase64", encoded)));
        assertThrows(IllegalArgumentException.class, () -> store.install(Map.of(
                "mimeType", "image/png", "extension", "jpg", "dataBase64", encoded)));
        assertThrows(IllegalArgumentException.class, () -> store.install(Map.of(
                "mimeType", "image/png", "extension", "png", "dataBase64", "%%%")));

        byte[] oversized = new byte[CloudMediaStore.MAX_MEDIA_BYTES + 1];
        oversized[0] = (byte) 0x89;
        oversized[1] = 0x50;
        oversized[2] = 0x4e;
        oversized[3] = 0x47;
        oversized[4] = 0x0d;
        oversized[5] = 0x0a;
        oversized[6] = 0x1a;
        oversized[7] = 0x0a;
        assertThrows(IllegalArgumentException.class, () -> store.install(Map.of(
                "mimeType", "image/png",
                "extension", "png",
                "dataBase64", Base64.getEncoder().encodeToString(oversized))));
    }

    @Test
    void rejectsPathLikeAndUnknownReferences() {
        CloudMediaStore store = new CloudMediaStore(temporaryDirectory.resolve("media"));
        assertFalse(store.resolve("../../secrets.yml").isPresent());
        assertFalse(store.resolve("coredsc-media://../secrets.yml").isPresent());
        assertFalse(store.resolve("coredsc-media://" + "a".repeat(64) + ".svg").isPresent());
        assertFalse(store.resolve("coredsc-media://" + "a".repeat(64) + ".png").isPresent());
    }
}
