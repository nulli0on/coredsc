# CoreDSC browser-only deployment and update guide

This guide is for **CoreDSC plugin 3.4.2** and **CoreDSC Panel 1.3.1**.

It assumes you no longer have a local development PC. Everything can be done with:

- the GitHub website;
- a GitHub Codespace;
- the Cloudflare dashboard;
- the Discord Developer Portal; and
- your Minecraft server's web panel or file manager.

The guide is written primarily for an **existing CoreDSC deployment**. It also explains how to recover the required values from Cloudflare when the old local project folder is unavailable.

## What is being deployed

CoreDSC uses two Cloudflare Workers:

```text
Browser
  |
  v
CoreDSC Panel Worker
  |
  | CONTROL_PLANE service binding
  v
CoreDSC control-plane Worker
  |                    |
  v                    v
D1 database      Durable Objects
                        ^
                        |
                outbound WSS connection
                        |
                Minecraft plugin 3.4.2
```

The public Panel Worker serves the website and forwards `/api/*` requests to the control-plane Worker. The control plane handles Discord login, server pairing, permissions, approvals, D1 data and live plugin connections.

No inbound port is opened on the Minecraft server. The plugin connects outward to the public Panel URL through TLS WebSocket.

---

# Part 1 — Put the new source in GitHub Codespaces

## Step 1 — Create or open a private GitHub repository

Use a **private** repository for the deployment source.

From the GitHub website:

1. Open **New repository**.
2. Choose a repository name such as `coredsc-hosted`.
3. Select **Private**.
4. Create the repository.

A public repository must never contain secrets. This source package does not contain production secrets, but a private repository reduces the chance of accidentally publishing later configuration changes.

## Step 2 — Upload the ZIP through the GitHub website

Upload:

```text
CoreDSC-3.4.2-Panel-1.3.1.zip
```

Use **Add file → Upload files** in the repository and commit the ZIP.

## Step 3 — Create a Codespace

From the repository page:

1. Select **Code**.
2. Open the **Codespaces** tab.
3. Select **Create codespace on main**.
4. Wait for the browser editor and terminal to open.

## Step 4 — Extract the source into the repository root

In the Codespaces terminal:

```bash
unzip CoreDSC-3.4.2-Panel-1.3.1.zip
cp -a CoreDSC-3.4.2-Panel-1.3.1/. .
rm -rf CoreDSC-3.4.2-Panel-1.3.1
rm CoreDSC-3.4.2-Panel-1.3.1.zip
```

The repository root should now contain:

```text
app/
control-plane/
plugin/
public/
worker/
package.json
vite.config.ts
README.md
SETUP.md
REFERENCE.md
CHANGELOG.md
```

Commit the extracted source:

```bash
git add .
git commit -m "Update CoreDSC plugin 3.4.2 and Panel 1.3.1"
git push
```

---

# Part 2 — Check the Codespace

## Step 5 — Verify Node.js and Java

Run:

```bash
node --version
java -version
```

Required versions:

```text
Node.js 22.13.0 or newer
Java 21
```

GitHub Codespaces normally provides Node.js. If Maven is missing, install it inside the Codespace:

```bash
sudo apt-get update
sudo apt-get install -y maven
mvn --version
```

Do not use `sudo npm ...`.

## Step 6 — Install and test the control plane

From the repository root:

```bash
cd control-plane
npm ci
npm run check
cd ..
```

The expected test result for this source is:

```text
tests 98
pass 98
fail 0
```

An `npm audit` summary is not the test result. A message such as `5 high severity vulnerabilities` means npm found dependency advisories; it does not mean five tests failed.

Save the advisory details before changing dependencies:

```bash
cd control-plane
npm audit --json > npm-audit-control-plane.json
cd ..
```

Do not run `npm audit fix --force` without reviewing the exact packages and breaking changes.

## Step 7 — Install and test the Panel

From the repository root:

```bash
npm ci
npm run lint
npm test
```

`npm test` performs a production build before checking the rendered pages.

If a shell script reports `Permission denied`, do not use `sudo`. Run:

```bash
chmod +x scripts/*.sh
npm test
```

The build scripts also call nested scripts through Bash, so a normal ZIP extraction should not require executable permissions.

---

# Part 3 — Recover the existing Cloudflare values

You need four existing values:

```text
1. Public Panel URL
2. D1 database ID
3. Discord application ID and client secret
4. Existing Worker names
```

The supplied Worker names are:

```text
Panel Worker:         coredsc-operations
Control-plane Worker: coredsc-control-plane
D1 database:          coredsc-control-plane
```

## Step 8 — Find the public Panel URL

In the Cloudflare dashboard:

1. Open **Workers & Pages**.
2. Open the public Panel Worker, normally `coredsc-operations`.
3. Copy its active `workers.dev` URL or custom domain.

Examples:

```text
https://coredsc-operations.YOUR-ACCOUNT.workers.dev
https://panel.example.eu.org
```

Use the public Panel address, not the separate control-plane `workers.dev` address.

In the rest of this guide it is called:

```text
PANEL_URL
```

Rules:

- it must use `https://`;
- it must not end with `/`;
- it must open the CoreDSC Panel; and
- Discord OAuth must use the same host.

## Step 9 — Find the D1 database ID

In the Cloudflare dashboard:

1. Open **Storage & Databases**.
2. Open **D1 SQL Database**.
3. Open `coredsc-control-plane`.
4. Copy the database ID from the database overview or settings page.

The ID looks like:

```text
xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
```

Do not create a second database when the existing deployment already contains your servers, staff and audit data.

## Step 10 — Confirm that the secrets still exist

In the Cloudflare dashboard:

1. Open **Workers & Pages**.
2. Open `coredsc-control-plane`.
3. Open **Settings**.
4. Open **Variables and Secrets**.

Confirm these secret names exist:

```text
DISCORD_CLIENT_ID
DISCORD_CLIENT_SECRET
COOKIE_SECRET
```

Cloudflare does not reveal existing secret values. That is normal.

Do not replace `COOKIE_SECRET` during a normal update. Replacing it signs out all current browser sessions. Replace it only when it may have leaked.

---

# Part 4 — Configure the source for the existing deployment

## Step 11 — Edit `control-plane/wrangler.jsonc`

Open this file in Codespaces:

```text
control-plane/wrangler.jsonc
```

Replace the placeholder database ID:

```json
"database_id": "REPLACE_WITH_D1_DATABASE_ID"
```

with the existing D1 database ID.

Replace the placeholder URLs with the exact public Panel URL:

```json
"vars": {
  "APP_ORIGIN": "https://YOUR-PANEL-HOST",
  "PUBLIC_APP_URL": "https://YOUR-PANEL-HOST",
  "DISCORD_REDIRECT_URI": "https://YOUR-PANEL-HOST/api/v1/auth/discord/callback",
  "SESSION_TTL_SECONDS": "604800"
}
```

Example:

```json
"vars": {
  "APP_ORIGIN": "https://coredsc-operations.example.workers.dev",
  "PUBLIC_APP_URL": "https://coredsc-operations.example.workers.dev",
  "DISCORD_REDIRECT_URI": "https://coredsc-operations.example.workers.dev/api/v1/auth/discord/callback",
  "SESSION_TTL_SECONDS": "604800"
}
```

Do not place the Discord client secret, cookie secret or bot token in this file.

Keep these bindings unchanged:

```text
COREDSC_DB
INSTANCE_ROOMS
```

Keep the Durable Object migration and cron trigger unchanged.

## Step 12 — Verify the Panel service binding

The supplied `vite.config.ts` already contains:

```ts
services: [
  {
    binding: "CONTROL_PLANE",
    service: "coredsc-control-plane",
  },
],
```

Do not rename either value.

The Panel uses `CONTROL_PLANE` to reach the backend internally. The browser does not need the control-plane Worker URL.

## Step 13 — Log Wrangler into the correct Cloudflare account

From the repository root:

```bash
npx wrangler login
npx wrangler whoami
```

Wrangler displays a browser authorization link. Open it, approve access and return to the Codespace.

Check the account shown by `wrangler whoami`. Do not deploy while logged into the wrong Cloudflare account.

---

# Part 5 — Update the control plane

## Step 14 — Remove stale generated Panel deployment state

The Cloudflare Vite build creates:

```text
.wrangler/deploy/config.json
```

That generated Panel configuration can conflict with `control-plane/wrangler.jsonc` when Wrangler searches parent folders.

Before deploying the control plane, run from the repository root:

```bash
rm -rf .wrangler
```

Do not delete:

```text
control-plane/wrangler.jsonc
```

## Step 15 — Apply the D1 migrations

Run:

```bash
cd control-plane
npm run db:remote
```

Wrangler applies only migrations that are not already recorded for the configured D1 database.

Do not rename, reorder or combine the numbered files in:

```text
control-plane/migrations/
```

Before confirming, verify that Wrangler names the existing `coredsc-control-plane` database.

## Step 16 — Deploy the control-plane Worker

Still inside `control-plane/`:

```bash
npm run deploy
```

The deployment must retain:

```text
D1 binding:            COREDSC_DB
Durable Object binding: INSTANCE_ROOMS
Worker name:           coredsc-control-plane
Cron:                  */1 * * * *
```

If Wrangler reports both `wrangler.jsonc` and `../.wrangler/deploy/config.json`, return to the repository root, delete `.wrangler`, and run the deployment again:

```bash
cd ..
rm -rf .wrangler
cd control-plane
npm run deploy
```

## Step 17 — Add missing secrets through the Cloudflare website

Only perform this step when a secret name is missing.

In Cloudflare:

1. Open **Workers & Pages**.
2. Open `coredsc-control-plane`.
3. Open **Settings → Variables and Secrets**.
4. Add the missing item as an encrypted secret.

Required values:

| Secret | Value |
|---|---|
| `DISCORD_CLIENT_ID` | Discord application ID |
| `DISCORD_CLIENT_SECRET` | Discord OAuth client secret |
| `COOKIE_SECRET` | Locally generated random session secret |

Generate a new cookie secret inside Codespaces only when needed:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('base64url'))"
```

Copy it directly into Cloudflare. Do not commit it or paste it into chat.

The Discord bot token never belongs in Cloudflare. It remains only in the Minecraft server's local `secrets.yml`.

---

# Part 6 — Update the public Panel

## Step 18 — Build the Panel

Return to the repository root:

```bash
cd ..
npm run build
```

A successful build creates the generated Cloudflare deployment configuration under `.wrangler/`.

## Step 19 — Deploy the Panel

Run:

```bash
npx wrangler deploy
```

Review the binding summary. It must contain a service binding equivalent to:

```text
CONTROL_PLANE -> coredsc-control-plane
```

Do not approve a deployment that removes `CONTROL_PLANE`.

The public URL should remain the same when the Worker name is unchanged.

## Step 20 — Verify the live backend through the Panel

Open:

```text
PANEL_URL/api/health
```

Expected response:

```json
{
  "ok": true,
  "service": "CoreDSC Control Plane",
  "protocol": 1,
  "version": "1.3.1"
}
```

This request verifies all three parts at once:

```text
Browser → Panel Worker → CONTROL_PLANE binding → control-plane Worker
```

Interpret common failures:

| Result | Meaning |
|---|---|
| Panel loads, `/api/health` returns 503 | `CONTROL_PLANE` binding is missing |
| `/api/health` returns 404 | wrong route or wrong Worker deployment |
| `/api/health` returns JSON version `1.3.1` | Panel and control plane are connected |
| Discord login redirects incorrectly | OAuth redirect or Panel origin does not match |

---

# Part 7 — Check Discord OAuth

## Step 21 — Verify the redirect URI

Open the Discord Developer Portal in the browser:

1. Select the CoreDSC application.
2. Open **OAuth2**.
3. Check the registered redirect URI.

It must exactly match:

```text
PANEL_URL/api/v1/auth/discord/callback
```

Example:

```text
https://panel.example.eu.org/api/v1/auth/discord/callback
```

Differences in protocol, host, path or trailing slash cause OAuth failure.

## Step 22 — Test login and logout

Open the Panel in a private browser window.

Verify:

1. **Sign in with Discord** opens Discord OAuth.
2. Discord returns to the Panel.
3. The dashboard loads only assigned servers.
4. Logout clears the session.

Do not test only with an already logged-in browser session; an old cookie can hide configuration mistakes.

---

# Part 8 — Build plugin 3.4.2 in Codespaces

## Step 23 — Compile and test the plugin

From the repository root:

```bash
cd plugin
mvn -e clean verify
```

Do not continue until Maven ends with:

```text
BUILD SUCCESS
```

The expected JAR path is:

```text
plugin/target/CoreDSC-3.4.2.jar
```

`-e` only enables detailed Maven error stack traces. It does not change the JAR.

## Step 24 — Download the JAR from Codespaces

In the Codespaces file explorer:

1. Open `plugin/target/`.
2. Find `CoreDSC-3.4.2.jar`.
3. Right-click it.
4. Select **Download**.

Upload that JAR through your Minecraft host's web panel or file manager.

Stop the server before replacing the old JAR. Keep a copy of the old working JAR for rollback.

## Step 25 — Preserve existing server data

Do not delete the existing:

```text
plugins/CoreDSC/
```

It contains configuration, identity, database and recovery state.

Replace only the old plugin JAR unless a documented migration explicitly requires more.

CoreDSC creates this file automatically on startup when missing:

```text
plugins/CoreDSC/bot/README.md
```

You do not need to create it manually.

## Step 26 — Verify the cloud endpoint

Open:

```text
plugins/CoreDSC/modules/cloud-control.yml
```

For the official hosted system, a fresh CoreDSC 3.4.2 configuration already uses:

```yaml
enabled: true
endpoint: "wss://dash.coredsc.workers.dev/api/v1/agent/connect"
```

When intentionally self-hosting, replace only the endpoint with your own public Panel host:

```yaml
enabled: true
endpoint: "wss://YOUR-PANEL-HOST/api/v1/agent/connect"
```

Example:

```yaml
enabled: true
endpoint: "wss://panel.example.eu.org/api/v1/agent/connect"
```

Do not use:

- the control-plane Worker URL;
- `https://` instead of `wss://`;
- `coredsc.example.invalid`; or
- an old `pages.dev` address.

Remote console execution remains disabled unless you explicitly enable and configure its allowlist.

## Step 27 — Start the server and verify

Start the Minecraft server and run:

```text
/coredsc status
/coredsc doctor
/coredsc editor status
```

Check the server log for a successful cloud connection. The Panel should show the server online after the next heartbeat.

---

# Part 9 — Hosted editor pairing

There is only one editor command path:

```text
/coredsc editor
```

The removed local `/coredsc webeditor` command must not be used.

For first-owner pairing:

1. Run `/coredsc editor` in Minecraft or the server console.
2. Open the single URL returned by CoreDSC.
3. Sign in with Discord.
4. The website displays a confirmation command.
5. Run the displayed command locally:

   ```text
   /coredsc editor auth XXXX-XXXX
   ```

6. The website detects confirmation and opens the server workspace.

The website must not produce a second editor URL before confirmation.

---

# Part 10 — Custom domains without buying a domain

A `workers.dev` address is free and fully usable.

A cleaner custom host can be attached when its DNS zone is active in your Cloudflare account. An approved `eu.org` domain delegated to Cloudflare can normally be used for a host such as:

```text
panel.yourname.eu.org
```

A DuckDNS hostname normally cannot be attached as a native Worker Custom Domain because you do not control the parent `duckdns.org` zone in Cloudflare.

To add a custom domain through the Cloudflare website:

1. Open **Workers & Pages**.
2. Open the public Panel Worker.
3. Open **Settings → Domains & Routes**.
4. Add the custom domain.
5. Wait until Cloudflare shows it as active.

After changing the Panel host, update all three locations:

```text
control-plane/wrangler.jsonc
Discord OAuth redirect URI
plugins/CoreDSC/modules/cloud-control.yml
```

Then redeploy both Workers and restart or reload the plugin.

---

# Part 11 — Safe update order for future releases

Use this order every time:

```bash
# 1. Open the Codespace and update the source.

# 2. Test the control plane.
cd control-plane
npm ci
npm run check
cd ..

# 3. Test the Panel.
npm ci
npm run lint
npm test

# 4. Test the plugin.
cd plugin
mvn -e clean verify
cd ..

# 5. Deploy the control plane.
rm -rf .wrangler
cd control-plane
npm run db:remote
npm run deploy
cd ..

# 6. Deploy the Panel.
npm run build
npx wrangler deploy

# 7. Verify the live API.
# Open PANEL_URL/api/health

# 8. Install the new JAR on a recoverable test server first.
```

Do not deploy the Panel first when it requires a control-plane change that has not been deployed yet.

---

# Troubleshooting

## Wrangler finds two configuration files

Error pattern:

```text
Found both a user configuration file at "wrangler.jsonc"
and a deploy configuration file at "../.wrangler/deploy/config.json"
```

Fix:

```bash
cd ..
rm -rf .wrangler
cd control-plane
npm run deploy
```

The root `.wrangler` directory is generated state. `control-plane/wrangler.jsonc` is source configuration and must remain.

## Every control-plane test fails

Run:

```bash
cd control-plane
node --version
rm -rf node_modules
npm ci
npm run check
```

Confirm Node.js is at least 22.13.0 and that the archive contains `src/`, `tests/` and `tsconfig.json`.

Do not confuse `npm audit` advisories with test failures.

## Panel works but backend requests fail

Check:

1. `PANEL_URL/api/health`;
2. the `CONTROL_PLANE` service binding;
3. the target Worker name `coredsc-control-plane`;
4. `APP_ORIGIN` and `PUBLIC_APP_URL`;
5. whether the control-plane Worker deployed successfully; and
6. whether D1 and Durable Object bindings are present.

## Discord login works but no server appears

Check:

1. the plugin is online;
2. the plugin endpoint uses the public Panel host;
3. the pairing confirmation command was run locally;
4. the signed-in Discord account owns or was granted access to the server; and
5. the Worker and plugin clocks are reasonably accurate.

## Plugin connects to the backend but commands time out

Check the Minecraft server log, `/coredsc editor status`, the Panel's server status and the control-plane Worker logs in Cloudflare.

Do not open an inbound Minecraft port. CoreDSC requires only its outbound WSS connection.

---

# Format-2 preset setup and rollback

For the DonutSMP-inspired preset, copy `examples/presets/donutsmp.yml` to `plugins/CoreDSC/configs/donutsmp.yml`, set `discord.guild-id`, then choose `CREATE_MISSING`, `USE_EXISTING` or `DISABLED` for the Discord resource groups. When `USE_EXISTING` is selected, fill the corresponding IDs in the `existing` section.

Run:

```text
/coredsc preset reload
/coredsc preset enable donutsmp
/coredsc preset preview donutsmp
/coredsc preset apply donutsmp
```

Preview is side-effect free. Apply creates an immutable rollback snapshot before creating resources or writing configuration. If a matching Discord object already exists during `CREATE_MISSING`, CoreDSC stops and reports the ID so the operator can explicitly switch to `USE_EXISTING`; it does not silently take ownership of existing server structure.

To restore:

```text
/coredsc rollback list
/coredsc rollback use <snapshot-id>
/coredsc confirm <six-character-code>
```

The confirmation code expires after 60 seconds. CoreDSC creates a second safety snapshot before restoration. The confirmation preview also reports CoreDSC-created external resources that would be removed because they were absent from the target snapshot. Reused administrator Discord/LuckPerms resources are never removed by that reconciliation.

---

# Final checklist

Before considering the update complete, verify all of the following:

- [ ] Panel package version is `1.3.1`.
- [ ] Plugin version is `3.4.2`.
- [ ] `control-plane/npm run check` passes all 115 tests.
- [ ] Root `npm run lint` and `npm test` pass.
- [ ] `mvn -e clean verify` ends with `BUILD SUCCESS`.
- [ ] D1 migrations were applied to the existing database.
- [ ] The control-plane Worker deployed without a configuration conflict.
- [ ] The Panel deployment includes `CONTROL_PLANE -> coredsc-control-plane`.
- [ ] `PANEL_URL/api/health` reports version `1.3.1`.
- [ ] Discord OAuth returns to the exact Panel callback URL.
- [ ] The Minecraft plugin reports version `3.4.2`.
- [ ] The plugin connects to `wss://PANEL_HOST/api/v1/agent/connect`.
- [ ] `/coredsc editor` uses one hosted pairing URL and one local confirmation command.
- [ ] `/coredsc preset browse` reaches the official registry and `/coredsc preset list` reports installed presets.
- [ ] A dashboard **Save & apply** test reports success only after the agent reconnects with the saved revisions.
- [ ] The old working JAR and Cloudflare deployment remain available for rollback.
