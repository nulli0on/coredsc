import assert from "node:assert/strict";
import { existsSync, readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";

const root = new URL("../../", import.meta.url);
const pomPath = new URL("plugin/pom.xml", root);
const pluginYmlPath = new URL("plugin/src/main/resources/plugin.yml", root);
const cloudConfigPath = new URL("plugin/src/main/resources/modules/cloud-control.yml", root);
const cloudDirectory = new URL("plugin/src/main/java/com/hubertstudios/coredsc/cloud/", root);
const pomExists = existsSync(pomPath);
const pluginYmlExists = existsSync(pluginYmlPath);
const cloudConfigExists = existsSync(cloudConfigPath);
const cloudDirectoryExists = existsSync(cloudDirectory);
const pom = pomExists ? readFileSync(pomPath, "utf8") : "";
const pluginYml = pluginYmlExists ? readFileSync(pluginYmlPath, "utf8") : "";
const cloudConfig = cloudConfigExists ? readFileSync(cloudConfigPath, "utf8") : "";
const cloudSources = cloudDirectoryExists ? readdirSync(cloudDirectory).filter((name) => name.endsWith(".java"))
  .map((name) => readFileSync(join(fileURLToPath(cloudDirectory), name), "utf8")).join("\n") : "";
const presetService = readFileSync(new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/service/PresetService.java", import.meta.url), "utf8");


test("plugin metadata and dependency boundaries match 3.4.2", () => {
  if (!pomExists || !pluginYmlExists) {
    return;
  }
  assert.match(pom, /<version>3\.4\.2<\/version>/u);
  assert.match(pluginYml, /^version: 3\.4\.2$/mu);
  assert.match(pluginYml, /^folia-supported: true$/mu);
  for (const artifact of ["paper-api", "slf4j-api", "api", "voicechat-api"]) {
    const dependency = new RegExp(`<artifactId>${artifact.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&")}<\\/artifactId>[\\s\\S]{0,180}<scope>provided<\\/scope>`, "u");
    assert.match(pom, dependency, `${artifact} must remain provided`);
  }
  for (const artifact of ["sqlite-jdbc", "bstats-bukkit", "JDA"]) {
    const dependency = new RegExp(`<artifactId>${artifact.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&")}<\\/artifactId>[\\s\\S]{0,220}<scope>provided<\\/scope>`, "u");
    assert.doesNotMatch(pom, dependency, `${artifact} must remain packaged for runtime`);
  }
});

test("official cloud transport is ready on fresh installs while remote console stays fail closed", () => {
  if (!cloudConfigExists) {
    return;
  }
  assert.match(cloudConfig, /^enabled: true$/mu);
  assert.match(cloudConfig, /^endpoint: ['"]wss:\/\/dash\.coredsc\.workers\.dev\/api\/v1\/agent\/connect['"]$/mu);
  assert.doesNotMatch(cloudConfig, /example\.invalid/u);
  assert.match(cloudConfig, /remote-execution:[\s\S]{0,180}\n\s+enabled: false/u);
  assert.doesNotMatch(cloudConfig, /(^|\s)\*($|\s)/mu);
});

test("setup module allowlist stays aligned with the runtime module registry", () => {
  const moduleManagerPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/module/ModuleManager.java", import.meta.url);
  const doctorPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/service/DoctorService.java", import.meta.url);
  const cloudModulePath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/module/impl/CloudControlModule.java", import.meta.url);
  if (!existsSync(moduleManagerPath) || !existsSync(doctorPath) || !existsSync(cloudModulePath)) return;
  const moduleManager = readFileSync(moduleManagerPath, "utf8");
  const doctor = readFileSync(doctorPath, "utf8");
  const cloudModule = readFileSync(cloudModulePath, "utf8");
  const runtimeIds = [...moduleManager.matchAll(/new ModuleSelection\("([^"]+)"/gu)].map((match) => match[1]);
  const setupBlock = doctor.match(/Set<String> allowed = Set\.of\(([\s\S]*?)\);/u)?.[1] ?? "";
  const setupIds = [...setupBlock.matchAll(/"([^"]+)"/gu)].map((match) => match[1]);
  assert.deepEqual(new Set(setupIds), new Set(runtimeIds));
  assert.match(cloudModule, /"cloud-control\.endpoint", "wss:\/\/dash\.coredsc\.workers\.dev\/api\/v1\/agent\/connect"/u);
  assert.doesNotMatch(cloudModule, /coredsc\.example\.invalid/u);
});

test("cloud package does not retain Player objects and scheduler-wraps direct Bukkit operations", () => {
  if (!cloudDirectoryExists) {
    return;
  }
  assert.doesNotMatch(cloudSources, /import org\.bukkit\.entity\.Player;/u);
  assert.doesNotMatch(cloudSources, /(?:private|protected|public)\s+(?:final\s+)?Player\s+/u);
  assert.match(cloudSources, /plugin\.callSync\(\(\) -> Bukkit\.dispatchCommand/u);
  assert.match(cloudSources, /plugin\.callSync\(\(\) -> Optional\.ofNullable\(Bukkit\.getOfflinePlayer/u);
  assert.match(cloudSources, /plugin\.runForPlayer\(uuid/u);
});


test("incident and maintenance chat pause ownership cannot cancel each other", () => {
  if (!cloudDirectoryExists) {
    return;
  }
  const coordinatorPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/cloud/OperationsCoordinator.java", import.meta.url);
  const coordinator = existsSync(coordinatorPath) ? readFileSync(coordinatorPath, "utf8") : "";
  assert.match(coordinator, /boolean incidentOwnsPause = incidentState != null && incidentState\.pauseChat\(\)/u);
  assert.match(coordinator, /boolean maintenanceOwnsPause = maintenanceState != null && maintenanceState\.pauseChat\(\)/u);
  assert.match(coordinator, /setChatPaused\(incidentOwnsPause \|\| maintenanceOwnsPause\)/u);
  assert.doesNotMatch(coordinator, /cancelMaintenance[\s\S]{0,900}setChatPaused\(false\)/u);
});

test("incident resolution remains retryable until channel restoration succeeds", () => {
  if (!cloudDirectoryExists) {
    return;
  }
  const coordinatorPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/cloud/OperationsCoordinator.java", import.meta.url);
  const channelsPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/cloud/ChannelOperationService.java", import.meta.url);
  const coordinator = existsSync(coordinatorPath) ? readFileSync(coordinatorPath, "utf8") : "";
  const channels = existsSync(channelsPath) ? readFileSync(channelsPath, "utf8") : "";
  assert.match(coordinator, /restoreConfiguredChannelsStrict\(current\.channelIds\(\)/u);
  assert.match(coordinator, /rollbackFailedIncidentStart\(/u);
  assert.match(coordinator, /preserveFailedIncident\(/u);
  assert.match(coordinator, /persisted incident remains active for an authorized restoration retry/u);
  assert.match(channels, /the incident remains active for retry/u);
  assert.match(channels, /No operation-owned snapshot remains; the channel was already restored or never changed/u);
});

test("scheduled-event creation rolls Discord back when local persistence fails", () => {
  if (!cloudDirectoryExists) {
    return;
  }
  const coordinatorPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/cloud/OperationsCoordinator.java", import.meta.url);
  const coordinator = existsSync(coordinatorPath) ? readFileSync(coordinatorPath, "utf8") : "";
  assert.match(coordinator, /repository\.putState\("event:" \+ event\.getId\(\)/u);
  assert.match(coordinator, /exceptionallyCompose\(error -> event\.delete\(\)/u);
  assert.match(coordinator, /CoreDSC rollback: local event persistence failed/u);
});

test("cloud agent permits only one WebSocket handshake at a time", () => {
  if (!cloudDirectoryExists) return;
  const agentPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudEditorAgent.java", import.meta.url);
  const agent = existsSync(agentPath) ? readFileSync(agentPath, "utf8") : "";
  assert.match(agent, /AtomicBoolean connectInFlight/u);
  assert.match(agent, /!connectInFlight\.compareAndSet\(false, true\)/u);
  assert.match(agent, /whenComplete\(\(connected, error\) -> \{[\s\S]{0,100}connectInFlight\.set\(false\)/u);
});

test("cloud agent shutdown rejects late successful WebSocket opens", () => {
  if (!cloudDirectoryExists) {
    return;
  }
  const agentPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudEditorAgent.java", import.meta.url);
  const agent = existsSync(agentPath) ? readFileSync(agentPath, "utf8") : "";
  assert.match(agent, /if \(!running\.get\(\)\) \{[\s\S]{0,260}sendClose\(1000, "CoreDSC is stopping"\)/u);
});

test("cloud agent close is idempotent even before start and prevents resurrection", () => {
  if (!cloudDirectoryExists) return;
  const agentPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudEditorAgent.java", import.meta.url);
  const agent = existsSync(agentPath) ? readFileSync(agentPath, "utf8") : "";
  assert.match(agent, /private final AtomicBoolean closed = new AtomicBoolean\(\)/u);
  assert.match(agent, /if \(closed\.get\(\) \|\| !running\.compareAndSet\(false, true\)\) return/u);
  assert.match(agent, /if \(!closed\.compareAndSet\(false, true\)\) return/u);
  assert.match(agent, /running\.set\(false\)/u);
  assert.match(agent, /else \{\s*executor\.shutdownNow\(\);\s*\}/u);
});

test("cloud module asynchronous initialization failure fully detaches runtime resources", () => {
  const modulePath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/module/impl/CloudControlModule.java", import.meta.url);
  if (!existsSync(modulePath)) return;
  const module = readFileSync(modulePath, "utf8");
  const failBody = module.match(/private void fail\(String context, Throwable error\) \{([\s\S]*?)\n    \}/u)?.[1] ?? "";
  assert.match(failBody, /active = false/u);
  assert.match(failBody, /HandlerList\.unregisterAll\(this\)/u);
  assert.match(failBody, /cancel\(initializationTask\)/u);
  assert.match(failBody, /cancel\(expiryTask\)/u);
  assert.match(failBody, /cancel\(cleanupTask\)/u);
  assert.match(failBody, /onlinePlayers\.clear\(\)/u);
  assert.match(module, /if \(state\.get\(\) == State\.FAILED\) \{[\s\S]{0,120}Cloud agent failed:/u);
});


test("configuration edits remain allowlisted, revision-bound, backed up and rollback-capable", () => {
  if (!cloudDirectoryExists) {
    return;
  }
  const servicePath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudConfigurationService.java", import.meta.url);
  const managerPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/config/ConfigManager.java", import.meta.url);
  const service = existsSync(servicePath) ? readFileSync(servicePath, "utf8") : "";
  const manager = existsSync(managerPath) ? readFileSync(managerPath, "utf8") : "";
  assert.match(service, /private static final Set<String> ALLOWED_PATCHES/u);
  assert.match(service, /hosted editor is not allowed to change/u);
  assert.match(service, /Configuration change is missing its expected revision/u);
  assert.match(manager, /A valid configuration revision is required/u);
  assert.match(manager, /changed after/u);
  assert.match(manager, /createEditorBatchBackup/u);
  assert.match(manager, /restoreEditorBatchBackup/u);
  assert.match(service, /restoreEditorBatchBackup\(backupPath/u);
  assert.match(service, /rollback reload failed/u);
  assert.match(manager, /rollbackFailure/u);
  assert.match(manager, /secrets\.yml/u);
  assert.match(manager, /resolves outside the CoreDSC data directory/u);
});

test("local moderation, console and payload boundaries remain independently enforced", () => {
  if (!cloudDirectoryExists) {
    return;
  }
  const routerPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudOperationRouter.java", import.meta.url);
  const moderationPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/cloud/ModerationOperationService.java", import.meta.url);
  const router = existsSync(routerPath) ? readFileSync(routerPath, "utf8") : "";
  const moderation = existsSync(moderationPath) ? readFileSync(moderationPath, "utf8") : "";
  assert.match(router, /HARD_DENIED_COMMAND/u);
  assert.match(router, /remote-execution\.enabled", false/u);
  assert.match(router, /allowlisted-commands/u);
  assert.match(router, /depth > 10 \|\| \+\+nodes\[0\] > 2_000/u);
  assert.match(router, /Secret-bearing field names are rejected by the local agent/u);
  assert.match(moderation, /protectedMinecraftNames/u);
  assert.match(moderation, /protectedMinecraftUuids/u);
  assert.match(moderation, /protectedDiscordIds/u);
  assert.match(moderation, /The Discord guild owner is always protected/u);
  assert.match(moderation, /bot role is not above the target/u);
});

test("optional module failures are isolated and SQLite shutdown drains a bounded queue", () => {
  if (!cloudDirectoryExists) {
    return;
  }
  const modulesPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/module/ModuleManager.java", import.meta.url);
  const sqlitePath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/storage/SQLiteStorage.java", import.meta.url);
  const pluginPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/CoreDSCPlugin.java", import.meta.url);
  const modules = existsSync(modulesPath) ? readFileSync(modulesPath, "utf8") : "";
  const sqlite = existsSync(sqlitePath) ? readFileSync(sqlitePath, "utf8") : "";
  const plugin = existsSync(pluginPath) ? readFileSync(pluginPath, "utf8") : "";
  assert.match(modules, /for \(ModuleSelection selection : selections\)/u);
  assert.match(modules, /catch \(Throwable throwable\)/u);
  assert.match(modules, /statuses\.put\(moduleId, new ModuleStatus\(ModuleState\.FAILED/u);
  assert.match(modules, /Failed to enable module/u);
  assert.match(sqlite, /new ArrayBlockingQueue<>\(queueCapacity, true\)/u);
  assert.match(sqlite, /CoreDSC's SQLite queue is full/u);
  assert.match(sqlite, /state = State\.CLOSING/u);
  assert.match(sqlite, /state == State\.CLOSING[\s\S]{0,120}writeQueue\.isEmpty\(\)/u);
  assert.match(plugin, /shutdownEvent\.get\(DISCORD_SHUTDOWN_EVENT_TIMEOUT_SECONDS, TimeUnit\.SECONDS\)/u);
  assert.match(plugin, /closeAsync\(\)\.get\(STORAGE_SHUTDOWN_TIMEOUT_SECONDS, TimeUnit\.SECONDS\)/u);
  assert.match(plugin, /catch \(TimeoutException timeout\)/u);
});

test("hosted editor replaces the removed loopback WebEditor and bot README is generated", () => {
  if (!pluginYmlExists) {
    return;
  }
  const pluginRoot = new URL("../../plugin/", import.meta.url);
  const moduleManagerPath = new URL("src/main/java/com/hubertstudios/coredsc/module/ModuleManager.java", pluginRoot);
  const configManagerPath = new URL("src/main/java/com/hubertstudios/coredsc/config/ConfigManager.java", pluginRoot);
  const localEditorPath = new URL("src/main/java/com/hubertstudios/coredsc/module/impl/WebEditorModule.java", pluginRoot);
  const localEditorConfigPath = new URL("src/main/resources/modules/web-editor.yml", pluginRoot);
  const botReadmeTemplatePath = new URL("src/main/resources/bot/README.txt", pluginRoot);
  const moduleManager = readFileSync(moduleManagerPath, "utf8");
  const configManager = readFileSync(configManagerPath, "utf8");

  assert.doesNotMatch(pluginYml, /webeditor|coredsc\.webeditor/iu);
  assert.doesNotMatch(moduleManager, /WebEditorModule|modules\.web-editor/u);
  assert.equal(existsSync(localEditorPath), false);
  assert.equal(existsSync(localEditorConfigPath), false);
  assert.equal(existsSync(botReadmeTemplatePath), true);
  assert.match(configManager, /ensureResourceCreated\("bot\/README\.txt", new File\(dataFolder, "bot\/README\.md"\)\)/u);
});


test("bStats module adoption includes the hosted cloud-control module", () => {
  const metricsPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/metrics/MetricsService.java", import.meta.url);
  if (!existsSync(metricsPath)) return;
  const metrics = readFileSync(metricsPath, "utf8");
  assert.match(metrics, /MODULE_IDS = List\.of\([\s\S]{0,240}"cloud-control"/u);
});

test("preset engine is declarative, bounded and rollback-aware", () => {
  assert.match(presetService, /plugins\/CoreDSC\/configs|new File\(plugin\.getDataFolder\(\), "configs"\)/u);
  assert.match(presetService, /editableFilePaths\(\)\.contains\(file\)/u);
  assert.match(presetService, /saveEditorPatch/u);
  assert.match(presetService, /requireReloadOrRestore/u);
  assert.match(presetService, /restoreEditorBatchBackup/u);
  assert.match(presetService, /preserveLocalOverrides/u);
  assert.match(presetService, /Preset package integrity check failed/u);
  assert.doesNotMatch(presetService, /ProcessBuilder|Runtime\.getRuntime\(\)\.exec|ClassLoader|\.jar/u);
});

test("Tickets V2 uses typed dynamic forms, category channels and upgrade-safe persistence", () => {
  const modulePath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/module/impl/TicketModule.java", import.meta.url);
  const settingsPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/ticket/TicketSettings.java", import.meta.url);
  const repositoryPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/storage/TicketRepository.java", import.meta.url);
  const storagePath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/storage/SQLiteStorage.java", import.meta.url);
  const cloudConfigPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudConfigurationService.java", import.meta.url);
  const configPath = new URL("../../plugin/src/main/resources/modules/tickets.yml", import.meta.url);
  for (const path of [modulePath, settingsPath, repositoryPath, storagePath, cloudConfigPath, configPath]) assert.equal(existsSync(path), true);
  const module = readFileSync(modulePath, "utf8");
  const settings = readFileSync(settingsPath, "utf8");
  const repository = readFileSync(repositoryPath, "utf8");
  const storage = readFileSync(storagePath, "utf8");
  const cloudConfig = readFileSync(cloudConfigPath, "utf8");
  const config = readFileSync(configPath, "utf8");

  assert.match(settings, /record TicketType\(/u);
  assert.match(settings, /Discord modals support at most 5/u);
  assert.match(settings, /ChannelMode \{ CHANNEL, THREAD \}/u);
  assert.match(module, /createTextChannel/u);
  assert.match(module, /coredsc:ticket:new:/u);
  assert.match(module, /\/ticket setup|Tickets V2 Setup/u);
  assert.match(module, /EntitySelectMenu/u);
  assert.match(module, /StringSelectMenu/u);
  assert.match(module, /newtype-category/u);
  assert.match(module, /panel-channel/u);
  assert.match(module, /staff:/u);
  assert.match(module, /saveEditorDocument/u);
  assert.match(module, /createTranscript/u);
  assert.match(module, /Message\.Attachment/u);
  assert.match(module, /isUnknownDiscordMessage/u);
  assert.match(module, /Setup configuration rollback failed/u);
  assert.match(module, /runTicketAsync/u);
  assert.match(module, /countOpenByType/u);
  assert.match(module, /contentfor:/u);
  assert.match(module, /typeContentSetupModal/u);
  assert.match(module, /private String prettyForm\(Ticket ticket\)[\s\S]*return TextUtil\.truncate\(ticket\.message\(\), 1_500\);/u);
  const staffReply = module.slice(module.indexOf("private CompletableFuture<Void> staffReply"), module.indexOf("private CompletableFuture<Boolean> closeTicket"));
  assert.ok(staffReply.indexOf('messages.add("TICKET"') < staffReply.indexOf("sendToTicketChannel"),
    "staff replies must be persisted before the outbound Discord send");
  assert.match(repository, /ticket_type/u);
  assert.match(repository, /form_data/u);
  assert.match(storage, /addColumnIfMissing\(connection, "tickets", "ticket_type"/u);
  assert.match(storage, /addColumnIfMissing\(connection, "tickets", "form_data"/u);
  assert.match(cloudConfig, /"roles", roles/u);
  assert.match(cloudConfig, /canInteract/u);
  assert.match(config, /^types:/mu);
  assert.match(config, /^panel:/mu);
  assert.match(config, /subcommands:[\s\S]*setup: setup/u);
});
