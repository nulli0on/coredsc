import assert from "node:assert/strict";
import test from "node:test";

import { requireCsrf } from "../src/database.ts";
import {
  assertTrustedOrigin,
  base64Url,
  csrfTokenFor,
  HttpError,
  secureCookie,
  sha256,
  verifyAgentSignature,
} from "../src/security.ts";
import type { Env, SessionUser } from "../src/types.ts";

const ORIGIN = "https://dashboard.example.test";
const SECRET = "test-cookie-secret-with-at-least-32-bytes";

test("host cookies are first-party, secure and inaccessible to JavaScript", () => {
  const value = secureCookie("__Host-coredsc_session", "token", 3600);
  assert.match(value, /^__Host-coredsc_session=token;/u);
  assert.match(value, /Path=\//u);
  assert.match(value, /HttpOnly/u);
  assert.match(value, /Secure/u);
  assert.match(value, /SameSite=Lax/u);
  assert.doesNotMatch(value, /Domain=/u);
});

test("trusted-origin checks require the exact configured origin", () => {
  const env = { APP_ORIGIN: ORIGIN } as Env;
  assert.doesNotThrow(() => assertTrustedOrigin(new Request(`${ORIGIN}/v1`, { headers: { Origin: ORIGIN } }), env));
  assert.throws(
    () => assertTrustedOrigin(new Request(`${ORIGIN}/v1`, { headers: { Origin: "https://evil.example" } }), env),
    (error: unknown) => error instanceof HttpError && error.status === 403,
  );
});

test("CSRF requires both the session-bound token and exact first-party origin", async () => {
  const sessionId = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa";
  const token = await csrfTokenFor(SECRET, sessionId);
  const user: SessionUser = {
    id: "100000000000000",
    username: "owner",
    displayName: "Owner",
    avatar: null,
    sessionId,
    csrfHash: await sha256(token),
  };
  const env = { APP_ORIGIN: ORIGIN } as Env;
  await requireCsrf(new Request(`${ORIGIN}/v1`, {
    method: "POST",
    headers: { Origin: ORIGIN, "X-CoreDSC-CSRF": token },
  }), env, user);
  await assert.rejects(() => requireCsrf(new Request(`${ORIGIN}/v1`, {
    method: "POST",
    headers: { Origin: ORIGIN, "X-CoreDSC-CSRF": `${token}x` },
  }), env, user), (error: unknown) => error instanceof HttpError && error.status === 403);
  await assert.rejects(() => requireCsrf(new Request(`${ORIGIN}/v1`, {
    method: "POST",
    headers: { Origin: "https://evil.example", "X-CoreDSC-CSRF": token },
  }), env, user), (error: unknown) => error instanceof HttpError && error.status === 403);
});

test("agent Ed25519 signatures bind instance, timestamp and nonce", async () => {
  const pair = await crypto.subtle.generateKey({ name: "Ed25519" }, true, ["sign", "verify"]);
  const instance = "11111111-1111-4111-8111-111111111111";
  const timestamp = "1785686400000";
  const nonce = "test-nonce";
  const canonical = new TextEncoder().encode(`coredsc-agent-v1\n${instance}\n${timestamp}\n${nonce}`);
  const signature = new Uint8Array(await crypto.subtle.sign({ name: "Ed25519" }, pair.privateKey, canonical));
  const publicKey = new Uint8Array(await crypto.subtle.exportKey("spki", pair.publicKey));
  assert.equal(await verifyAgentSignature(instance, timestamp, nonce, base64Url(publicKey), base64Url(signature)), true);
  assert.equal(await verifyAgentSignature(instance, timestamp, `${nonce}-changed`, base64Url(publicKey), base64Url(signature)), false);
});
