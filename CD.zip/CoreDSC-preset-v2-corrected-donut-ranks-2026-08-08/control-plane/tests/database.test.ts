import assert from "node:assert/strict";
import test from "node:test";
import { DatabaseSync, type StatementSync } from "node:sqlite";

import { enforceRateLimit, readBytes, readJson, safeText, uuid } from "../src/database.ts";
import { HttpError } from "../src/security.ts";

class SqliteStatement {
  private values: unknown[] = [];
  private readonly statement: StatementSync;
  constructor(statement: StatementSync) { this.statement = statement; }
  bind(...values: unknown[]): SqliteStatement { this.values = values; return this; }
  async first<T>(): Promise<T | null> { return (this.statement.get(...this.values) as T | undefined) ?? null; }
  async run<T>(): Promise<{ results: T[]; success: boolean; meta: { changes: number } }> {
    const result = this.statement.run(...this.values);
    return { results: [], success: true, meta: { changes: Number(result.changes) } };
  }
  async all<T>(): Promise<{ results: T[]; success: boolean; meta: { changes: number } }> {
    return { results: this.statement.all(...this.values) as T[], success: true, meta: { changes: 0 } };
  }
}

class SqliteD1 {
  private readonly db: DatabaseSync;
  constructor(db: DatabaseSync) { this.db = db; }
  prepare(query: string): SqliteStatement { return new SqliteStatement(this.db.prepare(query)); }
}

test("request parsing rejects non-JSON, malformed JSON and payload overflow", async () => {
  await assert.rejects(() => readJson(new Request("https://test.invalid", { method: "POST", body: "{}" })),
    (error: unknown) => error instanceof HttpError && error.status === 415);
  await assert.rejects(() => readJson(new Request("https://test.invalid", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: "{" }),
  ), (error: unknown) => error instanceof HttpError && error.status === 400);
  await assert.rejects(() => readJson(new Request("https://test.invalid", {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ value: "x".repeat(100) }),
  }), 32), (error: unknown) => error instanceof HttpError && error.status === 413);
});

test("JSON parsing streams bounded chunked bodies and rejects invalid UTF-8", async () => {
  let cancelled = false;
  const oversized = new Request("https://test.invalid", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(new TextEncoder().encode('{"value":"'));
        controller.enqueue(new TextEncoder().encode("x".repeat(64)));
      },
      cancel() { cancelled = true; },
    }),
    duplex: "half",
  } as RequestInit);
  await assert.rejects(() => readJson(oversized, 16),
    (error: unknown) => error instanceof HttpError && error.status === 413);
  assert.equal(cancelled, true);

  const invalidUtf8 = new Request("https://test.invalid", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: new Uint8Array([0x7b, 0x22, 0x78, 0x22, 0x3a, 0xff, 0x7d]),
  });
  await assert.rejects(() => readJson(invalidUtf8),
    (error: unknown) => error instanceof HttpError && error.status === 400
      && /UTF-8/u.test(error.message));
});

test("safe text and UUID validation reject control characters and malformed identifiers", () => {
  assert.equal(safeText("  ok  ", 10, "field", true), "ok");
  assert.throws(() => safeText("bad\nvalue", 20, "field"), (error: unknown) => error instanceof HttpError && error.status === 400);
  assert.equal(uuid("11111111-1111-4111-8111-111111111111", "id"), "11111111-1111-4111-8111-111111111111");
  assert.throws(() => uuid("not-a-uuid", "id"), (error: unknown) => error instanceof HttpError && error.status === 400);
});

test("rate limiting persists by scope, identity and client address", async () => {
  const db = new DatabaseSync(":memory:");
  db.exec(`CREATE TABLE rate_limits (bucket TEXT NOT NULL, window_start INTEGER NOT NULL,
    request_count INTEGER NOT NULL, expires_at INTEGER NOT NULL, PRIMARY KEY(bucket,window_start));`);
  const env = { COREDSC_DB: new SqliteD1(db) } as never;
  const request = new Request("https://test.invalid", { headers: { "CF-Connecting-IP": "203.0.113.10" } });
  await enforceRateLimit(request, env, "operation", "user-1", 2, 60_000);
  await enforceRateLimit(request, env, "operation", "user-1", 2, 60_000);
  await assert.rejects(() => enforceRateLimit(request, env, "operation", "user-1", 2, 60_000),
    (error: unknown) => error instanceof HttpError && error.status === 429);
  await enforceRateLimit(request, env, "operation", "user-2", 2, 60_000);
  await enforceRateLimit(new Request("https://test.invalid", { headers: { "CF-Connecting-IP": "203.0.113.11" } }),
    env, "operation", "user-1", 2, 60_000);
  db.close();
});


test("bounded byte reads stop chunked bodies before unbounded buffering", async () => {
  const exact = new Request("https://example.test/upload", {
    method: "POST",
    body: new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(new Uint8Array([1, 2]));
        controller.enqueue(new Uint8Array([3, 4]));
        controller.close();
      },
    }),
    duplex: "half",
  } as RequestInit);
  assert.deepEqual([...await readBytes(exact, 4)], [1, 2, 3, 4]);

  let cancelled = false;
  const oversized = new Request("https://example.test/upload", {
    method: "POST",
    body: new ReadableStream<Uint8Array>({
      start(controller) {
        controller.enqueue(new Uint8Array([1, 2, 3]));
        controller.enqueue(new Uint8Array([4, 5, 6]));
      },
      cancel() { cancelled = true; },
    }),
    duplex: "half",
  } as RequestInit);
  await assert.rejects(() => readBytes(oversized, 4), /Request is too large/u);
  assert.equal(cancelled, true);
});
