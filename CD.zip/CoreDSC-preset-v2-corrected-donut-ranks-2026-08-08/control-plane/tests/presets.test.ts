import assert from "node:assert/strict";
import test from "node:test";
import { readFileSync } from "node:fs";

import { getPreset, listPresets, packagePayload, publicPreset, sha256Hex } from "../src/presets.ts";

test("official preset registry publishes a verified DonutSMP acquisition preset", () => {
  const presets = listPresets();
  const donut = presets.find((item) => item.id === "donutsmp");
  assert.ok(donut);
  assert.equal(donut.verified, true);
  assert.match(String(donut.packageUrl), /^\/v1\/presets\/donutsmp\/package$/u);
  assert.ok(Array.isArray(donut.requiredVariables));
});

test("preset package is declarative, allowlisted and content-addressed", async () => {
  const preset = getPreset("donutsmp");
  const payload = packagePayload(preset);
  const parsed = JSON.parse(payload) as { changes: { file: string; path: string; value: unknown }[] };
  assert.ok(parsed.changes.length > 0);
  for (const change of parsed.changes) {
    assert.match(change.file, /^(?:config\.yml|modules\/[a-z0-9-]+\.yml)$/u);
    assert.doesNotMatch(change.file, /\.\.|\\|^\//u);
    assert.ok(change.path.length > 0);
    assert.deepEqual(Object.keys(change).sort(), ["file", "path", "value"]);
  }
  const hash = await sha256Hex(payload);
  assert.match(hash, /^[0-9a-f]{64}$/u);
  assert.equal(hash, await sha256Hex(payload));
});

test("unknown and malformed preset IDs fail closed", () => {
  assert.throws(() => getPreset("../evil"));
  assert.throws(() => getPreset("unknown"));
  assert.equal(publicPreset(getPreset("donutsmp")).available, true);
});

test("DonutSMP preset 0.4 composes bootstrap resources and keeps Discord levels separate from in-game ranks", () => {
  const preset = getPreset("donutsmp");
  const parsed = JSON.parse(packagePayload(preset)) as {
    version: string;
    requiredVariables: { key: string; type: string; required: boolean }[];
    changes: { file: string; path: string; value: unknown }[];
  };
  assert.equal(parsed.version, "0.4.0");
  assert.equal(parsed.requiredVariables.length <= 128, true);
  assert.ok(parsed.requiredVariables.some((item) => item.key === "guild-id" && item.required));
  assert.ok(parsed.requiredVariables.some((item) => item.key === "ban-appeal-category-id" && !item.required));
  assert.ok(parsed.requiredVariables.some((item) => item.key === "self-platform-pc-enabled" && item.required));
  assert.ok(parsed.changes.some((change) => change.file === "modules/tickets.yml" && change.path === "panel.channel-id"));
  const types = parsed.changes.find((change) => change.file === "modules/tickets.yml" && change.path === "types")?.value as Record<string, unknown>;
  assert.deepEqual(Object.keys(types), ["ban-appeal", "bug-report", "media-rank", "other"]);
  assert.ok(parsed.changes.some((change) => change.file === "modules/link.yml" && change.path === "code-direction" && change.value === "DISCORD_TO_MINECRAFT"));
  assert.ok(parsed.changes.some((change) => change.file === "modules/self-roles.yml" && change.path === "panels"));
  assert.ok(parsed.changes.some((change) => change.file === "modules/discord-levels.yml" && change.path === "roles.milestones"));
  assert.equal(parsed.changes.some((change) => change.file === "modules/luckperms-sync.yml"), false);
});


test("downloadable DonutSMP descriptor uses format-2 bootstrap choices instead of a flat snowflake wall", () => {
  const descriptorUrl = new URL("../../examples/presets/donutsmp.yml", import.meta.url);
  const descriptor = readFileSync(descriptorUrl, "utf8");
  assert.match(descriptor, /^format: 2$/mu);
  assert.match(descriptor, /^  id: donutsmp$/mu);
  assert.match(descriptor, /^  roles-mode: CREATE_MISSING$/mu);
  assert.match(descriptor, /^  channels-mode: CREATE_MISSING$/mu);
  assert.match(descriptor, /^  categories-mode: CREATE_MISSING$/mu);
  assert.doesNotMatch(descriptor, /^  rollback-before-apply:/mu);
  assert.match(descriptor, /always creates an immutable rollback snapshot/u);
  assert.match(descriptor, /^  require-preview: true$/mu);
  assert.match(descriptor, /Owner, Manager, Dev, Sr Admin, Admin, Sr Mod, Mod, Sr Helper, Helper, Media, DonutPlus/u);
  assert.doesNotMatch(descriptor, /^  ranks:/mu);
  assert.match(descriptor, /These groups are NOT connected to Affiliate\/General\/Official/u);
  assert.doesNotMatch(descriptor, /^\s{2}level-80-role-id:/mu);
});
