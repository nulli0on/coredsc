import assert from "node:assert/strict";
import test from "node:test";

import { allCapabilities, lookupOperationCapability, operationNeedsApproval, roleHas } from "../src/policy.ts";
import { MAX_MEDIA_BYTES, validateMediaBytes } from "../src/media.ts";
import {
  canonicalJson,
  dispatchLeaseExpired,
  networkRolloutKey,
  operationFingerprintInput,
  retryableResult,
  utf8ByteLength,
} from "../src/reliability.ts";

test("role capabilities stay least-privilege", () => {
  assert.equal(roleHas("OWNER", "console.execute"), true);
  assert.equal(roleHas("SERVER_ADMIN", "console.execute"), false);
  assert.equal(roleHas("MODERATOR", "moderation.manage"), true);
  assert.equal(roleHas("MODERATOR", "case.manage"), true);
  assert.equal(roleHas("CONSOLE_VIEWER", "console.execute"), false);
  assert.equal(roleHas("CONSOLE_OPERATOR", "console.execute"), true);
  assert.equal(roleHas("SUPPORT", "config.edit"), false);
  assert.equal(roleHas("SUPPORT", "case.manage"), true);
  assert.equal(roleHas("SUPPORT", "moderation.manage"), false);
  assert.equal(roleHas("VIEWER", "channel.manage"), false);
  assert.equal(roleHas("VIEWER", "preset.view"), true);
  assert.equal(roleHas("VIEWER", "preset.manage"), false);
  assert.equal(roleHas("SERVER_ADMIN", "preset.manage"), true);
  assert.equal(roleHas("SUPPORT", "ticket.manage"), true);
  assert.equal(roleHas("VIEWER", "ticket.view"), true);
  assert.equal(roleHas("VIEWER", "ticket.manage"), false);
});

test("all hosted staff roles have the documented exact capability matrix", () => {
  const expected = {
    OWNER: ["*"],
    SERVER_ADMIN: [
      "approval.decide", "approval.view", "automod.manage", "automod.view", "case.manage",
      "channel.manage", "channel.view", "config.apply", "config.edit", "config.view", "console.view",
      "event.manage", "event.view", "incident.manage", "incident.view", "maintenance.manage",
      "maintenance.view", "moderation.manage", "moderation.view", "network.manage", "network.view",
      "preset.manage", "preset.view", "server.manage", "server.view", "staff.view", "ticket.manage", "ticket.view",
    ],
    MODERATOR: [
      "approval.view", "case.manage", "channel.manage", "channel.view", "console.view",
      "incident.manage", "incident.view", "moderation.manage", "moderation.view", "server.view", "ticket.manage", "ticket.view",
    ],
    CONSOLE_VIEWER: ["console.view", "incident.view", "server.view"],
    CONSOLE_OPERATOR: ["console.execute", "console.view", "incident.view", "maintenance.view", "server.view"],
    SUPPORT: ["case.manage", "moderation.view", "server.view", "ticket.manage", "ticket.view"],
    VIEWER: ["channel.view", "config.view", "incident.view", "moderation.view", "preset.view", "server.view", "ticket.view"],
  } as const;
  for (const [role, capabilities] of Object.entries(expected)) {
    assert.deepEqual(allCapabilities(role as keyof typeof expected), [...capabilities].sort(), role);
  }
});

test("read-only and specialist roles cannot cross privilege boundaries", () => {
  for (const role of ["CONSOLE_VIEWER", "SUPPORT", "VIEWER"] as const) {
    assert.equal(roleHas(role, "config.apply"), false, `${role} config.apply`);
    assert.equal(roleHas(role, "channel.manage"), false, `${role} channel.manage`);
    assert.equal(roleHas(role, "console.execute"), false, `${role} console.execute`);
  }
  assert.equal(roleHas("CONSOLE_OPERATOR", "moderation.manage"), false);
  assert.equal(roleHas("MODERATOR", "maintenance.manage"), false);
  assert.equal(roleHas("SERVER_ADMIN", "console.execute"), false);
});

test("case notes are separate from sanction authority", () => {
  assert.equal(lookupOperationCapability("moderation.note"), "case.manage");
  assert.equal(lookupOperationCapability("moderation.history"), "moderation.view");
  assert.equal(lookupOperationCapability("moderation.ban"), "moderation.manage");
});

test("dangerous operations require second-person approval", () => {
  assert.equal(operationNeedsApproval("channel.purge", { count: 1 }), true);
  assert.equal(operationNeedsApproval("console.execute", { command: "list" }), true);
  assert.equal(operationNeedsApproval("network.template.apply", {}), true);
  assert.equal(operationNeedsApproval("moderation.ban", { duration: "permanent" }), true);
  assert.equal(operationNeedsApproval("moderation.ban", { duration: "7d" }), false);
  assert.equal(operationNeedsApproval("incident.start", { scope: "network" }), true);
  assert.equal(operationNeedsApproval("incident.start", { scope: "server" }), false);
});

test("network rollout keys distinguish new rollouts but remain retry-stable", () => {
  const instance = "11111111-1111-4111-8111-111111111111";
  assert.equal(networkRolloutKey("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", instance),
    networkRolloutKey("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", instance));
  assert.notEqual(networkRolloutKey("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", instance),
    networkRolloutKey("bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb", instance));
});

test("dispatch lease and retryability are explicit", () => {
  const now = 1_000_000;
  assert.equal(dispatchLeaseExpired(now - 119_999, now), false);
  assert.equal(dispatchLeaseExpired(now - 120_000, now), true);
  assert.equal(dispatchLeaseExpired(null, now), true);
  assert.equal(retryableResult({ error: { retryable: true } }), true);
  assert.equal(retryableResult({ error: { retryable: false } }), false);
  assert.equal(retryableResult({ ok: true }), false);
});

test("payload byte counting uses UTF-8 bytes rather than JavaScript characters", () => {
  assert.equal(utf8ByteLength("abc"), 3);
  assert.equal(utf8ByteLength("€"), 3);
  assert.equal(utf8ByteLength("😀"), 4);
});

test("media validation checks declared type, magic and bounds", () => {
  const png = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0]);
  assert.deepEqual(validateMediaBytes(png, "image/png"), { mimeType: "image/png", extension: "png" });
  assert.throws(() => validateMediaBytes(png, "image/jpeg"), /do not match/u);
  assert.throws(() => validateMediaBytes(new Uint8Array(), "image/png"), /empty/u);
  const maximumPng = new Uint8Array(MAX_MEDIA_BYTES);
  maximumPng.set(png.subarray(0, 8));
  assert.deepEqual(validateMediaBytes(maximumPng, "image/png"), { mimeType: "image/png", extension: "png" });
  assert.throws(() => validateMediaBytes(new Uint8Array(MAX_MEDIA_BYTES + 1), "image/png"), /exceeds/u);
  assert.deepEqual(validateMediaBytes(new Uint8Array([0xff, 0xd8, 0, 0xff, 0xd9]), "image/jpeg"),
    { mimeType: "image/jpeg", extension: "jpg" });
  assert.deepEqual(validateMediaBytes(new TextEncoder().encode("GIF89a"), "image/gif"),
    { mimeType: "image/gif", extension: "gif" });
  assert.deepEqual(validateMediaBytes(new Uint8Array([
    0x52, 0x49, 0x46, 0x46, 0, 0, 0, 0, 0x57, 0x45, 0x42, 0x50,
  ]), "image/webp"), { mimeType: "image/webp", extension: "webp" });
  assert.throws(() => validateMediaBytes(png, "image/svg+xml"), /Only PNG/u);
});

test("idempotency fingerprints are stable across object key order and bind the reason", () => {
  assert.equal(canonicalJson({ b: 2, a: 1 }), canonicalJson({ a: 1, b: 2 }));
  assert.equal(
    operationFingerprintInput("config.patch", { changes: [{ value: true, path: "x" }] }, "reason"),
    operationFingerprintInput("config.patch", { changes: [{ path: "x", value: true }] }, "reason"),
  );
  assert.notEqual(
    operationFingerprintInput("config.patch", { changes: [] }, "first"),
    operationFingerprintInput("config.patch", { changes: [] }, "second"),
  );
});
