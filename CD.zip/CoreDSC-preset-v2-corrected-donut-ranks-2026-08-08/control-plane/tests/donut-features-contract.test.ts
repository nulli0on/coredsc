import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const source = (path: string) => readFileSync(new URL(`../../${path}`, import.meta.url), "utf8");

test("Discord-first verification remains directional, single-use and role-compatible", () => {
  const link = source("plugin/src/main/java/com/hubertstudios/coredsc/module/impl/LinkModule.java");
  const pending = source("plugin/src/main/java/com/hubertstudios/coredsc/storage/PendingLinkCodeRepository.java");
  const config = source("plugin/src/main/resources/modules/link.yml");
  assert.match(link, /DISCORD_TO_MINECRAFT/u);
  assert.match(link, /issueDiscordCode\(event\.getUser\(\)\.getId\(\)/u);
  assert.match(link, /consumeDiscordCodeFromMinecraft/u);
  assert.match(link, /assignConfiguredRole\(null, null, account\.discordUserId\(\)\)/u);
  assert.match(pending, /direction, expires_at/u);
  assert.match(pending, /LinkStatus\.WRONG_DIRECTION/u);
  assert.match(pending, /DELETE FROM pending_link_codes WHERE code = \?/u);
  assert.match(config, /^code-direction: MINECRAFT_TO_DISCORD$/mu);
});

test("self-role panels are typed, hierarchy-safe and retire stale Discord components", () => {
  const module = source("plugin/src/main/java/com/hubertstudios/coredsc/module/impl/SelfRoleModule.java");
  const settings = source("plugin/src/main/java/com/hubertstudios/coredsc/selfrole/SelfRoleSettings.java");
  const repository = source("plugin/src/main/java/com/hubertstudios/coredsc/storage/SelfRolePanelRepository.java");
  assert.match(settings, /enum SelectionMode \{ SINGLE, MULTIPLE \}/u);
  assert.match(settings, /rawGroups\.size\(\) > 5/u);
  assert.match(settings, /rawOptions\.size\(\) > 25/u);
  assert.match(module, /Permission\.MANAGE_ROLES/u);
  assert.match(module, /canInteract\(role\)/u);
  assert.match(module, /editMessageComponents\(List\.of\(\)\)/u);
  assert.match(module, /retirePanelMessage/u);
  assert.match(repository, /CompletableFuture<List<PanelMessage>> findAll\(\)/u);
});

test("Discord activity XP is persistent and cannot be farmed faster than the configured window", () => {
  const module = source("plugin/src/main/java/com/hubertstudios/coredsc/module/impl/DiscordLevelsModule.java");
  const repository = source("plugin/src/main/java/com/hubertstudios/coredsc/storage/DiscordLevelRepository.java");
  const settings = source("plugin/src/main/java/com/hubertstudios/coredsc/levels/DiscordLevelSettings.java");
  assert.match(repository, /now - existing\.lastXpAt\(\) < minimumWindowMillis/u);
  assert.match(repository, /ON CONFLICT\(discord_user_id\) DO UPDATE/u);
  assert.match(module, /event\.getAuthor\(\)\.isBot\(\) \|\| event\.isWebhookMessage\(\)/u);
  assert.match(module, /reconcileRoles\(member, result\.after\(\)\.level\(\)\)/u);
  assert.match(module, /onGuildMemberJoin/u);
  assert.match(settings, /HIGHEST_ONLY, CUMULATIVE/u);
  assert.match(settings, /xpForLevel/u);
});

test("new Donut feature modules are part of config validation, runtime registration and SQLite schema", () => {
  const manager = source("plugin/src/main/java/com/hubertstudios/coredsc/config/ConfigManager.java");
  const modules = source("plugin/src/main/java/com/hubertstudios/coredsc/module/ModuleManager.java");
  const sqlite = source("plugin/src/main/java/com/hubertstudios/coredsc/storage/SQLiteStorage.java");
  assert.match(manager, /"self-roles", "discord-levels"/u);
  assert.match(manager, /SelfRoleSettings\.from\(merged\)/u);
  assert.match(manager, /DiscordLevelSettings\.from\(merged\)/u);
  assert.match(modules, /new SelfRoleModule\(plugin\)/u);
  assert.match(modules, /new DiscordLevelsModule\(plugin\)/u);
  assert.match(sqlite, /SCHEMA_VERSION = 14/u);
  assert.match(sqlite, /CREATE TABLE IF NOT EXISTS self_role_panels/u);
  assert.match(sqlite, /CREATE TABLE IF NOT EXISTS discord_levels/u);
  assert.match(sqlite, /idx_discord_levels_xp/u);
});

test("Donut preset exposes all level milestones and all four role-selector groups", () => {
  const preset = source("control-plane/src/presets.ts");
  for (const level of [1, 3, 5, 10, 20, 30, 40, 50, 60, 70, 80]) {
    assert.match(preset, new RegExp(`level-${level}-role-id`, "u"));
  }
  for (const group of ["platform", "age", "region", "notifications"]) {
    assert.match(preset, new RegExp(`id: \"${group}\"`, "u"));
  }
  assert.match(preset, /version: "0\.4\.0"/u);
});

test("published self-role and ticket components reject stale message surfaces", () => {
  const selfRoles = source("plugin/src/main/java/com/hubertstudios/coredsc/module/impl/SelfRoleModule.java");
  const tickets = source("plugin/src/main/java/com/hubertstudios/coredsc/module/impl/TicketModule.java");
  assert.match(selfRoles, /repository\.find\(panelId\)/u);
  assert.match(selfRoles, /event\.getMessageIdLong\(\)/u);
  assert.match(selfRoles, /stored\.get\(\)\.messageId\(\)\.equals\(messageId\)/u);
  assert.match(tickets, /event\.getMessageIdLong\(\) != panel\.messageId\(\)/u);
  assert.match(tickets, /event\.getChannel\(\)\.getIdLong\(\) != panel\.channelId\(\)/u);
});

test("level leaderboard uses the same tie ranking semantics as individual rank", () => {
  const repository = source("plugin/src/main/java/com/hubertstudios/coredsc/storage/DiscordLevelRepository.java");
  assert.match(repository, /state\.xp\(\) != previousXp/u);
  assert.match(repository, /rank = row/u);
  assert.match(repository, /WHERE xp > \?/u);
});

test("already-linked Discord verification repairs the configured role without relinking", () => {
  const link = source("plugin/src/main/java/com/hubertstudios/coredsc/module/impl/LinkModule.java");
  assert.match(link, /IssueStatus\.ALREADY_LINKED[\s\S]*assignConfiguredRole\(event\.getGuild\(\), event\.getMember\(\), event\.getUser\(\)\.getId\(\)\)/u);
  assert.match(link, /Permission\.MANAGE_ROLES/u);
  assert.match(link, /member\.getRoles\(\)\.contains\(role\)/u);
});

test("preset ownership and marketplace descriptors use atomic durable YAML replacement", () => {
  const presets = source("plugin/src/main/java/com/hubertstudios/coredsc/service/PresetService.java");
  assert.match(presets, /saveYamlAtomic\(state, stateFile\)/u);
  assert.match(presets, /FileChannel\.open\(temporary, StandardOpenOption\.WRITE\)/u);
  assert.match(presets, /channel\.force\(true\)/u);
  assert.match(presets, /StandardCopyOption\.ATOMIC_MOVE/u);
});

test("Discord levels ignore direct messages before accessing guild state", () => {
  const module = source("plugin/src/main/java/com/hubertstudios/coredsc/module/impl/DiscordLevelsModule.java");
  assert.match(module, /repository == null \|\| !event\.isFromGuild\(\)[\s\S]*event\.getGuild\(\)\.getIdLong\(\)/u);
});

test("Donut Tickets V2 can publish its panel automatically after Discord becomes ready", () => {
  const settings = source("plugin/src/main/java/com/hubertstudios/coredsc/ticket/TicketSettings.java");
  const module = source("plugin/src/main/java/com/hubertstudios/coredsc/module/impl/TicketModule.java");
  const defaults = source("plugin/src/main/resources/modules/tickets.yml");
  const preset = source("control-plane/src/presets.ts");
  assert.match(settings, /boolean publishOnStartup/u);
  assert.match(module, /onDiscordReady\(DiscordReadyEvent/u);
  assert.match(module, /panel\(\)\.publishOnStartup\(\)/u);
  assert.match(module, /panelPublishing\.compareAndSet\(false, true\)/u);
  assert.match(defaults, /publish-on-startup: false/u);
  assert.match(preset, /panel\.publish-on-startup", value: true/u);
});
