import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

const source = (path: string) => readFileSync(new URL(`../../${path}`, import.meta.url), "utf8");

test("global rollback snapshots are confirmation-gated and include preset operation state", () => {
  const rollback = source("plugin/src/main/java/com/hubertstudios/coredsc/service/RollbackService.java");
  const plugin = source("plugin/src/main/java/com/hubertstudios/coredsc/CoreDSCPlugin.java");
  const yml = source("plugin/src/main/resources/plugin.yml");
  assert.match(rollback, /CONFIRMATION_TTL_MILLIS\s*=\s*60_000L/u);
  assert.match(rollback, /SecureRandom/u);
  assert.match(rollback, /CONFIRMATION_RANDOM\.nextInt/u);
  assert.match(rollback, /createSnapshot\("before-rollback"/u);
  assert.match(rollback, /planExternalRollback/u);
  assert.match(rollback, /executeExternalRollback/u);
  assert.match(rollback, /externalResourcesToRemove/u);
  assert.match(rollback, /state\/preset-operations\.yml/u);
  assert.match(rollback, /channel\.force\(true\)/u);
  assert.match(rollback, /ATOMIC_MOVE/u);
  assert.match(plugin, /case "rollback"/u);
  assert.match(plugin, /case "confirm"/u);
  assert.match(plugin, /requestRestore\(sender\.getName\(\), args\[2\]\)/u);
  assert.match(plugin, /confirmRestoreAsync\(sender\.getName\(\), args\[1\]\)/u);
  assert.match(yml, /coredsc\.rollback:/u);
});

test("preset v2 supports enable preview apply repair and durable operation journaling", () => {
  const presets = source("plugin/src/main/java/com/hubertstudios/coredsc/service/PresetService.java");
  const plugin = source("plugin/src/main/java/com/hubertstudios/coredsc/CoreDSCPlugin.java");
  assert.match(presets, /public CompletableFuture<Map<String, Object>> enable/u);
  assert.match(presets, /public CompletableFuture<Map<String, Object>> preview/u);
  assert.match(presets, /public CompletableFuture<Map<String, Object>> apply/u);
  assert.match(presets, /public CompletableFuture<Map<String, Object>> repair/u);
  assert.match(presets, /state\/preset-operations\.yml/u);
  assert.match(presets, /beginOperation/u);
  assert.match(presets, /finishOperation/u);
  assert.match(presets, /status", "RUNNING"/u);
  assert.match(presets, /yaml\.getString\("preset\.id", fallback\)/u);
  assert.match(presets, /saveYamlAtomic\(journal, journalFile\)/u);
  assert.match(presets, /setupMode/u);
  assert.match(presets, /uses descriptor setup/u);
  assert.match(plugin, /case "repair"[\s\S]{0,350}presets\.repair/u);
});

test("bootstrap is bounded idempotent and tracks created versus reused Discord resources", () => {
  const bootstrap = source("plugin/src/main/java/com/hubertstudios/coredsc/service/PresetBootstrapService.java");
  assert.match(bootstrap, /MAXIMUM_RESOURCES\s*=\s*100/u);
  assert.match(bootstrap, /CREATE_MISSING,[\s\S]{0,80}USE_EXISTING,[\s\S]{0,80}DISABLED/u);
  assert.match(bootstrap, /managedReference\(context, "role", logicalId\)/u);
  assert.match(bootstrap, /managedReference\(context, "category", logicalId\)/u);
  assert.match(bootstrap, /managedReference\(context, "channel", logicalId\)/u);
  assert.match(bootstrap, /context\.detectByName && mode == ResourceMode\.CREATE_MISSING/u);
  assert.match(bootstrap, /context\.conflicts\.add\(conflict\)/u);
  assert.match(bootstrap, /createdExternalResources/u);
  assert.match(bootstrap, /executeExternalRollback/u);
  assert.doesNotMatch(bootstrap, /features\.ingame-ranks requires features\.discord-levels/u);
  assert.match(bootstrap, /DONUT_INGAME_RANK_GROUPS/u);
  assert.match(bootstrap, /ownership == Ownership\.CREATED \? " \(managed\)"/u);
  assert.match(bootstrap, /rollbackCreatedResources/u);
  assert.match(bootstrap, /Preserve ownership records for resources that are temporarily disabled/u);
  assert.match(bootstrap, /channel\.force\(true\)/u);
});

test("Donut bootstrap configures safe channel access role order and managed information messages", () => {
  const bootstrap = source("plugin/src/main/java/com/hubertstudios/coredsc/service/PresetBootstrapService.java");
  const descriptor = source("examples/presets/donutsmp.yml");
  assert.match(bootstrap, /configureManagedRoleOrder/u);
  assert.match(bootstrap, /modifyRolePositions\(\)/u);
  assert.match(bootstrap, /moveBelow\(previous\)/u);
  assert.match(bootstrap, /upsertPermissionOverride\(context\.guild\.getSelfMember\(\)\)/u);
  assert.match(bootstrap, /publishManagedMessage\(context, "role-info"/u);
  assert.match(bootstrap, /publishManagedMessage\(context, "media-rank-info"/u);
  assert.match(bootstrap, /publishManagedMessage\(context, "how-to-join"/u);
  assert.match(bootstrap, /retrieveMessageById/u);
  assert.match(bootstrap, /editMessage\(content\)/u);
  assert.match(descriptor, /configure-role-order: true/u);
  assert.doesNotMatch(descriptor, /configure-existing-role-order:/u);
  assert.doesNotMatch(descriptor, /configure-existing-permissions:/u);
});

test("Donut in-game ranks use the supplied LuckPerms rank export and remain independent from Discord levels", () => {
  const bootstrap = source("plugin/src/main/java/com/hubertstudios/coredsc/service/PresetBootstrapService.java");
  const descriptor = source("examples/presets/donutsmp.yml");
  const template = source("plugin/src/main/resources/presets/donutsmp-luckperms-ranks.json");
  assert.match(bootstrap, /LuckPermsProvider/u);
  assert.match(bootstrap, /createAndLoadGroup/u);
  assert.match(bootstrap, /donutsmp-luckperms-ranks\.json/u);
  assert.match(bootstrap, /Node\.builder\(spec\.key\(\)\)\.value\(spec\.value\(\)\)\.build\(\)/u);
  assert.match(bootstrap, /Map\.entry\("dev", "developer"\)/u);
  assert.match(bootstrap, /Map\.entry\("donut-plus", "donut\+"\)/u);
  assert.match(template, /"owner"/u);
  assert.match(template, /"manager"/u);
  assert.match(template, /"developer"/u);
  assert.match(template, /"sradmin"/u);
  assert.match(template, /"srmod"/u);
  assert.match(template, /"srhelper"/u);
  assert.match(template, /"media"/u);
  assert.match(template, /"donut\+"/u);
  assert.match(template, /prefix\.100\.&#00ADFC&lOWNER/u);
  assert.match(template, /weight\.150/u);
  assert.match(descriptor, /Discord-only activity levels/u);
  assert.match(descriptor, /Minecraft-only DonutRanks/u);
  assert.doesNotMatch(descriptor, /donut_affiliate/u);
});

test("Donut format-2 descriptor exposes only implemented safety controls", () => {
  const descriptor = source("examples/presets/donutsmp.yml");
  assert.doesNotMatch(descriptor, /require-confirmation:/u);
  assert.doesNotMatch(descriptor, /rollback-before-apply:/u);
  assert.doesNotMatch(descriptor, /rollback-on-failure:/u);
  assert.match(descriptor, /always creates an immutable rollback snapshot/u);
  assert.match(descriptor, /require-preview: true/u);
});

test("preset preview exposes unresolved existing-resource conflicts and apply fails closed before mutation", () => {
  const bootstrap = source("plugin/src/main/java/com/hubertstudios/coredsc/service/PresetBootstrapService.java");
  const presets = source("plugin/src/main/java/com/hubertstudios/coredsc/service/PresetService.java");
  const dashboard = source("app/dashboard/[serverId]/page.tsx");
  assert.match(bootstrap, /BootstrapResult preflight = resolve\(descriptor, false\)/u);
  assert.match(bootstrap, /if \(!preflight\.conflicts\(\)\.isEmpty\(\)\)/u);
  assert.match(bootstrap, /explicitly reuse it by setting/u);
  assert.match(presets, /result\.put\("conflicts", bootstrap\.conflicts\(\)\)/u);
  assert.match(presets, /result\.put\("ready", bootstrap\.conflicts\(\)\.isEmpty\(\)\)/u);
  assert.match(presets, /if \(!Boolean\.TRUE\.equals\(preview\.get\("ready"\)\)\)/u);
  assert.match(dashboard, /Needs your input/u);
});

test("compact Donut descriptor existing-role paths match bootstrap lookup paths", () => {
  const bootstrap = source("plugin/src/main/java/com/hubertstudios/coredsc/service/PresetBootstrapService.java");
  const descriptor = source("examples/presets/donutsmp.yml");
  assert.match(descriptor, /levels: \{ 1: "", 3: ""/u);
  assert.match(descriptor, /platform: \{ pc: "", xbox: ""/u);
  assert.match(descriptor, /notifications: \{ news-pings: ""/u);
  assert.match(bootstrap, /"existing\.roles\.levels\." \+ level/u);
  assert.match(bootstrap, /"existing\.roles\." \+ entry\.getKey\(\)/u);
});

test("successful preset apply is not unwound solely because operation-journal finalization fails", () => {
  const presets = source("plugin/src/main/java/com/hubertstudios/coredsc/service/PresetService.java");
  assert.match(presets, /try \{\s*finishOperation\(operationId, "SUCCESS"/u);
  assert.match(presets, /catch \(Throwable journalFailure\)[\s\S]{0,500}combined\.put\("journalWarning"/u);
  assert.match(presets, /Preset applied successfully, but the operation journal could not be finalized/u);
});

test("Donut descriptor does not create an empty STATS category by default", () => {
  const bootstrap = source("plugin/src/main/java/com/hubertstudios/coredsc/service/PresetBootstrapService.java");
  const descriptor = source("examples/presets/donutsmp.yml");
  assert.match(bootstrap, /case "stats" -> context\.yaml\.getBoolean\("create\.categories\.stats", false\)/u);
  assert.doesNotMatch(descriptor, /stats:\s*true/u);
});
