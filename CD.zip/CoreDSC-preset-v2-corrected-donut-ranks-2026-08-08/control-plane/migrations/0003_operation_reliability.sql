PRAGMA foreign_keys = ON;

ALTER TABLE audit_events ADD COLUMN attempted_at INTEGER;
UPDATE audit_events SET attempted_at = COALESCE(completed_at, created_at) WHERE attempted_at IS NULL;

ALTER TABLE approvals ADD COLUMN execution_started_at INTEGER;
ALTER TABLE approvals ADD COLUMN attempt_count INTEGER NOT NULL DEFAULT 0;

-- Preserve legacy rows while making future idempotency keys unique per server.
WITH duplicates AS (
  SELECT id,
         ROW_NUMBER() OVER (PARTITION BY instance_id, idempotency_key ORDER BY created_at, id) AS duplicate_number
    FROM approvals
)
UPDATE approvals
   SET idempotency_key = idempotency_key || ':legacy:' || substr(id, 1, 8)
 WHERE id IN (SELECT id FROM duplicates WHERE duplicate_number > 1);

CREATE UNIQUE INDEX IF NOT EXISTS idx_approvals_instance_idempotency
  ON approvals(instance_id, idempotency_key);
CREATE INDEX IF NOT EXISTS idx_audit_dispatch_lease
  ON audit_events(outcome, attempted_at);
CREATE INDEX IF NOT EXISTS idx_approvals_execution_lease
  ON approvals(status, execution_started_at);
