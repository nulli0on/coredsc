ALTER TABLE pairing_links ADD COLUMN ownership_recovery INTEGER NOT NULL DEFAULT 0
  CHECK(ownership_recovery IN (0,1));

CREATE INDEX IF NOT EXISTS idx_pairing_recovery
  ON pairing_links(instance_id, ownership_recovery, status, expires_at);
