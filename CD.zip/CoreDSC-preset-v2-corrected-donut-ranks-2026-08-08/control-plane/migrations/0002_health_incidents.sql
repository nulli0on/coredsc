CREATE TABLE IF NOT EXISTS health_incidents (
  id TEXT PRIMARY KEY,
  instance_id TEXT NOT NULL REFERENCES instances(id) ON DELETE CASCADE,
  kind TEXT NOT NULL CHECK(kind IN ('AGENT_HEARTBEAT_LOST')),
  status TEXT NOT NULL CHECK(status IN ('OPEN','RESOLVED')),
  detail TEXT NOT NULL,
  detected_at INTEGER NOT NULL,
  resolved_at INTEGER
);

CREATE INDEX IF NOT EXISTS idx_health_incidents_instance_time
  ON health_incidents(instance_id, detected_at DESC);

CREATE UNIQUE INDEX IF NOT EXISTS idx_health_incidents_one_open
  ON health_incidents(instance_id, kind) WHERE status='OPEN';
