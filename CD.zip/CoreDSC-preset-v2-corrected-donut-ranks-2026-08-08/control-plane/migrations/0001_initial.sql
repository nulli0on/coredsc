PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  discord_user_id TEXT PRIMARY KEY,
  username TEXT NOT NULL,
  display_name TEXT NOT NULL,
  avatar TEXT,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  token_hash TEXT NOT NULL UNIQUE,
  csrf_hash TEXT NOT NULL,
  discord_user_id TEXT NOT NULL REFERENCES users(discord_user_id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  last_seen_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);

CREATE TABLE IF NOT EXISTS oauth_states (
  state_hash TEXT PRIMARY KEY,
  return_path TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS instances (
  id TEXT PRIMARY KEY,
  public_key TEXT NOT NULL,
  display_name TEXT NOT NULL,
  plugin_version TEXT NOT NULL,
  minecraft_version TEXT NOT NULL DEFAULT '',
  scheduler_runtime TEXT NOT NULL DEFAULT '',
  status TEXT NOT NULL DEFAULT 'UNPAIRED',
  approval_mode INTEGER NOT NULL DEFAULT 1,
  last_seen_at INTEGER NOT NULL,
  clean_shutdown_at INTEGER,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_instances_seen ON instances(last_seen_at DESC);

CREATE TABLE IF NOT EXISTS instance_nonces (
  instance_id TEXT NOT NULL REFERENCES instances(id) ON DELETE CASCADE,
  nonce_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  PRIMARY KEY (instance_id, nonce_hash)
);

CREATE TABLE IF NOT EXISTS grants (
  instance_id TEXT NOT NULL REFERENCES instances(id) ON DELETE CASCADE,
  discord_user_id TEXT NOT NULL REFERENCES users(discord_user_id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK(role IN ('OWNER','SERVER_ADMIN','MODERATOR','CONSOLE_VIEWER','CONSOLE_OPERATOR','SUPPORT','VIEWER')),
  granted_by TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  revoked_at INTEGER,
  PRIMARY KEY (instance_id, discord_user_id)
);
CREATE INDEX IF NOT EXISTS idx_grants_user ON grants(discord_user_id, revoked_at);

CREATE TABLE IF NOT EXISTS pairing_links (
  id TEXT PRIMARY KEY,
  instance_id TEXT NOT NULL REFERENCES instances(id) ON DELETE CASCADE,
  link_hash TEXT NOT NULL UNIQUE,
  code_hash TEXT NOT NULL,
  requested_minecraft_uuid TEXT,
  requested_minecraft_name TEXT,
  requested_discord_user_id TEXT,
  claimed_discord_user_id TEXT REFERENCES users(discord_user_id),
  status TEXT NOT NULL CHECK(status IN ('CREATED','AWAITING_CONFIRM','CONFIRMED','EXPIRED','CANCELLED')),
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  confirmed_at INTEGER
);
CREATE INDEX IF NOT EXISTS idx_pairing_instance ON pairing_links(instance_id, status, expires_at);

CREATE TABLE IF NOT EXISTS audit_events (
  id TEXT PRIMARY KEY,
  instance_id TEXT NOT NULL REFERENCES instances(id) ON DELETE CASCADE,
  actor_discord_user_id TEXT NOT NULL,
  actor_display_name TEXT NOT NULL,
  operation TEXT NOT NULL,
  reason TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  request_json TEXT NOT NULL,
  result_json TEXT NOT NULL DEFAULT '{}',
  outcome TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  completed_at INTEGER,
  UNIQUE(instance_id, idempotency_key)
);
CREATE INDEX IF NOT EXISTS idx_audit_instance_time ON audit_events(instance_id, created_at DESC);

CREATE TABLE IF NOT EXISTS approvals (
  id TEXT PRIMARY KEY,
  instance_id TEXT NOT NULL REFERENCES instances(id) ON DELETE CASCADE,
  requester_id TEXT NOT NULL REFERENCES users(discord_user_id),
  operation TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  reason TEXT NOT NULL,
  idempotency_key TEXT NOT NULL,
  status TEXT NOT NULL CHECK(status IN ('PENDING','APPROVED','REJECTED','EXPIRED','EXECUTED','FAILED')),
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  decided_by TEXT REFERENCES users(discord_user_id),
  decided_at INTEGER,
  decision_note TEXT NOT NULL DEFAULT '',
  result_json TEXT NOT NULL DEFAULT '{}'
);
CREATE INDEX IF NOT EXISTS idx_approvals_instance_status ON approvals(instance_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS configuration_snapshots (
  id TEXT PRIMARY KEY,
  instance_id TEXT NOT NULL REFERENCES instances(id) ON DELETE CASCADE,
  revision TEXT NOT NULL,
  redacted_json TEXT NOT NULL,
  created_by TEXT NOT NULL,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_config_snapshots_instance ON configuration_snapshots(instance_id, created_at DESC);

CREATE TABLE IF NOT EXISTS network_groups (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  owner_discord_user_id TEXT NOT NULL REFERENCES users(discord_user_id),
  created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS network_members (
  network_id TEXT NOT NULL REFERENCES network_groups(id) ON DELETE CASCADE,
  instance_id TEXT NOT NULL REFERENCES instances(id) ON DELETE CASCADE,
  created_at INTEGER NOT NULL,
  PRIMARY KEY(network_id, instance_id)
);

CREATE TABLE IF NOT EXISTS configuration_templates (
  id TEXT PRIMARY KEY,
  network_id TEXT NOT NULL REFERENCES network_groups(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  patch_json TEXT NOT NULL,
  revision INTEGER NOT NULL DEFAULT 1,
  created_by TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  updated_at INTEGER NOT NULL
);
