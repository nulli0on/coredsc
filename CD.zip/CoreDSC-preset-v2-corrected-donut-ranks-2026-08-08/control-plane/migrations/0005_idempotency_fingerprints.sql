PRAGMA foreign_keys = ON;

ALTER TABLE audit_events ADD COLUMN request_hash TEXT NOT NULL DEFAULT '';
CREATE INDEX IF NOT EXISTS idx_audit_request_hash
  ON audit_events(instance_id, idempotency_key, request_hash);
