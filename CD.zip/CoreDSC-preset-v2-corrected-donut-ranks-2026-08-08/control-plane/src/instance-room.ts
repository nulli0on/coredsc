import type { AgentCommand, AgentResult, Env } from "./types.ts";
import { confirmationCode, randomToken, sha256 } from "./security.ts";
import { responseJson, safeText } from "./database.ts";
import { utf8ByteLength } from "./reliability.ts";

type PendingCall = {
  resolve: (result: AgentResult) => void;
  timer: ReturnType<typeof setTimeout>;
};

type SocketAttachment = { role?: string; instanceId?: string };

interface ProtocolMessage {
  v?: number;
  type?: string;
  requestId?: string;
  event?: string;
  ok?: boolean;
  payload?: unknown;
  error?: { code?: string; message?: string; retryable?: boolean };
}

export class InstanceRoom implements DurableObject {
  private readonly pending = new Map<string, PendingCall>();
  private readonly state: DurableObjectState;
  private readonly env: Env;
  private instanceId = "";
  private activeAgent: WebSocket | null = null;

  constructor(state: DurableObjectState, env: Env) {
    this.state = state;
    this.env = env;
    this.state.setWebSocketAutoResponse(new WebSocketRequestResponsePair("ping", "pong"));

    // Cloudflare WebSocket hibernation preserves accepted sockets but destroys
    // this object's in-memory fields. Rebuild the room identity from the agent's
    // serialized attachment before any resumed socket message can reach D1.
    for (const socket of this.state.getWebSockets("agent")) {
      const attached = this.socketAttachment(socket).instanceId ?? "";
      if (!attached) continue;
      if (this.instanceId && this.instanceId !== attached) {
        try { socket.close(1008, "Durable Object identity mismatch"); } catch { /* stale socket */ }
        continue;
      }
      this.instanceId = attached;
    }
  }

  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    const requestedInstance = request.headers.get("X-CoreDSC-Instance") ?? url.searchParams.get("instance") ?? "";
    this.instanceId ||= requestedInstance;
    if (!this.instanceId) return responseJson({ error: "Missing instance identity" }, 400);
    if (requestedInstance && requestedInstance !== this.instanceId) {
      return responseJson({ error: "Durable Object instance identity mismatch" }, 409);
    }

    if (url.pathname === "/agent") return this.acceptAgent(request);
    if (url.pathname === "/browser") return this.acceptBrowser(request);
    if (url.pathname === "/command" && request.method === "POST") return this.executeCommand(request);
    if (url.pathname === "/cloud-event" && request.method === "POST") {
      const event = await request.json<Record<string, unknown>>();
      this.broadcast(event);
      return responseJson({ delivered: true });
    }
    if (url.pathname === "/status" && request.method === "GET") {
      return responseJson({ online: this.agentSocket() !== null, instanceId: this.instanceId });
    }
    return responseJson({ error: "Not found" }, 404);
  }

  async webSocketMessage(socket: WebSocket, incoming: string | ArrayBuffer): Promise<void> {
    const role = this.socketRole(socket);
    if (role !== "agent" || socket !== this.agentSocket()) return;
    if (!this.restoreInstanceIdentity(socket)) return;
    const text = typeof incoming === "string" ? incoming : new TextDecoder().decode(incoming);
    const incomingBytes = typeof incoming === "string" ? utf8ByteLength(incoming) : incoming.byteLength;
    if (incomingBytes > 1_048_576) {
      socket.close(1009, "Message too large");
      return;
    }
    let message: ProtocolMessage;
    try {
      message = JSON.parse(text) as ProtocolMessage;
    } catch {
      socket.close(1007, "Invalid JSON");
      return;
    }
    if (message.v !== 1 || typeof message.type !== "string") {
      socket.close(1008, "Unsupported protocol");
      return;
    }
    if (message.type === "response") {
      this.finishPending(message);
      return;
    }
    if (message.type === "heartbeat") {
      await this.handleHeartbeat(message.payload);
      return;
    }
    if (message.type === "event") await this.handleAgentEvent(socket, message);
  }

  webSocketClose(socket: WebSocket): void {
    if (this.socketRole(socket) !== "agent") return;
    if (socket === this.activeAgent) this.activeAgent = null;
    if (this.agentSocket(socket) === null) {
      this.failPending("INSTANCE_OFFLINE", "Server connection closed");
      this.broadcast({ type: "presence", online: false, at: Date.now() });
    }
  }

  webSocketError(socket: WebSocket): void {
    if (this.socketRole(socket) === "agent") {
      if (socket === this.activeAgent) this.activeAgent = null;
      if (this.agentSocket(socket) === null) {
        this.failPending("INSTANCE_OFFLINE", "Server connection failed");
      }
    }
    try { socket.close(1011, "WebSocket error"); } catch { /* already closed */ }
  }

  private acceptAgent(request: Request): Response {
    if (request.headers.get("Upgrade")?.toLowerCase() !== "websocket") {
      return responseJson({ error: "WebSocket upgrade required" }, 426);
    }
    const existingAgents = this.agentSockets();
    if (existingAgents.length > 0) this.failPending("AGENT_REPLACED", "Server agent connection was replaced");
    for (const existing of existingAgents) existing.close(4001, "Replaced by a newer connection");
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    this.state.acceptWebSocket(server, ["agent"]);
    server.serializeAttachment({ role: "agent", instanceId: this.instanceId } satisfies SocketAttachment);
    this.activeAgent = server;
    this.broadcast({ type: "presence", online: true, at: Date.now() });
    return new Response(null, { status: 101, webSocket: client });
  }

  private acceptBrowser(request: Request): Response {
    if (request.headers.get("Upgrade")?.toLowerCase() !== "websocket") {
      return responseJson({ error: "WebSocket upgrade required" }, 426);
    }
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    this.state.acceptWebSocket(server, ["browser"]);
    server.serializeAttachment({ role: "browser" });
    server.send(JSON.stringify({ type: "presence", online: this.agentSocket() !== null, at: Date.now() }));
    return new Response(null, { status: 101, webSocket: client });
  }

  private async executeCommand(request: Request): Promise<Response> {
    const agent = this.agentSocket();
    if (!agent) {
      return responseJson({ ok: false, error: { code: "INSTANCE_OFFLINE", message: "Server agent is offline", retryable: true } }, 503);
    }
    const command = await request.json<AgentCommand>();
    const timeoutMillis = Math.min(30_000, Math.max(1_000, Number(command.timeoutMillis) || 15_000));
    const requestId = crypto.randomUUID();
    const result = await new Promise<AgentResult>((resolve) => {
      const timer = setTimeout(() => {
        this.pending.delete(requestId);
        resolve({ ok: false, error: { code: "AGENT_TIMEOUT", message: "The server did not answer in time", retryable: true } });
      }, timeoutMillis);
      this.pending.set(requestId, { resolve, timer });
      const message = JSON.stringify({
        v: 1,
        type: "request",
        requestId,
        operation: command.operation,
        payload: command.payload,
        actor: command.actor,
        idempotencyKey: command.idempotencyKey,
        deadline: Date.now() + timeoutMillis,
      });
      try {
        agent.send(message);
      } catch {
        clearTimeout(timer);
        this.pending.delete(requestId);
        resolve({ ok: false, error: { code: "INSTANCE_OFFLINE", message: "Server connection closed", retryable: true } });
      }
    });
    return responseJson(result, result.ok ? 200 : result.error?.retryable ? 503 : 422);
  }

  private failPending(code: string, message: string): void {
    for (const [requestId, pending] of this.pending) {
      this.pending.delete(requestId);
      clearTimeout(pending.timer);
      pending.resolve({ ok: false, error: { code, message, retryable: true } });
    }
  }

  private finishPending(message: ProtocolMessage): void {
    const requestId = typeof message.requestId === "string" ? message.requestId : "";
    const pending = this.pending.get(requestId);
    if (!pending) return;
    this.pending.delete(requestId);
    clearTimeout(pending.timer);
    pending.resolve(message.ok
      ? { ok: true, payload: message.payload }
      : { ok: false, error: {
        code: safeText(message.error?.code, 64, "error code") || "AGENT_REJECTED",
        message: safeText(message.error?.message, 500, "error message") || "Server rejected the operation",
        retryable: message.error?.retryable === true,
      } });
  }

  private async handleHeartbeat(payload: unknown): Promise<void> {
    const data = payload && typeof payload === "object" && !Array.isArray(payload)
      ? payload as Record<string, unknown> : {};
    const now = Date.now();
    await this.env.COREDSC_DB.batch([
      this.env.COREDSC_DB.prepare(
        `UPDATE instances SET last_seen_at=?, plugin_version=?, minecraft_version=?, scheduler_runtime=?, status='ONLINE'
          WHERE id=?`,
      ).bind(
        now,
        safeText(data.pluginVersion, 40, "pluginVersion"),
        safeText(data.minecraftVersion, 80, "minecraftVersion"),
        safeText(data.scheduler, 20, "scheduler"),
        this.instanceId,
      ),
      this.env.COREDSC_DB.prepare(
        `UPDATE health_incidents SET status='RESOLVED',resolved_at=?
          WHERE instance_id=? AND kind='AGENT_HEARTBEAT_LOST' AND status='OPEN'`,
      ).bind(now, this.instanceId),
    ]);
    this.broadcast({ type: "heartbeat", instanceId: this.instanceId, at: now, health: data });
  }

  private async handleAgentEvent(socket: WebSocket, message: ProtocolMessage): Promise<void> {
    const requestId = typeof message.requestId === "string" ? message.requestId : "";
    try {
      if (message.event === "pairing.create") {
        const result = await this.createPairing(message.payload);
        this.send(socket, { v: 1, type: "response", requestId, ok: true, payload: result });
        return;
      }
      if (message.event === "pairing.confirm") {
        const result = await this.confirmPairing(message.payload);
        this.send(socket, { v: 1, type: "response", requestId, ok: true, payload: result });
        return;
      }
      if (message.event === "shutdown.clean") {
        await this.env.COREDSC_DB.prepare(
          "UPDATE instances SET status='OFFLINE', clean_shutdown_at=?, last_seen_at=? WHERE id=?",
        ).bind(Date.now(), Date.now(), this.instanceId).run();
        this.send(socket, { v: 1, type: "response", requestId, ok: true, payload: { recorded: true } });
        return;
      }
      throw new Error("Unsupported agent event");
    } catch (error) {
      const text = error instanceof Error ? error.message : "Agent event failed";
      this.send(socket, { v: 1, type: "response", requestId, ok: false,
        error: { code: "EVENT_REJECTED", message: text.slice(0, 500), retryable: false } });
    }
  }

  private async createPairing(payload: unknown): Promise<Record<string, unknown>> {
    const data = payload && typeof payload === "object" && !Array.isArray(payload)
      ? payload as Record<string, unknown> : {};
    const boundDiscordId = safeText(data.boundDiscordUserId, 32, "boundDiscordUserId");
    const ownershipRecovery = data.ownershipRecovery === true;
    if (ownershipRecovery && (boundDiscordId || data.minecraftUuid)) {
      throw new Error("Ownership recovery must originate from the unbound local console flow");
    }
    const owner = await this.env.COREDSC_DB.prepare(
      "SELECT discord_user_id FROM grants WHERE instance_id=? AND role='OWNER' AND revoked_at IS NULL LIMIT 1",
    ).bind(this.instanceId).first<{ discord_user_id: string }>();
    if (owner && !ownershipRecovery) {
      if (!boundDiscordId) {
        return { paired: true, url: `${this.env.PUBLIC_APP_URL}/dashboard`,
          message: "This server is already paired. Sign in to the dashboard with an authorized Discord account." };
      }
      const grant = await this.env.COREDSC_DB.prepare(
        "SELECT 1 AS allowed FROM grants WHERE instance_id=? AND discord_user_id=? AND revoked_at IS NULL",
      ).bind(this.instanceId, boundDiscordId).first();
      if (!grant) throw new Error("The linked Discord account is not authorized for this server");
    }

    const pairingId = crypto.randomUUID();
    const linkToken = randomToken(24);
    const code = await confirmationCode(this.env.COOKIE_SECRET, pairingId);
    const now = Date.now();
    const expiresAt = now + 15 * 60_000;
    await this.env.COREDSC_DB.batch([
      this.env.COREDSC_DB.prepare(
        "UPDATE pairing_links SET status='CANCELLED' WHERE instance_id=? AND status IN ('CREATED','AWAITING_CONFIRM')",
      ).bind(this.instanceId),
      this.env.COREDSC_DB.prepare(
        `INSERT INTO pairing_links
          (id,instance_id,link_hash,code_hash,requested_minecraft_uuid,requested_minecraft_name,
           requested_discord_user_id,claimed_discord_user_id,ownership_recovery,status,created_at,expires_at)
         VALUES (?,?,?,?,?,?,?,NULL,?,'CREATED',?,?)`,
      ).bind(
        pairingId,
        this.instanceId,
        await sha256(linkToken),
        await sha256(code),
        safeText(data.minecraftUuid, 40, "minecraftUuid") || null,
        safeText(data.minecraftName, 16, "minecraftName") || null,
        boundDiscordId || null,
        ownershipRecovery ? 1 : 0,
        now,
        expiresAt,
      ),
    ]);
    return { paired: Boolean(owner) && !ownershipRecovery, ownershipRecovery,
      url: `${this.env.PUBLIC_APP_URL}/link/${linkToken}`, expiresAt };
  }

  private async confirmPairing(payload: unknown): Promise<Record<string, unknown>> {
    const data = payload && typeof payload === "object" && !Array.isArray(payload)
      ? payload as Record<string, unknown> : {};
    const code = safeText(data.code, 9, "code", true).toUpperCase();
    if (!/^[A-HJ-NP-Z2-9]{4}-[A-HJ-NP-Z2-9]{4}$/u.test(code)) throw new Error("Confirmation code format is invalid");
    const row = await this.env.COREDSC_DB.prepare(
      `SELECT p.id, p.claimed_discord_user_id, p.ownership_recovery, u.display_name
         FROM pairing_links p
         JOIN users u ON u.discord_user_id=p.claimed_discord_user_id
        WHERE p.instance_id=? AND p.code_hash=? AND p.status='AWAITING_CONFIRM' AND p.expires_at>?`,
    ).bind(this.instanceId, await sha256(code), Date.now()).first<{
      id: string; claimed_discord_user_id: string; ownership_recovery: number; display_name: string;
    }>();
    if (!row) throw new Error("The code is invalid, expired, or has not been claimed through Discord yet");
    const existingOwner = await this.env.COREDSC_DB.prepare(
      "SELECT discord_user_id FROM grants WHERE instance_id=? AND role='OWNER' AND revoked_at IS NULL LIMIT 1",
    ).bind(this.instanceId).first<{ discord_user_id: string }>();
    if (existingOwner && existingOwner.discord_user_id !== row.claimed_discord_user_id
        && row.ownership_recovery !== 1) {
      const existingGrant = await this.env.COREDSC_DB.prepare(
        "SELECT role FROM grants WHERE instance_id=? AND discord_user_id=? AND revoked_at IS NULL",
      ).bind(this.instanceId, row.claimed_discord_user_id).first();
      if (!existingGrant) throw new Error("Ownership already exists; add staff through the dashboard");
    }
    const now = Date.now();
    const statements = [
      this.env.COREDSC_DB.prepare(
        "UPDATE pairing_links SET status='CONFIRMED', confirmed_at=? WHERE id=? AND status='AWAITING_CONFIRM'",
      ).bind(now, row.id),
      this.env.COREDSC_DB.prepare("UPDATE instances SET status='ONLINE', last_seen_at=? WHERE id=?")
        .bind(now, this.instanceId),
    ];
    const ownershipChanged = !existingOwner
      || (row.ownership_recovery === 1 && existingOwner.discord_user_id !== row.claimed_discord_user_id);
    if (row.ownership_recovery === 1 && existingOwner
        && existingOwner.discord_user_id !== row.claimed_discord_user_id) {
      statements.push(this.env.COREDSC_DB.prepare(
        "UPDATE grants SET revoked_at=? WHERE instance_id=? AND role='OWNER' AND revoked_at IS NULL",
      ).bind(now, this.instanceId));
    }
    if (ownershipChanged) {
      statements.push(this.env.COREDSC_DB.prepare(
        `INSERT INTO grants(instance_id,discord_user_id,role,granted_by,created_at,revoked_at)
         VALUES (?,?,'OWNER',?,?,NULL)
         ON CONFLICT(instance_id,discord_user_id) DO UPDATE SET
           role='OWNER',granted_by=excluded.granted_by,created_at=excluded.created_at,revoked_at=NULL`,
      ).bind(this.instanceId, row.claimed_discord_user_id, row.claimed_discord_user_id, now));
    }
    if (row.ownership_recovery === 1) {
      statements.push(this.env.COREDSC_DB.prepare(
        `INSERT INTO audit_events(id,instance_id,actor_discord_user_id,actor_display_name,operation,reason,
          idempotency_key,request_json,result_json,outcome,created_at,completed_at)
         VALUES (?,?,?,?,?,?,?,?,?,'SUCCEEDED',?,?)`,
      ).bind(crypto.randomUUID(), this.instanceId, row.claimed_discord_user_id, row.display_name,
        "ownership.recover", "Confirmed from the authenticated local server console", row.id,
        JSON.stringify({ previousOwner: existingOwner?.discord_user_id ?? null }),
        JSON.stringify({ owner: row.claimed_discord_user_id }), now, now));
    }
    await this.env.COREDSC_DB.batch(statements);
    this.broadcast({ type: "pairing", status: "CONFIRMED", instanceId: this.instanceId });
    return { confirmed: true, ownershipRecovery: row.ownership_recovery === 1,
      discordUserId: row.claimed_discord_user_id, displayName: row.display_name };
  }

  private agentSockets(): WebSocket[] {
    return this.state.getWebSockets("agent");
  }

  private agentSocket(excluded?: WebSocket): WebSocket | null {
    const sockets = this.agentSockets().filter((socket) => socket !== excluded);
    if (this.activeAgent && sockets.includes(this.activeAgent)) return this.activeAgent;
    this.activeAgent = sockets.at(-1) ?? null;
    return this.activeAgent;
  }

  private socketAttachment(socket: WebSocket): SocketAttachment {
    const attachment = socket.deserializeAttachment() as SocketAttachment | null;
    return attachment ?? {};
  }

  private socketRole(socket: WebSocket): string {
    return this.socketAttachment(socket).role ?? "";
  }

  private restoreInstanceIdentity(socket: WebSocket): boolean {
    const attached = this.socketAttachment(socket).instanceId ?? "";
    if (!attached) {
      if (this.instanceId) return true;
      // Sockets accepted by an older deployment only carry {role}. Fail closed
      // and force the Java agent to reconnect so a valid identity is attached.
      try { socket.close(1012, "Reconnect required to restore server identity"); } catch { /* stale socket */ }
      return false;
    }
    if (this.instanceId && this.instanceId !== attached) {
      try { socket.close(1008, "Durable Object identity mismatch"); } catch { /* stale socket */ }
      return false;
    }
    this.instanceId = attached;
    return true;
  }

  private broadcast(value: unknown): void {
    const message = JSON.stringify(value);
    for (const socket of this.state.getWebSockets("browser")) {
      try { socket.send(message); } catch { /* stale sockets are removed by the runtime */ }
    }
  }

  private send(socket: WebSocket, value: unknown): void {
    try { socket.send(JSON.stringify(value)); } catch { /* caller will reconnect */ }
  }
}
