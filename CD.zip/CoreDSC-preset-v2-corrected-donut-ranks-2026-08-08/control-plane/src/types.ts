export interface Env {
  COREDSC_DB: D1Database;
  INSTANCE_ROOMS: DurableObjectNamespace;
  APP_ORIGIN: string;
  PUBLIC_APP_URL: string;
  DISCORD_CLIENT_ID: string;
  DISCORD_CLIENT_SECRET: string;
  DISCORD_REDIRECT_URI: string;
  COOKIE_SECRET: string;
  SESSION_TTL_SECONDS: string;
}

export type StaffRole =
  | "OWNER"
  | "SERVER_ADMIN"
  | "MODERATOR"
  | "CONSOLE_VIEWER"
  | "CONSOLE_OPERATOR"
  | "SUPPORT"
  | "VIEWER";

export interface SessionUser {
  id: string;
  username: string;
  displayName: string;
  avatar: string | null;
  sessionId: string;
  csrfHash: string;
}

export interface AgentActor {
  discordUserId: string;
  displayName: string;
  role: StaffRole;
  reason: string;
}

export interface AgentCommand {
  operation: string;
  payload: Record<string, unknown>;
  actor: AgentActor;
  idempotencyKey: string;
  timeoutMillis: number;
}

export interface AgentResult {
  ok: boolean;
  payload?: unknown;
  error?: { code: string; message: string; retryable: boolean };
}

export interface ExecutionContextLike {
  waitUntil(promise: Promise<unknown>): void;
}
