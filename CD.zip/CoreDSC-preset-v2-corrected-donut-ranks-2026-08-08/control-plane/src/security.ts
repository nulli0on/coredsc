import type { Env } from "./types.ts";

const encoder = new TextEncoder();

export function randomToken(bytes = 32): string {
  const value = new Uint8Array(bytes);
  crypto.getRandomValues(value);
  return base64Url(value);
}

export function base64Url(bytes: Uint8Array): string {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replaceAll("+", "-").replaceAll("/", "_").replace(/=+$/u, "");
}

export function fromBase64Url(value: string): Uint8Array {
  if (!/^[A-Za-z0-9_-]+$/u.test(value)) throw new Error("Invalid base64url value");
  const padded = value.replaceAll("-", "+").replaceAll("_", "/")
    + "=".repeat((4 - (value.length % 4)) % 4);
  const binary = atob(padded);
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

export async function sha256(value: string | Uint8Array): Promise<string> {
  const data = typeof value === "string" ? encoder.encode(value) : value;
  return base64Url(new Uint8Array(await crypto.subtle.digest("SHA-256", arrayBuffer(data))));
}

export async function hmac(secret: string, value: string): Promise<Uint8Array> {
  const key = await crypto.subtle.importKey(
    "raw",
    arrayBuffer(encoder.encode(secret)),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  return new Uint8Array(await crypto.subtle.sign("HMAC", key, arrayBuffer(encoder.encode(value))));
}

function arrayBuffer(bytes: Uint8Array): ArrayBuffer {
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer;
}

export async function confirmationCode(secret: string, pairingId: string): Promise<string> {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const digest = await hmac(secret, `pairing:${pairingId}`);
  let code = "";
  for (let index = 0; index < 8; index += 1) code += alphabet[digest[index] % alphabet.length];
  return `${code.slice(0, 4)}-${code.slice(4)}`;
}

export async function csrfTokenFor(secret: string, sessionId: string): Promise<string> {
  return base64Url(await hmac(secret, `csrf:${sessionId}`));
}

export function secureCookie(name: string, value: string, maxAgeSeconds: number): string {
  return `${name}=${value}; Path=/; Max-Age=${maxAgeSeconds}; HttpOnly; Secure; SameSite=Lax`;
}

export function clearCookie(name: string): string {
  return `${name}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax`;
}

export function cookie(request: Request, name: string): string | null {
  const raw = request.headers.get("Cookie") ?? "";
  for (const part of raw.split(";")) {
    const separator = part.indexOf("=");
    if (separator < 1) continue;
    if (part.slice(0, separator).trim() === name) return part.slice(separator + 1).trim();
  }
  return null;
}

export async function verifyAgentSignature(
  instanceId: string,
  timestamp: string,
  nonce: string,
  publicKey: string,
  signature: string,
): Promise<boolean> {
  try {
    const imported = await crypto.subtle.importKey(
      "spki",
      fromBase64Url(publicKey).buffer as ArrayBuffer,
      { name: "Ed25519" },
      false,
      ["verify"],
    );
    const canonical = encoder.encode(`coredsc-agent-v1\n${instanceId}\n${timestamp}\n${nonce}`);
    return crypto.subtle.verify(
      { name: "Ed25519" },
      imported,
      fromBase64Url(signature).buffer as ArrayBuffer,
      canonical,
    );
  } catch {
    return false;
  }
}

export function assertTrustedOrigin(request: Request, env: Env): void {
  const origin = request.headers.get("Origin");
  if (origin !== env.APP_ORIGIN) throw new HttpError(403, "Untrusted request origin");
}

export class HttpError extends Error {
  public readonly status: number;

  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}
