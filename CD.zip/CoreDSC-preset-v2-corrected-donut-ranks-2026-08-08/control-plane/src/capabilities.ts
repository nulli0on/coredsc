import type { StaffRole } from "./types.ts";
import { HttpError } from "./security.ts";
import {
  allCapabilities,
  lookupOperationCapability,
  operationNeedsApproval,
  roleHas,
} from "./policy.ts";

export { allCapabilities, operationNeedsApproval, roleHas } from "./policy.ts";

export function capabilityForOperation(operation: string): string {
  const capability = lookupOperationCapability(operation);
  if (!capability) throw new HttpError(400, `Unsupported operation '${operation}'`);
  return capability;
}

export function requireCapability(role: StaffRole, capability: string): void {
  if (!roleHas(role, capability)) throw new HttpError(403, `Missing capability '${capability}'`);
}
