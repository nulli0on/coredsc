export const MAX_MEDIA_BYTES = 512 * 1024;

export interface ValidatedMedia {
  mimeType: "image/png" | "image/jpeg" | "image/webp" | "image/gif";
  extension: "png" | "jpg" | "webp" | "gif";
}

const TYPES: Record<string, ValidatedMedia["extension"]> = {
  "image/png": "png",
  "image/jpeg": "jpg",
  "image/webp": "webp",
  "image/gif": "gif",
};

export function validateMediaBytes(bytes: Uint8Array, declaredType: string): ValidatedMedia {
  const mimeType = declaredType.split(";", 1)[0].trim().toLowerCase();
  const extension = TYPES[mimeType];
  if (!extension) throw new Error("Only PNG, JPEG, WebP and GIF images are accepted");
  if (!bytes.byteLength || bytes.byteLength > MAX_MEDIA_BYTES) {
    throw new Error(`Image is empty or exceeds the ${MAX_MEDIA_BYTES / 1024} KiB limit`);
  }
  const matches = mimeType === "image/png" ? isPng(bytes)
    : mimeType === "image/jpeg" ? isJpeg(bytes)
      : mimeType === "image/webp" ? isWebp(bytes)
        : isGif(bytes);
  if (!matches) throw new Error("Image bytes do not match the declared content type");
  return { mimeType: mimeType as ValidatedMedia["mimeType"], extension };
}

function isPng(bytes: Uint8Array): boolean {
  return bytes.length >= 8 && [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]
    .every((value, index) => bytes[index] === value);
}

function isJpeg(bytes: Uint8Array): boolean {
  return bytes.length >= 4 && bytes[0] === 0xff && bytes[1] === 0xd8
    && bytes[bytes.length - 2] === 0xff && bytes[bytes.length - 1] === 0xd9;
}

function isWebp(bytes: Uint8Array): boolean {
  return bytes.length >= 12 && ascii(bytes, 0, "RIFF") && ascii(bytes, 8, "WEBP");
}

function isGif(bytes: Uint8Array): boolean {
  return bytes.length >= 6 && (ascii(bytes, 0, "GIF87a") || ascii(bytes, 0, "GIF89a"));
}

function ascii(bytes: Uint8Array, offset: number, expected: string): boolean {
  if (bytes.length < offset + expected.length) return false;
  for (let index = 0; index < expected.length; index += 1) {
    if (bytes[offset + index] !== expected.charCodeAt(index)) return false;
  }
  return true;
}
