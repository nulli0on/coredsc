import { HttpError } from "./security.ts";

export interface PresetVariable {
  key: string;
  label: string;
  description: string;
  type: "guild" | "channel" | "category" | "role" | "text";
  required: boolean;
  group?: string;
}

interface PresetChange {
  file: string;
  path: string;
  value: unknown;
}

interface PresetDefinition {
  id: string;
  name: string;
  summary: string;
  description: string;
  version: string;
  minimumCoreDSC: string;
  verified: true;
  author: string;
  tags: string[];
  setupMode: "variables" | "descriptor";
  descriptorFile?: string;
  requiredVariables: PresetVariable[];
  changes: PresetChange[];
}

const PRESETS: Readonly<Record<string, PresetDefinition>> = Object.freeze({
  donutsmp: {
    id: "donutsmp",
    name: "DonutSMP Inspired",
    summary: "A complete starting point for a DonutSMP-style Discord community powered by CoreDSC.",
    description: "Configures Discord-first verification, linked Minecraft chat, Tickets V2, Donut-style self-role selectors, persistent Discord activity levels, optional automatic Discord resource bootstrap, and an independent DonutRanks-style LuckPerms rank template for Minecraft.",
    version: "0.4.0",
    minimumCoreDSC: "3.4.2",
    verified: true,
    author: "HubertStudios",
    tags: ["donutsmp", "smp", "discord", "tickets", "verification", "chat", "self-roles", "levels", "luckperms", "bootstrap"],
    setupMode: "descriptor",
    descriptorFile: "donutsmp.yml",
    requiredVariables: [
      { key: "guild-id", label: "Discord server", description: "Discord guild/server ID", type: "guild", required: true, group: "Connection" },
      { key: "verified-role-id", label: "Verified role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Connection" },
      { key: "chat-channel-id", label: "Minecraft chat channel", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "channel", required: false, group: "Connection" },
      { key: "ticket-panel-channel-id", label: "Ticket panel channel", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "channel", required: false, group: "Tickets" },
      { key: "ticket-log-channel-id", label: "Ticket log channel", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "channel", required: false, group: "Tickets" },
      { key: "ban-appeal-category-id", label: "Ban Appeal category", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "category", required: false, group: "Tickets" },
      { key: "bug-report-category-id", label: "Bug Report category", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "category", required: false, group: "Tickets" },
      { key: "other-ticket-category-id", label: "Other ticket category", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "category", required: false, group: "Tickets" },
      { key: "staff-role-id", label: "Ticket staff role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Tickets" },
      { key: "role-select-channel-id", label: "Role selection channel", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "channel", required: false, group: "Self Roles" },
      { key: "platform-pc-role-id", label: "PC role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Platform Roles" },
      { key: "platform-xbox-role-id", label: "Xbox role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Platform Roles" },
      { key: "platform-playstation-role-id", label: "PlayStation role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Platform Roles" },
      { key: "platform-mobile-role-id", label: "Mobile role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Platform Roles" },
      { key: "platform-switch-role-id", label: "Nintendo Switch role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Platform Roles" },
      { key: "age-13-14-role-id", label: "Age 13–14 role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Age Roles" },
      { key: "age-15-17-role-id", label: "Age 15–17 role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Age Roles" },
      { key: "age-18-20-role-id", label: "Age 18–20 role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Age Roles" },
      { key: "age-21-24-role-id", label: "Age 21–24 role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Age Roles" },
      { key: "age-25-29-role-id", label: "Age 25–29 role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Age Roles" },
      { key: "age-30-plus-role-id", label: "Age 30+ role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Age Roles" },
      { key: "region-europe-role-id", label: "Europe role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Region Roles" },
      { key: "region-na-role-id", label: "North America role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Region Roles" },
      { key: "region-asia-role-id", label: "Asia role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Region Roles" },
      { key: "region-oceania-role-id", label: "Oceania role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Region Roles" },
      { key: "region-sa-role-id", label: "South America role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Region Roles" },
      { key: "region-africa-role-id", label: "Africa role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Region Roles" },
      { key: "notify-news-role-id", label: "News notification role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Notification Roles" },
      { key: "notify-streams-role-id", label: "Streams notification role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Notification Roles" },
      { key: "notify-events-role-id", label: "Events notification role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Notification Roles" },
      { key: "notify-polls-role-id", label: "Polls notification role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Notification Roles" },
      { key: "notify-updates-role-id", label: "Updates notification role", description: "Resolved by the preset bootstrap or an existing Discord ID", type: "role", required: false, group: "Notification Roles" },
      { key: "self-group-platform-enabled", label: "Enable Platform self-role group", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-group-age-enabled", label: "Enable Age self-role group", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-group-region-enabled", label: "Enable Region self-role group", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-group-notifications-enabled", label: "Enable Notifications self-role group", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-platform-pc-enabled", label: "Enable PC", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-platform-xbox-enabled", label: "Enable Xbox", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-platform-playstation-enabled", label: "Enable PlayStation", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-platform-mobile-enabled", label: "Enable Mobile", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-platform-nintendo-switch-enabled", label: "Enable Nintendo Switch", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-age-age-13-14-enabled", label: "Enable Age 13–14", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-age-age-15-17-enabled", label: "Enable Age 15–17", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-age-age-18-20-enabled", label: "Enable Age 18–20", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-age-age-21-24-enabled", label: "Enable Age 21–24", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-age-age-25-29-enabled", label: "Enable Age 25–29", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-age-age-30-plus-enabled", label: "Enable Age 30+", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-region-europe-enabled", label: "Enable Europe", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-region-north-america-enabled", label: "Enable North America", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-region-asia-enabled", label: "Enable Asia", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-region-oceania-enabled", label: "Enable Oceania", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-region-south-america-enabled", label: "Enable South America", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-region-africa-enabled", label: "Enable Africa", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-notifications-news-pings-enabled", label: "Enable News Pings", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-notifications-stream-pings-enabled", label: "Enable Stream Pings", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-notifications-event-pings-enabled", label: "Enable Event Pings", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-notifications-poll-pings-enabled", label: "Enable Poll Pings", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "self-notifications-update-pings-enabled", label: "Enable Update Pings", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Self Roles" },
      { key: "level-1-role-id", label: "Level 1 role", description: "Discord activity level role", type: "role", required: false, group: "Activity Level Roles" },
      { key: "level-3-role-id", label: "Level 3 role", description: "Discord activity level role", type: "role", required: false, group: "Activity Level Roles" },
      { key: "level-5-role-id", label: "Level 5 role", description: "Discord activity level role", type: "role", required: false, group: "Activity Level Roles" },
      { key: "level-10-role-id", label: "Level 10 role", description: "Discord activity level role", type: "role", required: false, group: "Activity Level Roles" },
      { key: "level-20-role-id", label: "Level 20 role", description: "Discord activity level role", type: "role", required: false, group: "Activity Level Roles" },
      { key: "level-30-role-id", label: "Level 30 role", description: "Discord activity level role", type: "role", required: false, group: "Activity Level Roles" },
      { key: "level-40-role-id", label: "Level 40 role", description: "Discord activity level role", type: "role", required: false, group: "Activity Level Roles" },
      { key: "level-50-role-id", label: "Level 50 role", description: "Discord activity level role", type: "role", required: false, group: "Activity Level Roles" },
      { key: "level-60-role-id", label: "Level 60 role", description: "Discord activity level role", type: "role", required: false, group: "Activity Level Roles" },
      { key: "level-70-role-id", label: "Level 70 role", description: "Discord activity level role", type: "role", required: false, group: "Activity Level Roles" },
      { key: "level-80-role-id", label: "Level 80 role", description: "Discord activity level role", type: "role", required: false, group: "Activity Level Roles" },
      { key: "feature-verification", label: "Enable verification", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "feature-chat", label: "Enable Minecraft chat", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "feature-tickets", label: "Enable Tickets V2", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "feature-self-roles", label: "Enable self roles", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "feature-levels", label: "Enable Discord levels", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "link-code-expiry-seconds", label: "Link code expiry", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "link-code-length", label: "Link code length", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "xp-award-window-seconds", label: "XP award window", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "xp-minimum", label: "Minimum XP award", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "xp-maximum", label: "Maximum XP award", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "xp-minimum-message-length", label: "Minimum message length", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "levels-maximum", label: "Maximum Discord level", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "levels-role-mode", label: "Level role mode", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "ticket-panel-title", label: "Ticket panel title", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "ticket-panel-description", label: "Ticket panel description", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "ticket-maximum-open-per-user", label: "Maximum open tickets per user", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "ticket-ban-appeal-enabled", label: "Enable Ban Appeal tickets", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "ticket-bug-report-enabled", label: "Enable Bug Report tickets", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "ticket-media-rank-enabled", label: "Enable Media Rank tickets", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
      { key: "ticket-other-enabled", label: "Enable Other tickets", description: "Resolved from donutsmp.yml", type: "text", required: true, group: "Preset Options" },
    ],
    changes: [
      { file: "config.yml", path: "discord.guild-id", value: "${guild-id}" },
      { file: "config.yml", path: "discord.link-role-id", value: "${verified-role-id}" },
      { file: "modules/link.yml", path: "enabled", value: "${feature-verification}" },
      { file: "modules/link.yml", path: "code-expiry-seconds", value: "${link-code-expiry-seconds}" },
      { file: "modules/link.yml", path: "code-length", value: "${link-code-length}" },
      { file: "modules/link.yml", path: "code-direction", value: "DISCORD_TO_MINECRAFT" },
      { file: "modules/chat-sync.yml", path: "enabled", value: "${feature-chat}" },
      { file: "modules/chat-sync.yml", path: "minecraft-to-discord.channel-id", value: "${chat-channel-id}" },
      { file: "modules/chat-sync.yml", path: "discord-to-minecraft.channel-id", value: "${chat-channel-id}" },
      { file: "modules/chat-sync.yml", path: "discord-to-minecraft.allow-linked-users", value: true },
      { file: "modules/chat-sync.yml", path: "discord-to-minecraft.allow-unlinked-users", value: false },
      { file: "modules/self-roles.yml", path: "enabled", value: "${feature-self-roles}" },
      { file: "modules/self-roles.yml", path: "guild-id", value: "${guild-id}" },
      { file: "modules/self-roles.yml", path: "publish-on-startup", value: true },
      { file: "modules/self-roles.yml", path: "panels", value: [
        {
          enabled: true,
          id: "community-roles",
          "channel-id": "${role-select-channel-id}",
          title: "Choose Your Roles",
          description: "Pick the roles that describe you and the notifications you want to receive.",
          footer: "You can change these roles at any time.",
          color: "#F47FFF",
          groups: [
            { enabled: "${self-group-platform-enabled}", id: "platform", label: "Platform", placeholder: "Select your platform", mode: "SINGLE", "remove-unselected": true, options: [
              { enabled: "${self-platform-pc-enabled}", id: "pc", label: "PC", emoji: "🖥️", "role-id": "${platform-pc-role-id}" },
              { enabled: "${self-platform-xbox-enabled}", id: "xbox", label: "Xbox", emoji: "🎮", "role-id": "${platform-xbox-role-id}" },
              { enabled: "${self-platform-playstation-enabled}", id: "playstation", label: "PlayStation", emoji: "🎮", "role-id": "${platform-playstation-role-id}" },
              { enabled: "${self-platform-mobile-enabled}", id: "mobile", label: "Mobile", emoji: "📱", "role-id": "${platform-mobile-role-id}" },
              { enabled: "${self-platform-nintendo-switch-enabled}", id: "switch", label: "Nintendo Switch", emoji: "🎮", "role-id": "${platform-switch-role-id}" },
            ] },
            { enabled: "${self-group-age-enabled}", id: "age", label: "Age", placeholder: "Select your age range", mode: "SINGLE", "remove-unselected": true, options: [
              { enabled: "${self-age-age-13-14-enabled}", id: "13-14", label: "13–14", "role-id": "${age-13-14-role-id}" },
              { enabled: "${self-age-age-15-17-enabled}", id: "15-17", label: "15–17", "role-id": "${age-15-17-role-id}" },
              { enabled: "${self-age-age-18-20-enabled}", id: "18-20", label: "18–20", "role-id": "${age-18-20-role-id}" },
              { enabled: "${self-age-age-21-24-enabled}", id: "21-24", label: "21–24", "role-id": "${age-21-24-role-id}" },
              { enabled: "${self-age-age-25-29-enabled}", id: "25-29", label: "25–29", "role-id": "${age-25-29-role-id}" },
              { enabled: "${self-age-age-30-plus-enabled}", id: "30-plus", label: "30+", "role-id": "${age-30-plus-role-id}" },
            ] },
            { enabled: "${self-group-region-enabled}", id: "region", label: "Region", placeholder: "Select your region", mode: "SINGLE", "remove-unselected": true, options: [
              { enabled: "${self-region-europe-enabled}", id: "europe", label: "Europe", emoji: "🇪🇺", "role-id": "${region-europe-role-id}" },
              { enabled: "${self-region-north-america-enabled}", id: "north-america", label: "North America", emoji: "🌎", "role-id": "${region-na-role-id}" },
              { enabled: "${self-region-asia-enabled}", id: "asia", label: "Asia", emoji: "🌏", "role-id": "${region-asia-role-id}" },
              { enabled: "${self-region-oceania-enabled}", id: "oceania", label: "Oceania", emoji: "🌏", "role-id": "${region-oceania-role-id}" },
              { enabled: "${self-region-south-america-enabled}", id: "south-america", label: "South America", emoji: "🌎", "role-id": "${region-sa-role-id}" },
              { enabled: "${self-region-africa-enabled}", id: "africa", label: "Africa", emoji: "🌍", "role-id": "${region-africa-role-id}" },
            ] },
            { enabled: "${self-group-notifications-enabled}", id: "notifications", label: "Notifications", placeholder: "Choose notification roles", mode: "MULTIPLE", "remove-unselected": true, options: [
              { enabled: "${self-notifications-news-pings-enabled}", id: "news", label: "News", emoji: "📰", "role-id": "${notify-news-role-id}" },
              { enabled: "${self-notifications-stream-pings-enabled}", id: "streams", label: "Streams", emoji: "📺", "role-id": "${notify-streams-role-id}" },
              { enabled: "${self-notifications-event-pings-enabled}", id: "events", label: "Events", emoji: "🎉", "role-id": "${notify-events-role-id}" },
              { enabled: "${self-notifications-poll-pings-enabled}", id: "polls", label: "Polls", emoji: "📊", "role-id": "${notify-polls-role-id}" },
              { enabled: "${self-notifications-update-pings-enabled}", id: "updates", label: "Updates", emoji: "🔔", "role-id": "${notify-updates-role-id}" },
            ] },
          ],
        },
      ] },
      { file: "modules/discord-levels.yml", path: "enabled", value: "${feature-levels}" },
      { file: "modules/discord-levels.yml", path: "guild-id", value: "${guild-id}" },
      { file: "modules/discord-levels.yml", path: "xp.award-window-seconds", value: "${xp-award-window-seconds}" },
      { file: "modules/discord-levels.yml", path: "xp.minimum", value: "${xp-minimum}" },
      { file: "modules/discord-levels.yml", path: "xp.maximum", value: "${xp-maximum}" },
      { file: "modules/discord-levels.yml", path: "xp.minimum-message-length", value: "${xp-minimum-message-length}" },
      { file: "modules/discord-levels.yml", path: "curve.maximum-level", value: "${levels-maximum}" },
      { file: "modules/discord-levels.yml", path: "roles.mode", value: "${levels-role-mode}" },
      { file: "modules/discord-levels.yml", path: "roles.milestones", value: [
        { level: 1, "role-id": "${level-1-role-id}" }, { level: 3, "role-id": "${level-3-role-id}" },
        { level: 5, "role-id": "${level-5-role-id}" }, { level: 10, "role-id": "${level-10-role-id}" },
        { level: 20, "role-id": "${level-20-role-id}" }, { level: 30, "role-id": "${level-30-role-id}" },
        { level: 40, "role-id": "${level-40-role-id}" }, { level: 50, "role-id": "${level-50-role-id}" },
        { level: 60, "role-id": "${level-60-role-id}" }, { level: 70, "role-id": "${level-70-role-id}" },
        { level: 80, "role-id": "${level-80-role-id}" },
      ] },
      { file: "modules/discord-levels.yml", path: "commands.rank", value: "rank" },
      { file: "modules/discord-levels.yml", path: "commands.leaderboard", value: "levels" },
      { file: "modules/discord-levels.yml", path: "commands.prefix-rank", value: "!rank" },
      { file: "modules/tickets.yml", path: "enabled", value: "${feature-tickets}" },
      { file: "modules/tickets.yml", path: "channel-mode", value: "CHANNEL" },
      { file: "modules/tickets.yml", path: "require-linked-account", value: false },
      { file: "modules/tickets.yml", path: "panel.channel-id", value: "${ticket-panel-channel-id}" },
      { file: "modules/tickets.yml", path: "panel.publish-on-startup", value: true },
      { file: "modules/tickets.yml", path: "panel.title", value: "${ticket-panel-title}" },
      { file: "modules/tickets.yml", path: "panel.description", value: "${ticket-panel-description}" },
      { file: "modules/tickets.yml", path: "max-open-per-user", value: "${ticket-maximum-open-per-user}" },
      { file: "modules/tickets.yml", path: "panel.footer", value: "Select one option below to open a private ticket" },
      { file: "modules/tickets.yml", path: "panel.type-ids", value: ["ban-appeal", "bug-report", "media-rank", "other"] },
      { file: "modules/tickets.yml", path: "logs.channel-id", value: "${ticket-log-channel-id}" },
      { file: "modules/tickets.yml", path: "staff-role-ids", value: ["${staff-role-id}"] },
      { file: "modules/tickets.yml", path: "types", value: {
        "ban-appeal": {
          enabled: "${ticket-ban-appeal-enabled}",
          label: "Ban Appeal",
          description: "Appeal a punishment issued on the Minecraft server.",
          emoji: "⚠️",
          "button-style": "DANGER",
          "channel-mode": "CHANNEL",
          "category-id": "${ban-appeal-category-id}",
          "parent-channel-id": "",
          "closed-category-id": "",
          "channel-name": "appeal-%id%-%discord_name%",
          "opening-message": "**%type_label% #%id%**\nOpened by <@%discord_user_id%>\n\n%form%",
          "require-linked-account": false,
          "staff-role-ids": ["${staff-role-id}"],
          fields: {
            "minecraft-name": { enabled: true, label: "Minecraft Username", style: "SHORT", required: true, "min-length": 1, "max-length": 32, placeholder: "Your in-game name" },
            punishment: { enabled: true, label: "Why were you banned?", style: "PARAGRAPH", required: true, "min-length": 3, "max-length": 700, placeholder: "Explain the punishment you received" },
            appeal: { enabled: true, label: "Why should we unban you?", style: "PARAGRAPH", required: true, "min-length": 10, "max-length": 1000, placeholder: "Explain why staff should reconsider the punishment" },
          },
        },
        "bug-report": {
          enabled: "${ticket-bug-report-enabled}",
          label: "Bug Report",
          description: "Report a reproducible server or gameplay issue.",
          emoji: "🐛",
          "button-style": "PRIMARY",
          "channel-mode": "CHANNEL",
          "category-id": "${bug-report-category-id}",
          "parent-channel-id": "",
          "closed-category-id": "",
          "channel-name": "bug-%id%-%discord_name%",
          "opening-message": "**%type_label% #%id%**\nOpened by <@%discord_user_id%>\n\n%form%",
          "require-linked-account": false,
          "staff-role-ids": ["${staff-role-id}"],
          fields: {
            "minecraft-name": { enabled: true, label: "Minecraft Username", style: "SHORT", required: true, "min-length": 1, "max-length": 32, placeholder: "Your in-game name" },
            "minecraft-version": { enabled: true, label: "Minecraft Version", style: "SHORT", required: true, "min-length": 1, "max-length": 32, placeholder: "Example: 1.21.8" },
            description: { enabled: true, label: "Bug Report", style: "PARAGRAPH", required: true, "min-length": 10, "max-length": 1000, placeholder: "What happened and how can staff reproduce it?" },
          },
        },
        "media-rank": {
          enabled: "${ticket-media-rank-enabled}",
          label: "Media Rank",
          description: "Apply for a creator/media rank.",
          emoji: "🎥",
          "button-style": "SUCCESS",
          "channel-mode": "CHANNEL",
          "category-id": "${other-ticket-category-id}",
          "parent-channel-id": "",
          "closed-category-id": "",
          "channel-name": "media-%id%-%discord_name%",
          "opening-message": "**%type_label% #%id%**\nOpened by <@%discord_user_id%>\n\n%form%",
          "require-linked-account": false,
          "staff-role-ids": ["${staff-role-id}"],
          fields: {
            "minecraft-name": { enabled: true, label: "Minecraft Username", style: "SHORT", required: true, "min-length": 1, "max-length": 32, placeholder: "Your in-game name" },
            platform: { enabled: true, label: "Platform", style: "SHORT", required: true, "min-length": 2, "max-length": 80, placeholder: "YouTube, TikTok, Twitch, Instagram..." },
            profile: { enabled: true, label: "Channel / Profile", style: "SHORT", required: true, "min-length": 3, "max-length": 200, placeholder: "Link or account name" },
            evidence: { enabled: true, label: "Which requirement do you meet?", style: "PARAGRAPH", required: true, "min-length": 10, "max-length": 1000, placeholder: "Include the relevant views/viewer statistics" },
          },
        },
        other: {
          enabled: "${ticket-other-enabled}",
          label: "Other",
          description: "Open a ticket for anything that does not fit another category.",
          emoji: "📨",
          "button-style": "SECONDARY",
          "channel-mode": "CHANNEL",
          "category-id": "${other-ticket-category-id}",
          "parent-channel-id": "",
          "closed-category-id": "",
          "channel-name": "other-%id%-%discord_name%",
          "opening-message": "**%type_label% #%id%**\nOpened by <@%discord_user_id%>\n\n%form%",
          "require-linked-account": false,
          "staff-role-ids": ["${staff-role-id}"],
          fields: {
            "minecraft-name": { enabled: true, label: "Minecraft Username", style: "SHORT", required: false, "min-length": 0, "max-length": 32, placeholder: "Your in-game name (if relevant)" },
            subject: { enabled: true, label: "Subject", style: "SHORT", required: true, "min-length": 3, "max-length": 100, placeholder: "What do you need help with?" },
            description: { enabled: true, label: "Describe your request", style: "PARAGRAPH", required: true, "min-length": 10, "max-length": 1000, placeholder: "Give staff the details they need to help you" },
          },
        },
      } },
    ],
  },
});

export function listPresets(): Record<string, unknown>[] {
  return Object.values(PRESETS).map(publicPreset);
}

export function getPreset(id: string): PresetDefinition {
  const normalized = id.trim().toLowerCase();
  if (!/^[a-z0-9][a-z0-9._-]{1,63}$/u.test(normalized)) throw new HttpError(400, "Invalid preset ID");
  const preset = PRESETS[normalized];
  if (!preset) throw new HttpError(404, "Preset not found");
  return preset;
}

export function publicPreset(preset: PresetDefinition): Record<string, unknown> {
  return {
    id: preset.id,
    name: preset.name,
    summary: preset.summary,
    description: preset.description,
    version: preset.version,
    minimumCoreDSC: preset.minimumCoreDSC,
    verified: preset.verified,
    author: preset.author,
    tags: preset.tags,
    requiredVariables: preset.requiredVariables,
    packageUrl: `/v1/presets/${preset.id}/package`,
    available: true,
  };
}

export function packagePayload(preset: PresetDefinition): string {
  return JSON.stringify({
    format: 1,
    id: preset.id,
    version: preset.version,
    minimumCoreDSC: preset.minimumCoreDSC,
    verified: preset.verified,
    author: preset.author,
    requiredVariables: preset.requiredVariables,
    changes: preset.changes,
  });
}

export async function sha256Hex(value: string): Promise<string> {
  const data = new TextEncoder().encode(value);
  const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", data));
  return [...digest].map((byte) => byte.toString(16).padStart(2, "0")).join("");
}
