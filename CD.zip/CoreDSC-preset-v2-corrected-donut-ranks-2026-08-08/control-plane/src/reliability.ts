export const DISPATCH_LEASE_MILLIS = 120_000;

export function utf8ByteLength(value: string): number {
  return new TextEncoder().encode(value).byteLength;
}

export function dispatchLeaseExpired(attemptedAt: number | null | undefined, now = Date.now()): boolean {
  return !attemptedAt || attemptedAt <= now - DISPATCH_LEASE_MILLIS;
}

export function retryableResult(value: unknown): boolean {
  if (!value || typeof value !== "object" || Array.isArray(value)) return false;
  const error = (value as Record<string, unknown>).error;
  return Boolean(error && typeof error === "object" && !Array.isArray(error)
    && (error as Record<string, unknown>).retryable === true);
}

export function networkRolloutKey(rolloutId: string, instanceId: string): string {
  return `network-rollout:${rolloutId}:${instanceId}`;
}

export function canonicalJson(value: unknown): string {
  if (value === null || typeof value === "boolean" || typeof value === "string") return JSON.stringify(value);
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new TypeError("Only finite JSON numbers are supported");
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(",")}]`;
  if (value && typeof value === "object") {
    const entries = Object.entries(value as Record<string, unknown>)
      .filter(([, child]) => child !== undefined)
      .sort(([left], [right]) => left.localeCompare(right));
    return `{${entries.map(([key, child]) => `${JSON.stringify(key)}:${canonicalJson(child)}`).join(",")}}`;
  }
  throw new TypeError("Unsupported value in canonical JSON");
}

export function operationFingerprintInput(
  operation: string,
  payload: Record<string, unknown>,
  reason: string,
): string {
  return canonicalJson({ operation, payload, reason });
}
