import type { Env, SessionUser, StaffRole } from "./types.ts";
import { cookie, HttpError, sha256 } from "./security.ts";

interface SessionRow {
  session_id: string;
  discord_user_id: string;
  username: string;
  display_name: string;
  avatar: string | null;
  csrf_hash: string;
}

interface GrantRow {
  role: StaffRole;
}

export async function requireSession(request: Request, env: Env): Promise<SessionUser> {
  const token = cookie(request, "__Host-coredsc_session");
  if (!token || token.length > 128) throw new HttpError(401, "Sign in with Discord to continue");
  const tokenHash = await sha256(token);
  const now = Date.now();
  const row = await env.COREDSC_DB.prepare(
    `SELECT s.id AS session_id, s.discord_user_id, s.csrf_hash,
            u.username, u.display_name, u.avatar
       FROM sessions s
       JOIN users u ON u.discord_user_id=s.discord_user_id
      WHERE s.token_hash=? AND s.expires_at>?`,
  ).bind(tokenHash, now).first<SessionRow>();
  if (!row) throw new HttpError(401, "Session expired; sign in with Discord again");
  return {
    id: row.discord_user_id,
    username: row.username,
    displayName: row.display_name,
    avatar: row.avatar,
    sessionId: row.session_id,
    csrfHash: row.csrf_hash,
  };
}

export async function requireCsrf(request: Request, env: Env, user: SessionUser): Promise<void> {
  const token = request.headers.get("X-CoreDSC-CSRF") ?? "";
  if (token.length < 32 || token.length > 128 || await sha256(token) !== user.csrfHash) {
    throw new HttpError(403, "Invalid CSRF token; refresh the dashboard and try again");
  }
  const origin = request.headers.get("Origin");
  if (origin !== env.APP_ORIGIN) throw new HttpError(403, "Untrusted request origin");
}

export async function requireGrant(
  env: Env,
  instanceId: string,
  discordUserId: string,
): Promise<StaffRole> {
  const row = await env.COREDSC_DB.prepare(
    `SELECT role FROM grants
      WHERE instance_id=? AND discord_user_id=? AND revoked_at IS NULL`,
  ).bind(instanceId, discordUserId).first<GrantRow>();
  if (!row) throw new HttpError(403, "You do not have access to this CoreDSC server");
  return row.role;
}

export async function readJson<T extends Record<string, unknown>>(
  request: Request,
  maximumBytes = 131_072,
): Promise<T> {
  const contentType = request.headers.get("Content-Type")?.toLowerCase() ?? "";
  if (!contentType.startsWith("application/json")) {
    throw new HttpError(415, "Content-Type must be application/json");
  }
  const bytes = await readBytes(request, maximumBytes);
  let text: string;
  try {
    text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    throw new HttpError(400, "Request body must be valid UTF-8 JSON");
  }
  try {
    const parsed: unknown = JSON.parse(text);
    if (!parsed || Array.isArray(parsed) || typeof parsed !== "object") {
      throw new HttpError(400, "Expected a JSON object");
    }
    return parsed as T;
  } catch (error) {
    if (error instanceof HttpError) throw error;
    throw new HttpError(400, "Malformed JSON request");
  }
}

export async function readBytes(request: Request, maximumBytes: number): Promise<Uint8Array> {
  if (!Number.isSafeInteger(maximumBytes) || maximumBytes < 1) {
    throw new Error("Invalid byte limit");
  }
  const declared = Number(request.headers.get("Content-Length") ?? "0");
  if (Number.isFinite(declared) && declared > maximumBytes) {
    throw new HttpError(413, "Request is too large");
  }
  if (!request.body) return new Uint8Array();

  const reader = request.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maximumBytes) {
        await reader.cancel("Request is too large");
        throw new HttpError(413, "Request is too large");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }

  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    bytes.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return bytes;
}

export function safeText(value: unknown, maximum: number, field: string, required = false): string {
  const text = typeof value === "string" ? value.trim() : "";
  if (required && !text) throw new HttpError(400, `${field} is required`);
  if (text.length > maximum || /[\u0000\r\n]/u.test(text)) {
    throw new HttpError(400, `${field} is invalid or exceeds ${maximum} characters`);
  }
  return text;
}

export function uuid(value: unknown, field: string): string {
  const text = safeText(value, 64, field, true).toLowerCase();
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/u.test(text)) {
    throw new HttpError(400, `${field} must be a UUID`);
  }
  return text;
}

export function json(value: unknown): string {
  return JSON.stringify(value ?? {});
}


export async function enforceRateLimit(
  request: Request,
  env: Env,
  scope: string,
  identity: string,
  maximum: number,
  windowMillis: number,
): Promise<void> {
  if (!Number.isSafeInteger(maximum) || maximum < 1 || !Number.isSafeInteger(windowMillis) || windowMillis < 1_000) {
    throw new Error("Invalid rate-limit policy");
  }
  const now = Date.now();
  const windowStart = Math.floor(now / windowMillis) * windowMillis;
  const ip = request.headers.get("CF-Connecting-IP") ?? request.headers.get("X-Forwarded-For")?.split(",", 1)[0]?.trim() ?? "unknown";
  const bucket = `${scope}:${await sha256(`${identity}:${ip}`)}`;
  const row = await env.COREDSC_DB.prepare(
    `INSERT INTO rate_limits(bucket,window_start,request_count,expires_at) VALUES (?,?,1,?)
     ON CONFLICT(bucket,window_start) DO UPDATE SET request_count=request_count+1
     RETURNING request_count`,
  ).bind(bucket, windowStart, windowStart + windowMillis * 2).first<{ request_count: number }>();
  if (!row) throw new HttpError(503, "Rate-limit state could not be persisted");
  if (row.request_count > maximum) {
    throw new HttpError(429, "Too many requests; wait before trying again");
  }
}

export function responseJson(value: unknown, status = 200, headers?: HeadersInit): Response {
  const responseHeaders = new Headers(headers);
  responseHeaders.set("Content-Type", "application/json; charset=utf-8");
  responseHeaders.set("Cache-Control", "no-store");
  responseHeaders.set("X-Content-Type-Options", "nosniff");
  return new Response(JSON.stringify(value), { status, headers: responseHeaders });
}
