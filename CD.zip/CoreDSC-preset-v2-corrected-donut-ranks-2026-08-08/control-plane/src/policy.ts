import type { StaffRole } from "./types.ts";

const ROLE_CAPABILITIES: Record<StaffRole, ReadonlySet<string>> = {
  OWNER: new Set(["*"]),
  SERVER_ADMIN: new Set([
    "server.view", "server.manage", "config.view", "config.edit", "config.apply", "preset.view", "preset.manage", "ticket.view", "ticket.manage",
    "staff.view", "moderation.view", "moderation.manage", "case.manage", "channel.view", "channel.manage",
    "incident.view", "incident.manage", "maintenance.view", "maintenance.manage",
    "event.view", "event.manage", "approval.view", "approval.decide", "automod.view",
    "automod.manage", "network.view", "network.manage", "console.view",
  ]),
  MODERATOR: new Set([
    "server.view", "moderation.view", "moderation.manage", "case.manage", "ticket.view", "ticket.manage", "channel.view", "channel.manage",
    "incident.view", "incident.manage", "approval.view", "console.view",
  ]),
  CONSOLE_VIEWER: new Set(["server.view", "console.view", "incident.view"]),
  CONSOLE_OPERATOR: new Set([
    "server.view", "console.view", "console.execute", "incident.view", "maintenance.view",
  ]),
  SUPPORT: new Set(["server.view", "moderation.view", "case.manage", "ticket.view", "ticket.manage"]),
  VIEWER: new Set(["server.view", "config.view", "preset.view", "ticket.view", "moderation.view", "channel.view", "incident.view"]),
};

const OPERATION_CAPABILITY: Readonly<Record<string, string>> = Object.freeze({
  "health.snapshot": "server.view",
  "setup.doctor": "server.manage",
  "setup.createChannels": "server.manage",
  "discord.guilds": "config.view",
  "discord.channels": "config.view",
  "config.snapshot": "config.view",
  "config.validate": "config.edit",
  "config.patch": "config.edit",
  "config.apply": "config.apply",
  "preset.browse": "preset.view",
  "preset.list": "preset.view",
  "preset.status": "preset.view",
  "preset.enable": "preset.manage",
  "preset.disable": "preset.manage",
  "preset.preview": "preset.manage",
  "preset.apply": "preset.manage",
  "preset.repair": "preset.manage",
  "preset.install": "preset.manage",
  "preset.update": "preset.manage",
  "preset.remove": "preset.manage",
  "preset.reload": "preset.manage",
  "ticket.snapshot": "ticket.view",
  "ticket.publish": "ticket.manage",
  "ticket.reload": "ticket.manage",
  "ticket.panel.update": "ticket.manage",
  "ticket.type.upsert": "ticket.manage",
  "ticket.type.remove": "ticket.manage",
  "ticket.field.upsert": "ticket.manage",
  "ticket.field.remove": "ticket.manage",
  "media.install": "config.edit",
  "moderation.ban": "moderation.manage",
  "moderation.unban": "moderation.manage",
  "moderation.kick": "moderation.manage",
  "moderation.timeout": "moderation.manage",
  "moderation.warn": "moderation.manage",
  "moderation.history": "moderation.view",
  "moderation.note": "case.manage",
  "channel.snapshot": "channel.view",
  "channel.lock": "channel.manage",
  "channel.unlock": "channel.manage",
  "channel.slowmode": "channel.manage",
  "channel.slowmode.restore": "channel.manage",
  "channel.purge": "channel.manage",
  "channel.hide": "channel.manage",
  "channel.reveal": "channel.manage",
  "incident.status": "incident.view",
  "incident.start": "incident.manage",
  "incident.resolve": "incident.manage",
  "maintenance.status": "maintenance.view",
  "maintenance.start": "maintenance.manage",
  "maintenance.cancel": "maintenance.manage",
  "event.list": "event.view",
  "event.create": "event.manage",
  "event.cancel": "event.manage",
  "automod.rules": "automod.view",
  "automod.upsert": "automod.manage",
  "automod.delete": "automod.manage",
  "network.snapshot": "network.view",
  "network.announce": "network.manage",
  "network.template.validate": "network.manage",
  "network.template.apply": "network.manage",
  "console.snapshot": "console.view",
  "console.execute": "console.execute",
});

const ALWAYS_APPROVAL = new Set([
  "channel.purge",
  "console.execute",
  "network.template.apply",
]);

export function lookupOperationCapability(operation: string): string | undefined {
  return OPERATION_CAPABILITY[operation];
}

export function roleHas(role: StaffRole, capability: string): boolean {
  const values = ROLE_CAPABILITIES[role];
  return values.has("*") || values.has(capability);
}

export function operationNeedsApproval(operation: string, payload: Record<string, unknown>): boolean {
  if (ALWAYS_APPROVAL.has(operation)) return true;
  if (operation === "moderation.ban") {
    const duration = String(payload.duration ?? "").trim().toLowerCase();
    return duration === "permanent" || duration === "perm" || duration === "forever" || duration === "0";
  }
  if (operation === "incident.start") return payload.scope === "network";
  return false;
}

export function allCapabilities(role: StaffRole): string[] {
  return [...ROLE_CAPABILITIES[role]].sort();
}
