import { existsSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const required = { major: 22, minor: 13 };
const [major, minor] = process.versions.node.split(".").map(Number);
const supported = major > required.major || (major === required.major && minor >= required.minor);

if (!supported) {
  console.error(`CoreDSC control-plane tests require Node.js 22.13.0 or newer. Current version: ${process.version}`);
  console.error("Install a supported Node.js version, remove node_modules, run npm ci, then run npm run check again.");
  process.exit(1);
}

const scriptDirectory = dirname(fileURLToPath(import.meta.url));
const projectRoot = dirname(scriptDirectory);
for (const relativePath of ["src/index.ts", "tests", "tsconfig.json"]) {
  if (!existsSync(join(projectRoot, relativePath))) {
    console.error(`Control-plane source is incomplete: missing ${relativePath}`);
    process.exit(1);
  }
}

console.log(`Environment check passed (${process.version}).`);
