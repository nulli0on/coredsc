import { readdirSync } from "node:fs";
import { dirname, join } from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const scriptDirectory = dirname(fileURLToPath(import.meta.url));
const projectRoot = dirname(scriptDirectory);
const testsDirectory = join(projectRoot, "tests");
const testFiles = readdirSync(testsDirectory)
  .filter((name) => name.endsWith(".test.ts"))
  .sort()
  .map((name) => join(testsDirectory, name));

if (testFiles.length === 0) {
  console.error("No control-plane test files were found.");
  process.exit(1);
}

const result = spawnSync(process.execPath, [
  "--experimental-strip-types",
  "--test",
  "--test-concurrency=1",
  ...testFiles,
], {
  cwd: projectRoot,
  env: process.env,
  stdio: "inherit",
});

if (result.error) {
  console.error(`Could not start the control-plane test runner: ${result.error.message}`);
  process.exit(1);
}

process.exit(result.status ?? 1);
