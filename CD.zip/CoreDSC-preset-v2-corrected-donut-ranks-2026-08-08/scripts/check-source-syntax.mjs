import { execFileSync } from "node:child_process";
import { readdir, readFile } from "node:fs/promises";
import { extname, join, resolve } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

async function loadTypeScript() {
  try {
    return await import("typescript");
  } catch (localError) {
    const candidates = [];
    if (process.env.COREDSC_TYPESCRIPT_MODULE) {
      candidates.push(process.env.COREDSC_TYPESCRIPT_MODULE);
    }
    try {
      const globalRoot = execFileSync("npm", ["root", "-g"], { encoding: "utf8" }).trim();
      if (globalRoot) candidates.push(join(globalRoot, "typescript/lib/typescript.js"));
    } catch {
      // npm may be unavailable in stripped-down validation environments.
    }
    for (const candidate of candidates) {
      try {
        return await import(candidate.startsWith("file:") ? candidate : pathToFileURL(candidate).href);
      } catch {
        // Try the next explicit/global candidate before reporting the original failure.
      }
    }
    throw new Error("TypeScript is unavailable. Run npm ci or set COREDSC_TYPESCRIPT_MODULE.", { cause: localError });
  }
}

async function collect(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) files.push(...await collect(path));
    else if ([".ts", ".tsx"].includes(extname(entry.name))) files.push(path);
  }
  return files;
}

const tsModule = await loadTypeScript();
const ts = tsModule.default ?? tsModule;
const root = resolve(fileURLToPath(new URL("..", import.meta.url)));
const files = [...await collect(join(root, "app")), ...await collect(join(root, "worker"))].sort();
const failures = [];

for (const file of files) {
  const source = await readFile(file, "utf8");
  const result = ts.transpileModule(source, {
    fileName: file,
    reportDiagnostics: true,
    compilerOptions: {
      jsx: ts.JsxEmit.ReactJSX,
      module: ts.ModuleKind.ESNext,
      target: ts.ScriptTarget.ES2022,
      isolatedModules: true,
    },
  });
  for (const diagnostic of result.diagnostics ?? []) {
    if (diagnostic.category !== ts.DiagnosticCategory.Error) continue;
    failures.push(`${file}: ${ts.flattenDiagnosticMessageText(diagnostic.messageText, "\n")}`);
  }
}

if (failures.length > 0) {
  console.error(failures.join("\n"));
  process.exitCode = 1;
} else {
  console.log(`TypeScript/TSX syntax check passed for ${files.length} dashboard and Worker files.`);
}
