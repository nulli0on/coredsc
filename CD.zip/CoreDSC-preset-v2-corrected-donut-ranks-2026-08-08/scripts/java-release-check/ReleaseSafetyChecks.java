package com.hubertstudios.coredsc.cloud;

import com.hubertstudios.coredsc.scripting.MiniJson;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.Executors;

public final class ReleaseSafetyChecks {
    private ReleaseSafetyChecks() { }

    public static void main(String[] arguments) throws Exception {
        checkMiniJson();
        checkRequestFingerprint();
        checkTextFrames();
        checkIdentity();
        checkMediaStore();
        System.out.println("Java release safety checks passed.");
    }

    private static void checkMiniJson() {
        Map<String, Object> original = new LinkedHashMap<>();
        original.put("message", "CoreDSC 😀\nrelease");
        original.put("values", java.util.Arrays.asList(1L, true, null));
        check(original.equals(MiniJson.parseObject(MiniJson.write(original))), "MiniJson round trip failed");

        expectFailure(() -> MiniJson.parse("{\"role\":\"OWNER\",\"role\":\"VIEWER\"}"), "duplicate JSON key");
        expectFailure(() -> MiniJson.parse("{\"line\":\"first\nsecond\"}"), "raw JSON control character");
        expectFailure(() -> MiniJson.parse("1e9999"), "non-finite JSON number");
        expectFailure(() -> MiniJson.parse("[".repeat(66) + "0" + "]".repeat(66)), "deep JSON nesting");
        expectFailure(() -> MiniJson.parse("\"\\ud800\""), "unpaired JSON surrogate");

        List<Object> cycle = new ArrayList<>();
        cycle.add(cycle);
        expectFailure(() -> MiniJson.write(cycle), "cyclic JSON output");
    }


    private static void checkRequestFingerprint() {
        Map<String, Object> first = new LinkedHashMap<>();
        first.put("target", "Steve");
        first.put("details", Map.of("duration", "7d", "silent", false));
        first.put("nullable", null);
        first.put("list", java.util.Arrays.asList("a", null, "b"));
        Map<String, Object> second = new LinkedHashMap<>();
        second.put("nullable", null);
        second.put("list", java.util.Arrays.asList("a", null, "b"));
        second.put("details", Map.of("silent", false, "duration", "7d"));
        second.put("target", "Steve");

        String baseline = CloudRequestFingerprint.calculate(
                "moderation.ban", first, "Reviewed sanction");
        check(baseline.equals(CloudRequestFingerprint.calculate(
                "moderation.ban", second, "Reviewed sanction")),
                "request fingerprint changed with object key order");
        check(!baseline.equals(CloudRequestFingerprint.calculate(
                "moderation.ban", second, "Different reason")),
                "request fingerprint did not bind the audit reason");
        check(!baseline.equals(CloudRequestFingerprint.calculate(
                "moderation.warn", second, "Reviewed sanction")),
                "request fingerprint did not bind the operation");
    }

    private static void checkTextFrames() {
        check(CloudProtocolLimits.utf8Length("abc") == 3, "ASCII UTF-8 length failed");
        check(CloudProtocolLimits.utf8Length("😀") == 4, "surrogate-pair UTF-8 length failed");
        String malformed = "x" + '\ud800' + "y";
        check(CloudProtocolLimits.utf8Length(malformed)
                        == malformed.getBytes(StandardCharsets.UTF_8).length,
                "unpaired-surrogate UTF-8 length diverged from Java encoding");

        CloudTextFrameAssembler assembler = new CloudTextFrameAssembler(64);
        String emoji = "😀";
        check(assembler.append("old-", false) == null, "first fragment unexpectedly completed");
        assembler.reset();
        check(assembler.append("{\"emoji\":\"" + emoji.charAt(0), false) == null,
                "surrogate fragment unexpectedly completed");
        check("{\"emoji\":\"😀\"}".equals(assembler.append(emoji.substring(1) + "\"}", true)),
                "fragment reassembly failed");

        CloudTextFrameAssembler bounded = new CloudTextFrameAssembler(4);
        check("😀".equals(bounded.append("😀", true)), "exact UTF-8 limit was rejected");
        expectFailure(() -> bounded.append("abcde", true), "oversized WebSocket message");
        check("ok".equals(bounded.append("ok", true)), "assembler did not reset after rejection");
    }


    private static void checkIdentity() throws Exception {
        Path temporary = Files.createTempDirectory("coredsc-release-identity-");
        try {
            CloudIdentity first = CloudIdentity.loadOrCreate(temporary);
            CloudIdentity second = CloudIdentity.loadOrCreate(temporary);
            check(first.instanceId().equals(second.instanceId()), "cloud identity changed after reload");
            check(first.publicKeyBase64().equals(second.publicKeyBase64()), "cloud public key changed after reload");

            String message = "CoreDSC 3.4.2 identity test";
            byte[] publicBytes = Base64.getUrlDecoder().decode(first.publicKeyBase64());
            var publicKey = java.security.KeyFactory.getInstance("Ed25519")
                    .generatePublic(new java.security.spec.X509EncodedKeySpec(publicBytes));
            java.util.Arrays.fill(publicBytes, (byte) 0);
            var verifier = java.security.Signature.getInstance("Ed25519");
            verifier.initVerify(publicKey);
            verifier.update(message.getBytes(StandardCharsets.UTF_8));
            check(verifier.verify(Base64.getUrlDecoder().decode(first.sign(message))),
                    "cloud identity signature did not verify");

            Path symlinkRoot = temporary.resolve("symlink-case");
            Path state = symlinkRoot.resolve("state");
            Files.createDirectories(state);
            Path outside = temporary.resolve("identity-outside.properties");
            Files.writeString(outside, "format=1\n");
            Files.createSymbolicLink(state.resolve("cloud-identity.properties"), outside);
            expectIOException(() -> CloudIdentity.loadOrCreate(symlinkRoot), "symlink cloud identity");

            Path oversizedRoot = temporary.resolve("oversized-case");
            Files.createDirectories(oversizedRoot.resolve("state"));
            Files.write(oversizedRoot.resolve("state/cloud-identity.properties"), new byte[8_193]);
            expectIOException(() -> CloudIdentity.loadOrCreate(oversizedRoot), "oversized cloud identity");
        } finally {
            try (var paths = Files.walk(temporary)) {
                paths.sorted(java.util.Comparator.reverseOrder()).forEach(path -> {
                    try {
                        Files.deleteIfExists(path);
                    } catch (java.io.IOException error) {
                        throw new IllegalStateException(error);
                    }
                });
            }
        }
    }

    private static void checkMediaStore() throws Exception {
        Path temporary = Files.createTempDirectory("coredsc-release-media-");
        try {
            Path root = temporary.resolve("media");
            CloudMediaStore store = new CloudMediaStore(root);
            byte[] png = png();
            Map<String, Object> installed = store.install(payload("image/png", "png", png));
            String reference = String.valueOf(installed.get("reference"));
            Path stored = store.resolve(reference).orElseThrow().path();
            check(java.util.Arrays.equals(png, Files.readAllBytes(stored)), "stored media differs from input");

            try (var executor = Executors.newFixedThreadPool(8)) {
                List<Callable<String>> tasks = new ArrayList<>();
                for (int index = 0; index < 24; index++) {
                    tasks.add(() -> String.valueOf(store.install(payload("image/png", "png", png)).get("reference")));
                }
                for (var future : executor.invokeAll(tasks)) {
                    check(reference.equals(future.get()), "concurrent media install was not idempotent");
                }
            }

            Files.write(stored, new byte[] {(byte) 0x89, 0x50, 0x4e, 0x47, 0, 0, 0, 0});
            check(store.resolve(reference).isEmpty(), "tampered media was resolved");
            expectFailure(() -> store.install(payload("image/png", "png", png)), "tampered existing media");

            Path symlinkRoot = temporary.resolve("symlink-media");
            Files.createDirectories(symlinkRoot);
            String digest = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(png));
            Path outside = temporary.resolve("outside.png");
            Files.write(outside, png);
            Files.createSymbolicLink(symlinkRoot.resolve(digest + ".png"), outside);
            CloudMediaStore symlinkStore = new CloudMediaStore(symlinkRoot);
            expectFailure(() -> symlinkStore.install(payload("image/png", "png", png)), "content-addressed symlink");

            List<MediaCase> formats = List.of(
                    new MediaCase("image/jpeg", "jpg", new byte[] {(byte) 0xff, (byte) 0xd8, 1, (byte) 0xff, (byte) 0xd9}),
                    new MediaCase("image/webp", "webp", "RIFF0000WEBP".getBytes(StandardCharsets.US_ASCII)),
                    new MediaCase("image/gif", "gif", "GIF89a".getBytes(StandardCharsets.US_ASCII)));
            CloudMediaStore formatStore = new CloudMediaStore(temporary.resolve("formats"));
            for (MediaCase format : formats) {
                String formatReference = String.valueOf(formatStore.install(payload(
                        format.mimeType(), format.extension(), format.bytes())).get("reference"));
                check(formatStore.resolve(formatReference).isPresent(), "valid " + format.mimeType() + " was rejected");
            }
        } finally {
            try (var paths = Files.walk(temporary)) {
                paths.sorted(java.util.Comparator.reverseOrder()).forEach(path -> {
                    try {
                        Files.deleteIfExists(path);
                    } catch (java.io.IOException error) {
                        throw new IllegalStateException(error);
                    }
                });
            }
        }
    }

    private static Map<String, Object> payload(String mimeType, String extension, byte[] bytes) {
        return Map.of(
                "mimeType", mimeType,
                "extension", extension,
                "dataBase64", Base64.getEncoder().encodeToString(bytes));
    }

    private static byte[] png() {
        return new byte[] {
                (byte) 0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a,
                0x00, 0x01, 0x02, 0x03
        };
    }

    private static void expectIOException(ThrowingAction action, String description) {
        try {
            action.run();
            throw new AssertionError("Expected IOException: " + description);
        } catch (java.io.IOException expected) {
            // Expected rejection.
        } catch (Exception error) {
            throw new AssertionError("Unexpected exception for " + description, error);
        }
    }

    private static void expectFailure(ThrowingAction action, String description) {
        try {
            action.run();
            throw new AssertionError("Expected rejection: " + description);
        } catch (IllegalArgumentException | IllegalStateException expected) {
            // Expected rejection.
        } catch (Exception error) {
            throw new AssertionError("Unexpected exception for " + description, error);
        }
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }

    @FunctionalInterface
    private interface ThrowingAction {
        void run() throws Exception;
    }

    private record MediaCase(String mimeType, String extension, byte[] bytes) { }
}
