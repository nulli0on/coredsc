CoreDSC Python extensions
==========================

This folder is optional. CoreDSC works without Python extensions.

Files
-----
- config.yml: enables or disables the Python worker and selects the Python executable.
- scripts/: your optional command and event scripts.
- runtime/: files managed by CoreDSC. Do not edit these files manually.

Getting started
---------------
1. Open bot/config.yml.
2. Keep enabled: false until Python 3 is installed and your scripts are ready.
3. Copy an example from bot/scripts/ and edit the copy.
4. Enable the Python worker in bot/config.yml.
5. Run /coredsc reload and check /coredsc doctor.

Security
--------
Python scripts run as the same operating-system account as the Minecraft server.
Only install scripts you trust. Never place Discord tokens, private keys, database
files, or other secrets inside a script.

The hosted CoreDSC editor manages supported configuration files. It does not expose
or edit secrets.yml, databases, backups, private keys, or arbitrary files.
