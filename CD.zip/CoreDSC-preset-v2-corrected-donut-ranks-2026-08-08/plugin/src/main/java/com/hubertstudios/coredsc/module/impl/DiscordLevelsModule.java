package com.hubertstudios.coredsc.module.impl;

import com.hubertstudios.coredsc.CoreDSCPlugin;
import com.hubertstudios.coredsc.discord.DiscordBotService;
import com.hubertstudios.coredsc.levels.DiscordLevelSettings;
import com.hubertstudios.coredsc.module.CoreModule;
import com.hubertstudios.coredsc.module.DiscordCommandContributor;
import com.hubertstudios.coredsc.storage.DiscordLevelRepository;
import com.hubertstudios.coredsc.storage.SQLiteStorage;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.guild.member.GuildMemberJoinEvent;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.CommandData;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;

/** Persistent Discord activity XP, ranks, leaderboards and level milestone roles. */
public final class DiscordLevelsModule implements CoreModule, DiscordCommandContributor {
    private final CoreDSCPlugin plugin;
    private final AtomicBoolean active = new AtomicBoolean();
    private DiscordLevelSettings settings;
    private DiscordLevelRepository levels;
    private ListenerAdapter discordListener;

    public DiscordLevelsModule(CoreDSCPlugin plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
    }

    @Override public String id() { return "discord-levels"; }

    @Override
    public void enable() {
        SQLiteStorage storage = plugin.getStorage();
        if (storage == null || storage.getState() != SQLiteStorage.State.READY) {
            throw new IllegalStateException("SQLite storage is not ready");
        }
        DiscordBotService discord = plugin.getDiscordService();
        if (discord == null) throw new IllegalStateException("Discord service is not initialised");
        settings = DiscordLevelSettings.from(plugin.getAppConfig());
        levels = new DiscordLevelRepository(storage);
        active.set(true);
        discordListener = new ListenerAdapter() {
            @Override public void onMessageReceived(MessageReceivedEvent event) { handleMessage(event); }
            @Override public void onSlashCommandInteraction(SlashCommandInteractionEvent event) { handleSlash(event); }
            @Override public void onGuildMemberJoin(GuildMemberJoinEvent event) { handleMemberJoin(event); }
        };
        discord.addEventListener(discordListener);
    }

    @Override
    public void disable() {
        active.set(false);
        DiscordBotService discord = plugin.getDiscordService();
        if (discordListener != null && discord != null) discord.removeEventListener(discordListener);
        discordListener = null;
        levels = null;
        settings = null;
    }

    @Override public String statusDetail() {
        DiscordLevelSettings current = settings;
        return current == null ? "stopped" : "activity XP; max level=" + current.maximumLevel()
                + ", milestones=" + current.milestoneRoles().size();
    }

    @Override
    public List<CommandData> slashCommands() {
        DiscordLevelSettings current = settings;
        String rank = current == null ? "rank" : current.rankCommand();
        String leaderboard = current == null ? "levels" : current.leaderboardCommand();
        return List.of(
                Commands.slash(rank, "Show Discord activity rank")
                        .addOptions(new OptionData(OptionType.USER, "user", "User to inspect", false)),
                Commands.slash(leaderboard, "Show the Discord activity leaderboard")
        );
    }

    private void handleMessage(MessageReceivedEvent event) {
        DiscordLevelSettings current = settings;
        DiscordLevelRepository repository = levels;
        if (!active.get() || current == null || repository == null || !event.isFromGuild()
                || event.getGuild().getIdLong() != current.guildId()) return;
        if (event.getAuthor().isBot() || event.isWebhookMessage()) return;
        Member member = event.getMember();
        if (member == null) return;
        String raw = event.getMessage().getContentRaw().trim();
        if (!current.prefixRankCommand().isBlank() && raw.equalsIgnoreCase(current.prefixRankCommand())) {
            sendRankMessage(event, event.getAuthor(), false);
            return;
        }
        if (current.ignoredChannelIds().contains(event.getChannel().getIdLong())) return;
        if (member.getRoles().stream().map(Role::getIdLong).anyMatch(current.ignoredRoleIds()::contains)) return;
        String meaningful = event.getMessage().getContentDisplay().trim();
        if (meaningful.length() < current.minimumMessageLength()) return;
        int amount = ThreadLocalRandom.current().nextInt(current.minimumXp(), current.maximumXp() + 1);
        long now = System.currentTimeMillis();
        repository.awardIfEligible(event.getAuthor().getId(), now, current.awardWindowMillis(), amount, current::levelForXp)
                .whenComplete((result, error) -> {
                    if (!active.get()) return;
                    if (error != null) {
                        plugin.recordModuleFailure("discord-levels", error);
                        plugin.getLogger().log(Level.WARNING, "[DiscordLevels] Could not award XP", error);
                        return;
                    }
                    if (!result.awarded()) return;
                    plugin.recordFeatureUse("discord_level_xp_awarded");
                    // Reconcile on every eligible award, not only on a numeric level change.
                    // This repairs manual role drift and restores milestone roles after a restart
                    // without waiting for the member to cross another milestone.
                    reconcileRoles(member, result.after().level());
                    if (result.after().level() > result.before().level()) {
                        announceLevel(event, result.after().level());
                    }
                });
    }

    private void handleMemberJoin(GuildMemberJoinEvent event) {
        DiscordLevelSettings current = settings;
        DiscordLevelRepository repository = levels;
        if (!active.get() || current == null || repository == null
                || event.getGuild().getIdLong() != current.guildId()) return;
        repository.find(event.getUser().getId()).whenComplete((state, error) -> {
            if (!active.get()) return;
            if (error != null) {
                plugin.getLogger().log(Level.WARNING, "[DiscordLevels] Could not restore milestone roles for rejoining member", error);
                return;
            }
            state.ifPresent(value -> reconcileRoles(event.getMember(), value.level()));
        });
    }

    private void handleSlash(SlashCommandInteractionEvent event) {
        DiscordLevelSettings current = settings;
        if (!active.get() || current == null) return;
        if (!event.getName().equals(current.rankCommand()) && !event.getName().equals(current.leaderboardCommand())) return;
        if (event.getGuild() == null || event.getGuild().getIdLong() != current.guildId()) {
            event.reply("This levels system belongs to another Discord server.").setEphemeral(true).queue();
            return;
        }
        if (event.getName().equals(current.rankCommand())) {
            User target = event.getOption("user") == null ? event.getUser() : event.getOption("user").getAsUser();
            event.deferReply(current.ephemeralRank()).queue(hook -> levels.ranked(target.getId()).whenComplete((ranked, error) -> {
                if (error != null) hook.editOriginal("Could not load rank: " + rootMessage(error)).queue();
                else hook.editOriginalEmbeds(rankEmbed(target, ranked)).queue();
            }));
            return;
        }
        event.deferReply(false).queue(hook -> levels.leaderboard(current.leaderboardSize()).whenComplete((entries, error) -> {
            if (error != null) hook.editOriginal("Could not load leaderboard: " + rootMessage(error)).queue();
            else hook.editOriginalEmbeds(leaderboardEmbed(event.getJDA(), entries)).queue();
        }));
    }

    private void sendRankMessage(MessageReceivedEvent event, User target, boolean mention) {
        DiscordLevelRepository repository = levels;
        if (repository == null) return;
        repository.ranked(target.getId()).whenComplete((ranked, error) -> {
            if (!active.get()) return;
            if (error != null) {
                plugin.getLogger().log(Level.WARNING, "[DiscordLevels] Could not load !rank", error);
                return;
            }
            event.getChannel().sendMessageEmbeds(rankEmbed(target, ranked)).queue();
        });
    }

    private net.dv8tion.jda.api.entities.MessageEmbed rankEmbed(User target,
            Optional<DiscordLevelRepository.RankedState> ranked) {
        DiscordLevelSettings current = settings;
        DiscordLevelRepository.LevelState state = ranked.map(DiscordLevelRepository.RankedState::state)
                .orElse(new DiscordLevelRepository.LevelState(target.getId(), 0L, 0, 0L, 0L, 0L));
        int level = state.level();
        long start = current.xpForLevel(level);
        long next = current.xpForNextLevel(level);
        long within = Math.max(0L, state.xp() - start);
        long needed = Math.max(1L, next - start);
        int pct = level >= current.maximumLevel() ? 100 : (int) Math.min(100L, within * 100L / needed);
        String progress = progressBar(pct);
        String rank = ranked.map(value -> "#" + value.position()).orElse("Unranked");
        return new EmbedBuilder()
                .setTitle(target.getEffectiveName() + " — Activity Rank")
                .setThumbnail(target.getEffectiveAvatarUrl())
                .addField("Level", String.valueOf(level), true)
                .addField("Rank", rank, true)
                .addField("XP", String.format("%,d", state.xp()), true)
                .addField("Progress", progress + " **" + pct + "%**", false)
                .setColor(0x5865F2)
                .build();
    }

    private net.dv8tion.jda.api.entities.MessageEmbed leaderboardEmbed(JDA jda,
            List<DiscordLevelRepository.RankedState> entries) {
        StringBuilder text = new StringBuilder();
        for (DiscordLevelRepository.RankedState entry : entries) {
            User user = jda.getUserById(entry.state().discordUserId());
            String name = user == null ? "<@" + entry.state().discordUserId() + ">" : user.getEffectiveName();
            text.append('`').append(entry.position()).append(".` **").append(name).append("** — Level ")
                    .append(entry.state().level()).append(" · ").append(String.format("%,d", entry.state().xp())).append(" XP\n");
        }
        if (text.isEmpty()) text.append("No activity XP has been earned yet.");
        return new EmbedBuilder().setTitle("Discord Activity Leaderboard").setDescription(text.toString())
                .setColor(0x5865F2).build();
    }

    private void reconcileRoles(Member member, int level) {
        DiscordLevelSettings current = settings;
        if (current == null || current.milestoneRoles().isEmpty()) return;
        Guild guild = member.getGuild();
        if (!guild.getSelfMember().hasPermission(Permission.MANAGE_ROLES)) {
            plugin.getLogger().warning("[DiscordLevels] Cannot reconcile level roles: bot lacks Manage Roles");
            return;
        }
        Set<Long> desired = new LinkedHashSet<>();
        if (current.roleMode() == DiscordLevelSettings.RoleMode.CUMULATIVE) {
            current.milestoneRoles().forEach((milestone, roleId) -> { if (milestone <= level) desired.add(roleId); });
        } else {
            current.milestoneRoles().entrySet().stream().filter(entry -> entry.getKey() <= level)
                    .max(Map.Entry.comparingByKey()).ifPresent(entry -> desired.add(entry.getValue()));
        }
        Set<Long> configured = Set.copyOf(current.milestoneRoles().values());
        List<Role> add = new ArrayList<>();
        List<Role> remove = new ArrayList<>();
        for (Long roleId : configured) {
            Role role = guild.getRoleById(roleId);
            if (role == null) {
                plugin.getLogger().warning("[DiscordLevels] Configured milestone role no longer exists: " + roleId);
                continue;
            }
            boolean has = member.getRoles().contains(role);
            boolean wants = desired.contains(roleId);
            if (has == wants) continue;
            if (!guild.getSelfMember().canInteract(role)) {
                plugin.getLogger().warning("[DiscordLevels] Bot role is not above milestone role " + role.getName());
                continue;
            }
            if (wants) add.add(role); else remove.add(role);
        }
        if (add.isEmpty() && remove.isEmpty()) return;
        guild.modifyMemberRoles(member, add, remove).queue(
                ignored -> plugin.recordFeatureUse("discord_level_role_reconciled"),
                error -> plugin.getLogger().warning("[DiscordLevels] Could not reconcile milestone roles: " + rootMessage(error)));
    }

    private void announceLevel(MessageReceivedEvent event, int level) {
        DiscordLevelSettings current = settings;
        if (current == null || !current.announceLevelUp()) return;
        String message = current.levelUpMessage().replace("%discord_user_id%", event.getAuthor().getId())
                .replace("%level%", String.valueOf(level));
        if (current.announcementChannelId() > 0L) {
            TextChannel channel = event.getGuild().getTextChannelById(current.announcementChannelId());
            if (channel != null) channel.sendMessage(message).setAllowedMentions(List.of()).queue();
        } else {
            event.getChannel().sendMessage(message).setAllowedMentions(List.of()).queue();
        }
    }

    private static String progressBar(int percent) {
        int filled = Math.max(0, Math.min(10, percent / 10));
        return "█".repeat(filled) + "░".repeat(10 - filled);
    }

    private static String rootMessage(Throwable error) {
        Throwable current = error;
        while (current.getCause() != null) current = current.getCause();
        return current.getMessage() == null || current.getMessage().isBlank()
                ? current.getClass().getSimpleName() : current.getMessage();
    }
}
