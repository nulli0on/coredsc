package com.hubertstudios.coredsc.storage;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

/** Persists the Discord message backing each self-role panel without polluting configuration files. */
public final class SelfRolePanelRepository {
    public record PanelMessage(String panelId, String channelId, String messageId, long updatedAt) { }

    private final SQLiteStorage storage;

    public SelfRolePanelRepository(SQLiteStorage storage) {
        this.storage = Objects.requireNonNull(storage, "storage");
    }

    public CompletableFuture<Optional<PanelMessage>> find(String panelId) {
        return storage.execute(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT panel_id, channel_id, message_id, updated_at FROM self_role_panels WHERE panel_id=?")) {
                statement.setString(1, panelId);
                try (ResultSet result = statement.executeQuery()) {
                    if (!result.next()) return Optional.empty();
                    return Optional.of(new PanelMessage(result.getString("panel_id"), result.getString("channel_id"),
                            result.getString("message_id"), result.getLong("updated_at")));
                }
            }
        });
    }

    public CompletableFuture<List<PanelMessage>> findAll() {
        return storage.execute(connection -> {
            List<PanelMessage> values = new ArrayList<>();
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT panel_id, channel_id, message_id, updated_at FROM self_role_panels ORDER BY panel_id")) {
                try (ResultSet result = statement.executeQuery()) {
                    while (result.next()) {
                        values.add(new PanelMessage(result.getString("panel_id"), result.getString("channel_id"),
                                result.getString("message_id"), result.getLong("updated_at")));
                    }
                }
            }
            return List.copyOf(values);
        });
    }

    public CompletableFuture<Void> upsert(String panelId, String channelId, String messageId, long now) {
        return storage.execute(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO self_role_panels(panel_id, channel_id, message_id, updated_at) VALUES(?,?,?,?) "
                            + "ON CONFLICT(panel_id) DO UPDATE SET channel_id=excluded.channel_id, "
                            + "message_id=excluded.message_id, updated_at=excluded.updated_at")) {
                statement.setString(1, panelId);
                statement.setString(2, channelId);
                statement.setString(3, messageId);
                statement.setLong(4, now);
                statement.executeUpdate();
            }
            return null;
        });
    }

    public CompletableFuture<Void> delete(String panelId) {
        return storage.execute(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "DELETE FROM self_role_panels WHERE panel_id=?")) {
                statement.setString(1, panelId);
                statement.executeUpdate();
            }
            return null;
        });
    }
}
