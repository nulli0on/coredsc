package com.hubertstudios.coredsc.levels;

import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Immutable Discord activity-level configuration. */
public record DiscordLevelSettings(
        long guildId,
        long awardWindowMillis,
        int minimumXp,
        int maximumXp,
        int minimumMessageLength,
        Set<Long> ignoredChannelIds,
        Set<Long> ignoredRoleIds,
        int baseXp,
        double exponent,
        int maximumLevel,
        RoleMode roleMode,
        Map<Integer, Long> milestoneRoles,
        String rankCommand,
        String leaderboardCommand,
        String prefixRankCommand,
        boolean ephemeralRank,
        int leaderboardSize,
        boolean announceLevelUp,
        long announcementChannelId,
        String levelUpMessage
) {
    public enum RoleMode { HIGHEST_ONLY, CUMULATIVE }

    public static DiscordLevelSettings from(FileConfiguration config) {
        long guild = optionalSnowflake(config.get("discord-levels.guild-id"), "discord-levels.guild-id");
        if (guild == 0L) guild = optionalSnowflake(config.get("discord.guild-id"), "discord.guild-id");
        if (guild <= 0L) throw new IllegalArgumentException("discord-levels requires discord-levels.guild-id or discord.guild-id");
        long window = clamp(config.getLong("discord-levels.xp.award-window-seconds", 60L), 15L, 3_600L) * 1_000L;
        int minXp = (int) clamp(config.getLong("discord-levels.xp.minimum", 15L), 1L, 10_000L);
        int maxXp = (int) clamp(config.getLong("discord-levels.xp.maximum", 25L), 1L, 10_000L);
        if (minXp > maxXp) throw new IllegalArgumentException("discord-levels.xp.minimum cannot exceed maximum");
        int minLength = (int) clamp(config.getLong("discord-levels.xp.minimum-message-length", 3L), 0L, 500L);
        Set<Long> ignoredChannels = snowflakeSet(config.getList("discord-levels.xp.ignored-channel-ids"),
                "discord-levels.xp.ignored-channel-ids");
        Set<Long> ignoredRoles = snowflakeSet(config.getList("discord-levels.xp.ignored-role-ids"),
                "discord-levels.xp.ignored-role-ids");
        int baseXp = (int) clamp(config.getLong("discord-levels.curve.base-xp", 100L), 10L, 1_000_000L);
        double exponent = config.getDouble("discord-levels.curve.exponent", 1.6D);
        if (!Double.isFinite(exponent) || exponent < 1.0D || exponent > 4.0D) {
            throw new IllegalArgumentException("discord-levels.curve.exponent must be between 1.0 and 4.0");
        }
        int maximumLevel = (int) clamp(config.getLong("discord-levels.curve.maximum-level", 100L), 1L, 1_000L);
        RoleMode roleMode = enumValue(config.get("discord-levels.roles.mode"), RoleMode.class,
                RoleMode.HIGHEST_ONLY, "discord-levels.roles.mode");
        Map<Integer, Long> milestones = parseMilestones(config.getMapList("discord-levels.roles.milestones"), maximumLevel);
        String rankCommand = command(config.getString("discord-levels.commands.rank", "rank"),
                "discord-levels.commands.rank");
        String leaderboard = command(config.getString("discord-levels.commands.leaderboard", "levels"),
                "discord-levels.commands.leaderboard");
        if (rankCommand.equals(leaderboard)) throw new IllegalArgumentException("Discord level command names must be unique");
        String prefix = bounded(config.getString("discord-levels.commands.prefix-rank", "!rank"), 32,
                "discord-levels.commands.prefix-rank", false);
        boolean ephemeral = config.getBoolean("discord-levels.commands.rank-ephemeral", false);
        int size = (int) clamp(config.getLong("discord-levels.leaderboard.size", 10L), 3L, 25L);
        boolean announce = config.getBoolean("discord-levels.level-up.enabled", true);
        long announceChannel = optionalSnowflake(config.get("discord-levels.level-up.channel-id"),
                "discord-levels.level-up.channel-id");
        String message = bounded(config.getString("discord-levels.level-up.message",
                "🎉 <@%discord_user_id%> reached **Level %level%**!"), 1_000,
                "discord-levels.level-up.message", true);
        return new DiscordLevelSettings(guild, window, minXp, maxXp, minLength,
                ignoredChannels, ignoredRoles, baseXp, exponent, maximumLevel, roleMode,
                milestones, rankCommand, leaderboard, prefix, ephemeral, size,
                announce, announceChannel, message);
    }

    private static Map<Integer, Long> parseMilestones(List<Map<?, ?>> raw, int maximumLevel) {
        Map<Integer, Long> values = new LinkedHashMap<>();
        Set<Long> roles = new LinkedHashSet<>();
        int index = 0;
        for (Map<?, ?> item : raw) {
            String path = "discord-levels.roles.milestones[" + index++ + "]";
            int level;
            try {
                level = Integer.parseInt(String.valueOf(item.containsKey("level") ? item.get("level") : "0"));
            } catch (NumberFormatException error) {
                throw new IllegalArgumentException(path + ".level must be an integer", error);
            }
            if (level < 1 || level > maximumLevel) {
                throw new IllegalArgumentException(path + ".level must be between 1 and " + maximumLevel);
            }
            long role = requiredSnowflake(item.get("role-id"), path + ".role-id");
            if (values.putIfAbsent(level, role) != null) throw new IllegalArgumentException("Duplicate level milestone: " + level);
            if (!roles.add(role)) throw new IllegalArgumentException("A Discord role cannot be assigned to multiple level milestones");
        }
        return Collections.unmodifiableMap(new LinkedHashMap<>(values));
    }

    public int levelForXp(long xp) {
        if (xp <= 0L) return 0;
        int low = 0;
        int high = maximumLevel;
        while (low < high) {
            int mid = (low + high + 1) >>> 1;
            if (xp >= xpForLevel(mid)) low = mid;
            else high = mid - 1;
        }
        return low;
    }

    public long xpForLevel(int level) {
        if (level <= 0) return 0L;
        if (level > maximumLevel) level = maximumLevel;
        double value = baseXp * Math.pow(level, exponent);
        if (!Double.isFinite(value) || value >= Long.MAX_VALUE) return Long.MAX_VALUE;
        return Math.max(1L, Math.round(value));
    }

    public long xpForNextLevel(int level) {
        return level >= maximumLevel ? xpForLevel(maximumLevel) : xpForLevel(level + 1);
    }

    private static String command(String raw, String path) {
        String value = raw == null ? "" : raw.trim().toLowerCase(Locale.ROOT);
        if (!value.matches("[a-z0-9_-]{1,32}")) throw new IllegalArgumentException(path + " must match [a-z0-9_-]{1,32}");
        return value;
    }

    private static String bounded(String raw, int maximum, String path, boolean required) {
        String value = raw == null ? "" : raw.replace('\0', ' ').trim();
        if (required && value.isBlank()) throw new IllegalArgumentException(path + " is required");
        if (value.length() > maximum) throw new IllegalArgumentException(path + " exceeds " + maximum + " characters");
        return value;
    }

    private static long optionalSnowflake(Object raw, String path) {
        if (raw == null || String.valueOf(raw).trim().isBlank() || String.valueOf(raw).trim().equals("0")) return 0L;
        try {
            long value = Long.parseLong(String.valueOf(raw).trim());
            if (value <= 0L) throw new NumberFormatException();
            return value;
        } catch (NumberFormatException error) {
            throw new IllegalArgumentException(path + " must be a positive Discord ID or empty", error);
        }
    }

    private static long requiredSnowflake(Object raw, String path) {
        long value = optionalSnowflake(raw, path);
        if (value <= 0L) throw new IllegalArgumentException(path + " is required");
        return value;
    }

    private static Set<Long> snowflakeSet(List<?> raw, String path) {
        if (raw == null || raw.isEmpty()) return Set.of();
        Set<Long> values = new LinkedHashSet<>();
        for (Object item : raw) values.add(requiredSnowflake(item, path));
        return Set.copyOf(values);
    }

    private static <E extends Enum<E>> E enumValue(Object raw, Class<E> type, E fallback, String path) {
        String value = raw == null || String.valueOf(raw).isBlank()
                ? fallback.name() : String.valueOf(raw).trim().toUpperCase(Locale.ROOT).replace('-', '_');
        try {
            return Enum.valueOf(type, value);
        } catch (IllegalArgumentException error) {
            throw new IllegalArgumentException(path + " has unsupported value '" + raw + "'", error);
        }
    }

    private static long clamp(long value, long minimum, long maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}
