package com.hubertstudios.coredsc.module.impl;

import com.hubertstudios.coredsc.CoreDSCPlugin;
import com.hubertstudios.coredsc.api.CoreDSCApi;
import com.hubertstudios.coredsc.config.ConfigManager;
import com.hubertstudios.coredsc.discord.DiscordBotService;
import com.hubertstudios.coredsc.event.DiscordReadyEvent;
import com.hubertstudios.coredsc.event.TicketCloseEvent;
import com.hubertstudios.coredsc.event.TicketCreateEvent;
import com.hubertstudios.coredsc.module.CoreModule;
import com.hubertstudios.coredsc.module.DiscordCommandContributor;
import com.hubertstudios.coredsc.scripting.MiniJson;
import com.hubertstudios.coredsc.storage.LinkedAccountRepository;
import com.hubertstudios.coredsc.storage.LinkedAccountRepository.LinkedAccount;
import com.hubertstudios.coredsc.storage.SQLiteStorage;
import com.hubertstudios.coredsc.storage.SupportMessageRepository;
import com.hubertstudios.coredsc.storage.SupportMessageRepository.SupportMessage;
import com.hubertstudios.coredsc.storage.TicketRepository;
import com.hubertstudios.coredsc.storage.TicketRepository.ReserveStatus;
import com.hubertstudios.coredsc.storage.TicketRepository.Ticket;
import com.hubertstudios.coredsc.ticket.TicketSettings;
import com.hubertstudios.coredsc.ticket.TicketSettings.Field;
import com.hubertstudios.coredsc.ticket.TicketSettings.TicketType;
import com.hubertstudios.coredsc.util.TextUtil;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.entities.channel.concrete.Category;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.entities.channel.concrete.ThreadChannel;
import net.dv8tion.jda.api.entities.channel.ChannelType;
import net.dv8tion.jda.api.entities.emoji.Emoji;
import net.dv8tion.jda.api.events.interaction.ModalInteractionEvent;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.interaction.component.ButtonInteractionEvent;
import net.dv8tion.jda.api.events.interaction.component.EntitySelectInteractionEvent;
import net.dv8tion.jda.api.events.interaction.component.StringSelectInteractionEvent;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.exceptions.ErrorResponseException;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.InteractionHook;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.CommandData;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import net.dv8tion.jda.api.interactions.commands.build.OptionData;
import net.dv8tion.jda.api.interactions.commands.build.SubcommandData;
import net.dv8tion.jda.api.components.actionrow.ActionRow;
import net.dv8tion.jda.api.components.buttons.Button;
import net.dv8tion.jda.api.components.label.Label;
import net.dv8tion.jda.api.components.selections.EntitySelectMenu;
import net.dv8tion.jda.api.components.selections.SelectOption;
import net.dv8tion.jda.api.components.selections.StringSelectMenu;
import net.dv8tion.jda.api.components.textinput.TextInput;
import net.dv8tion.jda.api.components.textinput.TextInputStyle;
import net.dv8tion.jda.api.modals.Modal;
import net.dv8tion.jda.api.requests.ErrorResponse;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandMap;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.defaults.BukkitCommand;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.EnumSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.logging.Level;

/**
 * Tickets V2: typed ticket panels, per-type Discord destinations and forms,
 * persistent two-way support messaging, transcripts, and Discord-first setup.
 */
public final class TicketModule implements CoreModule, DiscordCommandContributor {
    private static final String CONFIG_PATH = "modules/tickets.yml";
    private static final int CONFIG_LIMIT_BYTES = 1_048_576;
    private static final Set<Permission> TICKET_ALLOW = EnumSet.of(
            Permission.VIEW_CHANNEL,
            Permission.MESSAGE_SEND,
            Permission.MESSAGE_HISTORY,
            Permission.MESSAGE_ATTACH_FILES,
            Permission.MESSAGE_EMBED_LINKS
    );
    private static final Set<Permission> VIEW_ONLY = EnumSet.of(
            Permission.VIEW_CHANNEL,
            Permission.MESSAGE_HISTORY
    );
    private static final Set<Permission> DENY_VIEW = EnumSet.of(Permission.VIEW_CHANNEL);
    private static final Set<Permission> DENY_SEND = EnumSet.of(Permission.MESSAGE_SEND);

    private final CoreDSCPlugin plugin;
    private LinkedAccountRepository linkedAccounts;
    private TicketRepository tickets;
    private SupportMessageRepository messages;
    private ListenerAdapter discordListener;
    private Listener bukkitListener;
    private volatile TicketSettings settings;
    private volatile boolean active;
    private final AtomicBoolean panelPublishing = new AtomicBoolean();

    private String commandName;
    private List<String> commandAliases = List.of();
    private String subCreate;
    private String subStatus;
    private String subReply;
    private String subClose;
    private String subClaim;
    private String subPriority;
    private String subSetup;
    private boolean keepDefaultCommand;
    private String userPermission;
    private final List<BukkitCommand> registeredCommands = new ArrayList<>();

    public TicketModule(CoreDSCPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public String id() {
        return "tickets";
    }

    @Override
    public void enable() {
        DiscordBotService discord = requireDiscord();
        SQLiteStorage storage = plugin.getStorage();
        if (storage == null || storage.getState() != SQLiteStorage.State.READY) {
            throw new IllegalStateException("SQLite storage is not ready");
        }
        linkedAccounts = new LinkedAccountRepository(storage);
        tickets = new TicketRepository(storage);
        messages = new SupportMessageRepository(storage);
        loadConfiguration(plugin.getAppConfig(), true);
        registerMinecraftCommand();
        active = true;

        bukkitListener = new Listener() {
            @EventHandler
            public void onJoin(PlayerJoinEvent event) {
                deliverOfflineMessages(event.getPlayer().getUniqueId());
            }

            @EventHandler
            public void onDiscordReady(DiscordReadyEvent ignored) {
                TicketSettings current = settings;
                if (active && current != null && current.panel().publishOnStartup()) {
                    publishConfiguredPanel().exceptionally(error -> {
                        plugin.getLogger().warning("[Tickets] Could not publish ticket panel after Discord became ready: "
                                + rootMessage(error));
                        return null;
                    });
                }
            }
        };
        plugin.getServer().getPluginManager().registerEvents(bukkitListener, plugin);

        discordListener = new ListenerAdapter() {
            @Override
            public void onSlashCommandInteraction(SlashCommandInteractionEvent event) {
                if (!event.getName().equals(commandName)) return;
                handleSlash(event);
            }

            @Override
            public void onMessageReceived(MessageReceivedEvent event) {
                handleTicketMessage(event);
            }

            @Override
            public void onButtonInteraction(ButtonInteractionEvent event) {
                handleButton(event);
            }

            @Override
            public void onStringSelectInteraction(StringSelectInteractionEvent event) {
                handleSetupStringSelect(event);
            }

            @Override
            public void onEntitySelectInteraction(EntitySelectInteractionEvent event) {
                handleSetupEntitySelect(event);
            }

            @Override
            public void onModalInteraction(ModalInteractionEvent event) {
                handleModal(event);
            }
        };
        discord.addEventListener(discordListener);
        TicketSettings current = settings;
        if (current != null && current.panel().publishOnStartup() && discord.isReady()) {
            publishConfiguredPanel().exceptionally(error -> {
                plugin.getLogger().warning("[Tickets] Could not publish ticket panel during module startup: "
                        + rootMessage(error));
                return null;
            });
        }
    }

    @Override
    public void disable() {
        active = false;
        DiscordBotService discord = plugin.getDiscordService();
        if (discordListener != null && discord != null) discord.removeEventListener(discordListener);
        discordListener = null;
        if (bukkitListener != null) HandlerList.unregisterAll(bukkitListener);
        bukkitListener = null;
        unregisterConfiguredCommands();
        PluginCommand command = plugin.getCommand("ticket");
        if (command != null) {
            command.setExecutor((sender, cmd, label, args) -> {
                sender.sendMessage("§cThe CoreDSC ticket module is disabled.");
                return true;
            });
            command.setTabCompleter(null);
        }
    }

    @Override
    public String statusDetail() {
        TicketSettings current = settings;
        return current == null ? "not configured" : "Tickets V2 · " + current.types().size()
                + " type(s) · " + current.channelMode().name().toLowerCase(Locale.ROOT);
    }

    @Override
    public List<CommandData> slashCommands() {
        return List.of(Commands.slash(commandName,
                        value(plugin.getAppConfig(), "tickets.commands.discord-description", "Create and manage support tickets"))
                .addSubcommands(
                        new SubcommandData(subCreate, "Create a support ticket").addOptions(
                                new OptionData(OptionType.STRING, "type", "Ticket type ID", false).setMaxLength(32),
                                new OptionData(OptionType.STRING, "reason", "Legacy quick reason", false).setMaxLength(100),
                                new OptionData(OptionType.STRING, "message", "Legacy quick message", false).setMaxLength(2_000)),
                        new SubcommandData(subStatus, "Show your open tickets"),
                        new SubcommandData(subClose, "Close a ticket").addOption(OptionType.INTEGER, "id", "Ticket ID", false),
                        new SubcommandData(subClaim, "Claim a ticket as staff").addOption(OptionType.INTEGER, "id", "Ticket ID", true),
                        new SubcommandData(subReply, "Reply to a ticket as staff").addOptions(
                                new OptionData(OptionType.INTEGER, "id", "Ticket ID", true),
                                new OptionData(OptionType.STRING, "message", "Reply", true).setMaxLength(2_000)),
                        new SubcommandData(subPriority, "Change ticket priority").addOptions(
                                new OptionData(OptionType.INTEGER, "id", "Ticket ID", true),
                                new OptionData(OptionType.STRING, "level", "LOW, NORMAL, HIGH, URGENT", true)),
                        new SubcommandData(subSetup, "Configure ticket panels, types and forms")
                ));
    }

    /** Maintains the public API used by workflows and other plugins. */
    public CompletableFuture<CoreDSCApi.CreateResult> createTicketForPlayer(UUID uuid, String reason, String message) {
        TicketType type = defaultType();
        if (type == null) {
            return CompletableFuture.completedFuture(new CoreDSCApi.CreateResult(false, 0L,
                    "No ticket types are configured."));
        }
        String safeReason = TextUtil.truncate(TextUtil.sanitizeMinecraftUserText(reason).trim(), 100);
        String safeMessage = TextUtil.truncate(TextUtil.sanitizeMinecraftUserText(message).trim(), settings.messageMaxLength());
        if (safeReason.isBlank() || safeMessage.isBlank()) {
            return CompletableFuture.completedFuture(new CoreDSCApi.CreateResult(false, 0L,
                    "Reason and message are required."));
        }
        Map<String, String> form = new LinkedHashMap<>();
        form.put("reason", safeReason);
        form.put("message", safeMessage);
        return linkedAccounts.findByMinecraftUuid(uuid.toString()).thenCompose(link -> {
            if (link.isEmpty()) {
                return CompletableFuture.completedFuture(new CoreDSCApi.CreateResult(false, 0L,
                        "You must link your Discord account first."));
            }
            return createTicket(type, Optional.of(link.get()), link.get().discordUserId(),
                            link.get().minecraftName(), link.get().minecraftName(), form)
                    .thenApply(ticket -> new CoreDSCApi.CreateResult(true, ticket.id(),
                            "Ticket #" + ticket.id() + " created."));
        }).exceptionally(error -> new CoreDSCApi.CreateResult(false, 0L, rootMessage(error)));
    }

    /** Snapshot used by the hosted dashboard without exposing ticket content. */
    public Map<String, Object> configurationSnapshot() {
        TicketSettings current = requireSettings();
        List<Map<String, Object>> types = new ArrayList<>();
        for (TicketType type : current.types().values()) {
            List<Map<String, Object>> fields = type.fields().stream().map(field -> Map.<String, Object>of(
                    "id", field.id(), "label", field.label(), "style", field.style().name(),
                    "required", field.required(), "minLength", field.minLength(), "maxLength", field.maxLength(),
                    "placeholder", field.placeholder()
            )).toList();
            Map<String, Object> item = new LinkedHashMap<>();
            item.put("id", type.id());
            item.put("label", type.label());
            item.put("description", type.description());
            item.put("emoji", type.emoji());
            item.put("buttonStyle", type.buttonStyle().name());
            item.put("channelMode", type.channelMode().name());
            item.put("categoryId", snowflakeText(type.categoryId()));
            item.put("parentChannelId", snowflakeText(type.parentChannelId()));
            item.put("closedCategoryId", snowflakeText(type.closedCategoryId()));
            item.put("channelName", type.channelName());
            item.put("openingMessage", type.openingMessage());
            item.put("staffRoleIds", type.staffRoleIds().stream().map(String::valueOf).toList());
            item.put("requireLinkedAccount", type.requiresLink(current.requireLinkedAccount()));
            item.put("fields", fields);
            types.add(Map.copyOf(item));
        }
        return Map.of(
                "panel", Map.of(
                        "channelId", snowflakeText(current.panel().channelId()),
                        "messageId", snowflakeText(current.panel().messageId()),
                        "title", current.panel().title(),
                        "description", current.panel().description(),
                        "footer", current.panel().footer(),
                        "color", String.format("#%06X", current.panel().color()),
                        "typeIds", current.panelTypeIds()),
                "types", List.copyOf(types),
                "logs", Map.of("channelId", snowflakeText(current.logChannelId()),
                        "transcriptMessageLimit", current.transcriptLimit()),
                "closeMode", current.closeMode().name(),
                "requireLinkedAccount", current.requireLinkedAccount());
    }

    /** Update the ticket panel and lifecycle targets from the hosted dashboard. */
    public CompletableFuture<Map<String, Object>> updatePanelFromCloud(Map<String, Object> payload) {
        Map<String, Object> request = payload == null ? Map.of() : Map.copyOf(payload);
        return mutateTicketsFile(yaml -> {
            String oldChannel = yaml.getString("panel.channel-id", "");
            String channel = cloudSnowflake(request.get("channelId"), "panel channel", true);
            String logChannel = cloudSnowflake(request.get("logChannelId"), "log channel", true);
            String title = cloudText(request.get("title"), 256, "panel title", true);
            String description = cloudText(request.get("description"), 4_000, "panel description", true);
            String footer = cloudText(request.get("footer"), 2_048, "panel footer", false);
            String color = cloudText(request.get("color"), 7, "panel color", true).toUpperCase(Locale.ROOT);
            if (!color.matches("#[0-9A-F]{6}")) {
                throw new IllegalArgumentException("panel color must be a six-digit hex value such as #5865F2");
            }
            String closeMode = cloudText(request.get("closeMode"), 16, "close mode", true).toUpperCase(Locale.ROOT);
            if (!Set.of("LOCK", "DELETE").contains(closeMode)) {
                throw new IllegalArgumentException("close mode must be LOCK or DELETE");
            }
            List<String> typeIds = cloudIdList(request.get("typeIds"), "panel type IDs", 25);
            for (String typeId : typeIds) {
                if (!yaml.isConfigurationSection("types." + typeId)) {
                    throw new IllegalArgumentException("Unknown panel ticket type '" + typeId + "'");
                }
            }
            yaml.set("panel.channel-id", channel);
            yaml.set("panel.title", title);
            yaml.set("panel.description", description);
            yaml.set("panel.footer", footer);
            yaml.set("panel.color", color);
            yaml.set("panel.type-ids", typeIds);
            yaml.set("logs.channel-id", logChannel);
            yaml.set("close.mode", closeMode);
            if (!java.util.Objects.equals(oldChannel, channel)) yaml.set("panel.message-id", "");
        }).thenApply(ignored -> configurationSnapshot());
    }

    /** Create or update one ticket type without exposing arbitrary YAML writes to the dashboard. */
    public CompletableFuture<Map<String, Object>> upsertTypeFromCloud(Map<String, Object> payload) {
        Map<String, Object> request = payload == null ? Map.of() : Map.copyOf(payload);
        String typeId = cloudId(request.get("id"), "ticket type ID");
        return mutateTicketsFile(yaml -> {
            String label = cloudText(request.get("label"), 80, "ticket type label", true);
            String description = cloudText(request.get("description"), 300, "ticket type description", false);
            String emoji = cloudText(request.get("emoji"), 100, "ticket type emoji", false);
            String buttonStyle = cloudText(request.get("buttonStyle"), 16, "button style", true).toUpperCase(Locale.ROOT);
            if (!Set.of("PRIMARY", "SECONDARY", "SUCCESS", "DANGER").contains(buttonStyle)) {
                throw new IllegalArgumentException("button style must be PRIMARY, SECONDARY, SUCCESS or DANGER");
            }
            String channelMode = cloudText(request.get("channelMode"), 16, "channel mode", true).toUpperCase(Locale.ROOT);
            if (!Set.of("CHANNEL", "THREAD").contains(channelMode)) {
                throw new IllegalArgumentException("channel mode must be CHANNEL or THREAD");
            }
            String categoryId = cloudSnowflake(request.get("categoryId"), "ticket category", true);
            String parentChannelId = cloudSnowflake(request.get("parentChannelId"), "ticket parent channel", true);
            if (channelMode.equals("CHANNEL") && categoryId.isBlank()) {
                throw new IllegalArgumentException("A Discord category is required for CHANNEL mode");
            }
            if (channelMode.equals("THREAD") && parentChannelId.isBlank()) {
                throw new IllegalArgumentException("A parent text channel is required for THREAD mode");
            }
            String closedCategoryId = cloudSnowflake(request.get("closedCategoryId"), "closed-ticket category", true);
            String channelName = cloudText(request.get("channelName"), 100, "ticket channel name", true);
            String openingMessage = cloudText(request.get("openingMessage"), 4_000, "ticket opening message", true);
            boolean requireLink = cloudBoolean(request.get("requireLinkedAccount"), false);
            List<String> staffRoleIds = cloudSnowflakeList(request.get("staffRoleIds"), "staff role IDs", 25);

            String base = "types." + typeId;
            yaml.set(base + ".enabled", true);
            yaml.set(base + ".label", label);
            yaml.set(base + ".description", description);
            yaml.set(base + ".emoji", emoji);
            yaml.set(base + ".button-style", buttonStyle);
            yaml.set(base + ".channel-mode", channelMode);
            yaml.set(base + ".category-id", categoryId);
            yaml.set(base + ".parent-channel-id", parentChannelId);
            yaml.set(base + ".closed-category-id", closedCategoryId);
            yaml.set(base + ".channel-name", channelName);
            yaml.set(base + ".opening-message", openingMessage);
            yaml.set(base + ".require-linked-account", requireLink);
            yaml.set(base + ".staff-role-ids", staffRoleIds);
            if (!yaml.contains(base + ".fields")) yaml.createSection(base + ".fields");
            List<String> panelTypes = new ArrayList<>(yaml.getStringList("panel.type-ids"));
            if (panelTypes.stream().noneMatch(typeId::equalsIgnoreCase) && panelTypes.size() < 25) {
                panelTypes.add(typeId);
                yaml.set("panel.type-ids", panelTypes);
            }
        }).thenApply(ignored -> configurationSnapshot());
    }

    public CompletableFuture<Map<String, Object>> removeTypeFromCloud(Map<String, Object> payload) {
        String typeId = cloudId(payload == null ? null : payload.get("id"), "ticket type ID");
        return removeTicketTypeSafely(typeId).thenApply(ignored -> configurationSnapshot());
    }

    public CompletableFuture<Map<String, Object>> upsertFieldFromCloud(Map<String, Object> payload) {
        Map<String, Object> request = payload == null ? Map.of() : Map.copyOf(payload);
        String typeId = cloudId(request.get("typeId"), "ticket type ID");
        String fieldId = cloudId(request.get("id"), "field ID");
        return mutateTicketsFile(yaml -> {
            if (!yaml.isConfigurationSection("types." + typeId)) {
                throw new IllegalArgumentException("Unknown ticket type '" + typeId + "'");
            }
            ConfigurationSection fields = yaml.getConfigurationSection("types." + typeId + ".fields");
            int existing = fields == null ? 0 : fields.getKeys(false).size();
            if ((fields == null || !fields.contains(fieldId)) && existing >= 5) {
                throw new IllegalArgumentException("Discord ticket forms support at most 5 fields");
            }
            String label = cloudText(request.get("label"), 45, "field label", true);
            String style = cloudText(request.get("style"), 16, "field style", true).toUpperCase(Locale.ROOT);
            if (!Set.of("SHORT", "PARAGRAPH").contains(style)) {
                throw new IllegalArgumentException("field style must be SHORT or PARAGRAPH");
            }
            boolean required = cloudBoolean(request.get("required"), true);
            int min = cloudInt(request.get("minLength"), required ? 1 : 0, 0, 4_000, "field minimum length");
            int max = cloudInt(request.get("maxLength"), style.equals("SHORT") ? 400 : 4_000, 1, 4_000, "field maximum length");
            if (min > max) throw new IllegalArgumentException("field minimum length cannot exceed maximum length");
            String placeholder = cloudText(request.get("placeholder"), 100, "field placeholder", false);
            String base = "types." + typeId + ".fields." + fieldId;
            yaml.set(base + ".enabled", true);
            yaml.set(base + ".label", label);
            yaml.set(base + ".style", style);
            yaml.set(base + ".required", required);
            yaml.set(base + ".min-length", min);
            yaml.set(base + ".max-length", max);
            yaml.set(base + ".placeholder", placeholder);
        }).thenApply(ignored -> configurationSnapshot());
    }

    public CompletableFuture<Map<String, Object>> removeFieldFromCloud(Map<String, Object> payload) {
        String typeId = cloudId(payload == null ? null : payload.get("typeId"), "ticket type ID");
        String fieldId = cloudId(payload == null ? null : payload.get("id"), "field ID");
        return mutateTicketsFile(yaml -> {
            if (!yaml.contains("types." + typeId + ".fields." + fieldId)) {
                throw new IllegalArgumentException("Unknown field '" + fieldId + "' on ticket type '" + typeId + "'");
            }
            yaml.set("types." + typeId + ".fields." + fieldId, null);
        }).thenApply(ignored -> configurationSnapshot());
    }

    /** Reload only the Tickets V2 definition after an external dashboard/config edit. */
    public CompletableFuture<Map<String, Object>> reloadConfigurationFromDisk() {
        return reloadTicketConfiguration().thenApply(ignored -> configurationSnapshot());
    }

    /** Publish/update the configured ticket panel. */
    public CompletableFuture<Map<String, Object>> publishConfiguredPanel() {
        if (!panelPublishing.compareAndSet(false, true)) {
            return CompletableFuture.failedFuture(new IllegalStateException("Ticket panel publication is already in progress"));
        }
        try {
            return publishConfiguredPanelInternal().whenComplete((ignored, error) -> panelPublishing.set(false));
        } catch (Throwable error) {
            panelPublishing.set(false);
            return CompletableFuture.failedFuture(error);
        }
    }

    private CompletableFuture<Map<String, Object>> publishConfiguredPanelInternal() {
        TicketSettings current = requireSettings();
        if (current.panel().channelId() <= 0L) {
            return CompletableFuture.failedFuture(new IllegalStateException(
                    "tickets.panel.channel-id is not configured"));
        }
        JDA jda = requireReadyJda();
        TextChannel channel = jda.getTextChannelById(current.panel().channelId());
        if (channel == null) {
            return CompletableFuture.failedFuture(new IllegalStateException("Ticket panel channel is unavailable"));
        }
        EmbedBuilder builder = new EmbedBuilder()
                .setTitle(current.panel().title())
                .setDescription(current.panel().description())
                .setColor(new Color(current.panel().color()));
        if (!current.panel().footer().isBlank()) builder.setFooter(current.panel().footer());
        List<ActionRow> rows = panelRows(current);
        if (rows.isEmpty()) {
            return CompletableFuture.failedFuture(new IllegalStateException("No enabled ticket types are available for the panel"));
        }

        CompletableFuture<Message> send;
        if (current.panel().messageId() > 0L) {
            send = channel.retrieveMessageById(current.panel().messageId()).submit()
                    .thenCompose(message -> message.editMessageEmbeds(builder.build()).setComponents(rows).submit())
                    .exceptionallyCompose(error -> {
                        if (!isUnknownDiscordMessage(error)) {
                            return CompletableFuture.failedFuture(error);
                        }
                        // Only replace a panel when Discord proves the configured message no longer exists.
                        // A transient REST/rate-limit/permission failure must not create duplicate panels.
                        return channel.sendMessageEmbeds(builder.build()).setComponents(rows).submit();
                    });
        } else {
            send = channel.sendMessageEmbeds(builder.build()).setComponents(rows).submit();
        }
        return send.thenCompose(message -> persistPanelMessageId(message.getIdLong())
                .thenApply(ignored -> Map.of("channelId", channel.getId(), "messageId", message.getId(),
                        "buttons", current.panelTypeIds().size())));
    }

    private void handleSlash(SlashCommandInteractionEvent event) {
        String subcommand = event.getSubcommandName() == null ? "" : event.getSubcommandName();
        if (subcommand.equals(subCreate)) handleDiscordCreate(event);
        else if (subcommand.equals(subStatus)) handleDiscordStatus(event);
        else if (subcommand.equals(subClose)) handleDiscordClose(event);
        else if (subcommand.equals(subClaim)) handleDiscordClaim(event);
        else if (subcommand.equals(subReply)) handleDiscordReply(event);
        else if (subcommand.equals(subPriority)) handleDiscordPriority(event);
        else if (subcommand.equals(subSetup)) handleDiscordSetup(event);
        else event.reply("Unknown ticket subcommand.").setEphemeral(true).queue();
    }

    private void handleDiscordCreate(SlashCommandInteractionEvent event) {
        if (!event.isFromGuild()) {
            event.reply("Tickets can only be created inside the Discord server.").setEphemeral(true).queue();
            return;
        }
        String requested = event.getOption("type") == null ? "" : TicketSettings.safeId(event.getOption("type").getAsString());
        TicketType type = requested.isBlank() ? defaultType() : requireSettings().type(requested);
        if (type == null) {
            event.reply("Unknown ticket type. Use the ticket panel or provide a configured type ID.")
                    .setEphemeral(true).queue();
            return;
        }
        if (!type.fields().isEmpty()) {
            event.replyModal(createTicketModal(type)).queue();
            return;
        }
        Map<String, String> values = new LinkedHashMap<>();
        if (event.getOption("reason") != null) values.put("reason", event.getOption("reason").getAsString());
        if (event.getOption("message") != null) values.put("message", event.getOption("message").getAsString());
        event.deferReply(true).queue(hook -> createTicketFromDiscord(type, event.getUser().getId(),
                        event.getUser().getEffectiveName(), values)
                .whenComplete((ticket, error) -> edit(hook, error == null
                        ? "Ticket #" + ticket.id() + " created: <#" + ticket.channelId() + ">"
                        : "Ticket creation failed: " + rootMessage(error))));
    }

    private Modal createTicketModal(TicketType type) {
        Modal.Builder builder = Modal.create("coredsc:ticket:new:" + type.id(),
                TextUtil.truncate(type.label(), 45));
        for (Field field : type.fields()) {
            TextInput.Builder input = TextInput.create(field.id(), field.style() == TicketSettings.InputStyle.PARAGRAPH
                            ? TextInputStyle.PARAGRAPH : TextInputStyle.SHORT)
                    .setRequired(field.required())
                    .setMinLength(field.minLength())
                    .setMaxLength(field.maxLength());
            if (!field.placeholder().isBlank()) input.setPlaceholder(field.placeholder());
            builder.addComponents(Label.of(field.label(), input.build()));
        }
        return builder.build();
    }

    private CompletableFuture<Ticket> createTicketFromDiscord(
            TicketType type,
            String discordUserId,
            String discordDisplayName,
            Map<String, String> rawForm
    ) {
        Map<String, String> form = sanitizeForm(type, rawForm);
        return linkedAccounts.findByDiscordUserId(discordUserId).thenCompose(account -> {
            TicketSettings current = requireSettings();
            if (type.requiresLink(current.requireLinkedAccount()) && account.isEmpty()) {
                return CompletableFuture.failedFuture(new SecurityException(
                        "Link your Minecraft account before creating this ticket."));
            }
            String minecraftName = account.map(LinkedAccount::minecraftName).orElseGet(() -> minecraftNameFromForm(form));
            return createTicket(type, account, discordUserId, discordDisplayName, minecraftName, form);
        });
    }

    private CompletableFuture<Ticket> createTicket(
            TicketType type,
            Optional<LinkedAccount> account,
            String discordUserId,
            String discordDisplayName,
            String minecraftName,
            Map<String, String> form
    ) {
        TicketSettings current = requireSettings();
        String uuid = account.map(LinkedAccount::minecraftUuid).orElse("");
        String reason = ticketSummary(type, form);
        String message = formDisplay(type, form);
        String formJson = MiniJson.write(new LinkedHashMap<>(form));
        long now = System.currentTimeMillis();
        return tickets.reserve(uuid, minecraftName == null ? "" : minecraftName, discordUserId,
                        reason, message, type.id(), formJson, now, current.cooldownMillis(),
                        current.maxOpenPerUser(), current.maxOpenGlobal())
                .thenCompose(reservation -> {
                    if (reservation.status() != ReserveStatus.RESERVED) {
                        return CompletableFuture.failedFuture(new IllegalStateException(
                                reservationMessage(reservation.status(), reservation.remainingMillis())));
                    }
                    return createDiscordContainer(type, reservation.ticketId(), account, discordUserId,
                                    discordDisplayName, minecraftName, form)
                            .thenCompose(container -> tickets.activate(reservation.ticketId(), container.id())
                                    .thenApply(ignored -> new Ticket(
                                            reservation.ticketId(), uuid, minecraftName == null ? "" : minecraftName,
                                            discordUserId, reason, message, "OPEN", container.id(), now, 0L, "", "",
                                            "NORMAL", now, type.id(), formJson))
                                    // Only activation failure is allowed to tear the Discord container back down.
                                    // Persisting the synthetic opening support-message is useful history, but it must
                                    // never turn an already-active ticket into an orphan by triggering rollback.
                                    .exceptionallyCompose(error -> deleteContainerQuietly(container)
                                            .thenCompose(ignored -> tickets.release(reservation.ticketId()))
                                            .thenCompose(ignored -> CompletableFuture.failedFuture(error))))
                            .thenApply(ticket -> {
                                messages.add("TICKET", ticket.id(), "SYSTEM", "", "CoreDSC", message, now, true, true)
                                        .exceptionally(error -> {
                                            plugin.getLogger().warning("[Tickets] Could not persist opening history for ticket #"
                                                    + ticket.id() + ": " + rootMessage(error));
                                            return 0L;
                                        });
                                UUID eventUuid = parseUuid(ticket.minecraftUuid());
                                plugin.runSync(() -> {
                                    Bukkit.getPluginManager().callEvent(new TicketCreateEvent(
                                            ticket.id(), eventUuid, ticket.discordUserId(), ticket.reason()));
                                    plugin.recordFeatureUse("ticket_created");
                                });
                                logLifecycle(ticket, "OPENED", "", type).exceptionally(error -> null);
                                return ticket;
                            });
                });
    }

    private CompletableFuture<TicketContainer> createDiscordContainer(
            TicketType type,
            long ticketId,
            Optional<LinkedAccount> account,
            String discordUserId,
            String discordDisplayName,
            String minecraftName,
            Map<String, String> form
    ) {
        return plugin.callSync(() -> renderTicket(type, ticketId, account, discordUserId,
                        discordDisplayName, minecraftName, form))
                .thenCompose(rendered -> type.channelMode() == TicketSettings.ChannelMode.THREAD
                        ? createThread(type, ticketId, discordUserId, rendered)
                        : createChannel(type, ticketId, discordUserId, rendered));
    }

    private CompletableFuture<TicketContainer> createChannel(
            TicketType type,
            long ticketId,
            String discordUserId,
            RenderedTicket rendered
    ) {
        JDA jda = requireReadyJda();
        Category category = jda.getCategoryById(type.categoryId());
        if (category == null) {
            return CompletableFuture.failedFuture(new IllegalStateException(
                    "Ticket category for '" + type.id() + "' is unavailable"));
        }
        long memberId;
        try {
            memberId = Long.parseLong(discordUserId);
        } catch (NumberFormatException error) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("Invalid Discord user ID", error));
        }
        var action = category.createTextChannel(rendered.name())
                .addRolePermissionOverride(category.getGuild().getPublicRole().getIdLong(), Collections.emptySet(), DENY_VIEW)
                .addMemberPermissionOverride(memberId, TICKET_ALLOW, Collections.emptySet());
        for (Long roleId : type.staffRoleIds()) {
            Role role = category.getGuild().getRoleById(roleId);
            if (role != null) action = action.addRolePermissionOverride(roleId, TICKET_ALLOW, Collections.emptySet());
        }
        return action.submit().thenCompose(channel -> sendOpening(channel, ticketId, rendered.opening())
                .thenApply(ignored -> new TicketContainer(channel.getId(), false))
                .exceptionallyCompose(error -> channel.delete().submit().handle((ignored, ignoredError) -> null)
                        .thenCompose(ignored -> CompletableFuture.failedFuture(error))));
    }

    private CompletableFuture<TicketContainer> createThread(
            TicketType type,
            long ticketId,
            String discordUserId,
            RenderedTicket rendered
    ) {
        JDA jda = requireReadyJda();
        TextChannel parent = jda.getTextChannelById(type.parentChannelId());
        if (parent == null) {
            return CompletableFuture.failedFuture(new IllegalStateException(
                    "Ticket parent channel for '" + type.id() + "' is unavailable"));
        }
        boolean privateThread = requireSettings().legacy().privateThread();
        return parent.createThreadChannel(rendered.name(), privateThread).submit().thenCompose(thread -> {
            CompletableFuture<?> membership = parent.getGuild().retrieveMemberById(discordUserId).submit()
                    .thenCompose(member -> thread.addThreadMember(member).submit());
            if (!privateThread) membership = membership.handle((ignored, error) -> null);
            return membership.thenCompose(ignored -> thread.sendMessage(rendered.opening())
                            .setAllowedMentions(Collections.emptyList())
                            .setComponents(ticketControlRow(ticketId))
                            .submit())
                    .thenApply(ignored -> new TicketContainer(thread.getId(), true))
                    .exceptionallyCompose(error -> thread.delete().submit().handle((ignored, ignoredError) -> null)
                            .thenCompose(ignored -> CompletableFuture.failedFuture(error)));
        });
    }

    private CompletableFuture<Message> sendOpening(TextChannel channel, long ticketId, String opening) {
        return channel.sendMessage(TextUtil.truncate(opening, 2_000))
                .setAllowedMentions(Collections.emptyList())
                .setComponents(ticketControlRow(ticketId))
                .submit();
    }

    private ActionRow ticketControlRow(long ticketId) {
        return ActionRow.of(
                Button.primary("coredsc:ticket:claim:" + ticketId, "Claim"),
                Button.secondary("coredsc:ticket:reply:" + ticketId, "Reply"),
                Button.danger("coredsc:ticket:close:" + ticketId, "Close")
        );
    }

    private void handleTicketMessage(MessageReceivedEvent event) {
        if (event.getAuthor().isBot() || event.isWebhookMessage()) return;
        String channelId = event.getChannel().getId();
        tickets.findOpenByChannel(channelId).whenComplete((found, error) -> {
            if (error != null || found.isEmpty()) return;
            Ticket ticket = found.get();
            TicketType type = typeFor(ticket);
            if (event.getMember() != null && !hasStaffRole(event.getMember(), type)
                    && !ticket.discordUserId().equals(event.getAuthor().getId())) return;
            String content = discordMessageContent(event.getMessage());
            if (content.isBlank()) return;
            deliverDiscordReply(ticket, event.getAuthor().getId(), event.getAuthor().getEffectiveName(), content)
                    .exceptionally(deliveryError -> {
                        plugin.getLogger().warning("[Tickets] Could not persist/deliver Discord reply: "
                                + rootMessage(deliveryError));
                        return null;
                    });
        });
    }

    private String discordMessageContent(Message message) {
        StringBuilder content = new StringBuilder(TextUtil.sanitizeMassMentions(
                message.getContentDisplay()).trim());
        int attachmentCount = 0;
        for (Message.Attachment attachment : message.getAttachments()) {
            if (attachmentCount++ >= 5) break;
            if (!content.isEmpty()) content.append('\n');
            String fileName = TextUtil.truncate(TextUtil.sanitizeMinecraftUserText(attachment.getFileName()), 120);
            String url = attachment.getUrl();
            content.append("[attachment: ").append(fileName.isBlank() ? "file" : fileName).append("] ")
                    .append(url);
        }
        return TextUtil.truncate(content.toString(), requireSettings().messageMaxLength());
    }

    private CompletableFuture<Void> deliverDiscordReply(
            Ticket ticket,
            String senderId,
            String senderName,
            String content
    ) {
        String safeName = TextUtil.sanitizeMinecraftUserText(senderName);
        String safeContent = TextUtil.sanitizeMinecraftUserText(content);
        UUID playerId = parseUuid(ticket.minecraftUuid());
        boolean noMinecraftTarget = playerId == null;
        return messages.add("TICKET", ticket.id(), "DISCORD", senderId, safeName, safeContent,
                        System.currentTimeMillis(), noMinecraftTarget, true)
                .thenCompose(messageId -> {
                    if (noMinecraftTarget) return CompletableFuture.completedFuture(null);
                    return plugin.runForPlayer(playerId, player ->
                                    player.sendMessage("§9[Ticket #" + ticket.id() + "] §b" + safeName + "§7: §f" + safeContent))
                            .thenCompose(delivered -> delivered
                                    ? messages.markMinecraftDelivered(List.of(messageId))
                                    : CompletableFuture.completedFuture(null));
                });
    }

    private void replyFromMinecraft(Player player, long id, String content) {
        String safe = TextUtil.truncate(TextUtil.sanitizeMinecraftUserText(content).trim(),
                requireSettings().messageMaxLength());
        UUID playerId = player.getUniqueId();
        String playerUuid = playerId.toString();
        String playerName = player.getName();
        tickets.findById(id).thenCompose(found -> {
            if (found.isEmpty() || !found.get().minecraftUuid().equals(playerUuid) || !isOpen(found.get())) {
                return CompletableFuture.failedFuture(new IllegalStateException("No matching open ticket."));
            }
            Ticket ticket = found.get();
            return messages.add("TICKET", id, "MINECRAFT", playerUuid, playerName, safe,
                            System.currentTimeMillis(), true, false)
                    .thenCompose(messageId -> sendToTicketChannel(ticket.channelId(),
                                    "**" + playerName + " (Minecraft):** " + TextUtil.sanitizeMassMentions(safe))
                            .thenCompose(ignored -> messages.markDiscordDelivered(messageId)));
        }).whenComplete((ignored, error) -> plugin.runForPlayer(playerId, currentPlayer -> currentPlayer.sendMessage(error == null
                ? "§aReply sent to ticket #" + id + "." : "§c" + rootMessage(error))));
    }

    private void closeFromMinecraft(Player player, long id) {
        UUID playerId = player.getUniqueId();
        String playerUuid = playerId.toString();
        String playerName = player.getName();
        tickets.findById(id).thenCompose(found -> {
            if (found.isEmpty() || !found.get().minecraftUuid().equals(playerUuid)) {
                return CompletableFuture.failedFuture(new IllegalStateException("Ticket not found."));
            }
            if (!requireSettings().userCanCloseOwn()) {
                return CompletableFuture.failedFuture(new SecurityException("Only ticket staff can close tickets."));
            }
            return closeTicket(found.get(), playerName).thenCompose(closed -> Boolean.TRUE.equals(closed)
                    ? CompletableFuture.completedFuture(null)
                    : CompletableFuture.failedFuture(new IllegalStateException("Ticket is already closed.")));
        }).whenComplete((ignored, error) -> plugin.runForPlayer(playerId, currentPlayer -> currentPlayer.sendMessage(error == null
                ? "§aTicket #" + id + " closed." : "§c" + rootMessage(error))));
    }

    private void showMinecraftStatus(Player player) {
        UUID playerId = player.getUniqueId();
        tickets.findOpenByMinecraftUuid(playerId.toString()).whenComplete((open, error) -> plugin.runForPlayer(playerId, currentPlayer -> {
            if (error != null) {
                currentPlayer.sendMessage("§cCould not load tickets.");
                return;
            }
            if (open.isEmpty()) {
                currentPlayer.sendMessage("§7You have no open tickets.");
                return;
            }
            currentPlayer.sendMessage("§bOpen tickets:");
            for (Ticket ticket : open) {
                currentPlayer.sendMessage("§7- §f#" + ticket.id() + " §8[" + ticket.priority() + "] §7"
                        + ticketTypeLabel(ticket) + " — " + ticket.reason());
            }
        }));
    }

    private void deliverOfflineMessages(UUID playerId) {
        messages.pendingForMinecraft(playerId.toString(), "TICKET", 50).whenComplete((pending, error) -> {
            if (error != null || pending.isEmpty()) return;
            plugin.runForPlayer(playerId, currentPlayer -> {
                List<Long> ids = new ArrayList<>();
                currentPlayer.sendMessage("§bYou have " + pending.size() + " new CoreDSC support message(s):");
                for (SupportMessage item : pending) {
                    currentPlayer.sendMessage("§9[" + item.itemType() + " #" + item.itemId() + "] §b"
                            + item.senderName() + "§7: §f" + item.message());
                    ids.add(item.id());
                }
                messages.markMinecraftDelivered(ids).exceptionally(markError -> null);
            });
        });
    }

    private void handleDiscordStatus(SlashCommandInteractionEvent event) {
        event.deferReply(true).queue(hook -> tickets.findOpenByUser(event.getUser().getId()).whenComplete((open, error) -> {
            if (error != null) {
                edit(hook, "Could not load tickets.");
                return;
            }
            if (open.isEmpty()) {
                edit(hook, "You have no open tickets.");
                return;
            }
            StringBuilder text = new StringBuilder("Open tickets:\n");
            for (Ticket ticket : open) text.append("• **#").append(ticket.id()).append("** [")
                    .append(ticket.priority()).append("] ").append(ticketTypeLabel(ticket)).append(" — ")
                    .append(ticket.reason()).append('\n');
            edit(hook, text.toString());
        }));
    }

    private void handleDiscordClose(SlashCommandInteractionEvent event) {
        long id = event.getOption("id") == null ? 0L : event.getOption("id").getAsLong();
        String channelId = event.getChannel().getId();
        event.deferReply(true).queue(hook -> resolveTicket(channelId, id).thenCompose(found -> {
            if (found.isEmpty()) return CompletableFuture.completedFuture(false);
            Ticket ticket = found.get();
            boolean owner = ticket.discordUserId().equals(event.getUser().getId());
            if (!hasStaffRole(event.getMember(), typeFor(ticket)) && !(requireSettings().userCanCloseOwn() && owner)) {
                return CompletableFuture.failedFuture(new SecurityException("You cannot close this ticket."));
            }
            return closeTicket(ticket, event.getUser().getEffectiveName());
        }).whenComplete((closed, error) -> {
            if (error != null) {
                edit(hook, "Could not close ticket: " + rootMessage(error));
            } else if (Boolean.TRUE.equals(closed)) {
                edit(hook, "Ticket closed.");
            } else {
                edit(hook, "Ticket is already closed or could not be found.");
            }
        }));
    }

    private void handleDiscordClaim(SlashCommandInteractionEvent event) {
        long id = event.getOption("id").getAsLong();
        event.deferReply(true).queue(hook -> tickets.findById(id).thenCompose(found -> {
            if (found.isEmpty() || !hasStaffRole(event.getMember(), typeFor(found.get()))) {
                return CompletableFuture.failedFuture(new SecurityException("Ticket staff role required."));
            }
            return tickets.claim(id, event.getUser().getEffectiveName(), System.currentTimeMillis());
        }).whenComplete((changed, error) -> {
            if (error != null) edit(hook, "Could not claim ticket: " + rootMessage(error));
            else edit(hook, Boolean.TRUE.equals(changed) ? "Ticket claimed." : "Ticket is already claimed or closed.");
        }));
    }

    private void handleDiscordReply(SlashCommandInteractionEvent event) {
        long id = event.getOption("id").getAsLong();
        String content = event.getOption("message").getAsString();
        event.deferReply(true).queue(hook -> tickets.findById(id).thenCompose(found -> {
            if (found.isEmpty() || !hasStaffRole(event.getMember(), typeFor(found.get()))) {
                return CompletableFuture.failedFuture(new SecurityException("Ticket staff role required."));
            }
            return staffReply(id, event.getUser().getId(), event.getUser().getEffectiveName(), content);
        }).whenComplete((ignored, error) -> edit(hook,
                error == null ? "Reply delivered." : "Reply failed: " + rootMessage(error))));
    }

    private void handleDiscordPriority(SlashCommandInteractionEvent event) {
        long id = event.getOption("id").getAsLong();
        String level = event.getOption("level").getAsString().toUpperCase(Locale.ROOT);
        if (!List.of("LOW", "NORMAL", "HIGH", "URGENT").contains(level)) {
            event.reply("Priority must be LOW, NORMAL, HIGH or URGENT.").setEphemeral(true).queue();
            return;
        }
        event.deferReply(true).queue(hook -> tickets.findById(id).thenCompose(found -> {
            if (found.isEmpty() || !hasStaffRole(event.getMember(), typeFor(found.get()))) {
                return CompletableFuture.failedFuture(new SecurityException("Ticket staff role required."));
            }
            return tickets.setPriority(id, level, System.currentTimeMillis());
        }).whenComplete((changed, error) -> {
            if (error != null) edit(hook, "Could not update priority: " + rootMessage(error));
            else edit(hook, Boolean.TRUE.equals(changed) ? "Priority updated." : "Ticket is closed or unavailable.");
        }));
    }

    private void handleButton(ButtonInteractionEvent event) {
        String id = event.getComponentId();
        if (id.startsWith("coredsc:ticket:new:")) {
            TicketSettings current = requireSettings();
            TicketSettings.Panel panel = current.panel();
            if (panel.channelId() <= 0L || panel.messageId() <= 0L
                    || event.getChannel().getIdLong() != panel.channelId()
                    || event.getMessageIdLong() != panel.messageId()) {
                event.reply("This ticket panel is stale. Ask an administrator to republish the active panel.")
                        .setEphemeral(true).queue();
                return;
            }
            String typeId = id.substring("coredsc:ticket:new:".length());
            TicketType type = current.type(typeId);
            if (type == null) {
                event.reply("This ticket type no longer exists. Ask an administrator to republish the panel.")
                        .setEphemeral(true).queue();
                return;
            }
            if (type.fields().isEmpty()) {
                event.deferReply(true).queue(hook -> createTicketFromDiscord(type, event.getUser().getId(),
                                event.getUser().getEffectiveName(), Map.of())
                        .whenComplete((ticket, error) -> edit(hook, error == null
                                ? "Ticket #" + ticket.id() + " created: <#" + ticket.channelId() + ">"
                                : "Ticket creation failed: " + rootMessage(error))));
            } else {
                event.replyModal(createTicketModal(type)).queue();
            }
            return;
        }
        if (id.startsWith("coredsc:ticketsetup:")) {
            handleSetupButton(event);
            return;
        }
        if (!id.startsWith("coredsc:ticket:")) return;
        String[] parts = id.split(":", 4);
        if (parts.length != 4) return;
        long ticketId;
        try {
            ticketId = Long.parseLong(parts[3]);
        } catch (NumberFormatException ignored) {
            return;
        }
        tickets.findById(ticketId).whenComplete((found, lookupError) -> {
            if (lookupError != null || found.isEmpty()) {
                event.reply("Ticket no longer exists.").setEphemeral(true).queue();
                return;
            }
            Ticket ticket = found.get();
            boolean staff = hasStaffRole(event.getMember(), typeFor(ticket));
            boolean ownerClose = parts[2].equals("close")
                    && requireSettings().userCanCloseOwn()
                    && ticket.discordUserId().equals(event.getUser().getId());
            if (!staff && !ownerClose) {
                event.reply(parts[2].equals("close")
                        ? "You cannot close this ticket." : "Ticket staff role required.")
                        .setEphemeral(true).queue();
                return;
            }
            switch (parts[2]) {
                case "claim" -> event.deferReply(true).queue(hook -> tickets.claim(ticketId,
                                event.getUser().getEffectiveName(), System.currentTimeMillis())
                        .whenComplete((ok, error) -> {
                            if (error != null) edit(hook, "Could not claim ticket: " + rootMessage(error));
                            else edit(hook, Boolean.TRUE.equals(ok) ? "Ticket claimed." : "Already claimed or closed.");
                        }));
                case "close" -> event.deferReply(true).queue(hook -> closeTicket(ticket,
                                event.getUser().getEffectiveName())
                        .whenComplete((ok, error) -> {
                            if (error != null) edit(hook, "Could not close ticket: " + rootMessage(error));
                            else if (Boolean.TRUE.equals(ok)) edit(hook, "Ticket closed.");
                            else edit(hook, "Ticket is already closed.");
                        }));
                case "reply" -> {
                    TextInput input = TextInput.create("message", TextInputStyle.PARAGRAPH)
                            .setRequired(true).setMaxLength(requireSettings().messageMaxLength()).build();
                    event.replyModal(Modal.create("coredsc:ticket:reply:" + ticketId,
                                    "Reply to ticket #" + ticketId)
                            .addComponents(Label.of("Reply", input)).build()).queue();
                }
                default -> { }
            }
        });
    }

    private void handleModal(ModalInteractionEvent event) {
        String id = event.getModalId();
        if (id.startsWith("coredsc:ticket:new:")) {
            TicketSettings current = requireSettings();
            String typeId = id.substring("coredsc:ticket:new:".length());
            TicketType type = current.type(typeId);
            if (type == null) {
                event.reply("This ticket type no longer exists.").setEphemeral(true).queue();
                return;
            }
            Map<String, String> form = new LinkedHashMap<>();
            for (Field field : type.fields()) {
                if (event.getValue(field.id()) != null) form.put(field.id(), event.getValue(field.id()).getAsString());
            }
            event.deferReply(true).queue(hook -> createTicketFromDiscord(type, event.getUser().getId(),
                            event.getUser().getEffectiveName(), form)
                    .whenComplete((ticket, error) -> edit(hook, error == null
                            ? "Ticket #" + ticket.id() + " created: <#" + ticket.channelId() + ">"
                            : "Ticket creation failed: " + rootMessage(error))));
            return;
        }
        if (id.startsWith("coredsc:ticketsetup:")) {
            handleSetupModal(event);
            return;
        }
        String[] parts = id.split(":", 4);
        if (parts.length != 4 || !parts[0].equals("coredsc") || !parts[1].equals("ticket")
                || !parts[2].equals("reply")) return;
        long ticketId;
        try {
            ticketId = Long.parseLong(parts[3]);
        } catch (NumberFormatException ignored) {
            return;
        }
        String content = event.getValue("message") == null ? "" : event.getValue("message").getAsString();
        event.deferReply(true).queue(hook -> tickets.findById(ticketId).thenCompose(found -> {
            if (found.isEmpty() || !hasStaffRole(event.getMember(), typeFor(found.get()))) {
                return CompletableFuture.failedFuture(new SecurityException("Ticket staff role required."));
            }
            return staffReply(ticketId, event.getUser().getId(), event.getUser().getEffectiveName(), content);
        }).whenComplete((ignored, error) -> edit(hook,
                error == null ? "Reply delivered." : "Reply failed: " + rootMessage(error))));
    }

    private CompletableFuture<Void> staffReply(long id, String senderId, String senderName, String content) {
        String safe = TextUtil.truncate(TextUtil.sanitizeMinecraftUserText(content).trim(),
                requireSettings().messageMaxLength());
        if (safe.isBlank()) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("Reply cannot be empty"));
        }
        String safeName = TextUtil.truncate(TextUtil.sanitizeMinecraftUserText(senderName), 80);
        return tickets.findById(id).thenCompose(found -> {
            if (found.isEmpty() || !isOpen(found.get())) {
                return CompletableFuture.failedFuture(new IllegalStateException("Ticket not open"));
            }
            Ticket ticket = found.get();
            UUID playerId = parseUuid(ticket.minecraftUuid());
            boolean noMinecraftTarget = playerId == null;

            // Persist before making the outbound Discord request. If Discord rejects the send,
            // the delivery row remains explicitly pending instead of losing the staff reply.
            return messages.add("TICKET", ticket.id(), "DISCORD", senderId, safeName, safe,
                            System.currentTimeMillis(), noMinecraftTarget, false)
                    .thenCompose(messageId -> sendToTicketChannel(ticket.channelId(),
                                    "**" + safeName + " (Staff):** " + TextUtil.sanitizeMassMentions(safe))
                            .thenCompose(ignored -> messages.markDiscordDelivered(messageId))
                            .thenCompose(ignored -> {
                                if (noMinecraftTarget) return CompletableFuture.completedFuture(null);
                                return plugin.runForPlayer(playerId, player -> player.sendMessage(
                                                "§9[Ticket #" + ticket.id() + "] §b" + safeName + "§7: §f" + safe))
                                        .thenCompose(delivered -> delivered
                                                ? messages.markMinecraftDelivered(List.of(messageId))
                                                : CompletableFuture.completedFuture(null));
                            }));
        });
    }

    private CompletableFuture<Boolean> closeTicket(Ticket ticket, String by) {
        TicketType type = typeFor(ticket);
        // Close Discord first. This operation is deliberately idempotent: a missing/deleted
        // container is treated as already closed. Persist CLOSED only after Discord has
        // reached the requested state so a transient Discord failure cannot strand a
        // writable channel behind a CLOSED database row.
        return closeDiscordContainer(ticket, type)
                .thenCompose(ignored -> tickets.close(ticket.id(), by, System.currentTimeMillis()))
                .thenApply(closed -> {
                    if (!closed) return false;
                    createTranscript(ticket, by).exceptionally(error -> {
                        plugin.getLogger().warning("[Tickets] Transcript failed for #" + ticket.id()
                                + ": " + rootMessage(error));
                        return null;
                    });
                    plugin.runSync(() -> Bukkit.getPluginManager().callEvent(new TicketCloseEvent(ticket.id(), by)));
                    logLifecycle(ticket, "CLOSED", by, type).exceptionally(error -> null);
                    return true;
                });
    }

    private CompletableFuture<Void> createTranscript(Ticket ticket, String closedBy) {
        TicketSettings current = requireSettings();
        if (current.logChannelId() <= 0L) return CompletableFuture.completedFuture(null);
        TextChannel log = requireReadyJda().getTextChannelById(current.logChannelId());
        if (log == null) return CompletableFuture.completedFuture(null);
        return messages.transcript("TICKET", ticket.id(), current.transcriptLimit()).thenCompose(items -> {
            StringBuilder transcript = new StringBuilder();
            transcript.append("Ticket #").append(ticket.id()).append(" — ").append(ticketTypeLabel(ticket)).append('\n')
                    .append("User: <@").append(ticket.discordUserId()).append(">\n")
                    .append("Minecraft: ").append(ticket.minecraftName().isBlank() ? "not linked" : ticket.minecraftName()).append('\n')
                    .append("Closed by: ").append(closedBy).append("\n\n")
                    .append("Form:\n").append(prettyForm(ticket)).append("\n\nTranscript:\n");
            for (SupportMessage item : items) {
                transcript.append('[').append(item.senderPlatform()).append("] ")
                        .append(item.senderName().isBlank() ? "CoreDSC" : item.senderName()).append(": ")
                        .append(item.message()).append('\n');
            }
            return sendChunks(log, transcript.toString(), "Ticket #" + ticket.id() + " transcript");
        });
    }

    private CompletableFuture<Void> logLifecycle(Ticket ticket, String action, String actor, TicketType type) {
        TicketSettings current = requireSettings();
        if (current.logChannelId() <= 0L) return CompletableFuture.completedFuture(null);
        TextChannel log = requireReadyJda().getTextChannelById(current.logChannelId());
        if (log == null) return CompletableFuture.completedFuture(null);
        String text = "**Ticket " + action + "** · #" + ticket.id() + " · "
                + (type == null ? ticket.ticketType() : type.label()) + " · <@" + ticket.discordUserId() + ">"
                + (actor == null || actor.isBlank() ? "" : " · by " + TextUtil.sanitizeMassMentions(actor));
        return log.sendMessage(TextUtil.truncate(text, 2_000)).setAllowedMentions(Collections.emptyList())
                .submit().thenApply(ignored -> null);
    }

    private CompletableFuture<Void> closeDiscordContainer(Ticket ticket, TicketType type) {
        JDA jda = requireReadyJda();
        ThreadChannel thread = jda.getThreadChannelById(ticket.channelId());
        if (thread != null) {
            return thread.getManager().setLocked(true).setArchived(true).submit().thenApply(ignored -> null);
        }
        TextChannel channel = jda.getTextChannelById(ticket.channelId());
        if (channel == null) return CompletableFuture.completedFuture(null);
        if (requireSettings().closeMode() == TicketSettings.CloseMode.DELETE) {
            return channel.delete().submit().thenApply(ignored -> null);
        }
        long memberId;
        try {
            memberId = Long.parseLong(ticket.discordUserId());
        } catch (NumberFormatException error) {
            memberId = 0L;
        }
        var manager = channel.getManager().setName(TextUtil.truncate("closed-" + ticket.id() + "-" +
                TextUtil.safeChannelToken(ticket.minecraftName().isBlank() ? "ticket" : ticket.minecraftName()), 100));
        if (memberId > 0L) manager = manager.putMemberPermissionOverride(memberId, VIEW_ONLY, DENY_SEND);
        long closedCategory = type == null ? requireSettings().closedCategoryId() : type.closedCategoryId();
        if (closedCategory > 0L) {
            Category category = jda.getCategoryById(closedCategory);
            if (category != null) manager = manager.setParent(category);
        }
        return manager.submit().thenApply(ignored -> null);
    }

    private CompletableFuture<Optional<Ticket>> resolveTicket(String channelId, long id) {
        return id > 0 ? tickets.findById(id) : tickets.findOpenByChannel(channelId);
    }

    private CompletableFuture<Void> sendToTicketChannel(String channelId, String content) {
        JDA jda = requireReadyJda();
        TextChannel channel = jda.getTextChannelById(channelId);
        if (channel != null) {
            return channel.sendMessage(TextUtil.truncate(content, 2_000)).setAllowedMentions(Collections.emptyList())
                    .submit().thenApply(ignored -> null);
        }
        ThreadChannel thread = jda.getThreadChannelById(channelId);
        if (thread != null) {
            return thread.sendMessage(TextUtil.truncate(content, 2_000)).setAllowedMentions(Collections.emptyList())
                    .submit().thenApply(ignored -> null);
        }
        return CompletableFuture.failedFuture(new IllegalStateException("Ticket Discord channel is unavailable"));
    }

    private RenderedTicket renderTicket(
            TicketType type,
            long id,
            Optional<LinkedAccount> account,
            String discordUserId,
            String discordDisplayName,
            String minecraftName,
            Map<String, String> form
    ) {
        Map<String, Object> values = new LinkedHashMap<>();
        values.put("id", id);
        values.put("type", type.id());
        values.put("type_label", type.label());
        values.put("minecraft_name", minecraftName == null ? "" : minecraftName);
        values.put("minecraft_uuid", account.map(LinkedAccount::minecraftUuid).orElse(""));
        values.put("discord_user_id", discordUserId);
        values.put("discord_name", discordDisplayName == null || discordDisplayName.isBlank()
                ? "user" : discordDisplayName);
        values.put("form", formDisplay(type, form));
        values.put("server_name", plugin.getServer().getName());
        form.forEach(values::put);
        String name = TextUtil.truncate(TextUtil.safeChannelToken(TextUtil.replace(type.channelName(), values)), 100);
        if (name.isBlank()) name = "ticket-" + id;
        String opening = TextUtil.replace(type.openingMessage(), values);
        if (account.isPresent()) {
            try {
                OfflinePlayer player = Bukkit.getOfflinePlayer(UUID.fromString(account.get().minecraftUuid()));
                opening = plugin.getPlaceholderService().apply(player, opening);
            } catch (IllegalArgumentException ignored) {
                // Stored UUID validation belongs to the account repository; placeholders are optional here.
            }
        }
        return new RenderedTicket(name, TextUtil.truncate(TextUtil.sanitizeMassMentions(opening), 2_000));
    }

    /* ------------------------------ Discord setup ------------------------------ */

    private void handleDiscordSetup(SlashCommandInteractionEvent event) {
        if (!event.isFromGuild() || !canConfigure(event.getMember())) {
            event.reply("Manage Server permission is required to configure tickets.").setEphemeral(true).queue();
            return;
        }
        event.reply(setupSummary()).setEphemeral(true).setComponents(setupRows()).queue();
    }

    private String setupSummary() {
        TicketSettings current = requireSettings();
        return "**CoreDSC Tickets V2 Setup**\n"
                + "Ticket types: **" + current.types().size() + "**\n"
                + "Panel channel: **" + (current.panel().channelId() > 0 ? "configured" : "missing") + "**\n"
                + "Log channel: **" + (current.logChannelId() > 0 ? "configured" : "optional") + "**\n\n"
                + "Add or update types and form fields, configure the panel, then publish it. Changes are validated and backed up.";
    }

    private List<ActionRow> setupRows() {
        TicketSettings current = requireSettings();
        List<ActionRow> rows = new ArrayList<>();
        if (!current.types().isEmpty()) {
            StringSelectMenu.Builder selector = StringSelectMenu.create("coredsc:ticketsetup:select-type")
                    .setPlaceholder("Select a ticket type to configure")
                    .setMinValues(1).setMaxValues(1);
            for (TicketType type : current.types().values()) {
                String description = type.description().isBlank()
                        ? type.channelMode().name() + " destination"
                        : TextUtil.truncate(type.description(), 100);
                selector.addOptions(SelectOption.of(TextUtil.truncate(type.label(), 100), type.id())
                        .withDescription(description));
            }
            rows.add(ActionRow.of(selector.build()));
        }
        rows.add(ActionRow.of(
                Button.primary("coredsc:ticketsetup:type", "Add Ticket Type"),
                Button.secondary("coredsc:ticketsetup:field", "Add / Edit Field"),
                Button.secondary("coredsc:ticketsetup:panel", "Panel Text"),
                Button.secondary("coredsc:ticketsetup:targets", "Discord Targets")
        ));
        rows.add(ActionRow.of(
                Button.danger("coredsc:ticketsetup:remove", "Remove Type / Field"),
                Button.success("coredsc:ticketsetup:publish", "Publish / Update Panel"),
                Button.secondary("coredsc:ticketsetup:reload", "Reload")
        ));
        return List.copyOf(rows);
    }

    private void handleSetupButton(ButtonInteractionEvent event) {
        if (!canConfigure(event.getMember())) {
            event.reply("Manage Server permission is required.").setEphemeral(true).queue();
            return;
        }
        String action = event.getComponentId().substring("coredsc:ticketsetup:".length());
        if (action.startsWith("edit:")) {
            String typeId = action.substring("edit:".length());
            TicketType type = requireSettings().types().get(typeId);
            if (type == null) {
                event.reply("That ticket type no longer exists. Run `/" + commandName + " " + subSetup + "` again.")
                        .setEphemeral(true).queue();
                return;
            }
            event.replyModal(typeSetupModal(type, "keep")).queue();
            return;
        }
        if (action.startsWith("fieldfor:")) {
            String typeId = action.substring("fieldfor:".length());
            event.replyModal(fieldSetupModal(typeId)).queue();
            return;
        }
        if (action.startsWith("contentfor:")) {
            String typeId = action.substring("contentfor:".length());
            TicketType type = requireSettings().types().get(typeId);
            if (type == null) {
                event.reply("That ticket type no longer exists.").setEphemeral(true).queue();
                return;
            }
            event.replyModal(typeContentSetupModal(type)).queue();
            return;
        }
        if (action.startsWith("removefor:")) {
            String typeId = action.substring("removefor:".length());
            event.replyModal(removeSetupModal(typeId)).queue();
            return;
        }
        switch (action) {
            case "type" -> event.reply("Choose the Discord category where tickets of the new type should be created.")
                    .setEphemeral(true)
                    .setComponents(ActionRow.of(EntitySelectMenu.create(
                                    "coredsc:ticketsetup:newtype-category",
                                    EntitySelectMenu.SelectTarget.CHANNEL)
                            .setChannelTypes(ChannelType.CATEGORY)
                            .setMinValues(1).setMaxValues(1)
                            .setPlaceholder("Choose ticket category")
                            .build()))
                    .queue();
            case "field" -> event.replyModal(fieldSetupModal("")).queue();
            case "panel" -> event.replyModal(panelSetupModal()).queue();
            case "targets" -> event.reply(panelTargetSummary()).setEphemeral(true)
                    .setComponents(panelTargetRows()).queue();
            case "remove" -> event.replyModal(removeSetupModal("")).queue();
            case "publish" -> event.deferReply(true).queue(hook -> publishConfiguredPanel()
                    .whenComplete((result, error) -> edit(hook, error == null
                            ? "Ticket panel published successfully."
                            : "Panel publish failed: " + rootMessage(error))));
            case "reload" -> event.deferReply(true).queue(hook -> reloadTicketConfiguration()
                    .whenComplete((ignored, error) -> edit(hook, error == null
                            ? "Tickets V2 configuration reloaded."
                            : "Reload failed: " + rootMessage(error))));
            default -> { }
        }
    }

    private void handleSetupStringSelect(StringSelectInteractionEvent event) {
        if (!event.getComponentId().equals("coredsc:ticketsetup:select-type")) return;
        if (!canConfigure(event.getMember())) {
            event.reply("Manage Server permission is required.").setEphemeral(true).queue();
            return;
        }
        String typeId = event.getValues().isEmpty() ? "" : event.getValues().getFirst();
        TicketType type = requireSettings().types().get(typeId);
        if (type == null) {
            event.reply("That ticket type no longer exists. Reload the setup menu.").setEphemeral(true).queue();
            return;
        }
        event.reply(typeSetupSummary(type)).setEphemeral(true).setComponents(typeSetupRows(type)).queue();
    }

    private void handleSetupEntitySelect(EntitySelectInteractionEvent event) {
        String id = event.getComponentId();
        if (!id.startsWith("coredsc:ticketsetup:")) return;
        if (!canConfigure(event.getMember())) {
            event.reply("Manage Server permission is required.").setEphemeral(true).queue();
            return;
        }
        List<String> ids = event.getValues().stream().map(value -> value.getId()).toList();
        if (id.equals("coredsc:ticketsetup:newtype-category")) {
            if (ids.isEmpty()) {
                event.reply("Choose one category.").setEphemeral(true).queue();
                return;
            }
            event.replyModal(typeSetupModal(null, ids.getFirst())).queue();
            return;
        }

        CompletableFuture<Void> work;
        String success;
        if (id.equals("coredsc:ticketsetup:panel-channel")) {
            if (ids.isEmpty()) return;
            work = mutateTicketsFile(yaml -> yaml.set("panel.channel-id", ids.getFirst()));
            success = "Ticket panel channel updated.";
        } else if (id.equals("coredsc:ticketsetup:log-channel")) {
            work = mutateTicketsFile(yaml -> yaml.set("logs.channel-id", ids.isEmpty() ? "" : ids.getFirst()));
            success = ids.isEmpty() ? "Ticket log channel cleared." : "Ticket log channel updated.";
        } else if (id.startsWith("coredsc:ticketsetup:category:")) {
            String typeId = id.substring("coredsc:ticketsetup:category:".length());
            if (ids.isEmpty()) return;
            work = mutateTicketsFile(yaml -> requireSetupType(yaml, typeId)
                    .set("category-id", ids.getFirst()));
            success = "Destination category updated for `" + typeId + "`.";
        } else if (id.startsWith("coredsc:ticketsetup:closed:")) {
            String typeId = id.substring("coredsc:ticketsetup:closed:".length());
            work = mutateTicketsFile(yaml -> requireSetupType(yaml, typeId)
                    .set("closed-category-id", ids.isEmpty() ? "" : ids.getFirst()));
            success = ids.isEmpty() ? "Closed category cleared for `" + typeId + "`."
                    : "Closed category updated for `" + typeId + "`.";
        } else if (id.startsWith("coredsc:ticketsetup:staff:")) {
            String typeId = id.substring("coredsc:ticketsetup:staff:".length());
            work = mutateTicketsFile(yaml -> requireSetupType(yaml, typeId)
                    .set("staff-role-ids", ids));
            success = ids.isEmpty() ? "Per-type staff roles cleared; global ticket roles will apply."
                    : "Staff roles updated for `" + typeId + "`.";
        } else {
            return;
        }
        String reply = success;
        event.deferReply(true).queue(hook -> work.whenComplete((ignored, error) -> edit(hook,
                error == null ? reply : "Configuration failed: " + rootMessage(error))));
    }

    private String typeSetupSummary(TicketType type) {
        return "**" + type.label() + "** (`" + type.id() + "`)\n"
                + "Destination: " + (type.categoryId() <= 0L ? "not configured" : "<#" + type.categoryId() + ">") + "\n"
                + "Staff roles: **" + type.staffRoleIds().size() + "**\n"
                + "Form fields: **" + type.fields().size() + "/5**\n"
                + "Linked account required: **" + type.requiresLink(requireSettings().requireLinkedAccount()) + "**\n\n"
                + "Use the selectors below instead of copying Discord IDs manually.";
    }

    private List<ActionRow> typeSetupRows(TicketType type) {
        EntitySelectMenu category = EntitySelectMenu.create(
                        "coredsc:ticketsetup:category:" + type.id(), EntitySelectMenu.SelectTarget.CHANNEL)
                .setChannelTypes(ChannelType.CATEGORY).setMinValues(1).setMaxValues(1)
                .setPlaceholder("Destination category")
                .build();
        EntitySelectMenu roles = EntitySelectMenu.create(
                        "coredsc:ticketsetup:staff:" + type.id(), EntitySelectMenu.SelectTarget.ROLE)
                .setMinValues(0).setMaxValues(10)
                .setPlaceholder("Staff roles (0 = use global roles)")
                .build();
        EntitySelectMenu closed = EntitySelectMenu.create(
                        "coredsc:ticketsetup:closed:" + type.id(), EntitySelectMenu.SelectTarget.CHANNEL)
                .setChannelTypes(ChannelType.CATEGORY).setMinValues(0).setMaxValues(1)
                .setPlaceholder("Closed-ticket category (optional)")
                .build();
        return List.of(
                ActionRow.of(category),
                ActionRow.of(roles),
                ActionRow.of(closed),
                ActionRow.of(
                        Button.primary("coredsc:ticketsetup:edit:" + type.id(), "Button & Link"),
                        Button.secondary("coredsc:ticketsetup:contentfor:" + type.id(), "Content"),
                        Button.secondary("coredsc:ticketsetup:fieldfor:" + type.id(), "Questions"),
                        Button.danger("coredsc:ticketsetup:removefor:" + type.id(), "Remove")
                )
        );
    }

    private String panelTargetSummary() {
        TicketSettings current = requireSettings();
        return "**Ticket Discord Targets**\n"
                + "Panel channel: " + (current.panel().channelId() <= 0L ? "not configured" : "<#" + current.panel().channelId() + ">") + "\n"
                + "Transcript/log channel: " + (current.logChannelId() <= 0L ? "disabled" : "<#" + current.logChannelId() + ">") + "\n\n"
                + "Select channels below. The log channel may be cleared by submitting no selection.";
    }

    private List<ActionRow> panelTargetRows() {
        EntitySelectMenu panel = EntitySelectMenu.create(
                        "coredsc:ticketsetup:panel-channel", EntitySelectMenu.SelectTarget.CHANNEL)
                .setChannelTypes(ChannelType.TEXT).setMinValues(1).setMaxValues(1)
                .setPlaceholder("Ticket panel text channel")
                .build();
        EntitySelectMenu logs = EntitySelectMenu.create(
                        "coredsc:ticketsetup:log-channel", EntitySelectMenu.SelectTarget.CHANNEL)
                .setChannelTypes(ChannelType.TEXT).setMinValues(0).setMaxValues(1)
                .setPlaceholder("Transcript / log channel (optional)")
                .build();
        return List.of(ActionRow.of(panel), ActionRow.of(logs));
    }

    private Modal typeSetupModal(TicketType type, String categoryId) {
        String typeId = type == null ? "" : type.id();
        String label = type == null ? "" : type.label();
        String emoji = type == null ? "" : type.emoji();
        String style = type == null ? "PRIMARY" : type.buttonStyle().name();
        String requireLink = type == null ? "false"
                : Boolean.toString(type.requiresLink(requireSettings().requireLinkedAccount()));
        String modalCategory = categoryId == null || categoryId.isBlank() ? "keep" : categoryId;
        return Modal.create("coredsc:ticketsetup:type:" + modalCategory,
                        type == null ? "Create ticket type" : "Edit " + TextUtil.truncate(type.label(), 35))
                .addComponents(
                        Label.of("Type ID", TextInput.create("type_id", TextInputStyle.SHORT)
                                .setRequired(true).setMinLength(1).setMaxLength(32)
                                .setValue(typeId).setPlaceholder("bug-report").build()),
                        Label.of("Button label", TextInput.create("label", TextInputStyle.SHORT)
                                .setRequired(true).setMaxLength(80).setValue(label).setPlaceholder("Bug Report").build()),
                        Label.of("Emoji (optional)", TextInput.create("emoji", TextInputStyle.SHORT)
                                .setRequired(false).setMaxLength(100).setValue(emoji).setPlaceholder("🐛").build()),
                        Label.of("Button style", TextInput.create("button_style", TextInputStyle.SHORT)
                                .setRequired(true).setMaxLength(16).setValue(style)
                                .setPlaceholder("PRIMARY / SECONDARY / SUCCESS / DANGER").build()),
                        Label.of("Require linked Minecraft account?", TextInput.create("require_link", TextInputStyle.SHORT)
                                .setRequired(true).setMaxLength(5).setValue(requireLink).setPlaceholder("true / false").build())
                ).build();
    }

    private Modal typeContentSetupModal(TicketType type) {
        return Modal.create("coredsc:ticketsetup:content:" + type.id(),
                        "Content · " + TextUtil.truncate(type.label(), 30))
                .addComponents(
                        Label.of("Description", TextInput.create("description", TextInputStyle.PARAGRAPH)
                                .setRequired(false).setMaxLength(300).setValue(type.description()).build()),
                        Label.of("Channel name template", TextInput.create("channel_name", TextInputStyle.SHORT)
                                .setRequired(true).setMaxLength(100).setValue(type.channelName()).build()),
                        Label.of("Opening message", TextInput.create("opening_message", TextInputStyle.PARAGRAPH)
                                .setRequired(true).setMaxLength(4_000).setValue(type.openingMessage()).build())
                ).build();
    }

    private Modal fieldSetupModal(String typeId) {
        return Modal.create("coredsc:ticketsetup:field", "Add or edit form field")
                .addComponents(
                        Label.of("Ticket type ID", TextInput.create("type_id", TextInputStyle.SHORT)
                                .setRequired(true).setMaxLength(32).setValue(typeId == null ? "" : typeId).build()),
                        Label.of("Field ID", TextInput.create("field_id", TextInputStyle.SHORT)
                                .setRequired(true).setMaxLength(32).setPlaceholder("minecraft-version").build()),
                        Label.of("Question / label", TextInput.create("label", TextInputStyle.SHORT)
                                .setRequired(true).setMaxLength(45).setPlaceholder("Minecraft Version").build()),
                        Label.of("Style", TextInput.create("style", TextInputStyle.SHORT)
                                .setRequired(true).setValue("SHORT").setMaxLength(16).build()),
                        Label.of("Rules", TextInput.create("rules", TextInputStyle.PARAGRAPH)
                                .setRequired(false).setMaxLength(300)
                                .setPlaceholder("required=true;min=1;max=100;placeholder=1.21.8").build())
                ).build();
    }

    private Modal panelSetupModal() {
        TicketSettings.Panel panel = requireSettings().panel();
        return Modal.create("coredsc:ticketsetup:panel", "Ticket panel text and layout")
                .addComponents(
                        Label.of("Panel title", TextInput.create("title", TextInputStyle.SHORT)
                                .setRequired(true).setMaxLength(256).setValue(panel.title()).build()),
                        Label.of("Panel description", TextInput.create("description", TextInputStyle.PARAGRAPH)
                                .setRequired(true).setMaxLength(4_000).setValue(panel.description()).build()),
                        Label.of("Footer (optional)", TextInput.create("footer", TextInputStyle.SHORT)
                                .setRequired(false).setMaxLength(2_048).setValue(panel.footer()).build()),
                        Label.of("Ticket type IDs (comma separated)", TextInput.create("type_ids", TextInputStyle.SHORT)
                                .setRequired(false).setMaxLength(500).setValue(String.join(",", requireSettings().panelTypeIds())).build()),
                        Label.of("Embed color", TextInput.create("color", TextInputStyle.SHORT)
                                .setRequired(true).setMaxLength(7)
                                .setValue(String.format("#%06X", panel.color())).setPlaceholder("#5865F2").build())
                ).build();
    }

    private Modal removeSetupModal(String typeId) {
        return Modal.create("coredsc:ticketsetup:remove", "Remove ticket type or field")
                .addComponents(
                        Label.of("Ticket type ID", TextInput.create("type_id", TextInputStyle.SHORT)
                                .setRequired(true).setMaxLength(32).setValue(typeId == null ? "" : typeId).build()),
                        Label.of("Field ID (leave empty to remove type)", TextInput.create("field_id", TextInputStyle.SHORT)
                                .setRequired(false).setMaxLength(32).build())
                ).build();
    }

    private void handleSetupModal(ModalInteractionEvent event) {
        if (!canConfigure(event.getMember())) {
            event.reply("Manage Server permission is required.").setEphemeral(true).queue();
            return;
        }
        String action = event.getModalId().substring("coredsc:ticketsetup:".length());
        event.deferReply(true).queue(hook -> {
            CompletableFuture<Void> work;
            try {
                if (action.startsWith("type:")) {
                    work = saveSetupType(event, action.substring("type:".length()));
                } else if (action.startsWith("content:")) {
                    work = saveSetupTypeContent(event, action.substring("content:".length()));
                } else {
                    work = switch (action) {
                        case "field" -> saveSetupField(event);
                        case "panel" -> saveSetupPanel(event);
                        case "remove" -> removeSetupItem(event);
                        default -> CompletableFuture.failedFuture(new IllegalArgumentException("Unknown setup action"));
                    };
                }
            } catch (Throwable error) {
                edit(hook, "Configuration rejected: " + rootMessage(error));
                return;
            }
            work.whenComplete((ignored, error) -> edit(hook, error == null
                    ? "Ticket configuration saved and reloaded. Use `/" + commandName + " " + subSetup + "` to continue."
                    : "Configuration failed: " + rootMessage(error)));
        });
    }

    private CompletableFuture<Void> saveSetupType(ModalInteractionEvent event, String categoryToken) {
        String typeId = requiredModal(event, "type_id").toLowerCase(Locale.ROOT);
        if (!typeId.matches("[a-z0-9_-]{1,32}")) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("Type ID must match [a-z0-9_-]{1,32}"));
        }
        String label = requiredModal(event, "label");
        String emoji = modal(event, "emoji");
        String style = requiredModal(event, "button_style").toUpperCase(Locale.ROOT);
        if (!Set.of("PRIMARY", "SECONDARY", "SUCCESS", "DANGER").contains(style)) {
            return CompletableFuture.failedFuture(new IllegalArgumentException(
                    "Button style must be PRIMARY, SECONDARY, SUCCESS or DANGER"));
        }
        String linkText = requiredModal(event, "require_link").toLowerCase(Locale.ROOT);
        if (!linkText.equals("true") && !linkText.equals("false")) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("Require-link value must be true or false"));
        }
        boolean requireLink = Boolean.parseBoolean(linkText);
        String chosenCategory = categoryToken.equals("keep") ? "" : requiredSnowflake(categoryToken, "Category ID");
        return mutateTicketsFile(yaml -> {
            String base = "types." + typeId;
            boolean existing = yaml.isConfigurationSection(base);
            if (!existing && chosenCategory.isBlank()) {
                throw new IllegalArgumentException("Choose a Discord category before creating a ticket type");
            }
            yaml.set(base + ".enabled", true);
            yaml.set(base + ".label", label);
            yaml.set(base + ".description", yaml.getString(base + ".description", ""));
            yaml.set(base + ".emoji", emoji);
            yaml.set(base + ".button-style", style);
            yaml.set(base + ".channel-mode", "CHANNEL");
            if (!chosenCategory.isBlank()) yaml.set(base + ".category-id", chosenCategory);
            yaml.set(base + ".parent-channel-id", "");
            yaml.set(base + ".closed-category-id", yaml.getString(base + ".closed-category-id", ""));
            yaml.set(base + ".channel-name", yaml.getString(base + ".channel-name", "ticket-%id%-%discord_name%"));
            yaml.set(base + ".opening-message", yaml.getString(base + ".opening-message",
                    "**%type_label% #%id%**\nOpened by <@%discord_user_id%>\n\n%form%"));
            yaml.set(base + ".require-linked-account", requireLink);
            if (!yaml.contains(base + ".staff-role-ids")) yaml.set(base + ".staff-role-ids", List.of());
            if (!yaml.contains(base + ".fields")) yaml.createSection(base + ".fields");
            List<String> panelTypes = new ArrayList<>(yaml.getStringList("panel.type-ids"));
            if (panelTypes.stream().noneMatch(typeId::equalsIgnoreCase) && panelTypes.size() < 25) {
                panelTypes.add(typeId);
                yaml.set("panel.type-ids", panelTypes);
            }
        });
    }

    private CompletableFuture<Void> saveSetupTypeContent(ModalInteractionEvent event, String typeId) {
        if (typeId == null || !typeId.matches("[a-z0-9_-]{1,32}")) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("Invalid ticket type ID"));
        }
        String description = modal(event, "description");
        String channelName = requiredModal(event, "channel_name");
        String openingMessage = requiredModal(event, "opening_message");
        return mutateTicketsFile(yaml -> {
            ConfigurationSection type = requireSetupType(yaml, typeId);
            type.set("description", description);
            type.set("channel-name", channelName);
            type.set("opening-message", openingMessage);
        });
    }

    private CompletableFuture<Void> saveSetupField(ModalInteractionEvent event) {
        String typeId = requiredModal(event, "type_id").toLowerCase(Locale.ROOT);
        String fieldId = requiredModal(event, "field_id").toLowerCase(Locale.ROOT);
        if (!typeId.matches("[a-z0-9_-]{1,32}") || !fieldId.matches("[a-z0-9_-]{1,32}")) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("Type/field IDs must match [a-z0-9_-]{1,32}"));
        }
        String label = requiredModal(event, "label");
        String style = requiredModal(event, "style").toUpperCase(Locale.ROOT);
        if (!style.equals("SHORT") && !style.equals("PARAGRAPH")) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("Style must be SHORT or PARAGRAPH"));
        }
        Map<String, String> rules = parseRuleString(modal(event, "rules"));
        boolean required = Boolean.parseBoolean(rules.getOrDefault("required", "true"));
        int minimum = boundedInt(rules.get("min"), required ? 1 : 0, 0, 4_000, "min");
        int maximum = boundedInt(rules.get("max"), style.equals("SHORT") ? 400 : 4_000, 1, 4_000, "max");
        if (minimum > maximum) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("min cannot exceed max"));
        }
        String placeholder = TextUtil.truncate(rules.getOrDefault("placeholder", ""), 100);
        return mutateTicketsFile(yaml -> {
            if (!yaml.isConfigurationSection("types." + typeId)) {
                throw new IllegalArgumentException("Unknown ticket type '" + typeId + "'");
            }
            ConfigurationSection fields = yaml.getConfigurationSection("types." + typeId + ".fields");
            int existing = fields == null ? 0 : fields.getKeys(false).size();
            if ((fields == null || !fields.contains(fieldId)) && existing >= 5) {
                throw new IllegalArgumentException("Discord ticket forms support at most 5 fields");
            }
            String base = "types." + typeId + ".fields." + fieldId;
            yaml.set(base + ".enabled", true);
            yaml.set(base + ".label", label);
            yaml.set(base + ".style", style);
            yaml.set(base + ".required", required);
            yaml.set(base + ".min-length", minimum);
            yaml.set(base + ".max-length", maximum);
            yaml.set(base + ".placeholder", placeholder);
        });
    }

    private CompletableFuture<Void> saveSetupPanel(ModalInteractionEvent event) {
        String title = requiredModal(event, "title");
        String description = requiredModal(event, "description");
        String footer = modal(event, "footer");
        List<String> typeIds = csvIds(modal(event, "type_ids"));
        String color = requiredModal(event, "color").toUpperCase(Locale.ROOT);
        if (!color.matches("#[0-9A-F]{6}")) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("Color must be a six-digit hex value such as #5865F2"));
        }
        return mutateTicketsFile(yaml -> {
            for (String typeId : typeIds) {
                if (!yaml.isConfigurationSection("types." + typeId)) {
                    throw new IllegalArgumentException("Unknown panel ticket type '" + typeId + "'");
                }
            }
            yaml.set("panel.title", title);
            yaml.set("panel.description", description);
            yaml.set("panel.footer", footer);
            yaml.set("panel.color", color);
            yaml.set("panel.type-ids", typeIds);
        });
    }

    private ConfigurationSection requireSetupType(YamlConfiguration yaml, String typeId) {
        if (typeId == null || !typeId.matches("[a-z0-9_-]{1,32}")) {
            throw new IllegalArgumentException("Invalid ticket type ID");
        }
        ConfigurationSection type = yaml.getConfigurationSection("types." + typeId);
        if (type == null) throw new IllegalArgumentException("Unknown ticket type '" + typeId + "'");
        return type;
    }

    private CompletableFuture<Void> removeSetupItem(ModalInteractionEvent event) {
        String typeId = requiredModal(event, "type_id").toLowerCase(Locale.ROOT);
        String fieldId = modal(event, "field_id").toLowerCase(Locale.ROOT);
        if (!typeId.matches("[a-z0-9_-]{1,32}")) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("Invalid ticket type ID"));
        }
        if (fieldId.isBlank()) return removeTicketTypeSafely(typeId);
        if (!fieldId.matches("[a-z0-9_-]{1,32}")) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("Invalid field ID"));
        }
        return mutateTicketsFile(yaml -> yaml.set("types." + typeId + ".fields." + fieldId, null));
    }

    private CompletableFuture<Void> removeTicketTypeSafely(String typeId) {
        if (!typeId.matches("[a-z0-9_-]{1,32}")) {
            return CompletableFuture.failedFuture(new IllegalArgumentException("Invalid ticket type ID"));
        }
        return tickets.countOpenByType(typeId).thenCompose(open -> {
            if (open > 0) {
                return CompletableFuture.failedFuture(new IllegalStateException(
                        "Ticket type '" + typeId + "' still has " + open + " open ticket(s). Close them before removing the type."));
            }
            return mutateTicketsFile(yaml -> {
                if (!yaml.isConfigurationSection("types." + typeId)) {
                    throw new IllegalArgumentException("Unknown ticket type '" + typeId + "'");
                }
                yaml.set("types." + typeId, null);
                List<String> ids = new ArrayList<>(yaml.getStringList("panel.type-ids"));
                ids.removeIf(typeId::equalsIgnoreCase);
                yaml.set("panel.type-ids", ids);
            });
        });
    }

    private CompletableFuture<Void> mutateTicketsFile(Consumer<YamlConfiguration> mutator) {
        return runTicketAsync(() -> {
            ConfigManager manager = plugin.getConfigManager();
            ConfigManager.EditorDocument document = null;
            ConfigManager.EditorSaveResult saved = null;
            try {
                document = manager.readEditorDocument(CONFIG_PATH, CONFIG_LIMIT_BYTES);
                YamlConfiguration yaml = new YamlConfiguration();
                yaml.loadFromString(document.content());
                mutator.accept(yaml);
                saved = manager.saveEditorDocument(
                        CONFIG_PATH, yaml.saveToString(), document.revision(), CONFIG_LIMIT_BYTES);
                manager.reload();
                if (!active) throw new IllegalStateException("Tickets module stopped while applying configuration");
                loadConfiguration(plugin.getAppConfig(), false);
            } catch (Throwable error) {
                // A Discord setup action must never leave a file on disk that failed to become
                // the live configuration. Restore our exact pre-edit bytes using optimistic locking.
                if (document != null && saved != null && !saved.revision().equals(document.revision())) {
                    try {
                        manager.saveEditorDocument(
                                CONFIG_PATH, document.content(), saved.revision(), CONFIG_LIMIT_BYTES);
                        manager.reload();
                        if (active) loadConfiguration(plugin.getAppConfig(), false);
                    } catch (Throwable rollbackFailure) {
                        error.addSuppressed(rollbackFailure);
                        plugin.getLogger().log(Level.SEVERE,
                                "[Tickets] Setup configuration rollback failed; restart from the saved backup before further edits",
                                rollbackFailure);
                    }
                }
                if (error instanceof Exception exception) throw exception;
                if (error instanceof Error fatal) throw fatal;
                throw new IllegalStateException(error);
            }
        });
    }

    private CompletableFuture<Void> reloadTicketConfiguration() {
        return runTicketAsync(() -> {
            plugin.getConfigManager().reload();
            if (!active) throw new IllegalStateException("Tickets module stopped while reloading configuration");
            loadConfiguration(plugin.getAppConfig(), false);
        });
    }

    private CompletableFuture<Void> runTicketAsync(TicketAsyncWork work) {
        if (!active || !plugin.isEnabled()) {
            return CompletableFuture.failedFuture(new IllegalStateException("Tickets module is not active"));
        }
        CompletableFuture<Void> future = new CompletableFuture<>();
        try {
            plugin.getCoreScheduler().runAsync(() -> {
                if (!active || !plugin.isEnabled()) {
                    future.completeExceptionally(new IllegalStateException("Tickets module is stopping"));
                    return;
                }
                try {
                    work.run();
                    future.complete(null);
                } catch (Throwable error) {
                    future.completeExceptionally(error);
                }
            });
        } catch (Throwable error) {
            future.completeExceptionally(error);
        }
        return future;
    }

    @FunctionalInterface
    private interface TicketAsyncWork {
        void run() throws Exception;
    }

    private CompletableFuture<Void> persistPanelMessageId(long messageId) {
        if (messageId <= 0L || requireSettings().panel().messageId() == messageId) {
            return CompletableFuture.completedFuture(null);
        }
        return mutateTicketsFile(yaml -> yaml.set("panel.message-id", String.valueOf(messageId)));
    }

    /* ------------------------------ Minecraft commands ------------------------------ */

    private void registerMinecraftCommand() {
        PluginCommand fallback = plugin.getCommand("ticket");
        if (fallback == null) throw new IllegalStateException("ticket command is missing from plugin.yml");
        fallback.setExecutor((sender, cmd, label, args) -> {
            if (!keepDefaultCommand && !commandName.equals("ticket")) {
                sender.sendMessage(TextUtil.colorize(value(plugin.getAppConfig(), "tickets.messages.command-disabled",
                                "&cThis command is disabled. Use /%command%.")
                        .replace("%command%", commandName)));
                return true;
            }
            return executeMinecraftCommand(sender, args);
        });
        fallback.setTabCompleter((sender, cmd, alias, args) -> tabComplete(args));

        if (!commandName.equals("ticket") || !commandAliases.isEmpty()) {
            CommandMap map = plugin.getServer().getCommandMap();
            BukkitCommand dynamic = new BukkitCommand(commandName,
                    value(plugin.getAppConfig(), "tickets.commands.description", "Create and manage support tickets"),
                    "/" + commandName, commandAliases) {
                @Override
                public boolean execute(CommandSender sender, String label, String[] args) {
                    return executeMinecraftCommand(sender, args);
                }

                @Override
                public List<String> tabComplete(CommandSender sender, String alias, String[] args) {
                    return TicketModule.this.tabComplete(args);
                }
            };
            if (!userPermission.isBlank()) dynamic.setPermission(userPermission);
            map.register("coredsc", dynamic);
            registeredCommands.add(dynamic);
            plugin.getServer().getOnlinePlayers().stream().map(Player::getUniqueId)
                    .forEach(playerId -> plugin.runForPlayer(playerId, Player::updateCommands));
        }
    }

    private boolean executeMinecraftCommand(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(TextUtil.colorize(value(plugin.getAppConfig(), "tickets.messages.players-only",
                    "&cOnly players can use tickets.")));
            return true;
        }
        UUID playerId = player.getUniqueId();
        if (!userPermission.isBlank() && !player.hasPermission(userPermission)) {
            player.sendMessage(TextUtil.colorize(value(plugin.getAppConfig(), "tickets.messages.no-permission",
                    "&cYou do not have permission.")));
            return true;
        }
        if (args.length == 0) {
            sendMinecraftHelp(player);
            return true;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (sub.equals(subCreate)) {
            if (args.length < 3) {
                player.sendMessage(TextUtil.colorize(ticketUsage("create", "/%command% %create% <reason> <message>")));
                return true;
            }
            createTicketForPlayer(playerId, args[1], join(args, 2)).whenComplete((result, error) ->
                    plugin.runForPlayer(playerId, currentPlayer -> {
                        if (error != null) {
                            plugin.getLogger().log(Level.WARNING, "[Tickets] Minecraft creation failed", error);
                            currentPlayer.sendMessage(TextUtil.colorize(value(plugin.getAppConfig(),
                                    "tickets.messages.creation-failed", "&cTicket creation failed.")));
                        } else currentPlayer.sendMessage(TextUtil.colorize((result.success() ? "&a" : "&c") + result.message()));
                    }));
            return true;
        }
        if (sub.equals(subStatus)) {
            showMinecraftStatus(player);
            return true;
        }
        if (sub.equals(subReply)) {
            if (args.length < 3) {
                player.sendMessage(TextUtil.colorize(ticketUsage("reply", "/%command% %reply% <id> <message>")));
                return true;
            }
            Long id = parseId(args[1]);
            if (id == null) {
                player.sendMessage(TextUtil.colorize(value(plugin.getAppConfig(), "tickets.messages.invalid-id", "&cInvalid ticket ID.")));
                return true;
            }
            replyFromMinecraft(player, id, join(args, 2));
            return true;
        }
        if (sub.equals(subClose)) {
            if (args.length != 2) {
                player.sendMessage(TextUtil.colorize(ticketUsage("close", "/%command% %close% <id>")));
                return true;
            }
            Long id = parseId(args[1]);
            if (id == null) {
                player.sendMessage(TextUtil.colorize(value(plugin.getAppConfig(), "tickets.messages.invalid-id", "&cInvalid ticket ID.")));
                return true;
            }
            closeFromMinecraft(player, id);
            return true;
        }
        sendMinecraftHelp(player);
        return true;
    }

    private List<String> tabComplete(String[] args) {
        if (args.length == 1) return List.of(subCreate, subStatus, subReply, subClose).stream()
                .filter(value -> value.startsWith(args[0].toLowerCase(Locale.ROOT))).toList();
        return List.of();
    }

    private void unregisterConfiguredCommands() {
        if (registeredCommands.isEmpty()) return;
        CommandMap map = plugin.getServer().getCommandMap();
        Map<String, org.bukkit.command.Command> known = map.getKnownCommands();
        for (BukkitCommand command : registeredCommands) {
            command.unregister(map);
            known.entrySet().removeIf(entry -> entry.getValue() == command);
        }
        registeredCommands.clear();
        plugin.getServer().getOnlinePlayers().stream().map(Player::getUniqueId)
                .forEach(playerId -> plugin.runForPlayer(playerId, Player::updateCommands));
    }

    private String ticketUsage(String key, String fallback) {
        return value(plugin.getAppConfig(), "tickets.commands.usage." + key, fallback)
                .replace("%command%", commandName).replace("%create%", subCreate)
                .replace("%reply%", subReply).replace("%close%", subClose);
    }

    private void sendMinecraftHelp(Player player) {
        List<String> configured = plugin.getAppConfig().getStringList("tickets.messages.help");
        List<String> lines = configured.isEmpty() ? List.of(
                "&b/%command% %create% <reason> <message>",
                "&b/%command% %status%",
                "&b/%command% %reply% <id> <message>",
                "&b/%command% %close% <id>") : configured;
        for (String line : lines) player.sendMessage(TextUtil.colorize(line
                .replace("%command%", commandName).replace("%create%", subCreate).replace("%status%", subStatus)
                .replace("%reply%", subReply).replace("%close%", subClose)));
    }

    /* ------------------------------ Helpers ------------------------------ */

    private synchronized void loadConfiguration(FileConfiguration config, boolean loadCommands) {
        TicketSettings loaded = TicketSettings.from(config);
        settings = loaded;
        if (!loadCommands) return;
        commandName = commandToken(value(config, "tickets.commands.root", "ticket"), "ticket");
        commandAliases = config.getStringList("tickets.commands.aliases").stream().map(v -> commandToken(v, ""))
                .filter(v -> !v.isBlank() && !v.equals(commandName)).distinct().toList();
        keepDefaultCommand = config.getBoolean("tickets.commands.keep-default-ticket-command", true);
        subCreate = commandToken(value(config, "tickets.commands.subcommands.create", "create"), "create");
        subStatus = commandToken(value(config, "tickets.commands.subcommands.status", "status"), "status");
        subReply = commandToken(value(config, "tickets.commands.subcommands.reply", "reply"), "reply");
        subClose = commandToken(value(config, "tickets.commands.subcommands.close", "close"), "close");
        subClaim = commandToken(value(config, "tickets.commands.subcommands.claim", "claim"), "claim");
        subPriority = commandToken(value(config, "tickets.commands.subcommands.priority", "priority"), "priority");
        subSetup = commandToken(value(config, "tickets.commands.subcommands.setup", "setup"), "setup");
        userPermission = value(config, "tickets.commands.permission", "coredsc.ticket").trim();
    }

    private TicketSettings requireSettings() {
        TicketSettings current = settings;
        if (current == null) throw new IllegalStateException("Tickets are not configured");
        return current;
    }

    private TicketType defaultType() {
        TicketSettings current = requireSettings();
        for (String id : current.panelTypeIds()) {
            TicketType type = current.type(id);
            if (type != null) return type;
        }
        return current.types().values().stream().findFirst().orElse(null);
    }

    private TicketType typeFor(Ticket ticket) {
        TicketType type = requireSettings().type(ticket.ticketType());
        return type == null ? defaultType() : type;
    }

    private String ticketTypeLabel(Ticket ticket) {
        TicketType type = typeFor(ticket);
        return type == null ? ticket.ticketType() : type.label();
    }

    private boolean hasStaffRole(Member member, TicketType type) {
        if (member == null) return false;
        if (member.hasPermission(Permission.MANAGE_CHANNEL, Permission.MANAGE_SERVER)) return true;
        Collection<Long> roles = type == null ? requireSettings().allStaffRoleIds() : type.staffRoleIds();
        for (Role role : member.getRoles()) if (roles.contains(role.getIdLong())) return true;
        return false;
    }

    private boolean canConfigure(Member member) {
        return member != null && member.hasPermission(Permission.MANAGE_SERVER);
    }

    private List<ActionRow> panelRows(TicketSettings current) {
        List<Button> buttons = new ArrayList<>();
        for (String id : current.panelTypeIds()) {
            TicketType type = current.type(id);
            if (type == null) continue;
            Button button = switch (type.buttonStyle()) {
                case PRIMARY -> Button.primary("coredsc:ticket:new:" + type.id(), type.label());
                case SECONDARY -> Button.secondary("coredsc:ticket:new:" + type.id(), type.label());
                case SUCCESS -> Button.success("coredsc:ticket:new:" + type.id(), type.label());
                case DANGER -> Button.danger("coredsc:ticket:new:" + type.id(), type.label());
            };
            if (!type.emoji().isBlank()) {
                try {
                    button = button.withEmoji(Emoji.fromFormatted(type.emoji()));
                } catch (IllegalArgumentException error) {
                    plugin.getLogger().warning("[Tickets] Invalid emoji for type " + type.id() + ": " + type.emoji());
                }
            }
            buttons.add(button);
        }
        List<ActionRow> rows = new ArrayList<>();
        for (int offset = 0; offset < buttons.size(); offset += 5) {
            rows.add(ActionRow.of(buttons.subList(offset, Math.min(offset + 5, buttons.size()))));
        }
        return List.copyOf(rows);
    }

    private Map<String, String> sanitizeForm(TicketType type, Map<String, String> raw) {
        Map<String, String> values = new LinkedHashMap<>();
        if (type.fields().isEmpty()) {
            for (Map.Entry<String, String> entry : raw.entrySet()) {
                String key = TicketSettings.safeId(entry.getKey());
                if (!key.isBlank()) values.put(key, TextUtil.truncate(TextUtil.sanitizeMinecraftUserText(entry.getValue()), 2_000));
            }
            return Map.copyOf(values);
        }
        for (Field field : type.fields()) {
            String value = raw.getOrDefault(field.id(), "").replace('\0', ' ').trim();
            if (field.required() && value.isBlank()) {
                throw new IllegalArgumentException(field.label() + " is required");
            }
            if (!value.isBlank() && value.length() < field.minLength()) {
                throw new IllegalArgumentException(field.label() + " must contain at least " + field.minLength() + " characters");
            }
            if (value.length() > field.maxLength()) value = value.substring(0, field.maxLength());
            values.put(field.id(), TextUtil.sanitizeMinecraftUserText(value));
        }
        return Map.copyOf(values);
    }

    private String minecraftNameFromForm(Map<String, String> form) {
        for (String key : List.of("minecraft-name", "minecraft_name", "username", "name")) {
            String value = form.getOrDefault(key, "").trim();
            if (!value.isBlank()) return TextUtil.truncate(value, 32);
        }
        return "";
    }

    private String ticketSummary(TicketType type, Map<String, String> form) {
        for (Field field : type.fields()) {
            String value = form.getOrDefault(field.id(), "").trim();
            if (!value.isBlank()) return TextUtil.truncate(type.label() + ": " + value, 100);
        }
        String reason = form.getOrDefault("reason", "").trim();
        return TextUtil.truncate(reason.isBlank() ? type.label() : reason, 100);
    }

    private String formDisplay(TicketType type, Map<String, String> form) {
        StringBuilder text = new StringBuilder();
        if (type.fields().isEmpty()) {
            for (Map.Entry<String, String> entry : form.entrySet()) {
                if (entry.getValue().isBlank()) continue;
                text.append("**").append(entry.getKey()).append(":** ")
                        .append(TextUtil.sanitizeMassMentions(entry.getValue())).append('\n');
            }
        } else {
            for (Field field : type.fields()) {
                String value = form.getOrDefault(field.id(), "");
                text.append("**").append(field.label()).append(":** ")
                        .append(value.isBlank() ? "—" : TextUtil.sanitizeMassMentions(value)).append('\n');
            }
        }
        return TextUtil.truncate(text.toString().trim(), 1_500);
    }

    private String prettyForm(Ticket ticket) {
        // The opening message is the immutable human-readable snapshot produced
        // when the ticket was created. Never rebuild a historical submission
        // from the current ticket-type schema: administrators may legitimately
        // rename or remove fields while older tickets are still open.
        return TextUtil.truncate(ticket.message(), 1_500);
    }

    private CompletableFuture<Void> sendChunks(TextChannel channel, String raw, String heading) {
        String text = TextUtil.sanitizeMassMentions(raw);
        List<String> chunks = new ArrayList<>();
        int offset = 0;
        while (offset < text.length()) {
            int end = Math.min(text.length(), offset + 1_850);
            // Never split a UTF-16 surrogate pair between Discord messages.
            if (end < text.length() && end > offset
                    && Character.isHighSurrogate(text.charAt(end - 1))
                    && Character.isLowSurrogate(text.charAt(end))) {
                end--;
            }
            if (end <= offset) end = Math.min(text.length(), offset + 1);
            chunks.add(text.substring(offset, end));
            offset = end;
        }
        CompletableFuture<Void> chain = CompletableFuture.completedFuture(null);
        for (int index = 0; index < chunks.size(); index++) {
            String prefix = index == 0 ? "**" + heading + "**\n```text\n" : "```text\n";
            String payload = prefix + chunks.get(index).replace("```", "'''" ) + "\n```";
            chain = chain.thenCompose(ignored -> channel.sendMessage(payload)
                    .setAllowedMentions(Collections.emptyList()).submit().thenApply(message -> null));
        }
        return chain;
    }

    private CompletableFuture<Void> deleteContainerQuietly(TicketContainer container) {
        try {
            JDA jda = requireReadyJda();
            if (container.thread()) {
                ThreadChannel thread = jda.getThreadChannelById(container.id());
                return thread == null ? CompletableFuture.completedFuture(null)
                        : thread.delete().submit().handle((ignored, error) -> null);
            }
            TextChannel channel = jda.getTextChannelById(container.id());
            return channel == null ? CompletableFuture.completedFuture(null)
                    : channel.delete().submit().handle((ignored, error) -> null);
        } catch (RuntimeException error) {
            return CompletableFuture.completedFuture(null);
        }
    }

    private JDA requireReadyJda() {
        DiscordBotService service = requireDiscord();
        if (!service.isReady() || service.getJda() == null) throw new IllegalStateException("Discord is not ready");
        return service.getJda();
    }

    private DiscordBotService requireDiscord() {
        DiscordBotService service = plugin.getDiscordService();
        if (service == null) throw new IllegalStateException("Discord service is not initialised");
        return service;
    }

    private void edit(InteractionHook hook, String message) {
        String safe = message == null ? "Operation failed." : message;
        hook.editOriginal(TextUtil.truncate(TextUtil.sanitizeMassMentions(safe), 2_000))
                .setAllowedMentions(Collections.emptyList()).queue(ignored -> { }, error -> { });
    }

    private static String modal(ModalInteractionEvent event, String id) {
        return event.getValue(id) == null ? "" : event.getValue(id).getAsString().replace('\0', ' ').trim();
    }

    private static String requiredModal(ModalInteractionEvent event, String id) {
        String value = modal(event, id);
        if (value.isBlank()) throw new IllegalArgumentException(id + " is required");
        return value;
    }

    private static String cloudId(Object raw, String label) {
        String value = raw == null ? "" : String.valueOf(raw).trim().toLowerCase(Locale.ROOT);
        if (!value.matches("[a-z0-9_-]{1,32}")) throw new IllegalArgumentException(label + " must match [a-z0-9_-]{1,32}");
        return value;
    }

    private static String cloudText(Object raw, int maximum, String label, boolean required) {
        String value = raw == null ? "" : String.valueOf(raw).replace('\0', ' ').trim();
        if (required && value.isBlank()) throw new IllegalArgumentException(label + " is required");
        if (value.length() > maximum) throw new IllegalArgumentException(label + " exceeds " + maximum + " characters");
        return value;
    }

    private static String cloudSnowflake(Object raw, String label, boolean allowBlank) {
        String value = raw == null ? "" : String.valueOf(raw).trim();
        if (value.isBlank() && allowBlank) return "";
        if (!value.matches("[1-9][0-9]{16,20}")) throw new IllegalArgumentException(label + " must be a Discord ID");
        return value;
    }

    private static List<String> cloudSnowflakeList(Object raw, String label, int maximum) {
        if (raw == null) return List.of();
        if (!(raw instanceof Collection<?> values)) throw new IllegalArgumentException(label + " must be an array");
        if (values.size() > maximum) throw new IllegalArgumentException(label + " exceeds " + maximum + " entries");
        List<String> result = new ArrayList<>();
        for (Object value : values) {
            String id = cloudSnowflake(value, label, false);
            if (!result.contains(id)) result.add(id);
        }
        return List.copyOf(result);
    }

    private static List<String> cloudIdList(Object raw, String label, int maximum) {
        if (raw == null) return List.of();
        if (!(raw instanceof Collection<?> values)) throw new IllegalArgumentException(label + " must be an array");
        if (values.size() > maximum) throw new IllegalArgumentException(label + " exceeds " + maximum + " entries");
        List<String> result = new ArrayList<>();
        for (Object value : values) {
            String id = cloudId(value, label);
            if (!result.contains(id)) result.add(id);
        }
        return List.copyOf(result);
    }

    private static boolean cloudBoolean(Object raw, boolean fallback) {
        if (raw == null) return fallback;
        if (raw instanceof Boolean value) return value;
        String text = String.valueOf(raw).trim().toLowerCase(Locale.ROOT);
        if (text.equals("true")) return true;
        if (text.equals("false")) return false;
        throw new IllegalArgumentException("Boolean value must be true or false");
    }

    private static int cloudInt(Object raw, int fallback, int minimum, int maximum, String label) {
        if (raw == null || String.valueOf(raw).isBlank()) return fallback;
        final long value;
        try { value = raw instanceof Number number ? number.longValue() : Long.parseLong(String.valueOf(raw).trim()); }
        catch (NumberFormatException error) { throw new IllegalArgumentException(label + " must be a whole number", error); }
        if (value < minimum || value > maximum) throw new IllegalArgumentException(label + " must be between " + minimum + " and " + maximum);
        return (int) value;
    }

    private static String requiredSnowflake(String raw, String label) {
        try {
            long value = Long.parseLong(raw.trim());
            if (value <= 0L) throw new NumberFormatException();
            return String.valueOf(value);
        } catch (NumberFormatException error) {
            throw new IllegalArgumentException(label + " must be a valid Discord ID", error);
        }
    }

    private static List<String> csvSnowflakes(String raw, String label) {
        if (raw == null || raw.isBlank()) return List.of();
        List<String> values = new ArrayList<>();
        for (String item : raw.split(",")) {
            String value = item.trim();
            if (!value.isBlank()) values.add(requiredSnowflake(value, label));
        }
        return values.stream().distinct().toList();
    }

    private static List<String> csvIds(String raw) {
        if (raw == null || raw.isBlank()) return List.of();
        List<String> values = new ArrayList<>();
        for (String item : raw.split(",")) {
            String id = TicketSettings.safeId(item);
            if (id.isBlank()) throw new IllegalArgumentException("Invalid ticket type ID '" + item.trim() + "'");
            if (!values.contains(id)) values.add(id);
        }
        if (values.size() > 25) throw new IllegalArgumentException("A ticket panel supports at most 25 buttons");
        return List.copyOf(values);
    }

    private static Map<String, String> parseRuleString(String raw) {
        Map<String, String> values = new LinkedHashMap<>();
        if (raw == null || raw.isBlank()) return values;
        for (String item : raw.split(";")) {
            int equals = item.indexOf('=');
            if (equals <= 0) continue;
            values.put(item.substring(0, equals).trim().toLowerCase(Locale.ROOT), item.substring(equals + 1).trim());
        }
        return values;
    }

    private static int boundedInt(String raw, int fallback, int minimum, int maximum, String label) {
        if (raw == null || raw.isBlank()) return fallback;
        try {
            int value = Integer.parseInt(raw.trim());
            if (value < minimum || value > maximum) throw new NumberFormatException();
            return value;
        } catch (NumberFormatException error) {
            throw new IllegalArgumentException(label + " must be between " + minimum + " and " + maximum, error);
        }
    }

    private static String commandToken(String value, String fallback) {
        String clean = value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
        return clean.matches("[a-z0-9_-]{1,32}") ? clean : fallback;
    }

    private static String value(FileConfiguration config, String path, String fallback) {
        String result = config.getString(path, fallback);
        return result == null ? fallback : result;
    }

    private static boolean isOpen(Ticket ticket) {
        return ticket.status().equals("OPEN") || ticket.status().equals("CLAIMED");
    }

    private static Long parseId(String value) {
        try {
            long id = Long.parseLong(value);
            return id > 0 ? id : null;
        } catch (NumberFormatException error) {
            return null;
        }
    }

    private static UUID parseUuid(String value) {
        if (value == null || value.isBlank()) return null;
        try {
            return UUID.fromString(value);
        } catch (IllegalArgumentException error) {
            return null;
        }
    }

    private static String join(String[] args, int start) {
        return String.join(" ", java.util.Arrays.copyOfRange(args, start, args.length));
    }

    private static String snowflakeText(long value) {
        return value <= 0L ? "" : Long.toString(value);
    }

    private static String reservationMessage(ReserveStatus status, long remaining) {
        return switch (status) {
            case USER_LIMIT -> "You already have the maximum number of open tickets.";
            case GLOBAL_LIMIT -> "The server currently has too many open tickets.";
            case COOLDOWN -> "Please wait " + Math.max(1L, (remaining + 999L) / 1_000L) + " second(s).";
            case RESERVED -> "Ticket reserved.";
        };
    }

    private static boolean isUnknownDiscordMessage(Throwable error) {
        Throwable current = error;
        while ((current instanceof java.util.concurrent.CompletionException
                || current instanceof java.util.concurrent.ExecutionException) && current.getCause() != null) {
            current = current.getCause();
        }
        while (current != null) {
            if (current instanceof ErrorResponseException response
                    && response.getErrorResponse() == ErrorResponse.UNKNOWN_MESSAGE) {
                return true;
            }
            current = current.getCause();
        }
        return false;
    }

    private static String rootMessage(Throwable error) {
        if (error == null) return "unknown error";
        Throwable current = error;
        while ((current instanceof java.util.concurrent.CompletionException
                || current instanceof java.util.concurrent.ExecutionException) && current.getCause() != null) {
            current = current.getCause();
        }
        while (current.getCause() != null) current = current.getCause();
        return current.getMessage() == null || current.getMessage().isBlank()
                ? current.getClass().getSimpleName() : current.getMessage();
    }

    private record TicketContainer(String id, boolean thread) { }
    private record RenderedTicket(String name, String opening) { }
}
