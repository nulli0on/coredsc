package com.hubertstudios.coredsc.module.impl;

import com.hubertstudios.coredsc.CoreDSCPlugin;
import com.hubertstudios.coredsc.discord.DiscordBotService;
import com.hubertstudios.coredsc.config.ConfigManager;
import com.hubertstudios.coredsc.event.DiscordReadyEvent;
import com.hubertstudios.coredsc.module.CoreModule;
import com.hubertstudios.coredsc.module.DiscordCommandContributor;
import com.hubertstudios.coredsc.selfrole.SelfRoleSettings;
import com.hubertstudios.coredsc.storage.SelfRolePanelRepository;
import com.hubertstudios.coredsc.storage.SQLiteStorage;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.components.actionrow.ActionRow;
import net.dv8tion.jda.api.components.selections.SelectOption;
import net.dv8tion.jda.api.components.selections.StringSelectMenu;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.entities.emoji.Emoji;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.events.interaction.component.StringSelectInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.InteractionHook;
import net.dv8tion.jda.api.interactions.commands.OptionType;
import net.dv8tion.jda.api.interactions.commands.build.CommandData;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import net.dv8tion.jda.api.interactions.commands.build.SubcommandData;
import net.dv8tion.jda.api.requests.ErrorResponse;
import net.dv8tion.jda.api.exceptions.ErrorResponseException;
import net.dv8tion.jda.api.utils.messages.MessageCreateBuilder;
import net.dv8tion.jda.api.utils.messages.MessageCreateData;
import net.dv8tion.jda.api.utils.messages.MessageEditBuilder;
import org.bukkit.event.EventHandler;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.configuration.file.YamlConfiguration;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionException;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;
import java.util.logging.Level;

/** Configurable Discord self-role panels with single/multi-select groups. */
public final class SelfRoleModule implements CoreModule, DiscordCommandContributor, Listener {
    private static final String COMPONENT_PREFIX = "coredsc:selfrole:";
    private static final String CONFIG_PATH = "modules/self-roles.yml";
    private static final int CONFIG_LIMIT_BYTES = 256 * 1024;
    private final CoreDSCPlugin plugin;
    private final AtomicBoolean active = new AtomicBoolean();
    private SelfRoleSettings settings;
    private SelfRolePanelRepository panels;
    private ListenerAdapter discordListener;

    public SelfRoleModule(CoreDSCPlugin plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
    }

    @Override public String id() { return "self-roles"; }

    @Override
    public void enable() {
        SQLiteStorage storage = plugin.getStorage();
        if (storage == null || storage.getState() != SQLiteStorage.State.READY) {
            throw new IllegalStateException("SQLite storage is not ready");
        }
        DiscordBotService discord = plugin.getDiscordService();
        if (discord == null) throw new IllegalStateException("Discord service is not initialised");
        settings = SelfRoleSettings.from(plugin.getAppConfig());
        panels = new SelfRolePanelRepository(storage);
        active.set(true);
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
        discordListener = new ListenerAdapter() {
            @Override public void onStringSelectInteraction(StringSelectInteractionEvent event) {
                handleSelect(event);
            }
            @Override public void onSlashCommandInteraction(SlashCommandInteractionEvent event) {
                if (!event.getName().equals("roles")) return;
                handleCommand(event);
            }
        };
        discord.addEventListener(discordListener);
        if (settings.publishOnStartup() && discord.isReady()) publishAll();
    }

    @Override
    public void disable() {
        active.set(false);
        HandlerList.unregisterAll(this);
        DiscordBotService discord = plugin.getDiscordService();
        if (discordListener != null && discord != null) discord.removeEventListener(discordListener);
        discordListener = null;
        settings = null;
        panels = null;
    }

    @Override public String statusDetail() {
        SelfRoleSettings current = settings;
        return current == null ? "stopped" : current.panels().size() + " self-role panel(s)";
    }

    @Override
    public List<CommandData> slashCommands() {
        return List.of(Commands.slash("roles", "Manage CoreDSC self-role panels")
                .addSubcommands(
                        new SubcommandData("status", "Show configured self-role panels"),
                        new SubcommandData("publish", "Publish or refresh a self-role panel")
                                .addOption(OptionType.STRING, "panel", "Panel ID; omit for all panels", false),
                        new SubcommandData("setup", "Create a complete first self-role panel/group/role")
                                .addOption(OptionType.STRING, "panel", "Panel ID", true)
                                .addOption(OptionType.CHANNEL, "channel", "Text channel for the panel", true)
                                .addOption(OptionType.STRING, "title", "Panel title", true)
                                .addOption(OptionType.STRING, "group", "First group ID", true)
                                .addOption(OptionType.STRING, "group-label", "First group label", true)
                                .addOption(OptionType.STRING, "mode", "SINGLE or MULTIPLE", true)
                                .addOption(OptionType.STRING, "option", "First option ID", true)
                                .addOption(OptionType.ROLE, "role", "Discord role for the first option", true)
                                .addOption(OptionType.STRING, "role-label", "Visible label for the first option", true),
                        new SubcommandData("add-group", "Add a role group with its first option")
                                .addOption(OptionType.STRING, "panel", "Panel ID", true)
                                .addOption(OptionType.STRING, "group", "New group ID", true)
                                .addOption(OptionType.STRING, "label", "Group label", true)
                                .addOption(OptionType.STRING, "mode", "SINGLE or MULTIPLE", true)
                                .addOption(OptionType.STRING, "option", "First option ID", true)
                                .addOption(OptionType.ROLE, "role", "Discord role for the first option", true)
                                .addOption(OptionType.STRING, "role-label", "Visible label", true),
                        new SubcommandData("add-option", "Add a selectable role to an existing group")
                                .addOption(OptionType.STRING, "panel", "Panel ID", true)
                                .addOption(OptionType.STRING, "group", "Group ID", true)
                                .addOption(OptionType.STRING, "option", "Option ID", true)
                                .addOption(OptionType.ROLE, "role", "Discord role", true)
                                .addOption(OptionType.STRING, "label", "Visible label", true)
                                .addOption(OptionType.STRING, "emoji", "Optional Unicode/custom emoji", false),
                        new SubcommandData("remove-option", "Remove one selectable role")
                                .addOption(OptionType.STRING, "panel", "Panel ID", true)
                                .addOption(OptionType.STRING, "group", "Group ID", true)
                                .addOption(OptionType.STRING, "option", "Option ID", true),
                        new SubcommandData("reload", "Reload self-role configuration from disk")
                ));
    }

    @EventHandler
    public void onDiscordReady(DiscordReadyEvent ignored) {
        SelfRoleSettings current = settings;
        if (active.get() && current != null && current.publishOnStartup()) publishAll();
    }

    private void handleCommand(SlashCommandInteractionEvent event) {
        if (!active.get()) return;
        if (event.getGuild() == null || event.getGuild().getIdLong() != settings.guildId()) {
            event.reply("This self-role setup belongs to another Discord server.").setEphemeral(true).queue();
            return;
        }
        Member member = event.getMember();
        if (member == null || !member.hasPermission(Permission.MANAGE_ROLES)) {
            event.reply("You need **Manage Roles** to manage self-role panels.").setEphemeral(true).queue();
            return;
        }
        String sub = event.getSubcommandName() == null ? "status" : event.getSubcommandName();
        if (sub.equals("status")) {
            event.reply("Configured self-role panels: **" + settings.panels().size() + "**\n"
                    + (settings.panels().isEmpty() ? "None" : String.join(", ", settings.panels().keySet())))
                    .setEphemeral(true).queue();
            return;
        }
        if (sub.equals("publish")) {
            String panelId = event.getOption("panel") == null ? ""
                    : requireSetupId(event.getOption("panel").getAsString(), "panel");
            event.deferReply(true).queue(hook -> {
                CompletableFuture<Integer> action;
                if (panelId.isBlank()) action = publishAll();
                else {
                    SelfRoleSettings.Panel panel = settings.panel(panelId);
                    if (panel == null) {
                        hook.editOriginal("Unknown self-role panel: `" + panelId + "`").queue();
                        return;
                    }
                    action = publish(panel).thenApply(ignored -> 1);
                }
                action.whenComplete((count, error) -> {
                    if (error != null) hook.editOriginal("Could not publish self-role panels: " + rootMessage(error)).queue();
                    else hook.editOriginal("Published/refreshed **" + count + "** self-role panel(s).").queue();
                });
            });
            return;
        }
        if (sub.equals("reload")) {
            event.deferReply(true).queue(hook -> reloadSelfRoleConfiguration().whenComplete((ignored, error) -> {
                if (error != null) hook.editOriginal("Could not reload self-role configuration: " + rootMessage(error)).queue();
                else hook.editOriginal("Self-role configuration reloaded. **" + settings.panels().size() + "** panel(s) are active.").queue();
            }));
            return;
        }

        CompletableFuture<Void> mutation;
        try {
            mutation = switch (sub) {
                case "setup" -> setupInitialPanel(event);
                case "add-group" -> addSetupGroup(event);
                case "add-option" -> addSetupOption(event);
                case "remove-option" -> removeSetupOption(event);
                default -> CompletableFuture.failedFuture(new IllegalArgumentException("Unknown self-role setup action"));
            };
        } catch (RuntimeException error) {
            event.reply(rootMessage(error)).setEphemeral(true).queue();
            return;
        }
        event.deferReply(true).queue(hook -> mutation.whenComplete((ignored, error) -> {
            if (error != null) hook.editOriginal("Self-role setup failed: " + rootMessage(error)).queue();
            else hook.editOriginal("Self-role configuration saved and reloaded. Use `/roles publish` to update the panel message.").queue();
        }));
    }

    private CompletableFuture<Void> setupInitialPanel(SlashCommandInteractionEvent event) {
        String panelId = requiredOptionId(event, "panel");
        String groupId = requiredOptionId(event, "group");
        String optionId = requiredOptionId(event, "option");
        String title = requiredBounded(event, "title", 256);
        String groupLabel = requiredBounded(event, "group-label", 100);
        String roleLabel = requiredBounded(event, "role-label", 100);
        String mode = requireMode(requiredBounded(event, "mode", 16));
        long channelId = event.getOption("channel").getAsChannel().getIdLong();
        long roleId = event.getOption("role").getAsRole().getIdLong();
        Guild guild = event.getGuild();
        if (guild == null || guild.getTextChannelById(channelId) == null) {
            throw new IllegalArgumentException("The selected panel destination must be a text channel.");
        }
        requireManageableRole(guild, roleId);
        return mutateSelfRoleFile(yaml -> {
            List<Map<String, Object>> all = mutablePanels(yaml);
            if (findPanel(all, panelId) != null) throw new IllegalArgumentException("Panel '" + panelId + "' already exists");
            Map<String, Object> option = optionMap(optionId, roleLabel, "", roleId);
            Map<String, Object> group = groupMap(groupId, groupLabel, mode, option);
            Map<String, Object> panel = new LinkedHashMap<>();
            panel.put("id", panelId); panel.put("channel-id", Long.toString(channelId)); panel.put("title", title);
            panel.put("description", "Choose your roles below."); panel.put("footer", ""); panel.put("color", "#5865F2");
            panel.put("groups", new ArrayList<>(List.of(group)));
            all.add(panel);
            yaml.set("panels", all);
        });
    }

    private CompletableFuture<Void> addSetupGroup(SlashCommandInteractionEvent event) {
        String panelId = requiredOptionId(event, "panel");
        String groupId = requiredOptionId(event, "group");
        String optionId = requiredOptionId(event, "option");
        String label = requiredBounded(event, "label", 100);
        String roleLabel = requiredBounded(event, "role-label", 100);
        String mode = requireMode(requiredBounded(event, "mode", 16));
        long roleId = event.getOption("role").getAsRole().getIdLong();
        requireManageableRole(event.getGuild(), roleId);
        return mutateSelfRoleFile(yaml -> {
            List<Map<String, Object>> all = mutablePanels(yaml);
            Map<String, Object> panel = requirePanel(all, panelId);
            List<Map<String, Object>> groups = mutableMapList(panel.get("groups"));
            if (findById(groups, groupId) != null) throw new IllegalArgumentException("Group '" + groupId + "' already exists");
            if (groups.size() >= 5) throw new IllegalArgumentException("A self-role panel supports at most 5 groups");
            groups.add(groupMap(groupId, label, mode, optionMap(optionId, roleLabel, "", roleId)));
            panel.put("groups", groups);
            yaml.set("panels", all);
        });
    }

    private CompletableFuture<Void> addSetupOption(SlashCommandInteractionEvent event) {
        String panelId = requiredOptionId(event, "panel");
        String groupId = requiredOptionId(event, "group");
        String optionId = requiredOptionId(event, "option");
        String label = requiredBounded(event, "label", 100);
        String emoji = event.getOption("emoji") == null ? "" : bounded(event.getOption("emoji").getAsString(), 100, "emoji");
        long roleId = event.getOption("role").getAsRole().getIdLong();
        requireManageableRole(event.getGuild(), roleId);
        return mutateSelfRoleFile(yaml -> {
            List<Map<String, Object>> all = mutablePanels(yaml);
            Map<String, Object> panel = requirePanel(all, panelId);
            List<Map<String, Object>> groups = mutableMapList(panel.get("groups"));
            Map<String, Object> group = findById(groups, groupId);
            if (group == null) throw new IllegalArgumentException("Unknown group '" + groupId + "'");
            List<Map<String, Object>> options = mutableMapList(group.get("options"));
            if (findById(options, optionId) != null) throw new IllegalArgumentException("Option '" + optionId + "' already exists");
            if (options.size() >= 25) throw new IllegalArgumentException("A self-role group supports at most 25 options");
            for (Map<String, Object> existing : options) {
                if (String.valueOf(existing.getOrDefault("role-id", "")).equals(Long.toString(roleId))) {
                    throw new IllegalArgumentException("That Discord role is already used in this group");
                }
            }
            options.add(optionMap(optionId, label, emoji, roleId));
            group.put("options", options); panel.put("groups", groups); yaml.set("panels", all);
        });
    }

    private CompletableFuture<Void> removeSetupOption(SlashCommandInteractionEvent event) {
        String panelId = requiredOptionId(event, "panel");
        String groupId = requiredOptionId(event, "group");
        String optionId = requiredOptionId(event, "option");
        return mutateSelfRoleFile(yaml -> {
            List<Map<String, Object>> all = mutablePanels(yaml);
            Map<String, Object> panel = requirePanel(all, panelId);
            List<Map<String, Object>> groups = mutableMapList(panel.get("groups"));
            Map<String, Object> group = findById(groups, groupId);
            if (group == null) throw new IllegalArgumentException("Unknown group '" + groupId + "'");
            List<Map<String, Object>> options = mutableMapList(group.get("options"));
            if (options.size() <= 1) throw new IllegalArgumentException("The last option cannot be removed; remove or replace the group through the dashboard/YAML instead");
            boolean removed = options.removeIf(item -> SelfRoleSettings.safeId(String.valueOf(item.get("id"))).equals(optionId));
            if (!removed) throw new IllegalArgumentException("Unknown option '" + optionId + "'");
            group.put("options", options); panel.put("groups", groups); yaml.set("panels", all);
        });
    }

    private void requireManageableRole(Guild guild, long roleId) {
        if (guild == null) throw new IllegalArgumentException("This command must be used in the configured Discord server");
        Role role = guild.getRoleById(roleId);
        if (role == null) throw new IllegalArgumentException("The selected role does not exist in this server");
        if (!guild.getSelfMember().hasPermission(Permission.MANAGE_ROLES) || !guild.getSelfMember().canInteract(role)) {
            throw new IllegalArgumentException("CoreDSC cannot manage '" + role.getName() + "'. Move the bot role above it and grant Manage Roles.");
        }
    }

    private CompletableFuture<Void> mutateSelfRoleFile(Consumer<YamlConfiguration> mutator) {
        return runSelfRoleAsync(() -> {
            ConfigManager manager = plugin.getConfigManager();
            ConfigManager.EditorDocument document = null;
            ConfigManager.EditorSaveResult saved = null;
            try {
                document = manager.readEditorDocument(CONFIG_PATH, CONFIG_LIMIT_BYTES);
                YamlConfiguration yaml = new YamlConfiguration();
                yaml.loadFromString(document.content());
                mutator.accept(yaml);
                saved = manager.saveEditorDocument(CONFIG_PATH, yaml.saveToString(), document.revision(), CONFIG_LIMIT_BYTES);
                manager.reload();
                if (!active.get()) throw new IllegalStateException("Self-role module stopped while applying configuration");
                settings = SelfRoleSettings.from(plugin.getAppConfig());
            } catch (Throwable error) {
                if (document != null && saved != null && !saved.revision().equals(document.revision())) {
                    try {
                        manager.saveEditorDocument(CONFIG_PATH, document.content(), saved.revision(), CONFIG_LIMIT_BYTES);
                        manager.reload();
                        if (active.get()) settings = SelfRoleSettings.from(plugin.getAppConfig());
                    } catch (Throwable rollbackFailure) {
                        error.addSuppressed(rollbackFailure);
                        plugin.getLogger().log(Level.SEVERE, "[SelfRoles] Setup rollback failed; restore the saved backup before further edits", rollbackFailure);
                    }
                }
                if (error instanceof Exception exception) throw exception;
                if (error instanceof Error fatal) throw fatal;
                throw new IllegalStateException(error);
            }
        });
    }

    private CompletableFuture<Void> reloadSelfRoleConfiguration() {
        return runSelfRoleAsync(() -> {
            plugin.getConfigManager().reload();
            if (!active.get()) throw new IllegalStateException("Self-role module stopped while reloading");
            settings = SelfRoleSettings.from(plugin.getAppConfig());
        });
    }

    private CompletableFuture<Void> runSelfRoleAsync(SelfRoleAsyncWork work) {
        if (!active.get() || !plugin.isEnabled()) return CompletableFuture.failedFuture(new IllegalStateException("Self-role module is not active"));
        CompletableFuture<Void> future = new CompletableFuture<>();
        try {
            plugin.getCoreScheduler().runAsync(() -> {
                if (!active.get() || !plugin.isEnabled()) {
                    future.completeExceptionally(new IllegalStateException("Self-role module stopped before setup work could run"));
                    return;
                }
                try { work.run(); future.complete(null); }
                catch (Throwable error) { future.completeExceptionally(error); }
            });
        } catch (Throwable error) {
            future.completeExceptionally(error);
        }
        return future;
    }

    private static List<Map<String, Object>> mutablePanels(YamlConfiguration yaml) {
        return mutableMapList(yaml.getMapList("panels"));
    }

    private static List<Map<String, Object>> mutableMapList(Object raw) {
        List<Map<String, Object>> result = new ArrayList<>();
        if (!(raw instanceof List<?> list)) return result;
        for (Object item : list) {
            if (!(item instanceof Map<?, ?> map)) continue;
            Map<String, Object> copy = new LinkedHashMap<>();
            map.forEach((key, value) -> copy.put(String.valueOf(key), value));
            result.add(copy);
        }
        return result;
    }

    private static Map<String, Object> findPanel(List<Map<String, Object>> panels, String id) { return findById(panels, id); }
    private static Map<String, Object> requirePanel(List<Map<String, Object>> panels, String id) {
        Map<String, Object> panel = findPanel(panels, id);
        if (panel == null) throw new IllegalArgumentException("Unknown panel '" + id + "'");
        return panel;
    }
    private static Map<String, Object> findById(List<Map<String, Object>> values, String id) {
        for (Map<String, Object> value : values) {
            if (SelfRoleSettings.safeId(String.valueOf(value.get("id"))).equals(id)) return value;
        }
        return null;
    }
    private static Map<String, Object> optionMap(String id, String label, String emoji, long roleId) {
        Map<String, Object> option = new LinkedHashMap<>();
        option.put("id", id); option.put("label", label); option.put("description", ""); option.put("emoji", emoji); option.put("role-id", Long.toString(roleId));
        return option;
    }
    private static Map<String, Object> groupMap(String id, String label, String mode, Map<String, Object> firstOption) {
        Map<String, Object> group = new LinkedHashMap<>();
        group.put("id", id); group.put("label", label); group.put("placeholder", "Select " + label); group.put("mode", mode); group.put("remove-unselected", true);
        group.put("options", new ArrayList<>(List.of(firstOption)));
        return group;
    }
    private static String requiredOptionId(SlashCommandInteractionEvent event, String name) {
        if (event.getOption(name) == null) throw new IllegalArgumentException("Missing required option '" + name + "'");
        return requireSetupId(event.getOption(name).getAsString(), name);
    }
    private static String requireSetupId(String value, String name) {
        String id = SelfRoleSettings.safeId(value);
        if (id.isBlank()) throw new IllegalArgumentException(name + " must match [a-z0-9_-]{1,32}");
        return id;
    }
    private static String requiredBounded(SlashCommandInteractionEvent event, String name, int maximum) {
        if (event.getOption(name) == null) throw new IllegalArgumentException("Missing required option '" + name + "'");
        return bounded(event.getOption(name).getAsString(), maximum, name);
    }
    private static String bounded(String value, int maximum, String name) {
        String clean = value == null ? "" : value.replace('\0', ' ').trim();
        if (clean.isBlank()) throw new IllegalArgumentException(name + " is required");
        if (clean.length() > maximum) throw new IllegalArgumentException(name + " exceeds " + maximum + " characters");
        return clean;
    }
    private static String requireMode(String raw) {
        String mode = raw.trim().toUpperCase(java.util.Locale.ROOT).replace('-', '_');
        if (!mode.equals("SINGLE") && !mode.equals("MULTIPLE")) throw new IllegalArgumentException("mode must be SINGLE or MULTIPLE");
        return mode;
    }

    @FunctionalInterface
    private interface SelfRoleAsyncWork { void run() throws Exception; }

    private void handleSelect(StringSelectInteractionEvent event) {
        if (!active.get() || !event.getComponentId().startsWith(COMPONENT_PREFIX)) return;
        String[] parts = event.getComponentId().split(":", 4);
        if (parts.length != 4) {
            event.reply("This role selector is invalid. Ask an administrator to republish it.").setEphemeral(true).queue();
            return;
        }
        String panelId = SelfRoleSettings.safeId(parts[2]);
        String groupId = SelfRoleSettings.safeId(parts[3]);
        SelfRoleSettings current = settings;
        SelfRoleSettings.Group group = current == null ? null : current.group(panelId, groupId);
        SelfRoleSettings.Panel panel = current == null ? null : current.panel(panelId);
        Guild guild = event.getGuild();
        Member member = event.getMember();
        if (panel == null || group == null || guild == null || member == null
                || guild.getIdLong() != current.guildId()
                || event.getChannel().getIdLong() != panel.channelId()) {
            event.reply("This role selector is stale. Ask an administrator to republish the panel.").setEphemeral(true).queue();
            return;
        }
        SelfRolePanelRepository repository = panels;
        if (repository == null) {
            event.reply("Self-role storage is unavailable. Try again after CoreDSC has reloaded.")
                    .setEphemeral(true).queue();
            return;
        }
        event.deferReply(true).queue(hook -> repository.find(panelId).whenComplete((stored, lookupError) -> {
            if (!active.get() || settings != current) {
                hook.editOriginal("This role selector became stale while CoreDSC reloaded. Please use the active panel.").queue();
                return;
            }
            if (lookupError != null) {
                plugin.getLogger().log(Level.WARNING, "[SelfRoles] Could not validate active panel " + panelId, lookupError);
                hook.editOriginal("Could not validate this role panel. Try again shortly.").queue();
                return;
            }
            String messageId = Long.toString(event.getMessageIdLong());
            if (stored.isEmpty() || !stored.get().channelId().equals(event.getChannel().getId())
                    || !stored.get().messageId().equals(messageId)) {
                hook.editOriginal("This role selector is stale. Please use the currently published panel.").queue();
                return;
            }
            applyRoleSelection(event, hook, guild, member, group);
        }), error -> plugin.getLogger().warning(
                "[SelfRoles] Could not defer role selection response: " + rootMessage(error)));
    }

    private void applyRoleSelection(
            StringSelectInteractionEvent event,
            InteractionHook hook,
            Guild guild,
            Member member,
            SelfRoleSettings.Group group
    ) {
        Set<String> selectedIds = Set.copyOf(event.getValues());
        Set<Long> selectedRoleIds = new LinkedHashSet<>();
        for (SelfRoleSettings.Option option : group.options()) {
            if (selectedIds.contains(option.id())) selectedRoleIds.add(option.roleId());
        }
        if (group.mode() == SelfRoleSettings.SelectionMode.SINGLE && selectedRoleIds.size() > 1) {
            hook.editOriginal("This role group allows only one selection.").queue();
            return;
        }
        List<Role> add = new ArrayList<>();
        List<Role> remove = new ArrayList<>();
        for (SelfRoleSettings.Option option : group.options()) {
            Role role = guild.getRoleById(option.roleId());
            if (role == null) {
                hook.editOriginal("A configured role no longer exists. Ask an administrator to repair this panel.").queue();
                return;
            }
            if (!guild.getSelfMember().hasPermission(Permission.MANAGE_ROLES) || !guild.getSelfMember().canInteract(role)) {
                hook.editOriginal("I cannot manage **" + role.getName()
                        + "**. Move the CoreDSC bot role above it and grant Manage Roles.").queue();
                return;
            }
            boolean selected = selectedRoleIds.contains(option.roleId());
            boolean currentlyHas = member.getRoles().contains(role);
            if (selected && !currentlyHas) add.add(role);
            if (!selected && currentlyHas
                    && (group.mode() == SelfRoleSettings.SelectionMode.SINGLE || group.removeUnselected())) {
                remove.add(role);
            }
        }
        guild.modifyMemberRoles(member, add, remove).queue(
                ignored -> hook.editOriginal("Your roles were updated.").queue(),
                error -> hook.editOriginal("Could not update your roles: " + rootMessage(error)).queue());
    }

    private CompletableFuture<Integer> publishAll() {
        SelfRoleSettings current = settings;
        SelfRolePanelRepository repository = panels;
        if (!active.get() || current == null || repository == null) return CompletableFuture.completedFuture(0);
        return repository.findAll().thenCompose(existing -> {
            CompletableFuture<Void> retire = CompletableFuture.completedFuture(null);
            for (SelfRolePanelRepository.PanelMessage panelMessage : existing) {
                if (!current.panels().containsKey(panelMessage.panelId())) {
                    retire = retire.thenCompose(ignored -> retirePanelMessage(panelMessage, true));
                }
            }
            CompletableFuture<Integer> chain = retire.thenApply(ignored -> 0);
            for (SelfRoleSettings.Panel panel : current.panels().values()) {
                chain = chain.thenCompose(count -> publish(panel).thenApply(ignored -> count + 1));
            }
            return chain;
        }).exceptionallyCompose(error -> {
            plugin.recordModuleFailure("self-roles", error);
            return CompletableFuture.failedFuture(error);
        });
    }

    private CompletableFuture<Void> publish(SelfRoleSettings.Panel panel) {
        JDA jda = requireJda();
        Guild guild = jda.getGuildById(settings.guildId());
        if (guild == null) return CompletableFuture.failedFuture(new IllegalStateException("Configured self-role guild is unavailable"));
        TextChannel channel = guild.getTextChannelById(panel.channelId());
        if (channel == null) return CompletableFuture.failedFuture(new IllegalStateException("Self-role channel does not exist: " + panel.channelId()));
        MessageCreateData payload = payload(panel);
        SelfRolePanelRepository repository = panels;
        if (repository == null) return CompletableFuture.failedFuture(new IllegalStateException("Self-role storage is unavailable"));
        return repository.find(panel.id()).thenCompose(existing -> {
            if (existing.isEmpty()) return createPanelMessage(repository, channel, panel, payload);
            if (!existing.get().channelId().equals(channel.getId())) {
                return retirePanelMessage(existing.get(), false)
                        .thenCompose(ignored -> createPanelMessage(repository, channel, panel, payload));
            }
            CompletableFuture<Void> result = new CompletableFuture<>();
            channel.retrieveMessageById(existing.get().messageId()).queue(message -> {
                MessageEditBuilder edit = MessageEditBuilder.fromCreateData(payload);
                message.editMessage(edit.build()).queue(
                        ignored -> repository.upsert(panel.id(), channel.getId(), message.getId(), System.currentTimeMillis())
                                .whenComplete((done, error) -> complete(result, error)),
                        error -> {
                            if (isUnknownMessage(error)) {
                                createPanelMessage(repository, channel, panel, payload).whenComplete((done, createError) -> complete(result, createError));
                            } else result.completeExceptionally(error);
                        });
            }, error -> {
                if (isUnknownMessage(error)) createPanelMessage(repository, channel, panel, payload)
                        .whenComplete((done, createError) -> complete(result, createError));
                else result.completeExceptionally(error);
            });
            return result;
        });
    }

    private CompletableFuture<Void> retirePanelMessage(SelfRolePanelRepository.PanelMessage panelMessage, boolean deleteState) {
        SelfRolePanelRepository repository = panels;
        JDA jda = requireJda();
        Guild guild = jda.getGuildById(settings.guildId());
        CompletableFuture<Void> result = new CompletableFuture<>();
        if (guild == null) {
            if (deleteState && repository != null) return repository.delete(panelMessage.panelId());
            return CompletableFuture.completedFuture(null);
        }
        TextChannel oldChannel = guild.getTextChannelById(panelMessage.channelId());
        if (oldChannel == null) {
            if (deleteState && repository != null) return repository.delete(panelMessage.panelId());
            return CompletableFuture.completedFuture(null);
        }
        oldChannel.retrieveMessageById(panelMessage.messageId()).queue(message ->
                message.editMessageComponents(List.of()).queue(
                        ignored -> finishRetire(result, repository, panelMessage.panelId(), deleteState),
                        error -> {
                            if (isUnknownMessage(error)) finishRetire(result, repository, panelMessage.panelId(), deleteState);
                            else result.completeExceptionally(error);
                        }),
                error -> {
                    if (isUnknownMessage(error)) finishRetire(result, repository, panelMessage.panelId(), deleteState);
                    else result.completeExceptionally(error);
                });
        return result;
    }

    private static void finishRetire(CompletableFuture<Void> result, SelfRolePanelRepository repository,
                                     String panelId, boolean deleteState) {
        if (!deleteState || repository == null) {
            result.complete(null);
            return;
        }
        repository.delete(panelId).whenComplete((ignored, error) -> complete(result, error));
    }

    private CompletableFuture<Void> createPanelMessage(SelfRolePanelRepository repository, TextChannel channel,
                                                        SelfRoleSettings.Panel panel, MessageCreateData payload) {
        CompletableFuture<Void> result = new CompletableFuture<>();
        channel.sendMessage(payload).queue(message -> repository.upsert(panel.id(), channel.getId(), message.getId(), System.currentTimeMillis())
                        .whenComplete((ignored, error) -> complete(result, error)), result::completeExceptionally);
        return result;
    }

    private MessageCreateData payload(SelfRoleSettings.Panel panel) {
        EmbedBuilder embed = new EmbedBuilder().setTitle(panel.title()).setColor(panel.color());
        if (!panel.description().isBlank()) embed.setDescription(panel.description());
        if (!panel.footer().isBlank()) embed.setFooter(panel.footer());
        List<ActionRow> rows = new ArrayList<>();
        for (SelfRoleSettings.Group group : panel.groups()) {
            StringSelectMenu.Builder menu = StringSelectMenu.create(COMPONENT_PREFIX + panel.id() + ':' + group.id())
                    .setPlaceholder(group.placeholder()).setMinValues(group.mode() == SelfRoleSettings.SelectionMode.SINGLE ? 1 : 0)
                    .setMaxValues(group.mode() == SelfRoleSettings.SelectionMode.SINGLE ? 1 : group.options().size());
            for (SelfRoleSettings.Option option : group.options()) {
                SelectOption built = SelectOption.of(option.label(), option.id());
                if (!option.description().isBlank()) built = built.withDescription(option.description());
                if (!option.emoji().isBlank()) {
                    try { built = built.withEmoji(Emoji.fromFormatted(option.emoji())); }
                    catch (IllegalArgumentException ignored) { /* invalid custom emoji stays text-only */ }
                }
                menu.addOptions(built);
            }
            rows.add(ActionRow.of(menu.build()));
        }
        return new MessageCreateBuilder().addEmbeds(embed.build()).addComponents(rows).build();
    }

    private JDA requireJda() {
        DiscordBotService discord = plugin.getDiscordService();
        JDA jda = discord == null ? null : discord.getJda();
        if (jda == null) throw new IllegalStateException("Discord is not ready");
        return jda;
    }

    private static boolean isUnknownMessage(Throwable error) {
        Throwable root = root(error);
        return root instanceof ErrorResponseException response && response.getErrorResponse() == ErrorResponse.UNKNOWN_MESSAGE;
    }

    private static void complete(CompletableFuture<Void> future, Throwable error) {
        if (error == null) future.complete(null); else future.completeExceptionally(error);
    }

    private static Throwable root(Throwable error) {
        Throwable current = error instanceof CompletionException && error.getCause() != null ? error.getCause() : error;
        while (current.getCause() != null) current = current.getCause();
        return current;
    }

    private static String rootMessage(Throwable error) {
        Throwable root = root(error);
        return root.getMessage() == null || root.getMessage().isBlank() ? root.getClass().getSimpleName() : root.getMessage();
    }
}
