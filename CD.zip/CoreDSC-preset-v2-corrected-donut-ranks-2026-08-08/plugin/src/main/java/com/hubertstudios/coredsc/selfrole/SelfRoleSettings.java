package com.hubertstudios.coredsc.selfrole;

import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Immutable configuration for Discord self-role panels. */
public record SelfRoleSettings(
        long guildId,
        boolean publishOnStartup,
        Map<String, Panel> panels
) {
    public enum SelectionMode { SINGLE, MULTIPLE }

    public record Panel(
            String id,
            long channelId,
            String title,
            String description,
            String footer,
            int color,
            List<Group> groups
    ) { }

    public record Group(
            String id,
            String label,
            String placeholder,
            SelectionMode mode,
            boolean removeUnselected,
            List<Option> options
    ) { }

    public record Option(
            String id,
            String label,
            String description,
            String emoji,
            long roleId
    ) { }

    public static SelfRoleSettings from(FileConfiguration config) {
        long guild = optionalSnowflake(config.get("self-roles.guild-id"), "self-roles.guild-id");
        if (guild == 0L) guild = optionalSnowflake(config.get("discord.guild-id"), "discord.guild-id");
        if (guild <= 0L) throw new IllegalArgumentException("self-roles requires self-roles.guild-id or discord.guild-id");
        boolean publish = config.getBoolean("self-roles.publish-on-startup", false);
        List<Map<?, ?>> rawPanels = config.getMapList("self-roles.panels");
        if (rawPanels.size() > 20) throw new IllegalArgumentException("self-roles supports at most 20 panels");
        Map<String, Panel> panels = new LinkedHashMap<>();
        int panelIndex = 0;
        for (Map<?, ?> raw : rawPanels) {
            String base = "self-roles.panels[" + panelIndex++ + "]";
            if (!booleanValue(raw.get("enabled"), true)) continue;
            String id = id(raw.get("id"), base + ".id");
            if (panels.containsKey(id)) throw new IllegalArgumentException("Duplicate self-role panel id: " + id);
            long channel = requiredSnowflake(raw.get("channel-id"), base + ".channel-id");
            String title = bounded(raw.get("title"), 256, base + ".title", true);
            String description = bounded(raw.get("description"), 4_000, base + ".description", false);
            String footer = bounded(raw.get("footer"), 2_048, base + ".footer", false);
            int color = parseColor(raw.get("color"), base + ".color");
            List<Group> groups = parseGroups(raw.get("groups"), base);
            if (groups.isEmpty()) throw new IllegalArgumentException(base + " needs at least one role group");
            panels.put(id, new Panel(id, channel, title, description, footer, color, groups));
        }
        return new SelfRoleSettings(guild, publish,
                Collections.unmodifiableMap(new LinkedHashMap<>(panels)));
    }

    private static List<Group> parseGroups(Object rawValue, String panelPath) {
        List<?> rawGroups = rawValue instanceof List<?> list ? list : List.of();
        if (rawGroups.size() > 5) {
            throw new IllegalArgumentException(panelPath + ".groups supports at most 5 groups per Discord message");
        }
        List<Group> groups = new ArrayList<>();
        Set<String> ids = new LinkedHashSet<>();
        int groupIndex = 0;
        for (Object item : rawGroups) {
            if (!(item instanceof Map<?, ?> raw)) {
                throw new IllegalArgumentException(panelPath + ".groups[" + groupIndex + "] must be a map");
            }
            String base = panelPath + ".groups[" + groupIndex++ + "]";
            if (!booleanValue(raw.get("enabled"), true)) continue;
            String id = id(raw.get("id"), base + ".id");
            if (!ids.add(id)) throw new IllegalArgumentException("Duplicate role group id '" + id + "' in " + panelPath);
            String label = bounded(raw.get("label"), 100, base + ".label", true);
            String placeholder = bounded(raw.get("placeholder"), 150, base + ".placeholder", false);
            if (placeholder.isBlank()) placeholder = "Select " + label;
            SelectionMode mode = enumValue(raw.get("mode"), SelectionMode.class, SelectionMode.SINGLE, base + ".mode");
            boolean remove = booleanValue(raw.get("remove-unselected"), true);
            List<Option> options = parseOptions(raw.get("options"), base);
            if (options.isEmpty()) throw new IllegalArgumentException(base + " needs at least one role option");
            groups.add(new Group(id, label, placeholder, mode, remove, options));
        }
        return List.copyOf(groups);
    }

    private static List<Option> parseOptions(Object rawValue, String groupPath) {
        List<?> rawOptions = rawValue instanceof List<?> list ? list : List.of();
        if (rawOptions.size() > 25) throw new IllegalArgumentException(groupPath + ".options supports at most 25 roles");
        List<Option> options = new ArrayList<>();
        Set<String> ids = new LinkedHashSet<>();
        Set<Long> roles = new LinkedHashSet<>();
        int optionIndex = 0;
        for (Object item : rawOptions) {
            if (!(item instanceof Map<?, ?> raw)) {
                throw new IllegalArgumentException(groupPath + ".options[" + optionIndex + "] must be a map");
            }
            String base = groupPath + ".options[" + optionIndex++ + "]";
            if (!booleanValue(raw.get("enabled"), true)) continue;
            String id = id(raw.get("id"), base + ".id");
            if (!ids.add(id)) throw new IllegalArgumentException("Duplicate self-role option id '" + id + "'");
            String label = bounded(raw.get("label"), 100, base + ".label", true);
            String description = bounded(raw.get("description"), 100, base + ".description", false);
            String emoji = bounded(raw.get("emoji"), 100, base + ".emoji", false);
            long role = requiredSnowflake(raw.get("role-id"), base + ".role-id");
            if (!roles.add(role)) throw new IllegalArgumentException("The same Discord role appears twice in " + groupPath);
            options.add(new Option(id, label, description, emoji, role));
        }
        return List.copyOf(options);
    }

    public Panel panel(String id) {
        return panels.get(safeId(id));
    }

    public Group group(String panelId, String groupId) {
        Panel panel = panel(panelId);
        if (panel == null) return null;
        String normalized = safeId(groupId);
        return panel.groups().stream().filter(group -> group.id().equals(normalized)).findFirst().orElse(null);
    }

    public static String safeId(String value) {
        if (value == null) return "";
        String normalized = value.trim().toLowerCase(Locale.ROOT);
        return normalized.matches("[a-z0-9_-]{1,32}") ? normalized : "";
    }

    private static String id(Object raw, String path) {
        String value = safeId(String.valueOf(raw == null ? "" : raw));
        if (value.isBlank()) throw new IllegalArgumentException(path + " must match [a-z0-9_-]{1,32}");
        return value;
    }

    private static String bounded(Object raw, int maximum, String path, boolean required) {
        String value = raw == null ? "" : String.valueOf(raw).replace('\0', ' ').trim();
        if (required && value.isBlank()) throw new IllegalArgumentException(path + " is required");
        if (value.length() > maximum) throw new IllegalArgumentException(path + " exceeds " + maximum + " characters");
        return value;
    }

    private static long optionalSnowflake(Object raw, String path) {
        if (raw == null || String.valueOf(raw).trim().isBlank() || String.valueOf(raw).trim().equals("0")) return 0L;
        try {
            long value = Long.parseLong(String.valueOf(raw).trim());
            if (value <= 0L) throw new NumberFormatException();
            return value;
        } catch (NumberFormatException error) {
            throw new IllegalArgumentException(path + " must be a positive Discord ID or empty", error);
        }
    }

    private static long requiredSnowflake(Object raw, String path) {
        long value = optionalSnowflake(raw, path);
        if (value <= 0L) throw new IllegalArgumentException(path + " is required");
        return value;
    }

    private static int parseColor(Object raw, String path) {
        String value = raw == null ? "#5865F2" : String.valueOf(raw).trim();
        if (value.startsWith("#")) value = value.substring(1);
        if (!value.matches("[0-9a-fA-F]{6}")) throw new IllegalArgumentException(path + " must be a six-digit hex color");
        return Integer.parseInt(value, 16);
    }

    private static boolean booleanValue(Object raw, boolean fallback) {
        if (raw == null) return fallback;
        if (raw instanceof Boolean value) return value;
        String value = String.valueOf(raw).trim();
        if (value.equalsIgnoreCase("true")) return true;
        if (value.equalsIgnoreCase("false")) return false;
        return fallback;
    }

    private static <E extends Enum<E>> E enumValue(Object raw, Class<E> type, E fallback, String path) {
        String value = raw == null || String.valueOf(raw).isBlank()
                ? fallback.name() : String.valueOf(raw).trim().toUpperCase(Locale.ROOT).replace('-', '_');
        try {
            return Enum.valueOf(type, value);
        } catch (IllegalArgumentException error) {
            throw new IllegalArgumentException(path + " has unsupported value '" + raw + "'", error);
        }
    }
}
