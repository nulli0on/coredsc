package com.hubertstudios.coredsc.service;

import com.hubertstudios.coredsc.CoreDSCPlugin;
import com.hubertstudios.coredsc.scripting.MiniJson;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.entities.channel.concrete.Category;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.node.Node;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.TimeUnit;

/**
 * Resolves and optionally creates Discord/LuckPerms resources required by a
 * format-2 CoreDSC preset descriptor.
 *
 * <p>The service intentionally supports a bounded set of capabilities. A
 * descriptor can ask CoreDSC to create/reuse roles, categories, text channels,
 * channel permission overrides and LuckPerms groups; it cannot execute arbitrary
 * code, console commands or filesystem operations.</p>
 */
public final class PresetBootstrapService {
    private static final long DISCORD_TIMEOUT_SECONDS = 20L;
    private static final int MAXIMUM_RESOURCES = 100;
    private static final Set<Integer> DONUT_LEVELS = Set.of(1, 3, 5, 10, 20, 30, 40, 50, 60, 70, 80);
    private static final Map<String, String> DONUT_INGAME_RANK_GROUPS = Map.ofEntries(
            Map.entry("owner", "owner"),
            Map.entry("manager", "manager"),
            Map.entry("dev", "developer"),
            Map.entry("sr-admin", "sradmin"),
            Map.entry("admin", "admin"),
            Map.entry("sr-mod", "srmod"),
            Map.entry("mod", "mod"),
            Map.entry("sr-helper", "srhelper"),
            Map.entry("helper", "helper"),
            Map.entry("media", "media"),
            Map.entry("donut-plus", "donut+")
    );
    private static final Map<String, String> SELF_ROLE_VARIABLES = Map.ofEntries(
            Map.entry("platform.pc", "platform-pc-role-id"),
            Map.entry("platform.xbox", "platform-xbox-role-id"),
            Map.entry("platform.playstation", "platform-playstation-role-id"),
            Map.entry("platform.mobile", "platform-mobile-role-id"),
            Map.entry("platform.nintendo-switch", "platform-switch-role-id"),
            Map.entry("age.age-13-14", "age-13-14-role-id"),
            Map.entry("age.age-15-17", "age-15-17-role-id"),
            Map.entry("age.age-18-20", "age-18-20-role-id"),
            Map.entry("age.age-21-24", "age-21-24-role-id"),
            Map.entry("age.age-25-29", "age-25-29-role-id"),
            Map.entry("age.age-30-plus", "age-30-plus-role-id"),
            Map.entry("region.europe", "region-europe-role-id"),
            Map.entry("region.north-america", "region-na-role-id"),
            Map.entry("region.asia", "region-asia-role-id"),
            Map.entry("region.oceania", "region-oceania-role-id"),
            Map.entry("region.south-america", "region-sa-role-id"),
            Map.entry("region.africa", "region-africa-role-id"),
            Map.entry("notifications.news-pings", "notify-news-role-id"),
            Map.entry("notifications.stream-pings", "notify-streams-role-id"),
            Map.entry("notifications.event-pings", "notify-events-role-id"),
            Map.entry("notifications.poll-pings", "notify-polls-role-id"),
            Map.entry("notifications.update-pings", "notify-updates-role-id")
    );

    private final CoreDSCPlugin plugin;
    private final File stateFile;

    public PresetBootstrapService(CoreDSCPlugin plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
        this.stateFile = new File(plugin.getDataFolder(), "state/preset-resources.yml");
    }

    public BootstrapResult preview(File descriptor) throws Exception {
        return resolve(descriptor, false);
    }

    public BootstrapResult apply(File descriptor) throws Exception {
        BootstrapResult preflight = resolve(descriptor, false);
        if (!preflight.conflicts().isEmpty()) {
            throw new IllegalStateException("Preset setup has unresolved Discord resources: "
                    + String.join(" | ", preflight.conflicts()));
        }
        return resolve(descriptor, true);
    }

    public void rollbackCreated(String presetId, List<String> createdResources) throws Exception {
        if (createdResources == null || createdResources.isEmpty()) return;
        YamlConfiguration state = stateFile.isFile() ? YamlConfiguration.loadConfiguration(stateFile) : new YamlConfiguration();
        JDA jda = plugin.getDiscordService() == null ? null : plugin.getDiscordService().getJda();
        List<Throwable> failures = new ArrayList<>();
        for (int index = createdResources.size() - 1; index >= 0; index--) {
            String resource = createdResources.get(index);
            try {
                if (resource.startsWith("luckperms-group:")) {
                    String groupName = resource.substring("luckperms-group:".length());
                    if (plugin.getServer().getPluginManager().isPluginEnabled("LuckPerms")) {
                        var manager = LuckPermsProvider.get().getGroupManager();
                        var group = manager.getGroup(groupName);
                        if (group != null) manager.deleteGroup(group).get(10L, TimeUnit.SECONDS);
                    }
                    continue;
                }
                String[] parts = resource.split(":", 3);
                if (parts.length != 3) continue;
                String type = parts[0];
                String logical = parts[1];
                long id = Long.parseLong(parts[2]);
                String statePath = "presets." + presetId + ".resources." + type + "." + logical;
                if (!"CREATED".equalsIgnoreCase(state.getString(statePath + ".ownership", ""))) continue;
                if (!Long.toString(id).equals(state.getString(statePath + ".id", ""))) continue;
                if (jda == null) throw new IllegalStateException("Discord is unavailable while rolling back created resources");
                switch (type) {
                    case "channel" -> {
                        var channel = jda.getTextChannelById(id);
                        if (channel != null) channel.delete().submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                    }
                    case "category" -> {
                        var category = jda.getCategoryById(id);
                        if (category != null) category.delete().submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                    }
                    case "role" -> {
                        var role = jda.getRoleById(id);
                        if (role != null) role.delete().submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                    }
                    case "message" -> {
                        long channelId = optionalSnowflake(state.get(statePath + ".channel-id"), statePath + ".channel-id");
                        var channel = channelId <= 0L ? null : jda.getTextChannelById(channelId);
                        if (channel != null) channel.deleteMessageById(id).submit()
                                .get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                    }
                    default -> { }
                }
                state.set(statePath, null);
            } catch (Throwable error) {
                failures.add(error);
            }
        }
        saveYamlAtomic(state, stateFile);
        if (!failures.isEmpty()) {
            IllegalStateException combined = new IllegalStateException("One or more preset-created resources could not be rolled back");
            failures.forEach(combined::addSuppressed);
            throw combined;
        }
    }

    /**
     * Captures CoreDSC-owned external resources that exist now but do not
     * exist in the target rollback snapshot. The immutable plan is executed
     * only after the CoreDSC files have been restored and reloaded.
     */
    RollbackPlan planExternalRollback(Path targetStateFile) throws IOException {
        YamlConfiguration current = stateFile.isFile()
                ? YamlConfiguration.loadConfiguration(stateFile) : new YamlConfiguration();
        YamlConfiguration target = targetStateFile != null && Files.isRegularFile(targetStateFile)
                ? YamlConfiguration.loadConfiguration(targetStateFile.toFile()) : new YamlConfiguration();
        Map<String, ExternalResource> currentResources = createdExternalResources(current);
        Map<String, ExternalResource> targetResources = createdExternalResources(target);
        List<ExternalResource> remove = new ArrayList<>();
        for (Map.Entry<String, ExternalResource> entry : currentResources.entrySet()) {
            ExternalResource wanted = targetResources.get(entry.getKey());
            ExternalResource existing = entry.getValue();
            if (wanted == null || !wanted.sameIdentity(existing)) remove.add(existing);
        }
        remove.sort(java.util.Comparator.comparingInt(ExternalResource::deletionOrder));
        return new RollbackPlan(List.copyOf(remove));
    }

    RollbackCleanupResult executeExternalRollback(RollbackPlan plan) {
        if (plan == null || plan.resources().isEmpty()) return new RollbackCleanupResult(List.of(), List.of());
        JDA jda = plugin.getDiscordService() == null ? null : plugin.getDiscordService().getJda();
        List<String> removed = new ArrayList<>();
        List<String> warnings = new ArrayList<>();
        for (ExternalResource resource : plan.resources()) {
            try {
                switch (resource.type()) {
                    case "MESSAGE" -> {
                        if (jda == null) throw new IllegalStateException("Discord is unavailable");
                        var channel = resource.channelId() <= 0L ? null : jda.getTextChannelById(resource.channelId());
                        if (channel != null) channel.deleteMessageById(resource.numericId())
                                .submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                    }
                    case "TEXT_CHANNEL" -> {
                        if (jda == null) throw new IllegalStateException("Discord is unavailable");
                        var channel = jda.getTextChannelById(resource.numericId());
                        if (channel != null) channel.delete().submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                    }
                    case "CATEGORY" -> {
                        if (jda == null) throw new IllegalStateException("Discord is unavailable");
                        var category = jda.getCategoryById(resource.numericId());
                        if (category != null) category.delete().submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                    }
                    case "ROLE" -> {
                        if (jda == null) throw new IllegalStateException("Discord is unavailable");
                        var role = jda.getRoleById(resource.numericId());
                        if (role != null) role.delete().submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                    }
                    case "LUCKPERMS_GROUP" -> {
                        if (!plugin.getServer().getPluginManager().isPluginEnabled("LuckPerms")) {
                            throw new IllegalStateException("LuckPerms is unavailable");
                        }
                        var manager = LuckPermsProvider.get().getGroupManager();
                        var group = manager.getGroup(resource.id());
                        if (group != null) manager.deleteGroup(group).get(10L, TimeUnit.SECONDS);
                    }
                    default -> throw new IllegalStateException("Unsupported rollback resource type " + resource.type());
                }
                removed.add(resource.label());
            } catch (Throwable failure) {
                warnings.add(resource.label() + ": " + failure.getClass().getSimpleName() + " - "
                        + (failure.getMessage() == null ? "cleanup failed" : failure.getMessage()));
            }
        }
        return new RollbackCleanupResult(List.copyOf(removed), List.copyOf(warnings));
    }

    private static Map<String, ExternalResource> createdExternalResources(YamlConfiguration state) {
        Map<String, ExternalResource> result = new LinkedHashMap<>();
        ConfigurationSection presets = state.getConfigurationSection("presets");
        if (presets == null) return result;
        for (String presetId : presets.getKeys(false)) {
            ConfigurationSection resources = presets.getConfigurationSection(presetId + ".resources");
            if (resources == null) continue;
            collectExternalResources(result, presetId, "", resources);
        }
        return result;
    }

    private static void collectExternalResources(
            Map<String, ExternalResource> output,
            String presetId,
            String relative,
            ConfigurationSection section
    ) {
        if (section.contains("type") && section.contains("id") && section.contains("ownership")) {
            if (!"CREATED".equalsIgnoreCase(section.getString("ownership", ""))) return;
            String type = section.getString("type", "").trim().toUpperCase(Locale.ROOT);
            String id = section.getString("id", "").trim();
            if (type.isBlank() || id.isBlank()) return;
            long channelId = 0L;
            String channelText = section.getString("channel-id", "").trim();
            if (!channelText.isBlank()) {
                try { channelId = Long.parseLong(channelText); }
                catch (NumberFormatException ignored) { channelId = 0L; }
            }
            String logical = relative.isBlank() ? "resource" : relative;
            ExternalResource resource = new ExternalResource(presetId, logical, type, id, channelId,
                    section.getString("name", logical));
            output.put(presetId + ":" + logical, resource);
            return;
        }
        for (String key : section.getKeys(false)) {
            ConfigurationSection child = section.getConfigurationSection(key);
            if (child == null) continue;
            collectExternalResources(output, presetId, relative.isBlank() ? key : relative + "." + key, child);
        }
    }

    private BootstrapResult resolve(File descriptor, boolean mutate) throws Exception {
        YamlConfiguration yaml = loadV2(descriptor);
        String presetId = presetId(yaml, descriptor);
        if (!"donutsmp".equals(presetId)) {
            return new BootstrapResult(Map.of(), List.of(), List.of(), List.of(), List.of(), List.of(),
                    "No bootstrap profile is registered for " + presetId);
        }
        long guildId = snowflake(yaml.get("discord.guild-id"), "discord.guild-id");
        Guild guild = requireGuild(guildId);
        ResourceMode roleMode = ResourceMode.parse(yaml.getString("discord.roles-mode", "CREATE_MISSING"));
        ResourceMode channelMode = ResourceMode.parse(yaml.getString("discord.channels-mode", "CREATE_MISSING"));
        ResourceMode categoryMode = ResourceMode.parse(yaml.getString("discord.categories-mode", "CREATE_MISSING"));
        validateModeCompatibility(yaml, roleMode, channelMode, categoryMode);
        boolean detectByName = yaml.getBoolean("discord.detect-existing-by-name", true);
        boolean configurePermissions = yaml.getBoolean("discord.configure-permissions", true);

        YamlConfiguration previousState = stateFile.isFile()
                ? YamlConfiguration.loadConfiguration(stateFile) : new YamlConfiguration();
        PlanContext context = new PlanContext(presetId, mutate, guild, yaml, detectByName, previousState);
        initializeOptionalVariables(context);
        context.variables.put("guild-id", Long.toString(guildId));
        context.variables.put("feature-verification", yaml.getBoolean("features.verification", true));
        context.variables.put("feature-chat", yaml.getBoolean("features.minecraft-chat", true));
        context.variables.put("feature-tickets", yaml.getBoolean("features.tickets", true));
        context.variables.put("feature-self-roles", yaml.getBoolean("features.self-roles", true));
        context.variables.put("feature-levels", yaml.getBoolean("features.discord-levels", true));
        context.variables.put("link-code-expiry-seconds", yaml.getInt("verification.code-expiry-seconds", 60));
        context.variables.put("link-code-length", yaml.getInt("verification.code-length", 8));
        context.variables.put("xp-award-window-seconds", yaml.getInt("levels.xp.award-window-seconds", 60));
        context.variables.put("xp-minimum", yaml.getInt("levels.xp.minimum", 15));
        context.variables.put("xp-maximum", yaml.getInt("levels.xp.maximum", 25));
        context.variables.put("xp-minimum-message-length", yaml.getInt("levels.xp.minimum-message-length", 3));
        context.variables.put("levels-maximum", yaml.getInt("levels.maximum-level", 80));
        context.variables.put("levels-role-mode", yaml.getString("levels.role-mode", "HIGHEST_ONLY"));
        context.variables.put("ticket-panel-title", yaml.getString("tickets.panel.title", "Support Tickets"));
        context.variables.put("ticket-panel-description", yaml.getString("tickets.panel.description",
                "Choose the option that best matches why you need help."));
        context.variables.put("ticket-maximum-open-per-user", yaml.getInt("tickets.maximum-open-per-user", 1));
        context.variables.put("ticket-ban-appeal-enabled", yaml.getBoolean("tickets.types.ban-appeal.enabled", true));
        context.variables.put("ticket-bug-report-enabled", yaml.getBoolean("tickets.types.bug-report.enabled", true));
        context.variables.put("ticket-media-rank-enabled", yaml.getBoolean("tickets.types.media-rank.enabled", true));
        context.variables.put("ticket-other-enabled", yaml.getBoolean("tickets.types.other.enabled", true));
        for (String group : List.of("platform", "age", "region", "notifications")) {
            context.variables.put("self-group-" + group + "-enabled",
                    yaml.getBoolean("self-roles." + group + ".enabled", true));
        }
        for (String selfRole : SELF_ROLE_VARIABLES.keySet()) {
            context.variables.put("self-" + selfRole.replace('.', '-') + "-enabled",
                    yaml.getBoolean("self-roles." + selfRole, true));
        }

        try {
            resolveCoreRoles(context, roleMode);
            resolveLevelRoles(context, roleMode);
            resolveSelfRoles(context, roleMode);
            resolveCategories(context, categoryMode);
            resolveChannels(context, channelMode);
            resolveBooster(context);
            resolveLuckPerms(context);

            if (context.totalResources() > MAXIMUM_RESOURCES) {
                throw new IllegalStateException("Preset bootstrap exceeds the " + MAXIMUM_RESOURCES + " resource safety limit");
            }
            if (mutate && yaml.getBoolean("discord.configure-role-order", true)) configureManagedRoleOrder(context);
            if (mutate && configurePermissions) configureChannelPermissions(context);
            publishInformation(context);
            if (mutate) saveOwnershipState(context);
        } catch (Throwable failure) {
            if (mutate) rollbackCreatedResources(context, failure);
            if (failure instanceof Exception exception) throw exception;
            if (failure instanceof Error error) throw error;
            throw new IllegalStateException("Preset bootstrap failed", failure);
        }

        String message = mutate
                ? "Bootstrap resources are ready: " + context.created.size() + " created, "
                    + context.reused.size() + " reused"
                : "Preview: " + context.createPlan.size() + " create, " + context.reusePlan.size()
                    + " reuse, " + context.conflicts.size() + " conflict, " + context.skipped.size() + " skip";
        return new BootstrapResult(Map.copyOf(context.variables), List.copyOf(context.createPlan),
                List.copyOf(context.reusePlan), List.copyOf(context.conflicts), List.copyOf(context.created),
                List.copyOf(context.reused), message);
    }

    private static void initializeOptionalVariables(PlanContext context) {
        for (String key : List.of(
                "verified-role-id", "booster-role-id", "staff-role-id",
                "chat-channel-id", "role-select-channel-id", "ticket-panel-channel-id", "ticket-log-channel-id",
                "ban-appeal-category-id", "bug-report-category-id", "other-ticket-category-id",
                "platform-pc-role-id", "platform-xbox-role-id", "platform-playstation-role-id",
                "platform-mobile-role-id", "platform-switch-role-id",
                "age-13-14-role-id", "age-15-17-role-id", "age-18-20-role-id",
                "age-21-24-role-id", "age-25-29-role-id", "age-30-plus-role-id",
                "region-europe-role-id", "region-na-role-id", "region-asia-role-id",
                "region-oceania-role-id", "region-sa-role-id", "region-africa-role-id",
                "notify-news-role-id", "notify-streams-role-id", "notify-events-role-id",
                "notify-polls-role-id", "notify-updates-role-id"
        )) {
            context.variables.put(key, "");
        }
        for (int level : DONUT_LEVELS) context.variables.put("level-" + level + "-role-id", "");
    }

    private void resolveCoreRoles(PlanContext context, ResourceMode mode) throws Exception {
        if (context.yaml.getBoolean("features.verification", true)) {
            ResourceMode verifiedMode = creationMode(mode, context.yaml.getBoolean("create.roles.verified", true));
            RoleResource verified = role(context, verifiedMode, "verified", "Verified", "#BFC3C9",
                    "existing.roles.verified", true);
            context.variables.put("verified-role-id", idValue(verified.id()));
        }
        if (context.yaml.getBoolean("features.tickets", true)) {
            String staffName = context.yaml.getString("tickets.staff-role.name", "Support Team");
            ResourceMode staffMode = creationMode(mode, context.yaml.getBoolean("create.roles.ticket-staff", true));
            RoleResource staff = role(context, staffMode, "ticket-staff", staffName, "#55B6E8",
                    "existing.roles.ticket-staff", true);
            context.variables.put("staff-role-id", idValue(staff.id()));
        }
    }

    private void resolveLevelRoles(PlanContext context, ResourceMode mode) throws Exception {
        boolean enabled = context.yaml.getBoolean("features.discord-levels", true);
        if (!enabled) return;
        ResourceMode levelMode = creationMode(mode, context.yaml.getBoolean("create.roles.level-roles", true));
        for (int level : DONUT_LEVELS.stream().sorted().toList()) {
            String path = "levels.roles." + level;
            String name = context.yaml.getString(path + ".name", defaultLevelName(level));
            String color = context.yaml.getString(path + ".color", defaultLevelColor(level));
            RoleResource role = role(context, levelMode, "level-" + level, name, color,
                    "existing.roles.levels." + level, true);
            context.variables.put("level-" + level + "-role-id", idValue(role.id()));
        }
    }

    private void resolveSelfRoles(PlanContext context, ResourceMode mode) throws Exception {
        if (!context.yaml.getBoolean("features.self-roles", true)) return;
        ResourceMode selfRoleMode = creationMode(mode, context.yaml.getBoolean("create.roles.self-roles", true));
        for (Map.Entry<String, String> entry : SELF_ROLE_VARIABLES.entrySet()) {
            String logical = entry.getKey().replace('.', '-');
            String section = "self-roles." + entry.getKey();
            String group = entry.getKey().substring(0, entry.getKey().indexOf('.'));
            if (!context.yaml.getBoolean("self-roles." + group + ".enabled", true)
                    || (!context.yaml.getBoolean(section, true) && context.yaml.isBoolean(section))) {
                context.variables.put(entry.getValue(), "");
                continue;
            }
            String defaultName = defaultSelfRoleName(entry.getKey());
            String name = context.yaml.getString(section + ".name", defaultName);
            String color = context.yaml.getString(section + ".color", "");
            RoleResource role = role(context, selfRoleMode, logical, name, color,
                    "existing.roles." + entry.getKey(), false);
            context.variables.put(entry.getValue(), idValue(role.id()));
        }
    }

    private void resolveCategories(PlanContext context, ResourceMode mode) throws Exception {
        List<CategorySpec> specs = List.of(
                new CategorySpec("read-only", "READ ONLY", "existing.categories.read-only"),
                new CategorySpec("general", "GENERAL", "existing.categories.general"),
                new CategorySpec("bot", "BOT", "existing.categories.bot"),
                new CategorySpec("support", "SUPPORT", "existing.categories.support"),
                new CategorySpec("ban-appeals", "BAN APPEALS", "existing.categories.ban-appeals"),
                new CategorySpec("bug-reports", "BUG REPORTS", "existing.categories.bug-reports"),
                new CategorySpec("other-tickets", "OTHER TICKETS", "existing.categories.other-tickets")
        );
        for (CategorySpec spec : specs) {
            if (!categoryNeeded(context, spec.id())) {
                context.skipped.add("category:" + spec.id());
                continue;
            }
            boolean enabled = context.yaml.getBoolean("create.categories." + spec.id(), true);
            CategoryResource category = category(context, creationMode(mode, enabled),
                    spec.id(), context.yaml.getString("category-names." + spec.id(), spec.defaultName()), spec.existingPath());
            context.categories.put(spec.id(), category);
        }
        context.variables.put("ban-appeal-category-id", categoryId(context, "ban-appeals"));
        context.variables.put("bug-report-category-id", categoryId(context, "bug-reports"));
        context.variables.put("other-ticket-category-id", categoryId(context, "other-tickets"));
    }

    private void resolveChannels(PlanContext context, ResourceMode mode) throws Exception {
        List<ChannelSpec> specs = List.of(
                new ChannelSpec("verify", "⚠️・verify", "general"),
                new ChannelSpec("chat", "💬・chat", "general"),
                new ChannelSpec("commands", "🔧・commands", "bot"),
                new ChannelSpec("news", "📌・news", "read-only"),
                new ChannelSpec("updates", "📋・updates", "read-only"),
                new ChannelSpec("rules", "📖・rules", "read-only"),
                new ChannelSpec("media-rank", "🎥・media-rank", "read-only"),
                new ChannelSpec("role-info", "⭐・role-info", "read-only"),
                new ChannelSpec("role-select", "✍️・role-select", "read-only"),
                new ChannelSpec("tickets", "📫・tickets", "read-only"),
                new ChannelSpec("ticket-logs", "ticket-logs", "support"),
                new ChannelSpec("boosts", "💎・boosts", "read-only"),
                new ChannelSpec("staff-apps", "📄・staff-apps", "read-only"),
                new ChannelSpec("how-to-join", "how-to-join", "read-only")
        );
        for (ChannelSpec spec : specs) {
            if (!channelNeeded(context, spec.id())) {
                context.skipped.add("channel:" + spec.id());
                continue;
            }
            boolean enabled = context.yaml.getBoolean("create.channels." + spec.id(), true);
            CategoryResource parent = context.categories.get(spec.category());
            TextChannelResource channel = textChannel(context, creationMode(mode, enabled),
                    spec.id(), context.yaml.getString("channel-names." + spec.id(), spec.defaultName()), parent,
                    "existing.channels." + spec.id());
            context.channels.put(spec.id(), channel);
        }
        context.variables.put("chat-channel-id", channelId(context, "chat"));
        context.variables.put("role-select-channel-id", channelId(context, "role-select"));
        context.variables.put("ticket-panel-channel-id", channelId(context, "tickets"));
        context.variables.put("ticket-log-channel-id", channelId(context, "ticket-logs"));
    }

    private static void validateModeCompatibility(
            YamlConfiguration yaml,
            ResourceMode roles,
            ResourceMode channels,
            ResourceMode categories
    ) {
        if (yaml.getBoolean("features.verification", true) && roles == ResourceMode.DISABLED) {
            throw new IllegalArgumentException("features.verification requires discord.roles-mode to be CREATE_MISSING or USE_EXISTING");
        }
        if (yaml.getBoolean("features.minecraft-chat", true) && channels == ResourceMode.DISABLED) {
            throw new IllegalArgumentException("features.minecraft-chat requires discord.channels-mode to be CREATE_MISSING or USE_EXISTING");
        }
        if (yaml.getBoolean("features.self-roles", true)
                && (roles == ResourceMode.DISABLED || channels == ResourceMode.DISABLED)) {
            throw new IllegalArgumentException("features.self-roles requires Discord roles and channels");
        }
        if (yaml.getBoolean("features.discord-levels", true) && roles == ResourceMode.DISABLED) {
            throw new IllegalArgumentException("features.discord-levels requires Discord roles for Donut milestone ranks");
        }
        if (yaml.getBoolean("features.tickets", true)
                && (roles == ResourceMode.DISABLED || channels == ResourceMode.DISABLED || categories == ResourceMode.DISABLED)) {
            throw new IllegalArgumentException("features.tickets requires Discord roles, channels and categories");
        }
        String provider = yaml.getString("ingame-ranks.provider", "LUCKPERMS");
        if (!"LUCKPERMS".equalsIgnoreCase(provider)) {
            throw new IllegalArgumentException("ingame-ranks.provider currently supports only LUCKPERMS");
        }
        if (yaml.getBoolean("discord.configure-existing-permissions", false)
                || yaml.getBoolean("discord.configure-existing-role-order", false)
                || yaml.getBoolean("ingame-ranks.configure-existing-groups", false)) {
            throw new IllegalArgumentException("Preset v2 does not mutate reused Discord/LuckPerms resources because those external changes cannot be restored safely. Leave configure-existing-* disabled.");
        }
    }

    private static ResourceMode creationMode(ResourceMode groupMode, boolean createMissing) {
        if (groupMode == ResourceMode.DISABLED) return ResourceMode.DISABLED;
        return createMissing ? groupMode : ResourceMode.USE_EXISTING;
    }

    private static boolean categoryNeeded(PlanContext context, String id) {
        return switch (id) {
            case "support" -> context.yaml.getBoolean("features.tickets", true);
            case "ban-appeals" -> context.yaml.getBoolean("features.tickets", true)
                    && context.yaml.getBoolean("tickets.types.ban-appeal.enabled", true);
            case "bug-reports" -> context.yaml.getBoolean("features.tickets", true)
                    && context.yaml.getBoolean("tickets.types.bug-report.enabled", true);
            case "other-tickets" -> context.yaml.getBoolean("features.tickets", true)
                    && (context.yaml.getBoolean("tickets.types.media-rank.enabled", true)
                        || context.yaml.getBoolean("tickets.types.other.enabled", true));
            case "general" -> context.yaml.getBoolean("features.verification", true)
                    || context.yaml.getBoolean("features.minecraft-chat", true);
            case "bot" -> context.yaml.getBoolean("features.verification", true)
                    || context.yaml.getBoolean("features.discord-levels", true);
            case "read-only" -> context.yaml.getBoolean("features.self-roles", true)
                    || context.yaml.getBoolean("features.tickets", true)
                    || context.yaml.getBoolean("features.media-rank", true)
                    || context.yaml.getBoolean("features.role-info", true)
                    || context.yaml.getBoolean("features.booster-support", true)
                    || context.yaml.getBoolean("features.staff-applications", true)
                    || context.yaml.getBoolean("features.how-to-join", true)
                    || context.yaml.getBoolean("create.channels.news", true)
                    || context.yaml.getBoolean("create.channels.updates", true)
                    || context.yaml.getBoolean("create.channels.rules", true);
            case "stats" -> context.yaml.getBoolean("create.categories.stats", false);
            default -> context.yaml.getBoolean("create.categories." + id, true);
        };
    }

    private static boolean channelNeeded(PlanContext context, String id) {
        return switch (id) {
            case "verify" -> context.yaml.getBoolean("features.verification", true);
            case "chat" -> context.yaml.getBoolean("features.minecraft-chat", true);
            case "commands" -> context.yaml.getBoolean("features.verification", true)
                    || context.yaml.getBoolean("features.discord-levels", true);
            case "media-rank" -> context.yaml.getBoolean("features.media-rank", true);
            case "role-info" -> context.yaml.getBoolean("features.role-info", true);
            case "role-select" -> context.yaml.getBoolean("features.self-roles", true);
            case "tickets", "ticket-logs" -> context.yaml.getBoolean("features.tickets", true);
            case "boosts" -> context.yaml.getBoolean("features.booster-support", true);
            case "staff-apps" -> context.yaml.getBoolean("features.staff-applications", true);
            case "how-to-join" -> context.yaml.getBoolean("features.how-to-join", true);
            default -> context.yaml.getBoolean("create.channels." + id, true);
        };
    }

    private void resolveBooster(PlanContext context) {
        Role boost = context.guild.getBoostRole();
        String configured = string(context.yaml.get("existing.roles.booster"));
        if (!configured.isBlank()) {
            long id = snowflake(configured, "existing.roles.booster");
            boost = context.guild.getRoleById(id);
            if (boost == null) throw new IllegalArgumentException("existing.roles.booster is not a role in the configured guild");
        }
        if (boost != null) context.variables.put("booster-role-id", boost.getId());
    }

    private void resolveLuckPerms(PlanContext context) throws Exception {
        boolean enabled = context.yaml.getBoolean("features.ingame-ranks", true)
                && context.yaml.getBoolean("ingame-ranks.enabled", true);
        if (!enabled) {
            context.variables.put("ingame-ranks-installed", false);
            return;
        }

        boolean installed = plugin.getServer().getPluginManager().isPluginEnabled("LuckPerms");
        String missingMode = context.yaml.getString("ingame-ranks.if-provider-missing", "SKIP_WITH_WARNING");
        if (!installed) {
            if ("REQUIRE".equalsIgnoreCase(missingMode)) {
                throw new IllegalStateException("DonutSMP in-game ranks require LuckPerms, but LuckPerms is not enabled");
            }
            context.variables.put("ingame-ranks-installed", false);
            context.skipped.add("LuckPerms in-game ranks (LuckPerms unavailable)");
            return;
        }

        Map<String, List<LuckPermsNodeSpec>> template = loadDonutLuckPermsTemplate();
        var manager = LuckPermsProvider.get().getGroupManager();
        boolean createMissing = context.yaml.getBoolean("ingame-ranks.create-missing-groups", true);
        Map<String, net.luckperms.api.model.group.Group> groupsToConfigure = new LinkedHashMap<>();

        for (Map.Entry<String, String> entry : DONUT_INGAME_RANK_GROUPS.entrySet()) {
            String logical = entry.getKey();
            String groupName = entry.getValue();
            List<LuckPermsNodeSpec> nodes = template.get(groupName);
            if (nodes == null || nodes.isEmpty()) {
                throw new IllegalStateException("Bundled Donut LuckPerms template is missing group " + groupName);
            }

            var existing = manager.getGroup(groupName);
            if (existing != null) {
                context.reusePlan.add("LuckPerms rank " + groupName);
                context.reused.add("luckperms-group:" + groupName);
                context.ownership.put("luckperms.rank-" + logical,
                        owned("LUCKPERMS_GROUP", groupName, groupName, Ownership.REUSED));
                continue;
            }

            if (!createMissing) {
                throw new IllegalStateException("LuckPerms rank " + groupName
                        + " does not exist and create-missing-groups=false");
            }
            if (!context.mutate) {
                context.createPlan.add("LuckPerms rank " + groupName + " (DonutRanks template)");
                continue;
            }

            var createdGroup = manager.createAndLoadGroup(groupName).get(10L, TimeUnit.SECONDS);
            groupsToConfigure.put(groupName, createdGroup);
            context.undo.add(() -> manager.deleteGroup(createdGroup).get(10L, TimeUnit.SECONDS));
            context.created.add("luckperms-group:" + groupName);
            context.ownership.put("luckperms.rank-" + logical,
                    owned("LUCKPERMS_GROUP", groupName, groupName, Ownership.CREATED));
        }

        // All missing groups are created before inheritance nodes are applied. This
        // preserves the exact hierarchy from the supplied LuckPerms export.
        for (Map.Entry<String, net.luckperms.api.model.group.Group> entry : groupsToConfigure.entrySet()) {
            List<LuckPermsNodeSpec> nodes = template.get(entry.getKey());
            for (LuckPermsNodeSpec spec : nodes) {
                entry.getValue().data().add(Node.builder(spec.key()).value(spec.value()).build());
            }
            manager.saveGroup(entry.getValue()).get(10L, TimeUnit.SECONDS);
        }
        context.variables.put("ingame-ranks-installed", true);
    }

    private static Map<String, List<LuckPermsNodeSpec>> loadDonutLuckPermsTemplate() throws IOException {
        try (InputStream input = PresetBootstrapService.class.getClassLoader()
                .getResourceAsStream("presets/donutsmp-luckperms-ranks.json")) {
            if (input == null) throw new IOException("Bundled Donut LuckPerms rank template is missing");
            String json = new String(input.readAllBytes(), StandardCharsets.UTF_8);
            Map<String, Object> root = MiniJson.parseObject(json);
            Object rawGroups = root.get("groups");
            if (!(rawGroups instanceof Map<?, ?> groups)) {
                throw new IOException("Bundled Donut LuckPerms rank template has no groups object");
            }
            Map<String, List<LuckPermsNodeSpec>> result = new LinkedHashMap<>();
            for (String groupName : DONUT_INGAME_RANK_GROUPS.values()) {
                Object rawGroup = groups.get(groupName);
                if (!(rawGroup instanceof Map<?, ?> group)) {
                    throw new IOException("Bundled Donut LuckPerms rank template is missing " + groupName);
                }
                Object rawNodes = group.get("nodes");
                if (!(rawNodes instanceof List<?> nodes)) {
                    throw new IOException("Bundled Donut LuckPerms rank template has invalid nodes for " + groupName);
                }
                List<LuckPermsNodeSpec> parsed = new ArrayList<>();
                for (Object rawNode : nodes) {
                    if (!(rawNode instanceof Map<?, ?> node)) {
                        throw new IOException("Invalid LuckPerms node in group " + groupName);
                    }
                    Object keyValue = node.get("key");
                    Object enabledValue = node.get("value");
                    if (!(keyValue instanceof String key) || key.isBlank() || !(enabledValue instanceof Boolean value)) {
                        throw new IOException("Invalid LuckPerms node key/value in group " + groupName);
                    }
                    parsed.add(new LuckPermsNodeSpec(key, value));
                }
                result.put(groupName, List.copyOf(parsed));
            }
            return Map.copyOf(result);
        }
    }

    private RoleResource role(
            PlanContext context,
            ResourceMode mode,
            String logicalId,
            String name,
            String color,
            String existingPath,
            boolean hoist
    ) throws Exception {
        if (mode == ResourceMode.DISABLED) {
            context.skipped.add("role:" + logicalId);
            RoleResource resource = new RoleResource(logicalId, 0L, Ownership.SKIPPED, name);
            context.roles.put(logicalId, resource);
            return resource;
        }
        long configured = optionalSnowflake(context.yaml.get(existingPath), existingPath);
        ManagedReference managed = managedReference(context, "role", logicalId);
        long candidateId = configured > 0L ? configured : managed.id();
        Role existing = candidateId > 0L ? context.guild.getRoleById(candidateId) : null;
        if (configured > 0L && existing == null) throw new IllegalArgumentException(existingPath + " is not a role in the configured guild");
        if (existing == null && context.detectByName && mode == ResourceMode.CREATE_MISSING) {
            Role matching = uniqueRoleByName(context.guild, name);
            if (matching != null) {
                String conflict = "Discord role @" + name + " already exists; explicitly reuse it by setting "
                        + existingPath + "=" + matching.getId();
                if (!context.mutate) {
                    context.conflicts.add(conflict);
                    RoleResource resource = new RoleResource(logicalId, matching.getIdLong(), Ownership.REUSED, matching.getName());
                    context.roles.put(logicalId, resource);
                    return resource;
                }
                throw new IllegalStateException(conflict);
            }
        }
        if (existing != null) {
            if (!context.guild.getSelfMember().canInteract(existing)) {
                throw new IllegalStateException("CoreDSC bot role must be above @" + existing.getName());
            }
            Ownership ownership = managed.matches(existing.getIdLong()) ? managed.ownership() : Ownership.REUSED;
            context.reusePlan.add("Role @" + existing.getName() + (ownership == Ownership.CREATED ? " (managed)" : ""));
            context.reused.add("role:" + logicalId + ":" + existing.getId());
            context.ownership.put("role." + logicalId, owned("ROLE", existing.getId(), existing.getName(), ownership));
            RoleResource resource = new RoleResource(logicalId, existing.getIdLong(), ownership, existing.getName());
            context.roles.put(logicalId, resource);
            return resource;
        }
        if (mode == ResourceMode.USE_EXISTING) {
            String conflict = "Missing existing Discord role ID for " + logicalId + " (" + existingPath + ")";
            if (!context.mutate) {
                context.conflicts.add(conflict);
                RoleResource resource = new RoleResource(logicalId, 0L, Ownership.SKIPPED, name);
                context.roles.put(logicalId, resource);
                return resource;
            }
            throw new IllegalStateException(conflict);
        }
        context.createPlan.add("Role @" + name);
        if (!context.mutate) {
            RoleResource resource = new RoleResource(logicalId, 0L, Ownership.PLANNED, name);
            context.roles.put(logicalId, resource);
            return resource;
        }
        var action = context.guild.createRole().setName(requireDiscordName(name, 100)).setHoisted(hoist).setMentionable(false);
        if (color != null && !color.isBlank()) action.setColor(parseColor(color));
        Role created = action.submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
        context.created.add("role:" + logicalId + ":" + created.getId());
        context.undo.add(() -> created.delete().submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS));
        context.ownership.put("role." + logicalId, owned("ROLE", created.getId(), created.getName(), Ownership.CREATED));
        RoleResource resource = new RoleResource(logicalId, created.getIdLong(), Ownership.CREATED, created.getName());
        context.roles.put(logicalId, resource);
        return resource;
    }

    private CategoryResource category(
            PlanContext context,
            ResourceMode mode,
            String logicalId,
            String name,
            String existingPath
    ) throws Exception {
        if (mode == ResourceMode.DISABLED) {
            context.skipped.add("category:" + logicalId);
            return new CategoryResource(logicalId, 0L, Ownership.SKIPPED, name);
        }
        long configured = optionalSnowflake(context.yaml.get(existingPath), existingPath);
        ManagedReference managed = managedReference(context, "category", logicalId);
        long candidateId = configured > 0L ? configured : managed.id();
        Category existing = candidateId > 0L ? context.guild.getCategoryById(candidateId) : null;
        if (configured > 0L && existing == null) throw new IllegalArgumentException(existingPath + " is not a category in the configured guild");
        if (existing == null && context.detectByName && mode == ResourceMode.CREATE_MISSING) {
            Category matching = uniqueCategoryByName(context.guild, name);
            if (matching != null) {
                String conflict = "Discord category " + name + " already exists; explicitly reuse it by setting "
                        + existingPath + "=" + matching.getId();
                if (!context.mutate) {
                    context.conflicts.add(conflict);
                    return new CategoryResource(logicalId, matching.getIdLong(), Ownership.REUSED, matching.getName());
                }
                throw new IllegalStateException(conflict);
            }
        }
        if (existing != null) {
            Ownership ownership = managed.matches(existing.getIdLong()) ? managed.ownership() : Ownership.REUSED;
            context.reusePlan.add("Category " + existing.getName() + (ownership == Ownership.CREATED ? " (managed)" : ""));
            context.reused.add("category:" + logicalId + ":" + existing.getId());
            context.ownership.put("category." + logicalId, owned("CATEGORY", existing.getId(), existing.getName(), ownership));
            return new CategoryResource(logicalId, existing.getIdLong(), ownership, existing.getName());
        }
        if (mode == ResourceMode.USE_EXISTING) {
            String conflict = "Missing existing Discord category ID for " + logicalId + " (" + existingPath + ")";
            if (!context.mutate) {
                context.conflicts.add(conflict);
                return new CategoryResource(logicalId, 0L, Ownership.SKIPPED, name);
            }
            throw new IllegalStateException(conflict);
        }
        context.createPlan.add("Category " + name);
        if (!context.mutate) return new CategoryResource(logicalId, 0L, Ownership.PLANNED, name);
        Category created = context.guild.createCategory(requireDiscordName(name, 100))
                .submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
        context.created.add("category:" + logicalId + ":" + created.getId());
        context.undo.add(() -> created.delete().submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS));
        context.ownership.put("category." + logicalId, owned("CATEGORY", created.getId(), created.getName(), Ownership.CREATED));
        return new CategoryResource(logicalId, created.getIdLong(), Ownership.CREATED, created.getName());
    }

    private TextChannelResource textChannel(
            PlanContext context,
            ResourceMode mode,
            String logicalId,
            String name,
            CategoryResource parent,
            String existingPath
    ) throws Exception {
        if (mode == ResourceMode.DISABLED) {
            context.skipped.add("channel:" + logicalId);
            return new TextChannelResource(logicalId, 0L, Ownership.SKIPPED, name);
        }
        long configured = optionalSnowflake(context.yaml.get(existingPath), existingPath);
        ManagedReference managed = managedReference(context, "channel", logicalId);
        long candidateId = configured > 0L ? configured : managed.id();
        TextChannel existing = candidateId > 0L ? context.guild.getTextChannelById(candidateId) : null;
        if (configured > 0L && existing == null) throw new IllegalArgumentException(existingPath + " is not a text channel in the configured guild");
        if (existing == null && context.detectByName && mode == ResourceMode.CREATE_MISSING) {
            TextChannel matching = uniqueTextChannelByName(context.guild, name);
            if (matching != null) {
                String conflict = "Discord channel #" + name + " already exists; explicitly reuse it by setting "
                        + existingPath + "=" + matching.getId();
                if (!context.mutate) {
                    context.conflicts.add(conflict);
                    return new TextChannelResource(logicalId, matching.getIdLong(), Ownership.REUSED, matching.getName());
                }
                throw new IllegalStateException(conflict);
            }
        }
        if (existing != null) {
            Ownership ownership = managed.matches(existing.getIdLong()) ? managed.ownership() : Ownership.REUSED;
            context.reusePlan.add("Channel #" + existing.getName() + (ownership == Ownership.CREATED ? " (managed)" : ""));
            context.reused.add("channel:" + logicalId + ":" + existing.getId());
            context.ownership.put("channel." + logicalId, owned("TEXT_CHANNEL", existing.getId(), existing.getName(), ownership));
            return new TextChannelResource(logicalId, existing.getIdLong(), ownership, existing.getName());
        }
        if (mode == ResourceMode.USE_EXISTING) {
            String conflict = "Missing existing Discord channel ID for " + logicalId + " (" + existingPath + ")";
            if (!context.mutate) {
                context.conflicts.add(conflict);
                return new TextChannelResource(logicalId, 0L, Ownership.SKIPPED, name);
            }
            throw new IllegalStateException(conflict);
        }
        context.createPlan.add("Channel #" + name);
        if (!context.mutate) return new TextChannelResource(logicalId, 0L, Ownership.PLANNED, name);
        Category category = parent == null || parent.id() <= 0L ? null : context.guild.getCategoryById(parent.id());
        TextChannel created = category == null
                ? context.guild.createTextChannel(requireChannelName(name)).submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS)
                : context.guild.createTextChannel(requireChannelName(name), category).submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
        context.created.add("channel:" + logicalId + ":" + created.getId());
        context.undo.add(() -> created.delete().submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS));
        context.ownership.put("channel." + logicalId, owned("TEXT_CHANNEL", created.getId(), created.getName(), Ownership.CREATED));
        return new TextChannelResource(logicalId, created.getIdLong(), Ownership.CREATED, created.getName());
    }

    private void configureChannelPermissions(PlanContext context) throws Exception {
        Role publicRole = context.guild.getPublicRole();
        Role verified = roleFromVariable(context, "verified-role-id");
        Role staff = roleFromVariable(context, "staff-role-id");
        Set<String> readOnly = Set.of("news", "updates", "rules", "media-rank", "role-info", "role-select",
                "tickets", "boosts", "staff-apps", "how-to-join");
        for (Map.Entry<String, TextChannelResource> entry : context.channels.entrySet()) {
            TextChannelResource resource = entry.getValue();
            if (resource.id() <= 0L) continue;
            TextChannel channel = context.guild.getTextChannelById(resource.id());
            if (channel == null) continue;
            boolean configureExisting = context.yaml.getBoolean("discord.configure-existing-permissions", false);
            if (resource.ownership() != Ownership.CREATED && !configureExisting) continue;
            String logical = entry.getKey();
            if (readOnly.contains(logical) || logical.equals("verify") || logical.equals("commands")) {
                channel.upsertPermissionOverride(publicRole)
                        .setAllowed(Permission.VIEW_CHANNEL)
                        .setDenied(Permission.MESSAGE_SEND)
                        .submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
            }
            if (logical.equals("verify") || logical.equals("commands")) {
                channel.upsertPermissionOverride(publicRole)
                        .setAllowed(Permission.VIEW_CHANNEL, Permission.USE_APPLICATION_COMMANDS)
                        .setDenied(Permission.MESSAGE_SEND)
                        .submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
            }
            if (logical.equals("chat") && verified != null) {
                channel.upsertPermissionOverride(publicRole)
                        .setAllowed(Permission.VIEW_CHANNEL)
                        .setDenied(Permission.MESSAGE_SEND)
                        .submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                channel.upsertPermissionOverride(verified)
                        .setAllowed(Permission.VIEW_CHANNEL, Permission.MESSAGE_SEND)
                        .submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
            }
            if (logical.equals("ticket-logs") && staff != null) {
                channel.upsertPermissionOverride(publicRole)
                        .setDenied(Permission.VIEW_CHANNEL)
                        .submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                channel.upsertPermissionOverride(staff)
                        .setAllowed(Permission.VIEW_CHANNEL, Permission.MESSAGE_SEND, Permission.MESSAGE_HISTORY)
                        .submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
            }
            channel.upsertPermissionOverride(context.guild.getSelfMember())
                    .setAllowed(Permission.VIEW_CHANNEL, Permission.MESSAGE_SEND, Permission.MESSAGE_HISTORY,
                            Permission.USE_APPLICATION_COMMANDS)
                    .submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
        }
    }

    private void configureManagedRoleOrder(PlanContext context) throws Exception {
        boolean reorderExisting = context.yaml.getBoolean("discord.configure-existing-role-order", false);
        List<Role> ordered = new ArrayList<>();
        for (int level : DONUT_LEVELS.stream().sorted(java.util.Comparator.reverseOrder()).toList()) {
            addOrderRole(context, ordered, "level-" + level, reorderExisting);
        }
        addOrderRole(context, ordered, "verified", reorderExisting);
        for (String logical : SELF_ROLE_VARIABLES.keySet().stream().map(value -> value.replace('.', '-')).sorted().toList()) {
            addOrderRole(context, ordered, logical, reorderExisting);
        }
        if (ordered.size() < 2) return;
        Role anchor = context.guild.getSelfMember().getRoles().stream()
                .filter(role -> role.canInteract(ordered.getFirst()))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                        "CoreDSC bot role must be above the managed preset roles before role ordering can be applied"));
        var action = context.guild.modifyRolePositions();
        Role previous = anchor;
        for (Role role : ordered) {
            if (!context.guild.getSelfMember().canInteract(role)) {
                throw new IllegalStateException("CoreDSC cannot reorder @" + role.getName() + "; move the bot role above it");
            }
            action.selectPosition(role).moveBelow(previous);
            previous = role;
        }
        action.submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
    }

    private static void addOrderRole(
            PlanContext context,
            List<Role> ordered,
            String logicalId,
            boolean reorderExisting
    ) {
        RoleResource resource = context.roles.get(logicalId);
        if (resource == null || resource.id() <= 0L) return;
        if (resource.ownership() != Ownership.CREATED && !reorderExisting) return;
        Role role = context.guild.getRoleById(resource.id());
        if (role != null && !role.isManaged() && !role.isPublicRole()) ordered.add(role);
    }

    private void publishInformation(PlanContext context) throws Exception {
        if (context.yaml.getBoolean("features.role-info", true)
                && context.yaml.getBoolean("create.publish.role-info", true)) {
            publishManagedMessage(context, "role-info", "role-info", buildRoleInfo(context));
        }
        if (context.yaml.getBoolean("features.media-rank", true)
                && context.yaml.getBoolean("create.publish.media-rank-info", true)) {
            publishManagedMessage(context, "media-rank-info", "media-rank", buildMediaRankInfo(context));
        }
        if (context.yaml.getBoolean("features.how-to-join", true)
                && context.yaml.getBoolean("create.publish.how-to-join", true)) {
            publishManagedMessage(context, "how-to-join", "how-to-join", buildHowToJoin(context));
        }
    }

    private void publishManagedMessage(
            PlanContext context,
            String logicalId,
            String channelLogicalId,
            String content
    ) throws Exception {
        TextChannelResource channelResource = context.channels.get(channelLogicalId);
        if (channelResource == null || channelResource.id() <= 0L || content.isBlank()) return;
        String root = "presets." + context.presetId + ".resources.message." + logicalId;
        long previousMessageId = optionalSnowflake(context.previousState.get(root + ".id"), root + ".id");
        long previousChannelId = optionalSnowflake(context.previousState.get(root + ".channel-id"), root + ".channel-id");
        TextChannel channel = context.guild.getTextChannelById(channelResource.id());
        if (channel == null) throw new IllegalStateException("Preset information channel is unavailable: " + channelLogicalId);

        boolean reusable = previousMessageId > 0L && previousChannelId == channelResource.id();
        if (!context.mutate) {
            if (reusable) context.reusePlan.add("Managed message in #" + channel.getName());
            else context.createPlan.add("Managed message in #" + channel.getName());
            return;
        }

        if (reusable) {
            try {
                var message = channel.retrieveMessageById(previousMessageId)
                        .submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                message.editMessage(content).submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
                context.reused.add("message:" + logicalId + ":" + previousMessageId);
                context.ownership.put("message." + logicalId,
                        ownedMessage(previousMessageId, channelResource.id(), logicalId, Ownership.CREATED));
                return;
            } catch (Exception ignored) {
                // The managed message was deleted or moved; create one replacement below.
            }
        }

        var message = channel.sendMessage(content).submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS);
        context.created.add("message:" + logicalId + ":" + message.getId());
        context.undo.add(() -> channel.deleteMessageById(message.getIdLong())
                .submit().get(DISCORD_TIMEOUT_SECONDS, TimeUnit.SECONDS));
        context.ownership.put("message." + logicalId,
                ownedMessage(message.getIdLong(), channelResource.id(), logicalId, Ownership.CREATED));
    }

    private String buildRoleInfo(PlanContext context) {
        StringBuilder text = new StringBuilder("**Community Levels**\n");
        for (int level : DONUT_LEVELS.stream().sorted(java.util.Comparator.reverseOrder()).toList()) {
            RoleResource role = context.roles.get("level-" + level);
            if (role != null && role.id() > 0L) {
                text.append("<@&").append(role.id()).append("> — Level ").append(level).append('\n');
            }
        }
        RoleResource booster = context.roles.get("booster");
        if (booster != null && booster.id() > 0L) {
            text.append("\nBoost the Discord server to receive <@&").append(booster.id()).append(">.\n");
        }
        TextChannelResource roleSelect = context.channels.get("role-select");
        if (roleSelect != null && roleSelect.id() > 0L) {
            text.append("\nChoose optional platform, region, age and notification roles in <#")
                    .append(roleSelect.id()).append(">.");
        }
        return boundedMessage(text.toString());
    }

    private String buildMediaRankInfo(PlanContext context) {
        YamlConfiguration yaml = context.yaml;
        int longform = yaml.getInt("media-rank.requirements.longform-live-average-viewers", 25);
        int shortform = yaml.getInt("media-rank.requirements.shortform-live-average-viewers", 100);
        int youtube = yaml.getInt("media-rank.requirements.youtube-video-views", 5_000);
        int tiktok = yaml.getInt("media-rank.requirements.tiktok-video-views", 50_000);
        int shorts = yaml.getInt("media-rank.requirements.youtube-short-views", 50_000);
        int reels = yaml.getInt("media-rank.requirements.instagram-reel-views", 50_000);
        int days = yaml.getInt("media-rank.duration-days", 90);
        TextChannelResource tickets = context.channels.get("tickets");
        String ticketMention = tickets == null || tickets.id() <= 0L ? "the ticket channel" : "<#" + tickets.id() + ">";
        String value = "**Media Rank Requirements** *(one is enough)*\n"
                + "• " + longform + "+ average viewers on a long-form Twitch/YouTube live stream\n"
                + "• " + shortform + "+ average viewers on a TikTok/YouTube short-form live stream\n"
                + "• " + youtube + "+ views on a YouTube video\n"
                + "• " + tiktok + "+ views on a TikTok video\n"
                + "• " + shorts + "+ views on a YouTube Short\n"
                + "• " + reels + "+ views on an Instagram Reel\n\n"
                + "Open a Media Rank ticket in " + ticketMention + " and provide analytics proof.\n"
                + "Default rank duration: " + days + " days.";
        return boundedMessage(value);
    }

    private String buildHowToJoin(PlanContext context) {
        String name = context.yaml.getString("server.name", "My SMP");
        String address = context.yaml.getString("server.minecraft-address", "play.example.net");
        String invite = context.yaml.getString("server.discord-invite", "");
        String website = context.yaml.getString("server.website", "");
        String safeName = name == null || name.isBlank() ? "Server" : name.trim();
        StringBuilder text = new StringBuilder("**").append(safeName).append(" — How to join**\nMinecraft: `")
                .append(address == null || address.isBlank() ? "play.example.net" : address.trim()).append('`');
        if (invite != null && !invite.isBlank()) text.append("\nDiscord: ").append(invite.trim());
        if (website != null && !website.isBlank()) text.append("\nWebsite: ").append(website.trim());
        return boundedMessage(text.toString());
    }

    private static String boundedMessage(String value) {
        String text = value == null ? "" : value.trim();
        if (text.length() <= 1_900) return text;
        return text.substring(0, 1_897) + "...";
    }

    private static Map<String, Object> ownedMessage(
            long messageId,
            long channelId,
            String name,
            Ownership ownership
    ) {
        Map<String, Object> value = owned("MESSAGE", Long.toString(messageId), name, ownership);
        value.put("channel-id", Long.toString(channelId));
        return value;
    }

    private Role roleFromVariable(PlanContext context, String key) {
        String id = String.valueOf(context.variables.getOrDefault(key, ""));
        if (id.isBlank()) return null;
        try { return context.guild.getRoleById(Long.parseLong(id)); }
        catch (NumberFormatException ignored) { return null; }
    }

    private void rollbackCreatedResources(PlanContext context, Throwable originalFailure) {
        for (int index = context.undo.size() - 1; index >= 0; index--) {
            try {
                context.undo.get(index).undo();
            } catch (Throwable rollbackFailure) {
                originalFailure.addSuppressed(rollbackFailure);
            }
        }
    }

    private void saveOwnershipState(PlanContext context) throws IOException {
        YamlConfiguration state = stateFile.isFile() ? YamlConfiguration.loadConfiguration(stateFile) : new YamlConfiguration();
        String root = "presets." + context.presetId + ".resources";
        // Preserve ownership records for resources that are temporarily disabled.
        // Losing a CREATED record would make a later remove/repair unable to
        // distinguish a CoreDSC-owned object from an administrator-owned one.
        for (Map.Entry<String, Map<String, Object>> entry : context.ownership.entrySet()) {
            String path = root + "." + entry.getKey();
            for (Map.Entry<String, Object> value : entry.getValue().entrySet()) state.set(path + "." + value.getKey(), value.getValue());
        }
        state.set("presets." + context.presetId + ".updated-at", System.currentTimeMillis());
        saveYamlAtomic(state, stateFile);
    }

    private Guild requireGuild(long guildId) {
        if (plugin.getDiscordService() == null || !plugin.getDiscordService().isReady()) {
            throw new IllegalStateException("Discord is not ready; connect CoreDSC before applying a bootstrap preset");
        }
        JDA jda = plugin.getDiscordService().getJda();
        Guild guild = jda == null ? null : jda.getGuildById(guildId);
        if (guild == null) throw new IllegalStateException("Configured Discord guild is not visible to the CoreDSC bot");
        if (!guild.getSelfMember().hasPermission(Permission.MANAGE_ROLES)) {
            throw new IllegalStateException("CoreDSC bot needs Manage Roles before applying the preset");
        }
        if (!guild.getSelfMember().hasPermission(Permission.MANAGE_CHANNEL)) {
            throw new IllegalStateException("CoreDSC bot needs Manage Channels before applying the preset");
        }
        return guild;
    }

    private static Role uniqueRoleByName(Guild guild, String name) {
        List<Role> matches = guild.getRolesByName(name, false);
        if (matches.size() > 1) throw new IllegalStateException("Multiple Discord roles are named '" + name + "'; configure an explicit ID");
        return matches.isEmpty() ? null : matches.getFirst();
    }

    private static Category uniqueCategoryByName(Guild guild, String name) {
        List<Category> matches = guild.getCategoriesByName(name, false);
        if (matches.size() > 1) throw new IllegalStateException("Multiple Discord categories are named '" + name + "'; configure an explicit ID");
        return matches.isEmpty() ? null : matches.getFirst();
    }

    private static TextChannel uniqueTextChannelByName(Guild guild, String name) {
        List<TextChannel> matches = guild.getTextChannelsByName(name, false);
        if (matches.size() > 1) throw new IllegalStateException("Multiple Discord channels are named '" + name + "'; configure an explicit ID");
        return matches.isEmpty() ? null : matches.getFirst();
    }

    private static YamlConfiguration loadV2(File file) throws IOException {
        YamlConfiguration yaml = new YamlConfiguration();
        try { yaml.load(file); }
        catch (org.bukkit.configuration.InvalidConfigurationException error) {
            throw new IOException("Invalid preset descriptor YAML in " + file.getName(), error);
        }
        if (yaml.getInt("format", 0) != 2) throw new IOException("Preset bootstrap requires format: 2");
        return yaml;
    }

    private static String presetId(YamlConfiguration yaml, File file) {
        String fallback = file.getName().replaceFirst("\\.ya?ml$", "");
        String id = yaml.getString("preset.id", fallback);
        if (id == null || !id.matches("[a-z0-9][a-z0-9._-]{1,63}")) throw new IllegalArgumentException("Invalid preset.id");
        return id;
    }

    private static long snowflake(Object raw, String path) {
        long value = optionalSnowflake(raw, path);
        if (value <= 0L) throw new IllegalArgumentException(path + " must be a positive Discord ID");
        return value;
    }

    private static long optionalSnowflake(Object raw, String path) {
        String value = string(raw);
        if (value.isBlank()) return 0L;
        try {
            long parsed = Long.parseLong(value);
            if (parsed <= 0L) throw new NumberFormatException("not positive");
            return parsed;
        } catch (NumberFormatException error) {
            throw new IllegalArgumentException(path + " must be a positive Discord ID", error);
        }
    }

    private static String idValue(long value) {
        return value <= 0L ? "" : Long.toString(value);
    }

    private static String categoryId(PlanContext context, String id) {
        CategoryResource resource = context.categories.get(id);
        return resource == null ? "" : idValue(resource.id());
    }

    private static String channelId(PlanContext context, String id) {
        TextChannelResource resource = context.channels.get(id);
        return resource == null ? "" : idValue(resource.id());
    }

    private static ManagedReference managedReference(PlanContext context, String type, String logicalId) {
        String root = "presets." + context.presetId + ".resources." + type + "." + logicalId;
        String idText = context.previousState.getString(root + ".id", "");
        long id = 0L;
        if (!idText.isBlank()) {
            try { id = Long.parseLong(idText); }
            catch (NumberFormatException ignored) { id = 0L; }
        }
        Ownership ownership;
        try {
            ownership = Ownership.valueOf(context.previousState.getString(root + ".ownership", "REUSED")
                    .toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ignored) {
            ownership = Ownership.REUSED;
        }
        if (ownership != Ownership.CREATED) ownership = Ownership.REUSED;
        return new ManagedReference(id, ownership);
    }

    private static Map<String, Object> owned(String type, String discordId, String name, Ownership ownership) {
        Map<String, Object> value = new LinkedHashMap<>();
        value.put("type", type);
        value.put("id", discordId);
        value.put("name", name);
        value.put("ownership", ownership.name());
        return Map.copyOf(value);
    }

    private static String requireDiscordName(String value, int maximum) {
        String name = value == null ? "" : value.trim();
        if (name.isBlank() || name.length() > maximum) throw new IllegalArgumentException("Invalid Discord resource name");
        return name;
    }

    private static String requireChannelName(String value) {
        return requireDiscordName(value, 100);
    }

    private static Color parseColor(String value) {
        String text = value == null ? "" : value.trim();
        if (!text.matches("#[0-9a-fA-F]{6}")) throw new IllegalArgumentException("Discord role color must use #RRGGBB");
        return new Color(Integer.parseInt(text.substring(1), 16));
    }


    private static String defaultLevelName(int level) {
        return switch (level) {
            case 1 -> "Affiliate DonutSMPer";
            case 3 -> "General DonutSMPer";
            case 5 -> "Loyal DonutSMPer";
            case 10 -> "Official DonutSMPer";
            case 20 -> "Prodigy DonutSMPer";
            case 30 -> "Immortal DonutSMPer";
            case 40 -> "Formidable DonutSMPer";
            case 50 -> "Legendary DonutSMPer";
            case 60 -> "Saint DonutSMPer";
            case 70 -> "Champion DonutSMPer";
            case 80 -> "GOD DonutSMPer";
            default -> "Level " + level;
        };
    }

    private static String defaultLevelColor(int level) {
        return switch (level) {
            case 1 -> "#F4C430";
            case 3 -> "#E3F220";
            case 5 -> "#78E92D";
            case 10 -> "#28D75A";
            case 20 -> "#43E6C1";
            case 30 -> "#37BCE8";
            case 40 -> "#3155F5";
            case 50 -> "#8D29DC";
            case 60 -> "#DA29D7";
            case 70 -> "#E72C8C";
            case 80 -> "#EE3232";
            default -> "#BFC3C9";
        };
    }


    private static String defaultSelfRoleName(String path) {
        return switch (path) {
            case "platform.pc" -> "PC";
            case "platform.xbox" -> "Xbox";
            case "platform.playstation" -> "PlayStation";
            case "platform.mobile" -> "Mobile";
            case "platform.nintendo-switch" -> "Nintendo Switch";
            case "age.age-13-14" -> "13-14";
            case "age.age-15-17" -> "15-17";
            case "age.age-18-20" -> "18-20";
            case "age.age-21-24" -> "21-24";
            case "age.age-25-29" -> "25-29";
            case "age.age-30-plus" -> "30+";
            case "region.europe" -> "EU";
            case "region.north-america" -> "North America";
            case "region.asia" -> "Asia";
            case "region.oceania" -> "Oceania";
            case "region.south-america" -> "South America";
            case "region.africa" -> "Africa";
            case "notifications.news-pings" -> "News Pings";
            case "notifications.stream-pings" -> "Stream Pings";
            case "notifications.event-pings" -> "Event Pings";
            case "notifications.poll-pings" -> "Poll Pings";
            case "notifications.update-pings" -> "Update Pings";
            default -> path;
        };
    }

    private static String string(Object value) {
        return value == null ? "" : String.valueOf(value).trim();
    }

    private static void saveYamlAtomic(YamlConfiguration yaml, File file) throws IOException {
        Path target = file.toPath().toAbsolutePath().normalize();
        Path parent = target.getParent();
        if (parent == null) throw new IOException("Preset resource state has no parent directory");
        Files.createDirectories(parent);
        Path temporary = Files.createTempFile(parent, "." + file.getName() + ".", ".tmp");
        try {
            Files.writeString(temporary, yaml.saveToString(), StandardCharsets.UTF_8,
                    StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);
            try (FileChannel channel = FileChannel.open(temporary, StandardOpenOption.WRITE)) {
                channel.force(true);
            }
            try {
                Files.move(temporary, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temporary);
        }
    }

    record RollbackPlan(List<ExternalResource> resources) {
        int size() { return resources.size(); }
        List<String> labels() { return resources.stream().map(ExternalResource::label).toList(); }
    }
    record RollbackCleanupResult(List<String> removed, List<String> warnings) { }

    private record ExternalResource(
            String presetId,
            String logicalId,
            String type,
            String id,
            long channelId,
            String name
    ) {
        private boolean sameIdentity(ExternalResource other) {
            return other != null && type.equals(other.type) && id.equals(other.id);
        }

        private long numericId() {
            try { return Long.parseLong(id); }
            catch (NumberFormatException failure) {
                throw new IllegalStateException("Invalid Discord resource id " + id, failure);
            }
        }

        private int deletionOrder() {
            return switch (type) {
                case "MESSAGE" -> 0;
                case "TEXT_CHANNEL" -> 1;
                case "CATEGORY" -> 2;
                case "ROLE" -> 3;
                case "LUCKPERMS_GROUP" -> 4;
                default -> 5;
            };
        }

        private String label() {
            return presetId + ":" + logicalId + " (" + type + " " + (name == null ? id : name) + ")";
        }
    }

    public record BootstrapResult(
            Map<String, Object> variables,
            List<String> plannedCreates,
            List<String> plannedReuses,
            List<String> conflicts,
            List<String> created,
            List<String> reused,
            String message
    ) { }

    private static final class PlanContext {
        private final String presetId;
        private final boolean mutate;
        private final Guild guild;
        private final YamlConfiguration yaml;
        private final boolean detectByName;
        private final YamlConfiguration previousState;
        private final Map<String, Object> variables = new LinkedHashMap<>();
        private final List<String> createPlan = new ArrayList<>();
        private final List<String> reusePlan = new ArrayList<>();
        private final List<String> conflicts = new ArrayList<>();
        private final List<String> created = new ArrayList<>();
        private final List<String> reused = new ArrayList<>();
        private final List<String> skipped = new ArrayList<>();
        private final Map<String, Map<String, Object>> ownership = new LinkedHashMap<>();
        private final List<UndoAction> undo = new ArrayList<>();
        private final Map<String, RoleResource> roles = new LinkedHashMap<>();
        private final Map<String, CategoryResource> categories = new LinkedHashMap<>();
        private final Map<String, TextChannelResource> channels = new LinkedHashMap<>();

        private PlanContext(
                String presetId,
                boolean mutate,
                Guild guild,
                YamlConfiguration yaml,
                boolean detectByName,
                YamlConfiguration previousState
        ) {
            this.presetId = presetId;
            this.mutate = mutate;
            this.guild = guild;
            this.yaml = yaml;
            this.detectByName = detectByName;
            this.previousState = previousState;
        }

        private int totalResources() {
            return createPlan.size() + reusePlan.size() + skipped.size();
        }
    }

    @FunctionalInterface
    private interface UndoAction {
        void undo() throws Exception;
    }

    private record ManagedReference(long id, Ownership ownership) {
        private boolean matches(long candidate) {
            return id > 0L && id == candidate;
        }
    }

    private record LuckPermsNodeSpec(String key, boolean value) { }

    private enum ResourceMode {
        CREATE_MISSING,
        USE_EXISTING,
        DISABLED;

        private static ResourceMode parse(String value) {
            try { return valueOf(value == null ? "" : value.trim().toUpperCase(Locale.ROOT)); }
            catch (IllegalArgumentException error) {
                throw new IllegalArgumentException("Preset resource mode must be CREATE_MISSING, USE_EXISTING or DISABLED", error);
            }
        }
    }

    private enum Ownership { CREATED, REUSED, PLANNED, SKIPPED }
    private record RoleResource(String logicalId, long id, Ownership ownership, String name) { }
    private record CategoryResource(String logicalId, long id, Ownership ownership, String name) { }
    private record TextChannelResource(String logicalId, long id, Ownership ownership, String name) { }
    private record CategorySpec(String id, String defaultName, String existingPath) { }
    private record ChannelSpec(String id, String defaultName, String category) { }
}
