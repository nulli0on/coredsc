package com.hubertstudios.coredsc.service;

import com.hubertstudios.coredsc.CoreDSCPlugin;
import com.hubertstudios.coredsc.config.ConfigManager;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;
import java.security.SecureRandom;

/**
 * CoreDSC-wide immutable configuration rollback snapshots.
 *
 * <p>Snapshots are created before preset/configuration mutations. Restores are
 * deliberately two-step: {@code /coredsc rollback use <id>} issues a short-lived
 * confirmation token and {@code /coredsc confirm <token>} performs the restore.
 * A fresh BEFORE_ROLLBACK snapshot is created immediately before restoration so
 * a rollback can itself be reversed.</p>
 */
public final class RollbackService implements AutoCloseable {
    private static final Pattern SAFE_ID = Pattern.compile("[0-9]{8}-[0-9]{6}-[a-z0-9._-]{2,80}");
    private static final DateTimeFormatter ID_TIME = DateTimeFormatter
            .ofPattern("yyyyMMdd-HHmmss", Locale.ROOT).withZone(ZoneOffset.UTC);
    private static final long CONFIRMATION_TTL_MILLIS = 60_000L;
    private static final int MAX_SNAPSHOTS = 40;
    private static final SecureRandom CONFIRMATION_RANDOM = new SecureRandom();

    private final CoreDSCPlugin plugin;
    private final Path rollbackRoot;
    private final Map<String, PendingRestore> pending = new ConcurrentHashMap<>();
    private final ExecutorService executor;
    private final AtomicBoolean closed = new AtomicBoolean();

    public RollbackService(CoreDSCPlugin plugin) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
        this.rollbackRoot = plugin.getDataFolder().toPath().resolve("backups/rollback")
                .toAbsolutePath().normalize();
        ThreadFactory factory = task -> {
            Thread thread = new Thread(task, "CoreDSC-Rollbacks");
            thread.setDaemon(true);
            return thread;
        };
        this.executor = Executors.newSingleThreadExecutor(factory);
    }

    public void start() throws IOException {
        Files.createDirectories(rollbackRoot);
        if (Files.isSymbolicLink(rollbackRoot)) {
            throw new IOException("Rollback directory may not be a symbolic link");
        }
        prune();
    }

    public synchronized Snapshot createSnapshot(String reason, String subject) throws IOException {
        ConfigManager manager = requireManager();
        String safeReason = slug(reason == null ? "snapshot" : reason);
        String id = ID_TIME.format(Instant.now()) + "-" + safeReason;
        Path target = uniqueDirectory(id);
        Path payload = target.resolve("payload");
        Files.createDirectories(payload);

        List<String> copied = new ArrayList<>();
        List<String> absent = new ArrayList<>();
        try {
            for (String relative : manager.editableFilePaths().stream().sorted().toList()) {
                Path source = plugin.getDataFolder().toPath().resolve(relative).toAbsolutePath().normalize();
                if (!source.startsWith(plugin.getDataFolder().toPath().toAbsolutePath().normalize())) {
                    throw new SecurityException("Editable CoreDSC path escaped the data directory: " + relative);
                }
                if (!Files.isRegularFile(source, LinkOption.NOFOLLOW_LINKS)) {
                    absent.add(relative);
                    continue;
                }
                copySnapshotFile(source, payload.resolve(relative));
                copied.add(relative);
            }

            for (String stateRelative : List.of("state/presets.yml", "state/preset-resources.yml", "state/preset-operations.yml")) {
                Path presetState = plugin.getDataFolder().toPath().resolve(stateRelative)
                        .toAbsolutePath().normalize();
                if (Files.isRegularFile(presetState, LinkOption.NOFOLLOW_LINKS)) {
                    copySnapshotFile(presetState, payload.resolve(stateRelative));
                    copied.add(stateRelative);
                } else {
                    absent.add(stateRelative);
                }
            }

            Path configs = plugin.getDataFolder().toPath().resolve("configs").toAbsolutePath().normalize();
            if (Files.isDirectory(configs, LinkOption.NOFOLLOW_LINKS)) {
                try (var stream = Files.list(configs)) {
                    for (Path source : stream
                            .filter(path -> Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS))
                            .filter(path -> path.getFileName().toString().matches("[a-z0-9][a-z0-9._-]{1,63}\\.ya?ml"))
                            .sorted().toList()) {
                        String relative = "configs/" + source.getFileName();
                        copySnapshotFile(source, payload.resolve(relative));
                        copied.add(relative);
                    }
                }
            }

            YamlConfiguration manifest = new YamlConfiguration();
            manifest.set("format", 1);
            manifest.set("id", target.getFileName().toString());
            manifest.set("created-at", System.currentTimeMillis());
            manifest.set("reason", bounded(reason, 120));
            manifest.set("subject", bounded(subject, 160));
            manifest.set("files", copied);
            manifest.set("absent-files", absent);
            manifest.set("config-files", copied.stream().filter(path -> path.startsWith("configs/")).toList());
            manifest.set("core-version", plugin.getDescription().getVersion());
            writeAtomic(target.resolve("manifest.yml"), manifest.saveToString());
            prune();
            return new Snapshot(target.getFileName().toString(), manifest.getLong("created-at"),
                    manifest.getString("reason", "snapshot"), manifest.getString("subject", ""),
                    List.copyOf(copied));
        } catch (Throwable failure) {
            deleteTreeQuietly(target);
            if (failure instanceof IOException io) throw io;
            if (failure instanceof RuntimeException runtime) throw runtime;
            throw new IOException("Could not create rollback snapshot", failure);
        }
    }

    public synchronized List<Snapshot> listSnapshots() throws IOException {
        if (!Files.isDirectory(rollbackRoot, LinkOption.NOFOLLOW_LINKS)) return List.of();
        List<Snapshot> result = new ArrayList<>();
        try (var stream = Files.list(rollbackRoot)) {
            for (Path directory : stream
                    .filter(path -> Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS))
                    .sorted(Comparator.comparing(path -> path.getFileName().toString(), Comparator.reverseOrder()))
                    .toList()) {
                readSnapshot(directory).ifPresent(result::add);
            }
        }
        return List.copyOf(result);
    }

    public PendingConfirmation requestRestore(String actor, String requestedId) throws IOException {
        String key = actorKey(actor);
        Snapshot snapshot = requireSnapshot(requestedId);
        Path targetResourceState = resolveSnapshotDirectory(snapshot.id()).resolve("payload/state/preset-resources.yml");
        PresetBootstrapService.RollbackPlan externalPlan = plugin.getPresetService()
                .planExternalRollback(targetResourceState);
        String token = confirmationToken();
        long expiresAt = System.currentTimeMillis() + CONFIRMATION_TTL_MILLIS;
        pending.put(key, new PendingRestore(snapshot.id(), token, expiresAt));
        return new PendingConfirmation(snapshot, token, expiresAt, externalPlan.labels());
    }


    public CompletableFuture<RestoreResult> confirmRestoreAsync(String actor, String suppliedToken) {
        return CompletableFuture.supplyAsync(() -> {
            if (closed.get()) throw new IllegalStateException("Rollback service is stopped");
            try {
                return confirmRestore(actor, suppliedToken);
            } catch (RuntimeException error) {
                throw error;
            } catch (Exception error) {
                throw new java.util.concurrent.CompletionException(error);
            }
        }, executor);
    }

    public synchronized RestoreResult confirmRestore(String actor, String suppliedToken) throws Exception {
        String key = actorKey(actor);
        PendingRestore request = pending.remove(key);
        if (request == null) throw new IllegalStateException("No rollback confirmation is pending for this sender");
        if (System.currentTimeMillis() > request.expiresAt()) {
            throw new IllegalStateException("Rollback confirmation expired; run /coredsc rollback use <id> again");
        }
        String token = suppliedToken == null ? "" : suppliedToken.trim().toUpperCase(Locale.ROOT);
        if (!request.token().equals(token)) throw new SecurityException("Rollback confirmation code is invalid");

        Snapshot target = requireSnapshot(request.snapshotId());
        Snapshot safety = createSnapshot("before-rollback", "Restoring " + target.id());
        Path targetResourceState = resolveSnapshotDirectory(target.id()).resolve("payload/state/preset-resources.yml");
        PresetBootstrapService.RollbackPlan externalPlan = plugin.getPresetService()
                .planExternalRollback(targetResourceState);
        List<String> restored = restoreSnapshot(target);
        CoreDSCPlugin.ReloadResult reload = plugin.callSync(plugin::reloadConfiguration).get(30L, java.util.concurrent.TimeUnit.SECONDS);
        if (!reload.success()) {
            throw new IllegalStateException("Rollback files were restored but CoreDSC reload failed: " + reload.message()
                    + ". Safety snapshot: " + safety.id());
        }
        PresetBootstrapService.RollbackCleanupResult external = plugin.getPresetService()
                .executeExternalRollback(externalPlan);
        String message = reload.message();
        if (!external.warnings().isEmpty()) {
            message += "; restored CoreDSC state, but " + external.warnings().size()
                    + " preset-created external resource(s) could not be removed";
        }
        return new RestoreResult(target, safety, restored, external.removed(), external.warnings(), message);
    }

    private List<String> restoreSnapshot(Snapshot snapshot) throws IOException {
        Path directory = resolveSnapshotDirectory(snapshot.id());
        Path payload = directory.resolve("payload").toAbsolutePath().normalize();
        if (!Files.isDirectory(payload, LinkOption.NOFOLLOW_LINKS) || Files.isSymbolicLink(payload)) {
            throw new IOException("Rollback payload is missing or unsafe");
        }
        Path dataRoot = plugin.getDataFolder().toPath().toAbsolutePath().normalize();
        YamlConfiguration manifest = YamlConfiguration.loadConfiguration(directory.resolve("manifest.yml").toFile());
        List<String> absent = manifest.getStringList("absent-files");
        Set<String> snapshotConfigs = new java.util.LinkedHashSet<>(manifest.getStringList("config-files"));
        Map<Path, byte[]> before = new LinkedHashMap<>();
        List<Path> written = new ArrayList<>();
        List<String> restored = new ArrayList<>();
        try (var stream = Files.walk(payload)) {
            for (Path source : stream.filter(path -> Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS)).sorted().toList()) {
                if (Files.isSymbolicLink(source)) throw new IOException("Rollback payload contains a symbolic link");
                String relative = payload.relativize(source).toString().replace(File.separatorChar, '/');
                if (!isRestorableRelative(relative)) throw new SecurityException("Rollback payload contains unapproved path " + relative);
                Path target = dataRoot.resolve(relative).normalize();
                if (!target.startsWith(dataRoot)) throw new SecurityException("Rollback target escaped CoreDSC data directory");
                before.put(target, Files.exists(target) ? Files.readAllBytes(target) : null);
                writeAtomic(target, Files.readString(source, StandardCharsets.UTF_8));
                written.add(target);
                restored.add(relative);
            }

            for (String relative : absent) {
                if (!isRestorableRelative(relative)) continue;
                Path target = dataRoot.resolve(relative).normalize();
                if (!target.startsWith(dataRoot)) throw new SecurityException("Rollback target escaped CoreDSC data directory");
                if (!before.containsKey(target)) before.put(target, Files.exists(target) ? Files.readAllBytes(target) : null);
                if (Files.deleteIfExists(target)) {
                    written.add(target);
                    restored.add(relative + " (removed)");
                }
            }

            Path currentConfigs = dataRoot.resolve("configs");
            if (Files.isDirectory(currentConfigs, LinkOption.NOFOLLOW_LINKS)) {
                try (var configs = Files.list(currentConfigs)) {
                    for (Path current : configs
                            .filter(path -> Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS))
                            .filter(path -> path.getFileName().toString().matches("[a-z0-9][a-z0-9._-]{1,63}\\.ya?ml"))
                            .toList()) {
                        String relative = "configs/" + current.getFileName();
                        if (snapshotConfigs.contains(relative)) continue;
                        if (!before.containsKey(current)) before.put(current, Files.readAllBytes(current));
                        Files.delete(current);
                        written.add(current);
                        restored.add(relative + " (removed)");
                    }
                }
            }
        } catch (Throwable failure) {
            for (int i = written.size() - 1; i >= 0; i--) {
                Path target = written.get(i);
                try {
                    byte[] previous = before.get(target);
                    if (previous == null) Files.deleteIfExists(target);
                    else writeAtomicBytes(target, previous);
                } catch (Throwable restoreFailure) {
                    failure.addSuppressed(restoreFailure);
                }
            }
            if (failure instanceof IOException io) throw io;
            if (failure instanceof RuntimeException runtime) throw runtime;
            throw new IOException("Rollback restoration failed", failure);
        }
        return List.copyOf(restored);
    }

    private boolean isRestorableRelative(String relative) {
        if (relative.equals("state/presets.yml") || relative.equals("state/preset-resources.yml")
                || relative.equals("state/preset-operations.yml")) return true;
        if (relative.matches("configs/[a-z0-9][a-z0-9._-]{1,63}\\.ya?ml")) return true;
        ConfigManager manager = requireManager();
        return manager.editableFilePaths().contains(relative);
    }

    private Snapshot requireSnapshot(String requestedId) throws IOException {
        String id = requestedId == null ? "" : requestedId.trim();
        if (!SAFE_ID.matcher(id).matches()) throw new IllegalArgumentException("Invalid rollback id");
        return readSnapshot(resolveSnapshotDirectory(id))
                .orElseThrow(() -> new IOException("Rollback snapshot not found: " + id));
    }

    private Optional<Snapshot> readSnapshot(Path directory) {
        try {
            Path manifestFile = directory.resolve("manifest.yml");
            if (!Files.isRegularFile(manifestFile, LinkOption.NOFOLLOW_LINKS) || Files.isSymbolicLink(manifestFile)) {
                return Optional.empty();
            }
            YamlConfiguration manifest = YamlConfiguration.loadConfiguration(manifestFile.toFile());
            String id = manifest.getString("id", "");
            if (!id.equals(directory.getFileName().toString()) || !SAFE_ID.matcher(id).matches()) return Optional.empty();
            List<String> files = manifest.getStringList("files");
            return Optional.of(new Snapshot(id, manifest.getLong("created-at", 0L),
                    manifest.getString("reason", "snapshot"), manifest.getString("subject", ""),
                    List.copyOf(files)));
        } catch (RuntimeException ignored) {
            return Optional.empty();
        }
    }

    private Path resolveSnapshotDirectory(String id) throws IOException {
        Path directory = rollbackRoot.resolve(id).normalize();
        if (!directory.startsWith(rollbackRoot) || directory.equals(rollbackRoot)) {
            throw new SecurityException("Rollback path escaped the rollback directory");
        }
        if (Files.isSymbolicLink(directory)) throw new IOException("Rollback snapshot may not be a symbolic link");
        return directory;
    }

    private Path uniqueDirectory(String baseId) throws IOException {
        String id = baseId;
        for (int i = 0; i < 100; i++) {
            if (i > 0) id = baseId + "-" + i;
            Path candidate = rollbackRoot.resolve(id).normalize();
            if (!candidate.startsWith(rollbackRoot)) throw new SecurityException("Unsafe rollback id");
            try {
                return Files.createDirectory(candidate);
            } catch (java.nio.file.FileAlreadyExistsException ignored) {
                // Try the next deterministic suffix.
            }
        }
        throw new IOException("Could not allocate a unique rollback snapshot id");
    }

    private void prune() throws IOException {
        if (!Files.isDirectory(rollbackRoot, LinkOption.NOFOLLOW_LINKS)) return;
        List<Path> directories;
        try (var stream = Files.list(rollbackRoot)) {
            directories = stream.filter(path -> Files.isDirectory(path, LinkOption.NOFOLLOW_LINKS))
                    .sorted(Comparator.comparing(path -> path.getFileName().toString(), Comparator.reverseOrder()))
                    .toList();
        }
        for (int i = MAX_SNAPSHOTS; i < directories.size(); i++) {
            deleteTreeQuietly(directories.get(i));
        }
    }

    private static void copySnapshotFile(Path source, Path target) throws IOException {
        if (Files.isSymbolicLink(source)) throw new IOException("Refusing to snapshot symbolic link " + source.getFileName());
        Files.createDirectories(target.getParent());
        Files.copy(source, target, StandardCopyOption.COPY_ATTRIBUTES, StandardCopyOption.REPLACE_EXISTING,
                LinkOption.NOFOLLOW_LINKS);
    }

    private static void writeAtomic(Path target, String content) throws IOException {
        writeAtomicBytes(target, content.getBytes(StandardCharsets.UTF_8));
    }

    private static void writeAtomicBytes(Path target, byte[] content) throws IOException {
        Files.createDirectories(target.getParent());
        Path temporary = Files.createTempFile(target.getParent(), "." + target.getFileName() + ".", ".tmp");
        try {
            Files.write(temporary, content);
            try (var channel = java.nio.channels.FileChannel.open(temporary, java.nio.file.StandardOpenOption.WRITE)) {
                channel.force(true);
            }
            try {
                Files.move(temporary, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temporary);
        }
    }

    private static void deleteTreeQuietly(Path root) {
        if (root == null || !Files.exists(root, LinkOption.NOFOLLOW_LINKS)) return;
        try (var stream = Files.walk(root)) {
            for (Path path : stream.sorted(Comparator.reverseOrder()).toList()) {
                try { Files.deleteIfExists(path); }
                catch (IOException ignored) { }
            }
        } catch (IOException ignored) { }
    }

    private ConfigManager requireManager() {
        ConfigManager manager = plugin.getConfigManager();
        if (manager == null) throw new IllegalStateException("CoreDSC configuration manager is not ready");
        return manager;
    }

    private static String slug(String value) {
        String normalized = value.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9._-]+", "-")
                .replaceAll("^-+|-+$", "");
        if (normalized.isBlank()) normalized = "snapshot";
        return normalized.substring(0, Math.min(60, normalized.length()));
    }

    private static String bounded(String value, int maximum) {
        String text = value == null ? "" : value.trim();
        return text.length() <= maximum ? text : text.substring(0, maximum);
    }

    private static String actorKey(String actor) {
        String key = actor == null ? "" : actor.trim().toLowerCase(Locale.ROOT);
        if (key.isBlank()) throw new IllegalArgumentException("Rollback actor is required");
        return key;
    }

    private static String confirmationToken() {
        final char[] alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".toCharArray();
        char[] output = new char[6];
        for (int i = 0; i < output.length; i++) {
            output[i] = alphabet[CONFIRMATION_RANDOM.nextInt(alphabet.length)];
        }
        return new String(output);
    }

    @Override
    public void close() {
        if (!closed.compareAndSet(false, true)) return;
        pending.clear();
        executor.shutdown();
        try {
            if (!executor.awaitTermination(5L, TimeUnit.SECONDS)) executor.shutdownNow();
        } catch (InterruptedException interrupted) {
            Thread.currentThread().interrupt();
            executor.shutdownNow();
        }
    }

    public record Snapshot(String id, long createdAt, String reason, String subject, List<String> files) { }
    public record PendingConfirmation(
            Snapshot snapshot,
            String token,
            long expiresAt,
            List<String> externalResourcesToRemove
    ) { }
    public record RestoreResult(
            Snapshot restored,
            Snapshot safetySnapshot,
            List<String> files,
            List<String> externalResourcesRemoved,
            List<String> warnings,
            String message
    ) { }
    private record PendingRestore(String snapshotId, String token, long expiresAt) { }
}
