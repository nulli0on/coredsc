package com.hubertstudios.coredsc.ticket;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/** Immutable, validated ticket-system configuration shared by runtime, setup and cloud views. */
public record TicketSettings(
        ChannelMode channelMode,
        boolean requireLinkedAccount,
        long cooldownMillis,
        int maxOpenPerUser,
        int maxOpenGlobal,
        int messageMaxLength,
        boolean userCanCloseOwn,
        CloseMode closeMode,
        long closedCategoryId,
        long logChannelId,
        int transcriptLimit,
        List<Long> defaultStaffRoleIds,
        Panel panel,
        Map<String, TicketType> types,
        Legacy legacy
) {
    public enum ChannelMode { CHANNEL, THREAD }
    public enum CloseMode { LOCK, DELETE }
    public enum InputStyle { SHORT, PARAGRAPH }
    public enum ButtonStyle { PRIMARY, SECONDARY, SUCCESS, DANGER }

    public record Panel(
            long channelId,
            long messageId,
            boolean publishOnStartup,
            String title,
            String description,
            String footer,
            int color,
            List<String> typeIds
    ) { }

    public record TicketType(
            String id,
            String label,
            String description,
            String emoji,
            ButtonStyle buttonStyle,
            ChannelMode channelMode,
            long categoryId,
            long parentChannelId,
            long closedCategoryId,
            String channelName,
            String openingMessage,
            Boolean requireLinkedAccount,
            List<Long> staffRoleIds,
            List<Field> fields
    ) {
        public boolean requiresLink(boolean globalDefault) {
            return requireLinkedAccount == null ? globalDefault : requireLinkedAccount;
        }
    }

    public record Field(
            String id,
            String label,
            InputStyle style,
            boolean required,
            int minLength,
            int maxLength,
            String placeholder
    ) { }

    /** Old 3.4.x thread configuration retained for no-break upgrades. */
    public record Legacy(
            long parentChannelId,
            boolean privateThread,
            String threadName,
            String openingMessage
    ) { }

    public static TicketSettings from(FileConfiguration config) {
        ChannelMode channelMode = enumValue(config.getString("tickets.channel-mode", "CHANNEL"),
                ChannelMode.class, ChannelMode.CHANNEL, "tickets.channel-mode");
        boolean requireLinked = config.getBoolean("tickets.require-linked-account", false);
        long cooldownMillis = clamp(config.getLong("tickets.cooldown-seconds", 300L), 0L, 86_400L) * 1000L;
        int maxPerUser = (int) clamp(config.getLong("tickets.max-open-per-user", 1L), 1L, 20L);
        int maxGlobal = (int) clamp(config.getLong("tickets.max-open-global", 100L), 0L, 10_000L);
        int messageMax = (int) clamp(config.getLong("tickets.message-max-length", 1000L), 10L, 2_000L);
        boolean closeOwn = config.getBoolean("tickets.user-can-close-own", true);
        CloseMode closeMode = enumValue(config.getString("tickets.close.mode", "LOCK"),
                CloseMode.class, CloseMode.LOCK, "tickets.close.mode");
        long closedCategory = optionalSnowflake(config.get("tickets.close.closed-category-id"),
                "tickets.close.closed-category-id");
        long logChannel = optionalSnowflake(config.get("tickets.logs.channel-id"), "tickets.logs.channel-id");
        int transcriptLimit = (int) clamp(config.getLong("tickets.logs.transcript-message-limit", 500L), 10L, 5_000L);
        List<Long> defaultStaff = snowflakeList(config.getList("tickets.staff-role-ids"), "tickets.staff-role-ids");

        Panel panel = parsePanel(config);
        Map<String, TicketType> types = parseTypes(config, channelMode, defaultStaff, closedCategory);

        long legacyParent = optionalSnowflake(config.get("tickets.parent-channel-id"), "tickets.parent-channel-id");
        Legacy legacy = new Legacy(
                legacyParent,
                config.getBoolean("tickets.private-thread", true),
                text(config, "tickets.thread-name", "ticket-%id%-%minecraft_name%", 100),
                text(config, "tickets.opening-message",
                        "**Ticket #%id%**\nMinecraft: `%minecraft_name%` (`%minecraft_uuid%`)\nDiscord: <@%discord_user_id%>\nReason: **%reason%**\n\n%message%",
                        4_000)
        );

        // Seamless upgrade: an enabled old config with no V2 types remains usable as a synthetic legacy type.
        if (types.isEmpty() && legacyParent > 0L) {
            TicketType legacyType = new TicketType(
                    "legacy", "Support", "Create a support ticket", "🎫", ButtonStyle.PRIMARY,
                    ChannelMode.THREAD, 0L, legacyParent, 0L, legacy.threadName(), legacy.openingMessage(),
                    true, defaultStaff, List.of(
                    new Field("reason", "Reason", InputStyle.SHORT, true, 3, 100, "Short reason"),
                    new Field("message", "Describe the problem", InputStyle.PARAGRAPH, true, 10, messageMax, "Include useful details")
            ));
            types = Map.of("legacy", legacyType);
        }

        if (!panel.typeIds().isEmpty()) {
            for (String id : panel.typeIds()) {
                if (!types.containsKey(id)) {
                    throw new IllegalArgumentException("tickets.panel.type-ids references unknown ticket type '" + id + "'");
                }
            }
        }

        return new TicketSettings(channelMode, requireLinked, cooldownMillis, maxPerUser, maxGlobal,
                messageMax, closeOwn, closeMode, closedCategory, logChannel, transcriptLimit,
                defaultStaff, panel, Collections.unmodifiableMap(new LinkedHashMap<>(types)), legacy);
    }

    private static Panel parsePanel(FileConfiguration config) {
        long channelId = optionalSnowflake(config.get("tickets.panel.channel-id"), "tickets.panel.channel-id");
        long messageId = optionalSnowflake(config.get("tickets.panel.message-id"), "tickets.panel.message-id");
        boolean publishOnStartup = config.getBoolean("tickets.panel.publish-on-startup", false);
        String title = text(config, "tickets.panel.title", "Support", 256);
        String description = text(config, "tickets.panel.description", "Choose the ticket type that best matches your request.", 4_000);
        String footer = text(config, "tickets.panel.footer", "CoreDSC Support", 2_048);
        int color = parseColor(config.getString("tickets.panel.color", "#5865F2"));
        List<String> typeIds = config.getStringList("tickets.panel.type-ids").stream()
                .map(TicketSettings::safeId).filter(value -> !value.isBlank()).distinct().toList();
        if (typeIds.size() > 25) throw new IllegalArgumentException("tickets.panel.type-ids supports at most 25 buttons");
        return new Panel(channelId, messageId, publishOnStartup, title, description, footer, color, typeIds);
    }

    private static Map<String, TicketType> parseTypes(
            FileConfiguration config,
            ChannelMode defaultMode,
            List<Long> defaultStaff,
            long defaultClosedCategory
    ) {
        ConfigurationSection root = config.getConfigurationSection("tickets.types");
        if (root == null) return Map.of();
        Map<String, TicketType> values = new LinkedHashMap<>();
        for (String rawId : root.getKeys(false)) {
            String id = safeId(rawId);
            if (id.isBlank() || !id.equals(rawId)) {
                throw new IllegalArgumentException("tickets.types key '" + rawId + "' must match [a-z0-9_-]{1,32}");
            }
            ConfigurationSection type = root.getConfigurationSection(rawId);
            if (type == null || !type.getBoolean("enabled", true)) continue;
            String base = "tickets.types." + id;
            String label = bounded(type.getString("label", id), 80, base + ".label", true);
            String description = bounded(type.getString("description", ""), 300, base + ".description", false);
            String emoji = bounded(type.getString("emoji", ""), 100, base + ".emoji", false);
            ButtonStyle button = enumValue(type.getString("button-style", "PRIMARY"),
                    ButtonStyle.class, ButtonStyle.PRIMARY, base + ".button-style");
            ChannelMode mode = enumValue(type.getString("channel-mode", defaultMode.name()),
                    ChannelMode.class, defaultMode, base + ".channel-mode");
            long category = optionalSnowflake(type.get("category-id"), base + ".category-id");
            long parent = optionalSnowflake(type.get("parent-channel-id"), base + ".parent-channel-id");
            long closedCategory = optionalSnowflake(type.get("closed-category-id"), base + ".closed-category-id");
            if (closedCategory == 0L) closedCategory = defaultClosedCategory;
            if (mode == ChannelMode.CHANNEL && category <= 0L) {
                throw new IllegalArgumentException(base + ".category-id is required for CHANNEL mode");
            }
            if (mode == ChannelMode.THREAD && parent <= 0L) {
                throw new IllegalArgumentException(base + ".parent-channel-id is required for THREAD mode");
            }
            String channelName = bounded(type.getString("channel-name", "ticket-%id%-%discord_name%"),
                    100, base + ".channel-name", true);
            String opening = bounded(type.getString("opening-message",
                    "**%type_label% #%id%**\nOpened by <@%discord_user_id%>\n\n%form%"),
                    4_000, base + ".opening-message", true);
            Boolean requireLink = type.contains("require-linked-account")
                    ? type.getBoolean("require-linked-account") : null;
            List<Long> staff = snowflakeList(type.getList("staff-role-ids"), base + ".staff-role-ids");
            if (staff.isEmpty()) staff = defaultStaff;
            List<Field> fields = parseFields(type, base);
            values.put(id, new TicketType(id, label, description, emoji, button, mode, category, parent,
                    closedCategory, channelName, opening, requireLink, staff, fields));
        }
        return Collections.unmodifiableMap(new LinkedHashMap<>(values));
    }

    private static List<Field> parseFields(ConfigurationSection type, String base) {
        ConfigurationSection root = type.getConfigurationSection("fields");
        if (root == null) return List.of();
        List<Field> values = new ArrayList<>();
        for (String rawId : root.getKeys(false)) {
            String id = safeId(rawId);
            if (id.isBlank() || !id.equals(rawId)) {
                throw new IllegalArgumentException(base + ".fields key '" + rawId + "' must match [a-z0-9_-]{1,32}");
            }
            ConfigurationSection field = root.getConfigurationSection(rawId);
            if (field == null || !field.getBoolean("enabled", true)) continue;
            String path = base + ".fields." + id;
            String label = bounded(field.getString("label", id), 45, path + ".label", true);
            InputStyle style = enumValue(field.getString("style", "SHORT"),
                    InputStyle.class, InputStyle.SHORT, path + ".style");
            boolean required = field.getBoolean("required", true);
            int min = (int) clamp(field.getLong("min-length", required ? 1 : 0), 0, 4_000);
            int defaultMax = style == InputStyle.SHORT ? 400 : 4_000;
            int max = (int) clamp(field.getLong("max-length", defaultMax), 1, 4_000);
            if (min > max) throw new IllegalArgumentException(path + ".min-length cannot exceed max-length");
            String placeholder = bounded(field.getString("placeholder", ""), 100, path + ".placeholder", false);
            values.add(new Field(id, label, style, required, min, max, placeholder));
        }
        if (values.size() > 5) {
            throw new IllegalArgumentException(base + ".fields has " + values.size() + " fields; Discord modals support at most 5");
        }
        return List.copyOf(values);
    }

    public List<String> panelTypeIds() {
        if (!panel.typeIds().isEmpty()) return panel.typeIds();
        return List.copyOf(types.keySet());
    }

    public TicketType type(String id) {
        return types.get(safeId(id));
    }

    public Set<Long> allStaffRoleIds() {
        Set<Long> values = new LinkedHashSet<>(defaultStaffRoleIds);
        for (TicketType type : types.values()) values.addAll(type.staffRoleIds());
        return Set.copyOf(values);
    }

    private static String text(FileConfiguration config, String path, String fallback, int maximum) {
        return bounded(config.getString(path, fallback), maximum, path, false);
    }

    private static String bounded(String raw, int maximum, String path, boolean required) {
        String value = raw == null ? "" : raw.replace('\0', ' ').trim();
        if (required && value.isBlank()) throw new IllegalArgumentException(path + " is required");
        if (value.length() > maximum) throw new IllegalArgumentException(path + " exceeds " + maximum + " characters");
        return value;
    }

    public static String safeId(String value) {
        if (value == null) return "";
        String normalized = value.trim().toLowerCase(Locale.ROOT);
        return normalized.matches("[a-z0-9_-]{1,32}") ? normalized : "";
    }

    private static long optionalSnowflake(Object raw, String path) {
        if (raw == null || String.valueOf(raw).trim().isBlank()) return 0L;
        try {
            long value = Long.parseLong(String.valueOf(raw).trim());
            if (value <= 0L) throw new NumberFormatException();
            return value;
        } catch (NumberFormatException error) {
            throw new IllegalArgumentException(path + " must be a positive Discord ID or empty", error);
        }
    }

    private static List<Long> snowflakeList(List<?> raw, String path) {
        if (raw == null || raw.isEmpty()) return List.of();
        List<Long> values = new ArrayList<>();
        for (Object item : raw) {
            long value = optionalSnowflake(item, path);
            if (value > 0L && !values.contains(value)) values.add(value);
        }
        return List.copyOf(values);
    }

    private static int parseColor(String raw) {
        String value = raw == null ? "#5865F2" : raw.trim();
        if (value.startsWith("#")) value = value.substring(1);
        if (!value.matches("[0-9a-fA-F]{6}")) {
            throw new IllegalArgumentException("tickets.panel.color must be a six-digit hexadecimal color");
        }
        return Integer.parseInt(value, 16);
    }

    private static <E extends Enum<E>> E enumValue(String raw, Class<E> type, E fallback, String path) {
        String value = raw == null || raw.isBlank() ? fallback.name() : raw.trim().toUpperCase(Locale.ROOT);
        try {
            return Enum.valueOf(type, value);
        } catch (IllegalArgumentException error) {
            throw new IllegalArgumentException(path + " has unsupported value '" + raw + "'", error);
        }
    }

    private static long clamp(long value, long minimum, long maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }
}
