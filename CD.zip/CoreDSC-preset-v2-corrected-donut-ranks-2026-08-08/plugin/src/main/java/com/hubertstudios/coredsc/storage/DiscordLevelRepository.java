package com.hubertstudios.coredsc.storage;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.function.LongToIntFunction;

/** Persistent, serialized Discord activity XP state. */
public final class DiscordLevelRepository {
    public record LevelState(String discordUserId, long xp, int level, long awards, long lastXpAt, long updatedAt) { }
    public record AwardResult(boolean awarded, LevelState before, LevelState after) { }
    public record RankedState(int position, LevelState state) { }

    private final SQLiteStorage storage;

    public DiscordLevelRepository(SQLiteStorage storage) {
        this.storage = Objects.requireNonNull(storage, "storage");
    }

    public CompletableFuture<Optional<LevelState>> find(String discordUserId) {
        return storage.execute(connection -> Optional.ofNullable(select(connection, discordUserId)));
    }

    public CompletableFuture<AwardResult> awardIfEligible(
            String discordUserId,
            long now,
            long minimumWindowMillis,
            int amount,
            LongToIntFunction levelResolver
    ) {
        Objects.requireNonNull(levelResolver, "levelResolver");
        return storage.transaction(connection -> {
            LevelState existing = select(connection, discordUserId);
            if (existing != null && now - existing.lastXpAt() < minimumWindowMillis) {
                return new AwardResult(false, existing, existing);
            }
            LevelState before = existing == null
                    ? new LevelState(discordUserId, 0L, 0, 0L, 0L, 0L) : existing;
            long nextXp;
            try {
                nextXp = Math.addExact(before.xp(), Math.max(0, amount));
            } catch (ArithmeticException overflow) {
                nextXp = Long.MAX_VALUE;
            }
            int nextLevel = Math.max(0, levelResolver.applyAsInt(nextXp));
            long nextAwards = before.awards() == Long.MAX_VALUE ? Long.MAX_VALUE : before.awards() + 1L;
            LevelState after = new LevelState(discordUserId, nextXp, nextLevel, nextAwards, now, now);
            try (PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO discord_levels(discord_user_id,xp,level,awards,last_xp_at,updated_at) VALUES(?,?,?,?,?,?) "
                            + "ON CONFLICT(discord_user_id) DO UPDATE SET xp=excluded.xp, level=excluded.level, "
                            + "awards=excluded.awards, last_xp_at=excluded.last_xp_at, updated_at=excluded.updated_at")) {
                bind(statement, after);
                statement.executeUpdate();
            }
            return new AwardResult(true, before, after);
        });
    }

    public CompletableFuture<List<RankedState>> leaderboard(int limit) {
        int safeLimit = Math.max(1, Math.min(100, limit));
        return storage.execute(connection -> {
            List<RankedState> values = new ArrayList<>();
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT discord_user_id,xp,level,awards,last_xp_at,updated_at FROM discord_levels "
                            + "ORDER BY xp DESC, updated_at ASC LIMIT ?")) {
                statement.setInt(1, safeLimit);
                try (ResultSet result = statement.executeQuery()) {
                    int row = 0;
                    int rank = 0;
                    long previousXp = Long.MIN_VALUE;
                    while (result.next()) {
                        row++;
                        LevelState state = read(result);
                        if (row == 1 || state.xp() != previousXp) {
                            rank = row;
                            previousXp = state.xp();
                        }
                        values.add(new RankedState(rank, state));
                    }
                }
            }
            return List.copyOf(values);
        });
    }

    public CompletableFuture<Optional<RankedState>> ranked(String discordUserId) {
        return storage.execute(connection -> {
            LevelState state = select(connection, discordUserId);
            if (state == null) return Optional.empty();
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT COUNT(*) FROM discord_levels WHERE xp > ?")) {
                statement.setLong(1, state.xp());
                try (ResultSet result = statement.executeQuery()) {
                    int above = result.next() ? result.getInt(1) : 0;
                    return Optional.of(new RankedState(above + 1, state));
                }
            }
        });
    }

    private static LevelState select(java.sql.Connection connection, String discordUserId) throws Exception {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT discord_user_id,xp,level,awards,last_xp_at,updated_at FROM discord_levels WHERE discord_user_id=?")) {
            statement.setString(1, discordUserId);
            try (ResultSet result = statement.executeQuery()) {
                return result.next() ? read(result) : null;
            }
        }
    }

    private static void bind(PreparedStatement statement, LevelState value) throws Exception {
        statement.setString(1, value.discordUserId());
        statement.setLong(2, value.xp());
        statement.setInt(3, value.level());
        statement.setLong(4, value.awards());
        statement.setLong(5, value.lastXpAt());
        statement.setLong(6, value.updatedAt());
    }

    private static LevelState read(ResultSet result) throws Exception {
        return new LevelState(result.getString("discord_user_id"), result.getLong("xp"), result.getInt("level"),
                result.getLong("awards"), result.getLong("last_xp_at"), result.getLong("updated_at"));
    }
}
