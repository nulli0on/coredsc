package com.hubertstudios.coredsc.storage;

import com.hubertstudios.coredsc.storage.LinkedAccountRepository.LinkedAccount;

import java.security.SecureRandom;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;

/** Issues and atomically consumes temporary account-linking codes in either direction. */
public final class PendingLinkCodeRepository {

    private static final String CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
    private static final SecureRandom RANDOM = new SecureRandom();

    public enum Direction {
        MINECRAFT_TO_DISCORD,
        DISCORD_TO_MINECRAFT
    }

    public enum IssueStatus {
        ISSUED,
        ALREADY_LINKED
    }

    public record IssueResult(IssueStatus status, String code, long expiresAt) { }

    public enum LinkStatus {
        LINKED,
        INVALID_OR_EXPIRED,
        WRONG_DIRECTION,
        MINECRAFT_ALREADY_LINKED,
        DISCORD_ALREADY_LINKED
    }

    public record LinkResult(LinkStatus status, LinkedAccount account) { }

    private final SQLiteStorage storage;

    public PendingLinkCodeRepository(SQLiteStorage storage) {
        this.storage = Objects.requireNonNull(storage, "storage");
    }

    /** Backward-compatible Minecraft -> Discord code issuance. */
    public CompletableFuture<IssueResult> issueCode(
            String minecraftUuid,
            String minecraftName,
            long expiresAt,
            int requestedLength
    ) {
        return issueMinecraftCode(minecraftUuid, minecraftName, expiresAt, requestedLength);
    }

    public CompletableFuture<IssueResult> issueMinecraftCode(
            String minecraftUuid,
            String minecraftName,
            long expiresAt,
            int requestedLength
    ) {
        int length = boundedLength(requestedLength);
        String uuid = requireIdentifier(minecraftUuid, "minecraftUuid");
        return storage.transaction(connection -> {
            if (LinkedAccountRepository.selectByMinecraft(connection, uuid) != null) {
                return new IssueResult(IssueStatus.ALREADY_LINKED, null, 0L);
            }

            try (PreparedStatement delete = connection.prepareStatement(
                    "DELETE FROM pending_link_codes WHERE minecraft_uuid = ?")) {
                delete.setString(1, uuid);
                delete.executeUpdate();
            }

            return insertCode(connection, Direction.MINECRAFT_TO_DISCORD,
                    uuid, minecraftName == null ? "" : minecraftName, "", expiresAt, length);
        });
    }

    public CompletableFuture<IssueResult> issueDiscordCode(
            String discordUserId,
            long expiresAt,
            int requestedLength
    ) {
        int length = boundedLength(requestedLength);
        String discordId = requireIdentifier(discordUserId, "discordUserId");
        return storage.transaction(connection -> {
            if (LinkedAccountRepository.selectByDiscord(connection, discordId) != null) {
                return new IssueResult(IssueStatus.ALREADY_LINKED, null, 0L);
            }

            try (PreparedStatement delete = connection.prepareStatement(
                    "DELETE FROM pending_link_codes WHERE discord_user_id = ?")) {
                delete.setString(1, discordId);
                delete.executeUpdate();
            }

            return insertCode(connection, Direction.DISCORD_TO_MINECRAFT,
                    "", "", discordId, expiresAt, length);
        });
    }

    /** Backward-compatible Minecraft-issued code consumption from Discord. */
    public CompletableFuture<LinkResult> consumeAndLink(
            String rawCode,
            String discordUserId,
            long now
    ) {
        return consumeMinecraftCodeFromDiscord(rawCode, discordUserId, now);
    }

    public CompletableFuture<LinkResult> consumeMinecraftCodeFromDiscord(
            String rawCode,
            String discordUserId,
            long now
    ) {
        String code = normalizeCode(rawCode);
        String discordId = discordUserId == null ? "" : discordUserId.trim();
        if (!isValidCode(code) || discordId.isBlank()) {
            return CompletableFuture.completedFuture(new LinkResult(LinkStatus.INVALID_OR_EXPIRED, null));
        }
        return storage.transaction(connection -> {
            PendingCode pending = selectPending(connection, code);
            LinkResult invalid = validatePending(connection, pending, code, now, Direction.MINECRAFT_TO_DISCORD);
            if (invalid != null) return invalid;

            if (LinkedAccountRepository.selectByMinecraft(connection, pending.minecraftUuid()) != null) {
                deleteCode(connection, code);
                return new LinkResult(LinkStatus.MINECRAFT_ALREADY_LINKED, null);
            }
            if (LinkedAccountRepository.selectByDiscord(connection, discordId) != null) {
                return new LinkResult(LinkStatus.DISCORD_ALREADY_LINKED, null);
            }

            LinkedAccount account = insertLinkedAccount(connection, pending.minecraftUuid(),
                    pending.minecraftName(), discordId, now);
            deleteCode(connection, code);
            return new LinkResult(LinkStatus.LINKED, account);
        });
    }

    public CompletableFuture<LinkResult> consumeDiscordCodeFromMinecraft(
            String rawCode,
            String minecraftUuid,
            String minecraftName,
            long now
    ) {
        String code = normalizeCode(rawCode);
        String uuid = minecraftUuid == null ? "" : minecraftUuid.trim();
        if (!isValidCode(code) || uuid.isBlank()) {
            return CompletableFuture.completedFuture(new LinkResult(LinkStatus.INVALID_OR_EXPIRED, null));
        }
        return storage.transaction(connection -> {
            PendingCode pending = selectPending(connection, code);
            LinkResult invalid = validatePending(connection, pending, code, now, Direction.DISCORD_TO_MINECRAFT);
            if (invalid != null) return invalid;

            if (LinkedAccountRepository.selectByMinecraft(connection, uuid) != null) {
                return new LinkResult(LinkStatus.MINECRAFT_ALREADY_LINKED, null);
            }
            if (LinkedAccountRepository.selectByDiscord(connection, pending.discordUserId()) != null) {
                deleteCode(connection, code);
                return new LinkResult(LinkStatus.DISCORD_ALREADY_LINKED, null);
            }

            LinkedAccount account = insertLinkedAccount(connection, uuid,
                    minecraftName == null ? "" : minecraftName, pending.discordUserId(), now);
            deleteCode(connection, code);
            return new LinkResult(LinkStatus.LINKED, account);
        });
    }

    public CompletableFuture<Integer> deleteExpired(long now) {
        return storage.execute(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "DELETE FROM pending_link_codes WHERE expires_at <= ?")) {
                statement.setLong(1, now);
                return statement.executeUpdate();
            }
        });
    }

    private static IssueResult insertCode(
            java.sql.Connection connection,
            Direction direction,
            String minecraftUuid,
            String minecraftName,
            String discordUserId,
            long expiresAt,
            int length
    ) throws Exception {
        SQLException lastCollision = null;
        for (int attempt = 0; attempt < 8; attempt++) {
            String code = randomCode(length);
            try (PreparedStatement insert = connection.prepareStatement(
                    "INSERT INTO pending_link_codes "
                            + "(code, minecraft_uuid, minecraft_name, discord_user_id, direction, expires_at) "
                            + "VALUES (?, ?, ?, ?, ?, ?)")) {
                insert.setString(1, code);
                insert.setString(2, minecraftUuid);
                insert.setString(3, minecraftName);
                insert.setString(4, discordUserId);
                insert.setString(5, direction.name());
                insert.setLong(6, expiresAt);
                insert.executeUpdate();
                return new IssueResult(IssueStatus.ISSUED, code, expiresAt);
            } catch (SQLException collision) {
                if (collision.getErrorCode() != 19) throw collision;
                lastCollision = collision;
            }
        }
        throw lastCollision == null
                ? new SQLException("Could not generate a unique link code")
                : lastCollision;
    }

    private static LinkedAccount insertLinkedAccount(
            java.sql.Connection connection,
            String minecraftUuid,
            String minecraftName,
            String discordUserId,
            long now
    ) throws Exception {
        LinkedAccount account = new LinkedAccount(minecraftUuid, discordUserId, minecraftName, now);
        try (PreparedStatement insert = connection.prepareStatement(
                "INSERT INTO linked_accounts "
                        + "(minecraft_uuid, discord_user_id, minecraft_name, linked_at) VALUES (?, ?, ?, ?)")) {
            insert.setString(1, account.minecraftUuid());
            insert.setString(2, account.discordUserId());
            insert.setString(3, account.minecraftName());
            insert.setLong(4, account.linkedAt());
            insert.executeUpdate();
        }
        return account;
    }

    private static LinkResult validatePending(
            java.sql.Connection connection,
            PendingCode pending,
            String code,
            long now,
            Direction requiredDirection
    ) throws Exception {
        if (pending == null || pending.expiresAt() <= now) {
            deleteCode(connection, code);
            return new LinkResult(LinkStatus.INVALID_OR_EXPIRED, null);
        }
        if (pending.direction() != requiredDirection) {
            return new LinkResult(LinkStatus.WRONG_DIRECTION, null);
        }
        return null;
    }

    private static PendingCode selectPending(java.sql.Connection connection, String code) throws Exception {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT code, minecraft_uuid, minecraft_name, discord_user_id, direction, expires_at "
                        + "FROM pending_link_codes WHERE code = ?")) {
            statement.setString(1, code);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (!resultSet.next()) return null;
                Direction direction;
                try {
                    direction = Direction.valueOf(resultSet.getString("direction").toUpperCase(Locale.ROOT));
                } catch (RuntimeException error) {
                    direction = Direction.MINECRAFT_TO_DISCORD;
                }
                return new PendingCode(
                        resultSet.getString("code"),
                        resultSet.getString("minecraft_uuid"),
                        resultSet.getString("minecraft_name"),
                        resultSet.getString("discord_user_id"),
                        direction,
                        resultSet.getLong("expires_at")
                );
            }
        }
    }

    private static void deleteCode(java.sql.Connection connection, String code) throws Exception {
        try (PreparedStatement statement = connection.prepareStatement(
                "DELETE FROM pending_link_codes WHERE code = ?")) {
            statement.setString(1, code);
            statement.executeUpdate();
        }
    }

    private static int boundedLength(int requestedLength) {
        return Math.max(6, Math.min(16, requestedLength));
    }

    private static String requireIdentifier(String value, String name) {
        String normalized = value == null ? "" : value.trim();
        if (normalized.isBlank()) throw new IllegalArgumentException(name + " is required");
        return normalized;
    }

    private static String randomCode(int length) {
        StringBuilder builder = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            builder.append(CODE_ALPHABET.charAt(RANDOM.nextInt(CODE_ALPHABET.length())));
        }
        return builder.toString();
    }

    public static String normalizeCode(String code) {
        return code == null ? "" : code.trim().replace("-", "").toUpperCase(Locale.ROOT);
    }

    public static boolean isValidCode(String code) {
        String normalized = normalizeCode(code);
        if (normalized.length() < 6 || normalized.length() > 16) return false;
        for (int index = 0; index < normalized.length(); index++) {
            if (CODE_ALPHABET.indexOf(normalized.charAt(index)) < 0) return false;
        }
        return true;
    }

    private record PendingCode(
            String code,
            String minecraftUuid,
            String minecraftName,
            String discordUserId,
            Direction direction,
            long expiresAt
    ) { }
}
