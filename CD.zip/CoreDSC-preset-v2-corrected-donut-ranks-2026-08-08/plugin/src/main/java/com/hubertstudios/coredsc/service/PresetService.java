package com.hubertstudios.coredsc.service;

import com.hubertstudios.coredsc.CoreDSCPlugin;
import com.hubertstudios.coredsc.config.ConfigManager;
import com.hubertstudios.coredsc.scripting.MiniJson;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.channels.FileChannel;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Installs approved, declarative CoreDSC configuration presets.
 *
 * <p>Preset packages are deliberately data-only. They may change only files already
 * allowlisted by {@link ConfigManager}; no downloaded Java, Python, shell, console
 * command or arbitrary filesystem operation is executed.</p>
 */
public final class PresetService implements AutoCloseable {
    public static final String DEFAULT_REGISTRY = "https://api.coredsc.workers.dev/v1/presets";
    private static final int MAXIMUM_HTTP_BYTES = 512 * 1024;
    private static final int MAXIMUM_CHANGES = 100;
    private static final Pattern PRESET_ID = Pattern.compile("[a-z0-9][a-z0-9._-]{1,63}");
    private static final Pattern VARIABLE = Pattern.compile("\\$\\{([a-zA-Z0-9][a-zA-Z0-9_.-]{0,79})}");

    private final CoreDSCPlugin plugin;
    private final File configsDirectory;
    private final File stateFile;
    private final File journalFile;
    private final URI registry;
    private final HttpClient http;
    private final RollbackService rollbackService;
    private final PresetBootstrapService bootstrapService;
    private final ExecutorService executor;
    private final AtomicBoolean closed = new AtomicBoolean();

    public PresetService(CoreDSCPlugin plugin, RollbackService rollbackService) {
        this.plugin = Objects.requireNonNull(plugin, "plugin");
        this.rollbackService = Objects.requireNonNull(rollbackService, "rollbackService");
        this.bootstrapService = new PresetBootstrapService(plugin);
        this.configsDirectory = new File(plugin.getDataFolder(), "configs");
        this.stateFile = new File(plugin.getDataFolder(), "state/presets.yml");
        this.journalFile = new File(plugin.getDataFolder(), "state/preset-operations.yml");
        String configured = System.getenv("COREDSC_PRESET_REGISTRY");
        this.registry = requireRegistryUri(configured == null || configured.isBlank()
                ? DEFAULT_REGISTRY : configured.trim());
        ThreadFactory factory = task -> {
            Thread thread = new Thread(task, "CoreDSC-Presets");
            thread.setDaemon(true);
            return thread;
        };
        this.executor = Executors.newSingleThreadExecutor(factory);
        // Do not reuse the single preset-transaction executor for HttpClient internals.
        // A blocking send from that same executor could otherwise starve its own
        // HTTP completion work and make preset installs appear intermittently hung.
        this.http = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(8))
                .followRedirects(HttpClient.Redirect.NEVER)
                .build();
    }

    public void start() {
        try {
            Files.createDirectories(configsDirectory.toPath());
            Files.createDirectories(stateFile.toPath().getParent());
            writeReadmeIfMissing();
        } catch (IOException error) {
            plugin.getLogger().warning("[Presets] Could not initialise preset directories: " + rootMessage(error));
            return;
        }
        // A marketplace descriptor can be dropped into plugins/CoreDSC/configs/.
        // Startup reconciliation is best-effort and never prevents CoreDSC from loading.
        CompletableFuture.runAsync(() -> {
            for (File descriptor : descriptorFiles()) {
                try {
                    YamlConfiguration yaml = loadDescriptor(descriptor);
                    int format = descriptorFormat(yaml);
                    boolean enabled = format == 2
                            ? yaml.getBoolean("preset.enabled", false)
                            : yaml.getBoolean("auto-apply", true);
                    boolean autoApply = format == 2
                            ? yaml.getBoolean("preset.auto-apply", false)
                            : yaml.getBoolean("auto-apply", true);
                    if (enabled && autoApply) {
                        String id = presetId(yaml, descriptor);
                        if (format == 2) applyBlocking(id, descriptor, true);
                        else installBlocking(id, descriptorVariables(yaml), false, descriptor, false, true);
                    }
                } catch (Throwable error) {
                    plugin.getLogger().warning("[Presets] " + descriptor.getName() + " was not applied: "
                            + rootMessage(error));
                }
            }
        }, executor);
    }

    public URI registry() {
        return registry;
    }

    public CompletableFuture<Map<String, Object>> browse() {
        return supply(() -> {
            Map<String, Object> response = fetchJson(registry);
            List<Map<String, Object>> presets = objectList(response.get("presets"), "presets", 250);
            return Map.of("registry", registry.toString(), "presets", presets);
        });
    }

    public CompletableFuture<Map<String, Object>> listInstalled() {
        return supply(() -> {
            YamlConfiguration state = loadState();
            ConfigurationSection installed = state.getConfigurationSection("installed");
            List<Map<String, Object>> values = new ArrayList<>();
            if (installed != null) {
                for (String id : installed.getKeys(false)) {
                    ConfigurationSection item = installed.getConfigurationSection(id);
                    if (item == null) continue;
                    values.add(Map.of(
                            "id", id,
                            "version", item.getString("version", "unknown"),
                            "installedAt", item.getLong("installed-at", 0L),
                            "updatedAt", item.getLong("updated-at", 0L),
                            "backup", item.getString("backup", ""),
                            "source", item.getString("source", "official")));
                }
            }
            return Map.of("installed", List.copyOf(values));
        });
    }

    public CompletableFuture<Map<String, Object>> install(String id, Map<String, Object> variables) {
        return supply(() -> installBlocking(id, variables, false, descriptorFor(id), true, true));
    }

    public CompletableFuture<Map<String, Object>> update(String id) {
        return supply(() -> {
            String normalized = requirePresetId(normalizeRequestedId(id));
            File descriptor = descriptorFor(normalized);
            if (descriptor.isFile()) {
                YamlConfiguration yaml = loadDescriptor(descriptor);
                if (descriptorFormat(yaml) == 2) return applyBlocking(normalized, descriptor, false);
                return installBlocking(normalized, descriptorVariables(yaml), true, descriptor, true, true);
            }
            return installBlocking(normalized, Map.of(), true, descriptor, true, true);
        });
    }

    public CompletableFuture<Map<String, Object>> reloadConfigured() {
        return supply(() -> {
            List<Map<String, Object>> results = new ArrayList<>();
            for (File descriptor : descriptorFiles()) {
                try {
                    YamlConfiguration yaml = loadDescriptor(descriptor);
                    String id = presetId(yaml, descriptor);
                    if (descriptorFormat(yaml) == 2) {
                        boolean enabled = yaml.getBoolean("preset.enabled", false);
                        boolean autoApply = yaml.getBoolean("preset.auto-apply", false);
                        if (enabled && autoApply) results.add(applyBlocking(id, descriptor, true));
                        else results.add(Map.of("file", descriptor.getName(), "id", id, "ok", true,
                                "enabled", enabled, "applied", false,
                                "message", enabled ? "Preset loaded; run preview/apply when ready" : "Preset loaded but disabled"));
                    } else {
                        results.add(installBlocking(id, descriptorVariables(yaml), true, descriptor, false, true));
                    }
                } catch (Throwable error) {
                    results.add(Map.of("file", descriptor.getName(), "ok", false,
                            "error", rootMessage(error)));
                }
            }
            return Map.of("results", List.copyOf(results));
        });
    }

    public CompletableFuture<Map<String, Object>> enable(String requestedId) {
        return supply(() -> {
            String id = requirePresetId(normalizeRequestedId(requestedId));
            File descriptor = descriptorFor(id);
            if (!descriptor.isFile()) throw new IOException("Preset descriptor not found: " + descriptor.getName());
            YamlConfiguration yaml = loadDescriptor(descriptor);
            if (descriptorFormat(yaml) != 2) {
                throw new IllegalStateException("/preset enable requires a format-2 descriptor");
            }
            if (!id.equals(presetId(yaml, descriptor))) {
                throw new IllegalArgumentException("Descriptor preset.id does not match the requested preset");
            }
            rollbackService.createSnapshot("before-preset-enable", id);
            yaml.set("preset.enabled", true);
            saveYamlAtomic(yaml, descriptor);
            return Map.of("ok", true, "id", id, "enabled", true, "status", "SETUP_REQUIRED",
                    "message", "Preset enabled. Edit plugins/CoreDSC/configs/" + descriptor.getName()
                            + ", then run /coredsc preset preview " + id);
        });
    }

    public CompletableFuture<Map<String, Object>> disable(String requestedId) {
        return supply(() -> {
            String id = requirePresetId(normalizeRequestedId(requestedId));
            File descriptor = descriptorFor(id);
            if (!descriptor.isFile()) throw new IOException("Preset descriptor not found: " + descriptor.getName());
            YamlConfiguration yaml = loadDescriptor(descriptor);
            if (descriptorFormat(yaml) != 2) throw new IllegalStateException("/preset disable requires a format-2 descriptor");
            rollbackService.createSnapshot("before-preset-disable", id);
            yaml.set("preset.enabled", false);
            saveYamlAtomic(yaml, descriptor);
            return Map.of("ok", true, "id", id, "enabled", false,
                    "message", "Preset disabled. Existing configuration/resources were not removed.");
        });
    }

    public CompletableFuture<Map<String, Object>> preview(String requestedId) {
        return supply(() -> previewBlocking(requirePresetId(normalizeRequestedId(requestedId)), descriptorFor(requestedId)));
    }

    public CompletableFuture<Map<String, Object>> apply(String requestedId) {
        return supply(() -> applyBlocking(requirePresetId(normalizeRequestedId(requestedId)), descriptorFor(requestedId), false));
    }

    public CompletableFuture<Map<String, Object>> repair(String requestedId) {
        return supply(() -> {
            String id = requirePresetId(normalizeRequestedId(requestedId));
            Map<String, Object> result = new LinkedHashMap<>(applyBlocking(id, descriptorFor(requestedId), false));
            result.put("message", "Preset repaired/reconciled successfully");
            return Map.copyOf(result);
        });
    }

    public CompletableFuture<Map<String, Object>> status(String requestedId) {
        return supply(() -> {
            String id = requirePresetId(normalizeRequestedId(requestedId));
            File descriptor = descriptorFor(id);
            YamlConfiguration state = loadState();
            Map<String, Object> result = new LinkedHashMap<>();
            result.put("id", id);
            result.put("descriptor", descriptor.getName());
            result.put("installed", state.contains("installed." + id));
            result.put("installedVersion", state.getString("installed." + id + ".version", ""));
            if (descriptor.isFile()) {
                YamlConfiguration yaml = loadDescriptor(descriptor);
                result.put("format", descriptorFormat(yaml));
                result.put("enabled", descriptorFormat(yaml) == 2
                        ? yaml.getBoolean("preset.enabled", false) : yaml.getBoolean("auto-apply", true));
            } else {
                result.put("format", 0);
                result.put("enabled", false);
            }
            return Map.copyOf(result);
        });
    }

    private Map<String, Object> previewBlocking(String id, File descriptor) throws Exception {
        if (!descriptor.isFile()) throw new IOException("Preset descriptor not found: " + descriptor.getName());
        YamlConfiguration yaml = loadDescriptor(descriptor);
        if (descriptorFormat(yaml) != 2) throw new IllegalStateException("Preset preview requires a format-2 descriptor");
        if (!yaml.getBoolean("preset.enabled", false)) throw new IllegalStateException("Preset is disabled; enable it first");
        PresetBootstrapService.BootstrapResult bootstrap = bootstrapService.preview(descriptor);
        Map<String, Object> metadata = fetchJson(resolveRegistry(id));
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("ok", true);
        result.put("id", id);
        result.put("version", metadata.getOrDefault("version", "unknown"));
        result.put("plannedCreates", bootstrap.plannedCreates());
        result.put("plannedReuses", bootstrap.plannedReuses());
        result.put("conflicts", bootstrap.conflicts());
        result.put("createCount", bootstrap.plannedCreates().size());
        result.put("reuseCount", bootstrap.plannedReuses().size());
        result.put("conflictCount", bootstrap.conflicts().size());
        result.put("ready", bootstrap.conflicts().isEmpty());
        result.put("message", bootstrap.message());
        return Map.copyOf(result);
    }

    private Map<String, Object> applyBlocking(String id, File descriptor, boolean startupAutoApply) throws Exception {
        if (!descriptor.isFile()) throw new IOException("Preset descriptor not found: " + descriptor.getName());
        YamlConfiguration yaml = loadDescriptor(descriptor);
        if (descriptorFormat(yaml) != 2) throw new IllegalStateException("Preset apply requires a format-2 descriptor");
        if (!yaml.getBoolean("preset.enabled", false)) throw new IllegalStateException("Preset is disabled; enable it first");
        if (!startupAutoApply && yaml.getBoolean("safety.require-preview", true)) {
            // Preview is deterministic and side-effect free. Running it here again prevents a
            // stale descriptor from bypassing validation between an earlier preview and apply.
            Map<String, Object> preview = previewBlocking(id, descriptor);
            if (!Boolean.TRUE.equals(preview.get("ready"))) {
                int conflicts = preview.get("conflictCount") instanceof Number number ? number.intValue() : 1;
                throw new IllegalStateException("Preset setup has " + conflicts
                        + " unresolved Discord resource conflict(s). Run /coredsc preset preview " + id
                        + " and configure the reported existing IDs before applying.");
            }
        }
        RollbackService.Snapshot rollback = rollbackService.createSnapshot("before-preset-apply", id);
        String operationId = beginOperation(id, startupAutoApply ? "AUTO_APPLY" : "APPLY", rollback.id());
        PresetBootstrapService.BootstrapResult bootstrap = null;
        try {
            bootstrap = bootstrapService.apply(descriptor);
            Map<String, Object> result = installBlocking(id, bootstrap.variables(), true, descriptor, false, false);
            Map<String, Object> combined = new LinkedHashMap<>(result);
            combined.put("rollback", rollback.id());
            combined.put("createdResources", bootstrap.created());
            combined.put("reusedResources", bootstrap.reused());
            combined.put("bootstrapMessage", bootstrap.message());
            combined.put("operationId", operationId);
            try {
                finishOperation(operationId, "SUCCESS", bootstrap.created(), bootstrap.reused(), "Preset applied successfully");
            } catch (Throwable journalFailure) {
                plugin.getLogger().warning("[Presets] Preset applied successfully, but the operation journal could not be finalized: "
                        + rootMessage(journalFailure));
                combined.put("journalWarning", rootMessage(journalFailure));
            }
            return Map.copyOf(combined);
        } catch (Throwable failure) {
            if (bootstrap != null && !bootstrap.created().isEmpty()) {
                try { bootstrapService.rollbackCreated(id, bootstrap.created()); }
                catch (Throwable cleanupFailure) { failure.addSuppressed(cleanupFailure); }
            }
            try {
                finishOperation(operationId, "FAILED",
                        bootstrap == null ? List.of() : bootstrap.created(),
                        bootstrap == null ? List.of() : bootstrap.reused(), rootMessage(failure));
            } catch (Throwable journalFailure) {
                failure.addSuppressed(journalFailure);
            }
            throw failure;
        }
    }

    PresetBootstrapService.RollbackPlan planExternalRollback(Path targetResourceState) throws IOException {
        return bootstrapService.planExternalRollback(targetResourceState);
    }

    PresetBootstrapService.RollbackCleanupResult executeExternalRollback(PresetBootstrapService.RollbackPlan plan) {
        return bootstrapService.executeExternalRollback(plan);
    }

    public CompletableFuture<Map<String, Object>> remove(String requestedId) {
        return supply(() -> {
            String id = requirePresetId(requestedId);
            YamlConfiguration state = loadState();
            String root = "installed." + id;
            if (!state.contains(root)) {
                return Map.of("removed", false, "id", id, "message", "Preset is not installed");
            }
            List<Map<String, Object>> originals = configurationMaps(state.getList(root + ".originals"));
            if (originals.isEmpty()) {
                throw new IllegalStateException("Preset state has no rollback values; refusing destructive removal");
            }
            rollbackService.createSnapshot("before-preset-remove", id);
            ConfigManager manager = requireManager();
            List<ConfigManager.EditorPatch> patches = patchesWithCurrentRevisions(manager, originals);
            ConfigManager.EditorBatchSaveResult saved = manager.saveEditorPatch(patches, MAXIMUM_HTTP_BYTES);
            requireReloadOrRestore(manager, saved, "Preset removal");
            state.set(root, null);
            saveState(state);
            File descriptor = descriptorFor(id);
            if (descriptor.isFile() && !descriptor.delete()) {
                plugin.getLogger().warning("[Presets] Could not delete descriptor " + descriptor.getName());
            }
            return Map.of("removed", true, "id", id, "changedFiles", saved.changedFiles(),
                    "message", "Preset removed and pre-install configuration restored");
        });
    }

    private Map<String, Object> installBlocking(
            String requestedId,
            Map<String, Object> suppliedVariables,
            boolean update,
            File descriptor,
            boolean persistDescriptor,
            boolean createRollback
    ) throws Exception {
        if (closed.get()) throw new IllegalStateException("Preset service is stopped");
        String id = requirePresetId(requestedId);
        Map<String, Object> metadata = fetchJson(resolveRegistry(id));
        if (Boolean.FALSE.equals(metadata.get("available"))) {
            throw new IllegalStateException(text(metadata.get("message"), "This preset is not available yet"));
        }
        if ("descriptor".equalsIgnoreCase(text(metadata.get("setupMode"), ""))) {
            boolean validDescriptor = descriptor != null && descriptor.isFile()
                    && descriptorFormat(loadDescriptor(descriptor)) == 2;
            if (!validDescriptor) {
                String fileName = text(metadata.get("descriptorFile"), id + ".yml");
                throw new IllegalStateException("Preset " + id + " uses descriptor setup. Put " + fileName
                        + " in plugins/CoreDSC/configs/, run /coredsc preset reload, then /coredsc preset enable "
                        + id + ", /coredsc preset preview " + id + " and /coredsc preset apply " + id + ".");
            }
        }
        String packageUrl = text(metadata.get("packageUrl"), "");
        URI packageUri = packageUrl.isBlank()
                ? resolveRegistry(id + "/package")
                : requireRegistryChild(registry.resolve(packageUrl).toString());
        Map<String, Object> envelope = fetchJson(packageUri);
        String payload = text(envelope.get("payload"), "");
        String expectedHash = text(envelope.get("sha256"), "").toLowerCase(Locale.ROOT);
        if (payload.isBlank() || !expectedHash.matches("[0-9a-f]{64}")) {
            throw new IOException("Preset registry returned an invalid package envelope");
        }
        String actualHash = sha256(payload.getBytes(StandardCharsets.UTF_8));
        if (!MessageDigest.isEqual(expectedHash.getBytes(StandardCharsets.US_ASCII),
                actualHash.getBytes(StandardCharsets.US_ASCII))) {
            throw new SecurityException("Preset package integrity check failed");
        }

        Map<String, Object> packageData = MiniJson.parseObject(payload);
        if (!id.equals(requirePresetId(text(packageData.get("id"), "")))) {
            throw new SecurityException("Preset package identity does not match the requested preset");
        }
        String version = text(packageData.get("version"), "");
        if (version.isBlank() || version.length() > 40) throw new IOException("Preset version is invalid");
        String minimum = text(packageData.get("minimumCoreDSC"), "0");
        if (compareVersions(plugin.getDescription().getVersion(), minimum) < 0) {
            throw new IllegalStateException("Preset " + id + " requires CoreDSC " + minimum + " or newer");
        }

        List<Map<String, Object>> requiredVariables = objectList(
                packageData.get("requiredVariables"), "requiredVariables", 128);
        Map<String, Object> variables = new LinkedHashMap<>(suppliedVariables == null ? Map.of() : suppliedVariables);
        List<String> missing = new ArrayList<>();
        for (Map<String, Object> requirement : requiredVariables) {
            String key = variableKey(requirement.get("key"));
            boolean required = !Boolean.FALSE.equals(requirement.get("required"));
            Object value = variables.get(key);
            if (required && (value == null || String.valueOf(value).isBlank())) missing.add(key);
        }
        if (!missing.isEmpty()) {
            if (persistDescriptor) writeDescriptorScaffold(descriptor, id, variables, requiredVariables);
            throw new IllegalStateException("Preset needs configuration before it can be applied: "
                    + String.join(", ", missing) + ". Fill plugins/CoreDSC/configs/" + id + ".yml or use the dashboard Configs page.");
        }

        List<Map<String, Object>> rawChanges = objectList(packageData.get("changes"), "changes", MAXIMUM_CHANGES);
        if (rawChanges.isEmpty()) throw new IllegalStateException("Preset contains no configuration changes");
        ConfigManager manager = requireManager();
        List<Map<String, Object>> resolvedChanges = resolveChanges(rawChanges, variables);

        YamlConfiguration state = loadState();
        String stateRoot = "installed." + id;
        boolean installedBefore = state.contains(stateRoot);
        if (!update && installedBefore) {
            String current = state.getString(stateRoot + ".version", "unknown");
            if (current.equals(version)) {
                return Map.of("ok", true, "id", id, "version", version, "changed", false,
                        "message", "Preset is already installed at this version");
            }
        }

        List<Map<String, Object>> originals = installedBefore
                ? configurationMaps(state.getMapList(stateRoot + ".originals"))
                : captureOriginals(resolvedChanges);
        List<Map<String, Object>> conflicts = new ArrayList<>();
        List<Map<String, Object>> applicableChanges = resolvedChanges;
        if (installedBefore && update) {
            List<Map<String, Object>> previouslyManaged = configurationMaps(state.getMapList(stateRoot + ".managed"));
            applicableChanges = preserveLocalOverrides(resolvedChanges, previouslyManaged, conflicts);
        }
        if (createRollback) {
            rollbackService.createSnapshot(update ? "before-preset-update" : "before-preset-install",
                    id + " " + (installedBefore ? state.getString(stateRoot + ".version", "unknown") : "new") + " -> " + version);
        }

        ConfigManager.EditorBatchSaveResult saved;
        if (applicableChanges.isEmpty()) {
            saved = new ConfigManager.EditorBatchSaveResult(Map.of(), "", List.of(), List.of());
        } else {
            List<ConfigManager.EditorPatch> patches = patchesWithCurrentRevisions(manager, applicableChanges);
            saved = manager.saveEditorPatch(patches, MAXIMUM_HTTP_BYTES);
        }
        requireReloadOrRestore(manager, saved, update ? "Preset update" : "Preset installation");

        long now = System.currentTimeMillis();
        state.set(stateRoot + ".version", version);
        state.set(stateRoot + ".source", "official");
        if (!installedBefore) state.set(stateRoot + ".installed-at", now);
        state.set(stateRoot + ".updated-at", now);
        state.set(stateRoot + ".backup", saved.backupPath());
        state.set(stateRoot + ".originals", originals);
        state.set(stateRoot + ".managed", resolvedChanges);
        saveState(state);
        if (persistDescriptor) saveDescriptor(descriptor, id, variables);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("ok", true);
        result.put("id", id);
        result.put("version", version);
        result.put("changed", !saved.changedFiles().isEmpty());
        result.put("changedFiles", saved.changedFiles());
        result.put("backup", saved.backupPath());
        result.put("warnings", saved.warnings().size());
        result.put("preservedOverrides", List.copyOf(conflicts));
        result.put("message", conflicts.isEmpty()
                ? "Preset applied and CoreDSC reloaded successfully"
                : "Preset updated; " + conflicts.size() + " locally customized setting(s) were preserved");
        return Map.copyOf(result);
    }

    private List<Map<String, Object>> captureOriginals(List<Map<String, Object>> changes) {
        Map<String, YamlConfiguration> loaded = new LinkedHashMap<>();
        List<Map<String, Object>> originals = new ArrayList<>();
        for (Map<String, Object> change : changes) {
            String file = text(change.get("file"), "");
            String path = text(change.get("path"), "");
            YamlConfiguration yaml = loaded.computeIfAbsent(file,
                    key -> YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), key)));
            Object value = yaml.get(path);
            if (value == null) {
                // Managed files are materialized from defaults; an absent value cannot be restored
                // by the structured editor without introducing a nullable patch type.
                continue;
            }
            originals.add(Map.of("file", file, "path", path, "value", jsonSafe(value)));
        }
        return List.copyOf(originals);
    }

    private List<ConfigManager.EditorPatch> patchesWithCurrentRevisions(
            ConfigManager manager,
            List<Map<String, Object>> changes
    ) throws IOException {
        Map<String, String> revisions = new LinkedHashMap<>();
        List<ConfigManager.EditorPatch> patches = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        for (Map<String, Object> change : changes) {
            String file = text(change.get("file"), "");
            String path = text(change.get("path"), "");
            if (!manager.editableFilePaths().contains(file)) {
                throw new SecurityException("Preset attempted to modify non-allowlisted CoreDSC file " + file);
            }
            String key = file + '\u0000' + path;
            if (!seen.add(key)) throw new IllegalArgumentException("Preset changes " + file + ":" + path + " more than once");
            String revision = revisions.get(file);
            if (revision == null) {
                revision = manager.readEditorDocument(file, MAXIMUM_HTTP_BYTES).revision();
                revisions.put(file, revision);
            }
            Object value = jsonSafe(change.get("value"));
            patches.add(new ConfigManager.EditorPatch(file, path, value, revision));
        }
        return List.copyOf(patches);
    }

    private List<Map<String, Object>> preserveLocalOverrides(
            List<Map<String, Object>> incoming,
            List<Map<String, Object>> previouslyManaged,
            List<Map<String, Object>> conflicts
    ) {
        Map<String, Object> previous = new LinkedHashMap<>();
        for (Map<String, Object> change : previouslyManaged) {
            previous.put(text(change.get("file"), "") + '\u0000' + text(change.get("path"), ""),
                    jsonSafe(change.get("value")));
        }
        Map<String, YamlConfiguration> loaded = new LinkedHashMap<>();
        List<Map<String, Object>> applicable = new ArrayList<>();
        for (Map<String, Object> change : incoming) {
            String file = text(change.get("file"), "");
            String path = text(change.get("path"), "");
            String key = file + '\u0000' + path;
            if (!previous.containsKey(key)) {
                applicable.add(change);
                continue;
            }
            YamlConfiguration yaml = loaded.computeIfAbsent(file,
                    name -> YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), name)));
            Object current = jsonSafe(yaml.get(path));
            Object prior = previous.get(key);
            if (!Objects.equals(current, prior)) {
                Map<String, Object> conflict = new LinkedHashMap<>();
                conflict.put("file", file);
                conflict.put("path", path);
                conflict.put("current", current == null ? "" : current);
                conflict.put("preset", jsonSafe(change.get("value")));
                conflicts.add(Map.copyOf(conflict));
                continue;
            }
            applicable.add(change);
        }
        return List.copyOf(applicable);
    }

    private List<Map<String, Object>> resolveChanges(List<Map<String, Object>> changes, Map<String, Object> variables) {
        List<Map<String, Object>> resolved = new ArrayList<>();
        for (Map<String, Object> change : changes) {
            if (!change.keySet().equals(Set.of("file", "path", "value"))) {
                throw new SecurityException("Preset change contains unsupported fields; only file/path/value are allowed");
            }
            String file = bounded(text(change.get("file"), ""), 120, "file");
            String path = bounded(text(change.get("path"), ""), 160, "path");
            if (file.contains("..") || file.startsWith("/") || file.contains("\\")) {
                throw new SecurityException("Preset contains an unsafe file path");
            }
            Object value = resolveValue(change.get("value"), variables, 0);
            resolved.add(Map.of("file", file, "path", path, "value", jsonSafe(value)));
        }
        return List.copyOf(resolved);
    }

    private Object resolveValue(Object value, Map<String, Object> variables, int depth) {
        if (depth > 5) throw new IllegalArgumentException("Preset value nesting is too deep");
        if (value instanceof String text) {
            Matcher exact = VARIABLE.matcher(text);
            if (exact.matches()) {
                Object replacement = variables.get(exact.group(1));
                if (replacement == null) throw new IllegalArgumentException("Missing preset variable " + exact.group(1));
                return replacement;
            }
            Matcher matcher = VARIABLE.matcher(text);
            StringBuffer output = new StringBuffer();
            while (matcher.find()) {
                Object replacement = variables.get(matcher.group(1));
                if (replacement == null) throw new IllegalArgumentException("Missing preset variable " + matcher.group(1));
                matcher.appendReplacement(output, Matcher.quoteReplacement(String.valueOf(replacement)));
            }
            matcher.appendTail(output);
            return output.toString();
        }
        if (value instanceof List<?> list) {
            List<Object> result = new ArrayList<>();
            for (Object item : list) result.add(resolveValue(item, variables, depth + 1));
            return List.copyOf(result);
        }
        if (value instanceof Map<?, ?> map) {
            Map<String, Object> result = new LinkedHashMap<>();
            for (Map.Entry<?, ?> entry : map.entrySet()) {
                result.put(String.valueOf(entry.getKey()), resolveValue(entry.getValue(), variables, depth + 1));
            }
            return Map.copyOf(result);
        }
        return value;
    }

    private void requireReloadOrRestore(
            ConfigManager manager,
            ConfigManager.EditorBatchSaveResult saved,
            String operation
    ) throws Exception {
        CoreDSCPlugin.ReloadResult reload = reloadOnServerThread();
        if (reload.success()) return;

        IllegalStateException failure = new IllegalStateException(
                operation + " failed during runtime reload: " + reload.message());
        if (saved.backupPath() == null || saved.backupPath().isBlank()) {
            throw failure;
        }
        try {
            manager.restoreEditorBatchBackup(saved.backupPath(), MAXIMUM_HTTP_BYTES);
            CoreDSCPlugin.ReloadResult rollback = reloadOnServerThread();
            if (!rollback.success()) {
                throw new IllegalStateException("Previous configuration was restored on disk but rollback reload failed: "
                        + rollback.message());
            }
        } catch (Throwable rollbackFailure) {
            failure.addSuppressed(rollbackFailure);
            throw failure;
        }
        throw new IllegalStateException(operation
                + " was rejected and the previous configuration was restored: " + reload.message());
    }

    private CoreDSCPlugin.ReloadResult reloadOnServerThread() throws Exception {
        return plugin.callSync(plugin::reloadConfiguration).get(30L, TimeUnit.SECONDS);
    }

    private ConfigManager requireManager() {
        ConfigManager manager = plugin.getConfigManager();
        if (manager == null) throw new IllegalStateException("CoreDSC configuration manager is not ready");
        return manager;
    }

    private Map<String, Object> fetchJson(URI uri) throws IOException, InterruptedException {
        requireRegistryChild(uri.toString());
        HttpRequest request = HttpRequest.newBuilder(uri)
                .GET().timeout(Duration.ofSeconds(12))
                .header("Accept", "application/json")
                .header("User-Agent", "CoreDSC/" + plugin.getDescription().getVersion())
                .build();
        HttpResponse<InputStream> response = http.send(request, HttpResponse.BodyHandlers.ofInputStream());
        try (InputStream input = response.body()) {
            byte[] bytes = input.readNBytes(MAXIMUM_HTTP_BYTES + 1);
            if (bytes.length > MAXIMUM_HTTP_BYTES) throw new IOException("Preset registry response is too large");
            if (response.statusCode() != 200) {
                Map<String, Object> error;
                try { error = MiniJson.parseObject(new String(bytes, StandardCharsets.UTF_8)); }
                catch (RuntimeException ignored) { error = Map.of(); }
                throw new IOException(text(error.get("error"), "Preset registry returned HTTP " + response.statusCode()));
            }
            return MiniJson.parseObject(new String(bytes, StandardCharsets.UTF_8));
        }
    }

    private URI resolveRegistry(String child) {
        String base = registry.toString().replaceAll("/+$", "");
        return requireRegistryChild(base + "/" + URLEncoder.encode(child, StandardCharsets.UTF_8)
                .replace("%2F", "/"));
    }

    private URI requireRegistryChild(String value) {
        URI uri = URI.create(value);
        if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null) {
            throw new SecurityException("Preset registry must use HTTPS");
        }
        if (!Objects.equals(uri.getHost(), registry.getHost())) {
            throw new SecurityException("Preset package redirected to an untrusted host");
        }
        return uri;
    }

    private static URI requireRegistryUri(String value) {
        URI uri = URI.create(value);
        if (!"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null) {
            throw new IllegalArgumentException("COREDSC_PRESET_REGISTRY must be an HTTPS URL");
        }
        return uri;
    }

    private File descriptorFor(String id) {
        return new File(configsDirectory, requirePresetId(normalizeRequestedId(id)) + ".yml");
    }

    private static String normalizeRequestedId(String value) {
        String id = value == null ? "" : value.trim().toLowerCase(Locale.ROOT);
        id = id.replaceFirst("\\.ya?ml$", "");
        return id;
    }

    private File[] descriptorFiles() {
        File[] files = configsDirectory.listFiles((directory, name) -> name.matches("[a-z0-9][a-z0-9._-]{1,63}\\.ya?ml"));
        if (files == null) return new File[0];
        java.util.Arrays.sort(files, java.util.Comparator.comparing(File::getName));
        return files;
    }

    private static YamlConfiguration loadDescriptor(File file) throws IOException {
        YamlConfiguration yaml = new YamlConfiguration();
        try { yaml.load(file); }
        catch (org.bukkit.configuration.InvalidConfigurationException error) {
            throw new IOException("Invalid preset descriptor YAML in " + file.getName(), error);
        }
        int format = yaml.getInt("format", 1);
        if (format != 1 && format != 2) throw new IOException("Unsupported preset descriptor format: " + format);
        return yaml;
    }

    private static int descriptorFormat(YamlConfiguration yaml) {
        int format = yaml.getInt("format", 1);
        if (format != 1 && format != 2) {
            throw new IllegalArgumentException("Preset descriptor format must be 1 or 2");
        }
        return format;
    }

    private static String presetId(YamlConfiguration yaml, File file) {
        String fallback = file.getName().replaceFirst("\\.ya?ml$", "");
        int format = descriptorFormat(yaml);
        String configured = format == 2
                ? yaml.getString("preset.id", fallback)
                : yaml.getString("preset", fallback);
        return requirePresetId(configured);
    }

    private static Map<String, Object> descriptorVariables(YamlConfiguration yaml) {
        ConfigurationSection variables = yaml.getConfigurationSection("variables");
        if (variables == null) return Map.of();
        Map<String, Object> result = new LinkedHashMap<>();
        variables.getKeys(true).stream().sorted().forEach(key -> {
            if (variables.isConfigurationSection(key)) return;
            Object value = variables.get(key);
            if (value != null) result.put(key, jsonSafe(value));
        });
        return Map.copyOf(result);
    }

    private void saveDescriptor(File file, String id, Map<String, Object> variables) throws IOException {
        YamlConfiguration yaml = file.isFile() ? loadDescriptor(file) : new YamlConfiguration();
        yaml.set("format", 1);
        yaml.set("preset", id);
        yaml.set("version", "latest");
        yaml.set("registry", "official");
        yaml.set("auto-apply", true);
        for (Map.Entry<String, Object> entry : variables.entrySet()) {
            yaml.set("variables." + variableKey(entry.getKey()), entry.getValue());
        }
        saveYamlAtomic(yaml, file);
    }

    private void writeDescriptorScaffold(
            File file,
            String id,
            Map<String, Object> current,
            List<Map<String, Object>> requirements
    ) throws IOException {
        YamlConfiguration yaml = file.isFile() ? loadDescriptor(file) : new YamlConfiguration();
        yaml.set("format", 1);
        yaml.set("preset", id);
        yaml.set("version", "latest");
        yaml.set("registry", "official");
        yaml.set("auto-apply", true);
        for (Map<String, Object> requirement : requirements) {
            String key = variableKey(requirement.get("key"));
            yaml.set("variables." + key, current.getOrDefault(key, ""));
        }
        saveYamlAtomic(yaml, file);
    }

    private String beginOperation(String presetId, String action, String rollbackId) throws IOException {
        String operationId = Long.toString(System.currentTimeMillis(), 36) + "-"
                + Integer.toString(java.util.concurrent.ThreadLocalRandom.current().nextInt(36 * 36 * 36), 36);
        YamlConfiguration journal = journalFile.isFile()
                ? YamlConfiguration.loadConfiguration(journalFile) : new YamlConfiguration();
        String root = "operations." + operationId;
        journal.set(root + ".preset", presetId);
        journal.set(root + ".action", action);
        journal.set(root + ".status", "RUNNING");
        journal.set(root + ".rollback", rollbackId);
        journal.set(root + ".started-at", System.currentTimeMillis());
        pruneOperationJournal(journal);
        saveYamlAtomic(journal, journalFile);
        return operationId;
    }

    private void finishOperation(
            String operationId,
            String status,
            List<String> created,
            List<String> reused,
            String message
    ) throws IOException {
        YamlConfiguration journal = journalFile.isFile()
                ? YamlConfiguration.loadConfiguration(journalFile) : new YamlConfiguration();
        String root = "operations." + operationId;
        journal.set(root + ".status", status);
        journal.set(root + ".finished-at", System.currentTimeMillis());
        journal.set(root + ".created", created == null ? List.of() : List.copyOf(created));
        journal.set(root + ".reused", reused == null ? List.of() : List.copyOf(reused));
        String safeMessage = message == null ? "" : message.trim();
        if (safeMessage.length() > 500) safeMessage = safeMessage.substring(0, 500);
        journal.set(root + ".message", safeMessage);
        pruneOperationJournal(journal);
        saveYamlAtomic(journal, journalFile);
    }

    private static void pruneOperationJournal(YamlConfiguration journal) {
        ConfigurationSection operations = journal.getConfigurationSection("operations");
        if (operations == null) return;
        List<String> ids = operations.getKeys(false).stream().sorted().toList();
        int excess = Math.max(0, ids.size() - 50);
        for (int index = 0; index < excess; index++) journal.set("operations." + ids.get(index), null);
    }

    private YamlConfiguration loadState() {
        return stateFile.isFile() ? YamlConfiguration.loadConfiguration(stateFile) : new YamlConfiguration();
    }

    private void saveState(YamlConfiguration state) throws IOException {
        saveYamlAtomic(state, stateFile);
    }

    private static void saveYamlAtomic(YamlConfiguration yaml, File file) throws IOException {
        Path target = file.toPath().toAbsolutePath().normalize();
        Path parent = target.getParent();
        if (parent == null) throw new IOException("Preset file has no parent directory: " + file);
        Files.createDirectories(parent);
        Path temporary = Files.createTempFile(parent, "." + file.getName() + ".", ".tmp");
        try {
            Files.writeString(temporary, yaml.saveToString(), StandardCharsets.UTF_8,
                    StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);
            try (FileChannel channel = FileChannel.open(temporary, StandardOpenOption.WRITE)) {
                channel.force(true);
            }
            try {
                Files.move(temporary, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temporary, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temporary);
        }
    }

    private void writeReadmeIfMissing() throws IOException {
        File readme = new File(configsDirectory, "README.txt");
        if (readme.exists()) return;
        Files.writeString(readme.toPath(), """
                CoreDSC Presets
                ===============
                Drop one approved .yml descriptor into this folder, then restart CoreDSC or run:
                  /coredsc preset reload

                Format-2 setup flow:
                  1. Copy an approved descriptor such as donutsmp.yml into this folder.
                  2. Set discord.guild-id and choose CREATE_MISSING / USE_EXISTING modes.
                  3. /coredsc preset reload
                  4. /coredsc preset enable donutsmp
                  5. /coredsc preset preview donutsmp
                  6. /coredsc preset apply donutsmp

                A format-2 descriptor starts like this:
                  format: 2
                  preset:
                    id: donutsmp
                    version: latest
                    enabled: false
                    auto-apply: false
                  discord:
                    guild-id: ''
                    roles-mode: CREATE_MISSING
                    channels-mode: CREATE_MISSING
                    categories-mode: CREATE_MISSING

                CREATE_MISSING creates only CoreDSC-owned missing resources. If a matching resource
                already exists, preview/apply asks you to switch to USE_EXISTING and provide its ID.
                CoreDSC creates an immutable rollback snapshot before preset mutations.

                Presets are declarative. CoreDSC never executes downloaded Java, Python or shell code.
                """, StandardCharsets.UTF_8);
    }

    private static List<Map<String, Object>> configurationMaps(List<?> source) {
        if (source == null) return List.of();
        List<Map<String, Object>> result = new ArrayList<>();
        for (Object item : source) {
            if (!(item instanceof Map<?, ?> map)) continue;
            Map<String, Object> value = new LinkedHashMap<>();
            map.forEach((key, entryValue) -> value.put(String.valueOf(key), jsonSafe(entryValue)));
            result.add(Map.copyOf(value));
        }
        return List.copyOf(result);
    }

    private static List<Map<String, Object>> objectList(Object value, String field, int maximum) {
        if (!(value instanceof List<?> list)) throw new IllegalArgumentException(field + " must be an array");
        if (list.size() > maximum) throw new IllegalArgumentException(field + " exceeds the item limit");
        List<Map<String, Object>> result = new ArrayList<>();
        for (Object item : list) {
            if (!(item instanceof Map<?, ?> map)) throw new IllegalArgumentException(field + " contains a non-object item");
            Map<String, Object> entry = new LinkedHashMap<>();
            map.forEach((key, child) -> entry.put(String.valueOf(key), child));
            result.add(Map.copyOf(entry));
        }
        return List.copyOf(result);
    }

    private static Object jsonSafe(Object value) {
        if (value == null || value instanceof String || value instanceof Boolean
                || value instanceof Byte || value instanceof Short || value instanceof Integer
                || value instanceof Long || value instanceof Float || value instanceof Double) return value;
        if (value instanceof List<?> list) {
            List<Object> values = new ArrayList<>();
            for (Object item : list) values.add(jsonSafe(item));
            return List.copyOf(values);
        }
        if (value instanceof ConfigurationSection section) return jsonSafe(section.getValues(false));
        if (value instanceof Map<?, ?> map) {
            Map<String, Object> values = new LinkedHashMap<>();
            map.forEach((key, child) -> values.put(String.valueOf(key), jsonSafe(child)));
            return Map.copyOf(values);
        }
        return String.valueOf(value);
    }

    private static int compareVersions(String actual, String minimum) {
        int[] left = numericVersion(actual);
        int[] right = numericVersion(minimum);
        for (int index = 0; index < Math.max(left.length, right.length); index++) {
            int a = index < left.length ? left[index] : 0;
            int b = index < right.length ? right[index] : 0;
            if (a != b) return Integer.compare(a, b);
        }
        return 0;
    }

    private static int[] numericVersion(String value) {
        String[] tokens = (value == null ? "" : value).split("[^0-9]+");
        return java.util.Arrays.stream(tokens).filter(token -> !token.isBlank()).limit(4)
                .mapToInt(token -> {
                    try { return Integer.parseInt(token); }
                    catch (NumberFormatException ignored) { return 0; }
                }).toArray();
    }

    private static String sha256(byte[] bytes) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes)); }
        catch (NoSuchAlgorithmException impossible) { throw new IllegalStateException("SHA-256 is unavailable", impossible); }
    }

    private static String requirePresetId(Object value) {
        String id = value == null ? "" : String.valueOf(value).trim().toLowerCase(Locale.ROOT);
        if (!PRESET_ID.matcher(id).matches()) throw new IllegalArgumentException("Invalid preset id");
        return id;
    }

    private static String variableKey(Object value) {
        String key = value == null ? "" : String.valueOf(value).trim();
        if (!key.matches("[a-zA-Z0-9][a-zA-Z0-9_.-]{0,79}")) throw new IllegalArgumentException("Invalid preset variable key");
        return key;
    }

    private static String bounded(String value, int maximum, String field) {
        if (value.isBlank() || value.length() > maximum) throw new IllegalArgumentException("Invalid preset " + field);
        return value;
    }

    private static String text(Object value, String fallback) {
        String text = value == null ? "" : String.valueOf(value).trim();
        return text.isBlank() ? fallback : text;
    }

    private <T> CompletableFuture<T> supply(ThrowingSupplier<T> supplier) {
        return CompletableFuture.supplyAsync(() -> {
            if (closed.get()) throw new IllegalStateException("Preset service is stopped");
            try { return supplier.get(); }
            catch (PresetRuntimeException error) { throw error; }
            catch (Throwable error) { throw new PresetRuntimeException(error); }
        }, executor);
    }

    @Override
    public void close() {
        if (!closed.compareAndSet(false, true)) return;
        executor.shutdownNow();
    }

    private static String rootMessage(Throwable error) {
        Throwable current = error;
        while (current.getCause() != null) current = current.getCause();
        return current.getMessage() == null || current.getMessage().isBlank()
                ? current.getClass().getSimpleName() : current.getMessage();
    }

    @FunctionalInterface
    private interface ThrowingSupplier<T> { T get() throws Exception; }

    private static final class PresetRuntimeException extends RuntimeException {
        private static final long serialVersionUID = 1L;
        PresetRuntimeException(Throwable cause) { super(cause); }
    }
}
