# CoreDSC Reference

## Version and runtime targets

| Component | Current value |
|---|---|
| CoreDSC plugin version | `3.4.2` |
| CoreDSC Panel/control-plane version | `1.3.1` |
| Java release | 21 |
| Paper API | `1.21.11-R0.1-SNAPSHOT` |
| Bukkit API version | `1.21` |
| Folia declaration | `folia-supported: true` |
| Node.js | `>=22.13.0` |
| JDA | `6.5.0` |
| SQLite JDBC | `3.53.2.0` |
| Local SQLite schema | `14` |
| bStats | `3.2.1`, relocated when shaded |
| Cloudflare compatibility date | `2026-07-01` |
| Protocol version | 1 |

Paper, SLF4J, LuckPerms and Simple Voice Chat APIs are provided dependencies. JDA, SQLite JDBC and bStats are intended runtime contents of the shaded plugin JAR.

## Plugin commands

| Command | Purpose |
|---|---|
| `/coredsc status` | Show plugin and module status. |
| `/coredsc setup ...` | Run guided setup actions through the Doctor service. |
| `/coredsc doctor [test|fix]` | Diagnose configuration/integration problems, test a target or apply supported safe fixes. |
| `/coredsc queue ...` | Inspect or retry the Discord delivery queue. |
| `/coredsc bot <status|scripts|start|stop|reload>` | Manage the optional local Python worker. |
| `/coredsc emit ...` | Publish a configured custom event to local Python scripts. |
| `/coredsc telemetry ...` | Inspect telemetry state. |
| `/coredsc migrate ...` | Run supported non-destructive migration helpers. |
| `/coredsc editor <open|status|recover|auth>` | Pair/open the hosted dashboard, inspect agent state, recover ownership or confirm a pairing. |
| `/coredsc preset <browse|list|install|update|remove|reload>` | Browse and manage approved configuration presets. |
| `/coredsc reload` | Reload CoreDSC configuration and modules. |
| `/link [code]`, `/unlink` | Manage account linking. The configured direction decides which platform issues or consumes the temporary code. |
| `/ticket ...` | Create/manage Tickets V2 support flows when enabled. |
| Discord `/roles ...` | Configure/publish self-role panels and let users select configured roles. |
| Discord `/rank [user]`, `/levels`, `!rank` | Discord activity rank and leaderboard when `discord-levels` is enabled. |
| `/report ...` | Create player reports when enabled. |
| `/case ...`, `/appeal ...` | Inspect/manage cases and submit appeals when enabled. |
| `/apply ...`, `/application ...` | Player application and staff decision flows when enabled. |
| `/lore <profile> <message>` | Trigger a configured Lore Sync NPC persona. |

Disabled or unavailable modules return an explicit message instead of silently accepting their commands.

## Bukkit permissions

| Permission | Default |
|---|---|
| `coredsc.status` | operator |
| `coredsc.reload` | operator |
| `coredsc.doctor` | operator |
| `coredsc.queue` | operator |
| `coredsc.bot` | operator |
| `coredsc.emit` | operator |
| `coredsc.migrate` | operator |
| `coredsc.preset` | Manage approved configuration presets. |
| `coredsc.editor` | operator |
| `coredsc.link` | everyone |
| `coredsc.unlink` | everyone |
| `coredsc.link.bypass` | operator |
| `coredsc.ticket` | everyone |
| `coredsc.report` | everyone |
| `coredsc.report.bypass` | operator |
| `coredsc.report.admin` | operator |
| `coredsc.case.view` | operator |
| `coredsc.case.manage` | operator |
| `coredsc.appeal` | everyone |
| `coredsc.apply` | everyone |
| `coredsc.application.manage` | operator |
| `coredsc.voice.optout` | false |
| `coredsc.lore.trigger` | operator |

## Hosted staff roles

Capabilities are deny-by-default and are checked by both the Worker and plugin.

| Role | Principal capabilities |
|---|---|
| `OWNER` | All capabilities, including staff administration. |
| `SERVER_ADMIN` | Server/configuration management, moderation and case notes, channel, incident, maintenance, event, approval, AutoMod and network management; console viewing only. |
| `MODERATOR` | Moderation, case notes and channel management, incident management, approval viewing and console viewing. |
| `CONSOLE_VIEWER` | Server, incident and console read access. |
| `CONSOLE_OPERATOR` | Console viewing/execution plus server, incident and maintenance read access. |
| `SUPPORT` | Server/moderation read access plus case history, case notes and ticket management; no sanction authority. |
| `VIEWER` | Read-only server, configuration, moderation, channel and incident access. |

Only `OWNER` may grant or revoke hosted staff access. A target Discord user must already have signed in before a grant can be created.

## Cloud operations

### Setup and health

- `health.snapshot`
- `setup.doctor`
- `setup.createChannels`
- `discord.guilds`
- `discord.channels`

### Configuration and media

Preset operations:

- `preset.browse`
- `preset.list`
- `preset.install`
- `preset.update`
- `preset.remove`
- `preset.reload`
- `preset.status`
- `preset.enable`
- `preset.disable`
- `preset.preview`
- `preset.apply`
- `preset.repair`

The registry is readable without the Minecraft agent, but installed-state reads and all mutations require the connected local agent. Format-2 descriptor presets can create only their bounded, explicitly supported Discord/LuckPerms resource types; package configuration mutations remain validated against the plugin-side configuration allowlist.

Rollback commands are local Minecraft commands: `/coredsc rollback list`, `/coredsc rollback use <snapshot-id>` and confirmation via `/coredsc confirm <code>`. Preset/config state is snapshotted before mutation. A restore creates a fresh safety snapshot first and can reconcile CoreDSC-owned external resources that did not exist in the target state.


- `config.snapshot`
- `config.validate`
- `config.patch`
- `config.apply`
- `media.install`

Configuration access is constrained to the plugin's explicit allowlist. Secret files, databases, backups, private keys and arbitrary paths are excluded. Mutations use revisions; stale revisions are rejected. Local backups are created before application and rollback is local.

### Moderation and cases

- `moderation.ban`
- `moderation.unban`
- `moderation.kick`
- `moderation.timeout`
- `moderation.warn`
- `moderation.history`
- `moderation.note`

`moderation.history` returns detached local case records from the enabled cases module. `moderation.note` requires `case.manage`, not sanction authority, so SUPPORT can record a case note without gaining ban, kick, timeout, warn or unban permissions. The plugin rechecks protected Minecraft names/UUIDs, protected Discord IDs and Discord role hierarchy. Permanent bans require approval.

### Reversible channel operations

- `channel.snapshot`
- `channel.lock`
- `channel.unlock`
- `channel.slowmode`
- `channel.slowmode.restore`
- `channel.purge`
- `channel.hide`
- `channel.reveal`

The local agent snapshots exact permission overwrites before reversible mutations. Purge is bounded and always requires approval.

### Incident, maintenance and events

- `incident.status`, `incident.start`, `incident.resolve`
- `maintenance.status`, `maintenance.start`, `maintenance.cancel`
- `event.list`, `event.create`, `event.cancel`

Network-scoped Incident Mode requires approval. Incident and maintenance state is persisted locally so restoration can continue after restart.

### AutoMod

- `automod.rules`
- `automod.upsert`
- `automod.delete`

Only rules that CoreDSC identifies as locally managed may be deleted through CoreDSC.

### Network tools

- `network.snapshot`
- `network.announce`
- `network.template.validate`
- `network.template.apply`

Network template application always requires approval. Template revisions are optimistic-lock revisions; stale updates and stale rollout requests are rejected. Repeated rollouts require new idempotency keys.

For every local mutation, the plugin computes a canonical SHA-256 fingerprint over the operation, payload and audited reason. A persistent or in-flight idempotency key cannot be reused with a different fingerprint. Schema 13 added `request_fingerprint` to `cloud_operation_results`; legacy rows remain readable and new results are fingerprint-bound.

### Smart Console

- `console.snapshot`
- `console.execute`

Execution always requires two-person approval, the `console.execute` capability, the local feature switch and the local root-command allowlist. The default feature switch is disabled.

## Two-person approval rules

Approval is always required for:

- `channel.purge`
- `console.execute`
- `network.template.apply`

It is also required for permanent `moderation.ban` requests and `incident.start` when `scope` is `network`.

The requester cannot approve their own operation. Requests can be rejected or expire. Dispatch uses a lease so an interrupted approval can be safely retried without executing twice.

## HTTP API surface

The dashboard proxies `/api/*` to the control plane and removes the `/api` prefix.

Public/authentication routes:

- `GET /health`
- `GET /v1/auth/discord`
- `GET /v1/auth/discord/callback`
- `POST /v1/auth/logout`
- `GET /v1/me`
- `GET /v1/agent/connect`
- `POST /v1/pairings/claim`
- `GET /v1/pairings/status`

Authenticated resources:

- `GET /v1/servers`
- `GET /v1/servers/{instanceId}/overview`
- `GET /v1/servers/{instanceId}/live`
- `POST /v1/servers/{instanceId}/operations`
- `GET /v1/servers/{instanceId}/audit`
- `GET /v1/servers/{instanceId}/approvals`
- `GET|POST /v1/servers/{instanceId}/staff`
- `DELETE /v1/servers/{instanceId}/staff/{discordUserId}`
- `POST /v1/approvals/{approvalId}/decision`
- `GET|POST /v1/networks`
- `GET /v1/networks/{networkId}`
- `POST /v1/networks/{networkId}/members`
- `DELETE /v1/networks/{networkId}/members/{instanceId}`
- `POST /v1/networks/{networkId}/templates`
- `PUT|DELETE /v1/networks/{networkId}/templates/{templateId}`
- `POST /v1/networks/{networkId}/templates/{templateId}/apply`
- `POST /v1/uploads`

Mutation requests require a valid session, exact first-party `Origin`, `X-CoreDSC-CSRF`, an applicable grant/capability and rate-limit allowance.

## Cloudflare bindings and values

### Control-plane bindings

| Name | Type | Required |
|---|---|---|
| `COREDSC_DB` | D1 database | yes |
| `INSTANCE_ROOMS` | Durable Object namespace | yes |

### Dashboard binding

| Name | Type | Required |
|---|---|---|
| `CONTROL_PLANE` | Service binding to the control-plane Worker | yes for `/api/*` |

The hosting runtime also provides the Vinext asset/image bindings used by the generated dashboard Worker.

### Control-plane variables

- `APP_ORIGIN`
- `PUBLIC_APP_URL`
- `DISCORD_REDIRECT_URI`
- `SESSION_TTL_SECONDS` — accepted range is one hour to 30 days; default configuration is seven days.

### Control-plane secrets

- `DISCORD_CLIENT_ID`
- `DISCORD_CLIENT_SECRET`
- `COOKIE_SECRET`

The customer's Discord bot token is not a control-plane secret.

## D1 migrations

Migrations must remain ordered and immutable once deployed:

1. `0001_initial.sql`
2. `0002_health_incidents.sql`
3. `0003_operation_reliability.sql`
4. `0004_rate_limits.sql`
5. `0005_idempotency_fingerprints.sql`
6. `0006_ownership_recovery.sql`

## Default module state

Enabled by default:

- `chat-sync`
- `cloud-control`
- `delivery-queue`
- `link`
- `placeholderapi`
- `status-channels`

Disabled by default:

- `applications`, `authme`, `ban-sync`, `booster-rewards`, `cases`, `competitive`, `console`, `custom-commands`, `discord-levels`, `economy-market`, `link-rewards`, `lore-sync`, `luckperms-sync`, `moderation-bridge`, `network`, `nickname-sync`, `reports`, `self-roles`, `server-events`, `tickets`, `voicechat-sync`, `workflows` and the optional Python worker.

An optional integration being absent should disable only the dependent module, not the entire plugin.

## Important configuration defaults

`config.yml`:

- Discord token source: environment variable `COREDSC_BOT_TOKEN`
- SQLite queue capacity: 8192
- Debug: false

`modules/cloud-control.yml`:

- Agent enabled: true
- Endpoint: `wss://dash.coredsc.workers.dev/api/v1/agent/connect`
- Maximum queued frames: 256
- Maximum reconnect backoff: 300 seconds
- Idempotency retention: 30 days
- Remote console execution: false
- Default command roots: `list`, `tps`, `mspt`, `say`, `whitelist`

## Donut-oriented generic modules

`modules/link.yml` supports `MINECRAFT_TO_DISCORD`, `DISCORD_TO_MINECRAFT` and `BOTH`. `modules/self-roles.yml` defines managed select panels and role groups. `modules/discord-levels.yml` defines anti-spam XP, the level curve, rank/leaderboard commands and milestone roles. The verified `donutsmp` preset 0.4.0 uses a format-2 descriptor and can bootstrap missing Discord resources plus an independent DonutRanks-style LuckPerms group template before composing verification, linked chat, Tickets V2, self roles and activity levels. Discord activity roles such as Affiliate/Official/GOD DonutSMPer remain Discord-only and are never mapped to Minecraft ranks. Existing named resources require explicit `USE_EXISTING` IDs rather than silent adoption.

## Media limits

- Accepted types: PNG, JPEG, WebP and GIF
- Maximum decoded size: 512 KiB
- Declared MIME type must match magic bytes
- Worker sends validated Base64 to the local agent only
- D1 and audit events do not retain image bodies
- Plugin generates the destination and content-addressed filename; no arbitrary path is accepted

## Verification boundaries for this delivery

- The dashboard syntax gate, control-plane TypeScript no-emit gate, dependency-free Java 21 release safety harness and **115/115** dependency-free control-plane/contract tests pass.
- Complete Java compilation, Maven/JUnit tests and shaded-JAR inspection were not possible because `mvn` and retrievable Maven artifacts were unavailable in the execution environment.
- A full root dashboard production bundle was not completed in this environment because the configured package infrastructure could not resolve the locked `vinext` dependency; source syntax and control-plane type/tests are not a substitute for that build.
- Browser QA and real Paper/Folia runtime tests were not performed.
- Real Cloudflare deployment, service binding, domain, D1 and Durable Object behavior require an operator account and were not tested externally.
- Discord OAuth, guild permissions and hierarchy behavior require operator credentials and a test guild and were not tested externally.
