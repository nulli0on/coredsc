"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { api, ApiError, CoreServer, CoreUser, csrfHeader, oauthUrl, relativeTime } from "../lib/control-plane";
import { Brand, Icon } from "../ui";

type CoreNetwork = { id: string; name: string; server_count: number; created_at: number };
type NetworkMember = {
  id: string;
  display_name: string;
  plugin_version: string;
  minecraft_version: string;
  scheduler_runtime: string;
  status: string;
  last_seen_at: number;
};
type NetworkTemplate = {
  id: string;
  name: string;
  patch: Record<string, unknown>;
  revision: number;
  updatedAt: number;
};
type WorkspaceView = "servers" | "networks" | "pair";

type NetworkDetails = {
  network: { id: string; name: string; createdAt: number };
  members: NetworkMember[];
  templates: NetworkTemplate[];
};

const TEMPLATE_EXAMPLE = JSON.stringify({
  changes: [
    { file: "modules/chat-sync.yml", path: "enabled", value: true },
    { file: "modules/server-events.yml", path: "events.death.enabled", value: true },
  ],
}, null, 2);

export default function DashboardPage() {
  const [user, setUser] = useState<CoreUser | null>(null);
  const [servers, setServers] = useState<CoreServer[]>([]);
  const [networks, setNetworks] = useState<CoreNetwork[]>([]);
  const [networkDetails, setNetworkDetails] = useState<NetworkDetails | null>(null);
  const [csrf, setCsrf] = useState("");
  const [networkName, setNetworkName] = useState("");
  const [selectedNetwork, setSelectedNetwork] = useState("");
  const [selectedServer, setSelectedServer] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [templateName, setTemplateName] = useState("");
  const [templateJson, setTemplateJson] = useState(TEMPLATE_EXAMPLE);
  const [applyReason, setApplyReason] = useState("");
  const [error, setError] = useState("");
  const [authRequired, setAuthRequired] = useState(false);
  const [actionError, setActionError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const busyRef = useRef(false);
  const [loading, setLoading] = useState(true);
  const [workspace, setWorkspace] = useState<WorkspaceView>("servers");
  const [search, setSearch] = useState("");

  useEffect(() => {
    Promise.all([
      api<{ user: CoreUser; csrfToken: string }>("/v1/me"),
      api<{ servers: CoreServer[] }>("/v1/servers"),
      api<{ networks: CoreNetwork[] }>("/v1/networks"),
    ]).then(([identity, list, networkList]) => {
      setUser(identity.user);
      setCsrf(identity.csrfToken);
      setServers(list.servers);
      setNetworks(networkList.networks);
      const initialNetwork = networkList.networks[0]?.id ?? "";
      setSelectedNetwork(initialNetwork);
      setSelectedServer(list.servers.find((server) => server.role === "OWNER")?.id ?? "");
      if (initialNetwork) {
        void api<NetworkDetails>(`/v1/networks/${initialNetwork}`)
          .then(setNetworkDetails)
          .catch((failure: unknown) => setActionError(messageOf(failure)));
      }
    }).catch((failure: unknown) => {
      setAuthRequired(failure instanceof ApiError && failure.status === 401);
      setError(messageOf(failure));
    })
      .finally(() => setLoading(false));
  }, []);

  const online = useMemo(() => servers.filter((server) => server.online).length, [servers]);
  const ownedServers = useMemo(() => servers.filter((server) => server.role === "OWNER"), [servers]);
  const filteredServers = useMemo(() => servers.filter((server) => server.name.toLowerCase().includes(search.trim().toLowerCase())), [search, servers]);
  const filteredNetworks = useMemo(() => networks.filter((network) => network.name.toLowerCase().includes(search.trim().toLowerCase())), [networks, search]);
  const activeNetwork = useMemo(() => networks.find((network) => network.id === selectedNetwork) ?? null, [networks, selectedNetwork]);
  const availableServers = useMemo(() => {
    const members = new Set(networkDetails?.members.map((member) => member.id) ?? []);
    return ownedServers.filter((server) => !members.has(server.id));
  }, [networkDetails, ownedServers]);

  async function refreshNetwork(networkId = selectedNetwork) {
    try {
      const details = await api<NetworkDetails>(`/v1/networks/${networkId}`);
      setNetworkDetails(details);
      const selected = details.templates.find((template) => template.id === selectedTemplate);
      if (!selected && selectedTemplate) setSelectedTemplate("");
    } catch (failure) {
      setActionError(messageOf(failure));
    }
  }

  async function perform(action: () => Promise<void>) {
    if (busyRef.current) return;
    busyRef.current = true;
    setBusy(true);
    setActionError("");
    setNotice("");
    try {
      await action();
    } catch (failure) {
      setActionError(messageOf(failure));
    } finally {
      busyRef.current = false;
      setBusy(false);
    }
  }

  function chooseTemplate(templateId: string) {
    setSelectedTemplate(templateId);
    const template = networkDetails?.templates.find((item) => item.id === templateId);
    if (!template) {
      setTemplateName("");
      setTemplateJson(TEMPLATE_EXAMPLE);
      return;
    }
    setTemplateName(template.name);
    setTemplateJson(JSON.stringify(template.patch, null, 2));
  }

  async function createNetwork() {
    await perform(async () => {
      if (!networkName.trim()) throw new Error("Enter a network name first.");
      const result = await api<{ network: { id: string; name: string } }>("/v1/networks", {
        method: "POST", headers: csrfHeader(csrf), body: JSON.stringify({ name: networkName }),
      });
      const created: CoreNetwork = { ...result.network, server_count: 0, created_at: Date.now() };
      setNetworks((current) => [...current, created]);
      setSelectedNetwork(created.id);
      setNetworkName("");
      await refreshNetwork(created.id);
      setNotice(`Network “${created.name}” created.`);
    });
  }

  async function addServer() {
    await perform(async () => {
      if (!selectedNetwork || !selectedServer) throw new Error("Choose a network and an owned server.");
      const result = await api<{ added: boolean }>(`/v1/networks/${selectedNetwork}/members`, {
        method: "POST", headers: csrfHeader(csrf), body: JSON.stringify({ instanceId: selectedServer }),
      });
      if (result.added) {
        setNetworks((current) => current.map((network) => network.id === selectedNetwork
          ? { ...network, server_count: Number(network.server_count) + 1 } : network));
      }
      await refreshNetwork();
      setNotice(result.added ? "Server added to the network." : "That server is already a member.");
    });
  }

  async function removeServer(instanceId: string) {
    await perform(async () => {
      await api(`/v1/networks/${selectedNetwork}/members/${instanceId}`, {
        method: "DELETE", headers: csrfHeader(csrf),
      });
      setNetworks((current) => current.map((network) => network.id === selectedNetwork
        ? { ...network, server_count: Math.max(0, Number(network.server_count) - 1) } : network));
      await refreshNetwork();
      setNotice("Server removed from the network. Its local configuration was not changed.");
    });
  }

  async function saveTemplate() {
    await perform(async () => {
      if (!selectedNetwork) throw new Error("Create or select a network first.");
      if (!templateName.trim()) throw new Error("Enter a template name.");
      const patch = parseTemplate(templateJson);
      const current = networkDetails?.templates.find((template) => template.id === selectedTemplate);
      if (current) {
        await api(`/v1/networks/${selectedNetwork}/templates/${current.id}`, {
          method: "PUT",
          headers: csrfHeader(csrf),
          body: JSON.stringify({ name: templateName, patch, revision: current.revision }),
        });
        setNotice("Template saved.");
      } else {
        const created = await api<{ template: NetworkTemplate }>(`/v1/networks/${selectedNetwork}/templates`, {
          method: "POST", headers: csrfHeader(csrf), body: JSON.stringify({ name: templateName, patch }),
        });
        setSelectedTemplate(created.template.id);
        setNotice("Template created.");
      }
      await refreshNetwork();
    });
  }

  async function deleteTemplate() {
    await perform(async () => {
      if (!selectedTemplate) throw new Error("Choose a saved template first.");
      await api(`/v1/networks/${selectedNetwork}/templates/${selectedTemplate}`, {
        method: "DELETE", headers: csrfHeader(csrf),
      });
      setSelectedTemplate("");
      setTemplateName("");
      setTemplateJson(TEMPLATE_EXAMPLE);
      await refreshNetwork();
      setNotice("Template deleted. No server configuration was changed.");
    });
  }

  async function applyTemplate() {
    await perform(async () => {
      if (!selectedTemplate) throw new Error("Save or choose a template first.");
      if (!applyReason.trim()) throw new Error("Enter a reason for this change.");
      const result = await api<{ targets: Array<{ approvalRequired?: boolean }> }>(
        `/v1/networks/${selectedNetwork}/templates/${selectedTemplate}/apply`, {
          method: "POST", headers: csrfHeader(csrf), body: JSON.stringify({ reason: applyReason, rolloutId: crypto.randomUUID() }),
        },
      );
      const approvals = result.targets.filter((target) => target.approvalRequired).length;
      setApplyReason("");
      setNotice(`${result.targets.length} server(s) accepted the template${approvals
        ? `; ${approvals} need approval from another administrator` : " and will apply the changes"}.`);
    });
  }

  if (loading) return <LoadingScreen />;
  if (error) return authRequired ? <SignInState error={error} /> : <UnavailableState error={error} />;

  return (
    <main className="editor-app">
      <header className="editor-topbar">
        <Brand />
        <span className="topbar-divider" />
        <span className="topbar-title">Dashboard</span>
        <div className="topbar-account">
          <Avatar user={user} />
          <div><strong>{user?.displayName}</strong><small>@{user?.username}</small></div>
        </div>
      </header>

      <div className="editor-body">
        <aside className="resource-browser">
          <label className="browser-search">
            <Icon name="search" />
            <input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search" />
          </label>

          <section className="browser-section">
            <button className="browser-heading" type="button" onClick={() => setWorkspace("servers")}>
              <span><Icon name="server" /> Servers</span><em>{servers.length}</em>
            </button>
            <div className="browser-items">
              {filteredServers.map((server) => <ServerBrowserRow server={server} key={server.id} />)}
              {!filteredServers.length && <p className="browser-empty">No servers found.</p>}
            </div>
          </section>

          <section className="browser-section">
            <button className="browser-heading" type="button" onClick={() => setWorkspace("networks")}>
              <span><Icon name="network" /> Networks</span><em>{networks.length}</em>
            </button>
            <div className="browser-items">
              {filteredNetworks.map((network) => (
                <button type="button" key={network.id}
                  className={workspace === "networks" && selectedNetwork === network.id ? "browser-row active" : "browser-row"}
                  onClick={() => { setWorkspace("networks"); setSelectedNetwork(network.id); setNetworkDetails(null); void refreshNetwork(network.id); }}>
                  <span className="browser-row-icon"><Icon name="network" /></span>
                  <span><strong>{network.name}</strong><small>{network.server_count} server{network.server_count === 1 ? "" : "s"}</small></span>
                </button>
              ))}
              {!filteredNetworks.length && <p className="browser-empty">No networks found.</p>}
            </div>
          </section>

          <button className="browser-create" type="button" onClick={() => setWorkspace("pair")}>
            <Icon name="plus" /> Pair a server
          </button>
        </aside>

        <section className="editor-workspace">
          {actionError && <div className="inline-alert error">{actionError}</div>}
          {notice && <div className="inline-alert success">{notice}</div>}

          {workspace === "servers" && <>
            <WorkspaceHeader eyebrow="Servers" title="Your servers"
              description={`${online} of ${servers.length} connected`}
              action={<button className="button button-primary button-small" type="button" onClick={() => setWorkspace("pair")}><Icon name="plus" /> Pair server</button>} />
            {servers.length === 0 ? <EmptyServers /> : (
              <div className="editor-table server-table">
                <div className="editor-table-head"><span>Name</span><span>Status</span><span>Version</span><span>Last seen</span><span>Access</span><span /></div>
                {servers.map((server) => <ServerTableRow server={server} key={server.id} />)}
              </div>
            )}
          </>}

          {workspace === "pair" && <>
            <WorkspaceHeader eyebrow="Servers" title="Pair a server" description="Connect another CoreDSC installation to this account." />
            <div className="plain-section pairing-guide">
              <ol>
                <li><span>1</span><div><strong>Create a link</strong><p>Run <code>/coredsc editor</code> from the Minecraft server console or an allowed account.</p></div></li>
                <li><span>2</span><div><strong>Open the link</strong><p>Sign in with Discord. The page shows a short confirmation command.</p></div></li>
                <li><span>3</span><div><strong>Confirm locally</strong><p>Run the displayed command on the same server. It will then appear in the list on the left.</p></div></li>
              </ol>
              <a className="text-link" href="https://github.com/nulli0on/coredsc-doc">Open the full setup guide <Icon name="chevron" /></a>
            </div>
          </>}

          {workspace === "networks" && <>
            <WorkspaceHeader eyebrow="Networks" title={activeNetwork?.name ?? "Networks"}
              description={activeNetwork ? `${activeNetwork.server_count} server${activeNetwork.server_count === 1 ? "" : "s"}` : "Apply the same supported settings to several servers."} />

            <div className="network-editor-layout">
              <section className="plain-section network-sidebar-panel">
                <h2>Create network</h2>
                <p>Use a network to group servers that share configuration.</p>
                <label>Network name<input maxLength={80} value={networkName} onChange={(event) => setNetworkName(event.target.value)} placeholder="Production servers" /></label>
                <button type="button" className="button button-primary button-small" disabled={busy} onClick={() => void createNetwork()}>Create network</button>

                <hr />
                <h2>Add server</h2>
                <label>Server<select value={selectedServer} onChange={(event) => setSelectedServer(event.target.value)}><option value="">Choose a server</option>{availableServers.map((server) => <option value={server.id} key={server.id}>{server.name}</option>)}</select></label>
                <button type="button" className="button button-secondary button-small" disabled={busy || !selectedNetwork || !selectedServer} onClick={() => void addServer()}>Add to network</button>
              </section>

              <div className="network-editor-main">
                {!activeNetwork && <div className="empty-state"><span className="empty-icon"><Icon name="network" /></span><h3>Select or create a network</h3><p>Networks appear in the left sidebar.</p></div>}
                {activeNetwork && !networkDetails && <div className="empty-inline"><Icon name="activity" /> Loading network…</div>}
                {networkDetails && <>
                  <section className="plain-section">
                    <div className="section-bar"><div><h2>Servers</h2><p>Members of this network.</p></div><span>{networkDetails.members.length}</span></div>
                    <div className="editor-table member-table">
                      <div className="editor-table-head"><span>Name</span><span>Status</span><span>Version</span><span>Last seen</span><span /></div>
                      {networkDetails.members.length ? networkDetails.members.map((member) => (
                        <div className="editor-table-row" key={member.id}>
                          <span className="table-primary"><i className="server-initials">{member.display_name.slice(0, 2).toUpperCase()}</i><strong>{member.display_name}</strong></span>
                          <span><i className={member.status === "ONLINE" ? "status-dot online" : "status-dot"} /> {member.status === "ONLINE" ? "Connected" : "Offline"}</span>
                          <span>CoreDSC {member.plugin_version || "unknown"}</span>
                          <span>{relativeTime(member.last_seen_at)}</span>
                          <span><button type="button" className="text-button danger" disabled={busy} onClick={() => void removeServer(member.id)}>Remove</button></span>
                        </div>
                      )) : <div className="empty-inline">No servers in this network.</div>}
                    </div>
                  </section>

                  <section className="plain-section template-editor">
                    <div className="section-bar"><div><h2>Configuration template</h2><p>Save supported settings and apply them to every server in the network.</p></div></div>
                    <div className="form-row">
                      <label>Saved template<select value={selectedTemplate} onChange={(event) => chooseTemplate(event.target.value)}><option value="">New template</option>{networkDetails.templates.map((template) => <option value={template.id} key={template.id}>{template.name}</option>)}</select></label>
                      <label>Template name<input maxLength={80} value={templateName} onChange={(event) => setTemplateName(event.target.value)} placeholder="Production settings" /></label>
                    </div>
                    <label>Changes<textarea rows={11} spellCheck={false} value={templateJson} onChange={(event) => setTemplateJson(event.target.value)} /></label>
                    <div className="button-row"><button type="button" className="button button-secondary button-small" disabled={busy} onClick={() => void saveTemplate()}>{selectedTemplate ? "Save template" : "Create template"}</button>{selectedTemplate && <button type="button" className="text-button danger" disabled={busy} onClick={() => void deleteTemplate()}>Delete template</button>}</div>
                    <label>Reason for this change<input maxLength={500} value={applyReason} onChange={(event) => setApplyReason(event.target.value)} placeholder="Why are these settings being applied?" /></label>
                    <button type="button" className="button button-primary" disabled={busy || !selectedTemplate || !networkDetails.members.length} onClick={() => void applyTemplate()}>Apply to network</button>
                    <p className="form-help">Some servers may ask another administrator to approve the change before it is applied.</p>
                  </section>
                </>}
              </div>
            </div>
          </>}
        </section>
      </div>
    </main>
  );
}

function parseTemplate(value: string): Record<string, unknown> {
  let parsed: unknown;
  try { parsed = JSON.parse(value); } catch { throw new Error("Template changes must be valid JSON."); }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("Template root must be a JSON object.");
  return parsed as Record<string, unknown>;
}

function messageOf(failure: unknown) {
  return failure instanceof Error ? failure.message : "The request could not be completed.";
}

function WorkspaceHeader({ eyebrow, title, description, action }: { eyebrow: string; title: string; description: string; action?: React.ReactNode }) {
  return <header className="workspace-header"><div><span>{eyebrow}</span><h1>{title}</h1><p>{description}</p></div>{action}</header>;
}

function ServerBrowserRow({ server }: { server: CoreServer }) {
  return <Link className="browser-row" href={`/dashboard/${server.id}`}>
    <span className="browser-row-icon server-initials">{server.name.slice(0, 2).toUpperCase()}</span>
    <span><strong>{server.name}</strong><small>{server.online ? "Connected" : "Offline"}</small></span>
    <i className={server.online ? "status-dot online" : "status-dot"} />
  </Link>;
}

function ServerTableRow({ server }: { server: CoreServer }) {
  return <Link className="editor-table-row" href={`/dashboard/${server.id}`}>
    <span className="table-primary"><i className="server-initials">{server.name.slice(0, 2).toUpperCase()}</i><strong>{server.name}</strong></span>
    <span><i className={server.online ? "status-dot online" : "status-dot"} /> {server.online ? "Connected" : "Offline"}</span>
    <span>{server.minecraftVersion || "Minecraft unknown"}<small>CoreDSC {server.pluginVersion || "3.4.2"}</small></span>
    <span>{relativeTime(server.lastSeenAt)}</span>
    <span>{server.role.replaceAll("_", " ").toLowerCase()}</span>
    <span className="row-arrow"><Icon name="chevron" /></span>
  </Link>;
}

function Avatar({ user }: { user: CoreUser | null }) {
  if (user?.avatar) return <Image unoptimized width={32} height={32} className="account-avatar" alt="" src={`https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=64`} />;
  return <span className="account-avatar fallback">{user?.displayName?.slice(0, 1).toUpperCase() ?? "?"}</span>;
}

function LoadingScreen() { return <main className="center-state"><span className="loading-mark"><Brand compact /></span><p>Loading dashboard…</p></main>; }
function SignInState({ error }: { error: string }) { return <main className="center-state"><Brand /><h1>Sign in with Discord</h1><p>{error}</p><a className="button button-primary" href={oauthUrl("/dashboard")}><Icon name="discord" /> Sign in</a></main>; }
function UnavailableState({ error }: { error: string }) { return <main className="center-state"><Brand /><h1>Dashboard unavailable</h1><p>{error}</p><button className="button button-secondary" onClick={() => window.location.reload()}>Try again</button></main>; }
function EmptyServers() { return <div className="empty-state"><span className="empty-icon"><Icon name="server" /></span><h3>No paired servers</h3><p>Choose “Pair server” and follow the three steps.</p></div>; }
