export const API_BASE = (process.env.NEXT_PUBLIC_COREDSC_API_BASE ?? "/api").replace(/\/$/u, "");

export type CoreUser = { id: string; username: string; displayName: string; avatar: string | null };
export type CoreServer = {
  id: string;
  name: string;
  pluginVersion: string;
  minecraftVersion: string;
  scheduler: string;
  online: boolean;
  status: string;
  lastSeenAt: number;
  cleanShutdownAt: number | null;
  approvalMode: boolean;
  role: string;
  capabilities: string[];
};

export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

export async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  const method = String(init.method ?? "GET").toUpperCase();
  const attempts = method === "GET" ? 3 : 1;
  let lastError: unknown;
  for (let attempt = 0; attempt < attempts; attempt += 1) {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15_000);
    try {
      const response = await fetch(`${API_BASE}${path}`, { ...init, signal: controller.signal, credentials: "include", headers: {
        Accept: "application/json",
        ...init.headers,
      } });
      const body = await response.json().catch(() => ({})) as Record<string, unknown>;
      if (response.ok) return body as T;
      const error = new ApiError(response.status, typeof body.error === "string" ? body.error : "Request failed");
      if (attempt + 1 >= attempts || ![408, 425, 429, 502, 503, 504].includes(response.status)) throw error;
      lastError = error;
    } catch (failure) {
      lastError = failure;
      if (attempt + 1 >= attempts || failure instanceof ApiError) throw failure;
    } finally {
      clearTimeout(timeout);
    }
    await new Promise((resolve) => setTimeout(resolve, 350 * (2 ** attempt)));
  }
  throw lastError instanceof Error ? lastError : new Error("Request failed");
}

export function csrfHeader(token: string): HeadersInit {
  return { "Content-Type": "application/json", "X-CoreDSC-CSRF": token };
}

export function oauthUrl(returnPath: string): string {
  return `${API_BASE}/v1/auth/discord?return=${encodeURIComponent(returnPath)}`;
}

export function liveUrl(path: string): string {
  if (typeof window === "undefined") return "";
  const base = new URL(API_BASE || "/", window.location.href);
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  base.pathname = `${base.pathname.replace(/\/$/u, "")}${normalizedPath}`;
  base.search = "";
  base.hash = "";
  base.protocol = base.protocol === "https:" ? "wss:" : "ws:";
  return base.toString();
}

export function relativeTime(timestamp: number): string {
  if (!timestamp) return "Never";
  const seconds = Math.max(0, Math.round((Date.now() - timestamp) / 1000));
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}
