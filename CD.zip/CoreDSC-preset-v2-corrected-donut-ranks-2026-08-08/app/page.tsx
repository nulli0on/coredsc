import Link from "next/link";
import { Brand, Icon } from "./ui";

const workspaceRows = [
  ["server", "Server setup", "Review setup checks and edit supported configuration."],
  ["shield", "Moderation", "Open cases, issue actions and add staff notes."],
  ["channel", "Discord tools", "Manage channels, scheduled events and AutoMod rules."],
  ["users", "Staff access", "Add staff, set roles and review approvals."],
] as const;

const docsUrl = "https://github.com/nulli0on/coredsc-doc";
const changelogUrl = "https://github.com/nulli0on/coredsc-doc/blob/main/doc/docs/changelog.md";
const signInUrl = "/api/v1/auth/discord?return=/dashboard";

export default function Home() {
  return (
    <main className="public-editor-shell">
      <header className="public-topbar">
        <Brand />
        <div className="public-topbar-path"><span>/</span><strong>Dashboard</strong></div>
        <nav className="public-topbar-links" aria-label="Project links">
          <a href={docsUrl}>Documentation</a>
          <a href={changelogUrl}>Changelog</a>
          <a href="https://github.com/nulli0on">GitHub</a>
        </nav>
        <Link className="button button-primary button-small" href={signInUrl}>
          <Icon name="discord" /> Sign in
        </Link>
      </header>

      <div className="public-editor-body">
        <aside className="public-resource-browser" aria-label="Public navigation">
          <div className="public-browser-heading">CoreDSC</div>
          <nav className="public-browser-nav">
            <Link className="active" href="/"><Icon name="home" /> Overview</Link>
            <a href={docsUrl}><Icon name="book" /> Documentation</a>
            <a href={changelogUrl}><Icon name="history" /> Changelog</a>
            <a href="https://github.com/nulli0on"><Icon name="github" /> GitHub</a>
          </nav>
          <div className="public-browser-footer">
            <span>CoreDSC Panel 1.3.1</span>
            <small>Paper and Folia</small>
          </div>
        </aside>

        <section className="public-workspace">
          <header className="public-workspace-header">
            <div>
              <span className="workspace-path">CoreDSC / Dashboard</span>
              <h1>Manage your CoreDSC servers</h1>
              <p>Sign in with Discord to open the servers you own or help manage.</p>
            </div>
            <Link className="button button-primary" href={signInUrl}>
              <Icon name="discord" /> Continue with Discord
            </Link>
          </header>

          <div className="public-workspace-grid">
            <section className="public-panel public-tools-panel">
              <div className="public-panel-header">
                <div><h2>Server workspace</h2><p>Available after you sign in.</p></div>
              </div>
              <div className="public-tool-list">
                {workspaceRows.map(([icon, title, body]) => (
                  <div className="public-tool-row" key={title}>
                    <span className="public-tool-icon"><Icon name={icon} /></span>
                    <div><strong>{title}</strong><p>{body}</p></div>
                  </div>
                ))}
              </div>
            </section>

            <aside className="public-panel public-connect-panel">
              <div className="public-panel-header">
                <div><h2>Connect a server</h2><p>First-time setup</p></div>
              </div>
              <ol>
                <li><span>1</span><div><strong>Enable cloud control</strong><p>Finish the plugin and Worker setup.</p></div></li>
                <li><span>2</span><div><strong>Create a link</strong><p>Run <code>/coredsc editor</code> in Minecraft or the local server console.</p></div></li>
                <li><span>3</span><div><strong>Confirm access</strong><p>Open the link, sign in and enter the shown command in the local console.</p></div></li>
              </ol>
              <a className="text-link" href={docsUrl}>Open setup documentation <Icon name="chevron" /></a>
            </aside>
          </div>

          <div className="public-workspace-note">
            <Icon name="lock" />
            <p><strong>No public server list.</strong> You only see servers assigned to your Discord account.</p>
          </div>
        </section>
      </div>
    </main>
  );
}
