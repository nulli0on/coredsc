# CoreDSC plugin 3.4.2 and Panel 1.3.1

CoreDSC is a source-available Minecraft and Discord operations platform for Paper/Folia servers. This source package contains CoreDSC plugin 3.4.2 and CoreDSC Panel/control-plane 1.3.1.

The Java plugin and its generated configuration templates use version `3.4.2`. The dashboard and control-plane package manifests and live health response use version `1.3.1`. Stage changes on a recoverable test server, review local policy and keep verified backups.

## Components

- `plugin/` — Java 21 Paper/Folia plugin, local Discord bot, SQLite persistence, configuration validation, moderation, incidents, maintenance, scheduling, AutoMod, Smart Console and network operations.
- `app/`, `worker/` — editor-style hosted dashboard and first-party API proxy for the Sites workflow declared in `.openai/hosting.json`.
- `control-plane/` — Cloudflare Worker with Discord OAuth, D1, Durable Objects, server pairing, role/capability enforcement, approvals, idempotency, audit records, health tracking and the official preset registry.
- `plugin/src/main/java/.../PresetService.java` — data-only preset installer for approved multi-module configurations stored as small descriptors under `plugins/CoreDSC/configs/`.
- `control-plane/migrations/` — ordered D1 schema migrations.

## Security model

The customer server remains the authority for every remote operation.

- The plugin opens one outbound TLS WebSocket. No inbound Minecraft-server port is required.
- The Discord bot token stays on the customer server and is never sent through the cloud protocol.
- The protocol exposes only named operations. It does not expose arbitrary files, `secrets.yml`, databases, backups or private keys.
- The Worker checks sessions, first-party origin, CSRF, grants, capabilities, payload bounds, rate limits, approvals and idempotency.
- The plugin independently checks capabilities, feature switches, command allowlists, protected identities, Discord hierarchy, configuration paths, revisions and payload bounds.
- Configuration writes require validation, an allowlisted path, a current revision, a local backup and local application.
- High-risk operations use two-person approval where configured. The requester cannot approve their own request.
- Bukkit/Paper access must re-enter the proper global, region or entity scheduler. Player objects are not retained across database, Discord, cloud or asynchronous callbacks.

## Verified configuration presets

CoreDSC includes a PlaceholderAPI-style preset workflow for approved, data-only configuration packages. Format-2 presets use a readable descriptor under `plugins/CoreDSC/configs/` and can bootstrap controlled Discord/LuckPerms resources without executing downloaded code.

The DonutSMP-inspired descriptor flow is:

```text
/coredsc preset reload
/coredsc preset enable donutsmp
/coredsc preset status donutsmp
/coredsc preset preview donutsmp
/coredsc preset apply donutsmp
/coredsc preset repair donutsmp
```

`donutsmp` 0.4 can create missing Discord roles, categories and channels, configure CoreDSC-owned channel permissions and role ordering, publish managed information/ticket/self-role surfaces, create the separate DonutRanks-style LuckPerms groups (Owner, Manager, Dev, Sr Admin, Admin, Sr Mod, Mod, Sr Helper, Helper, Media and Donut+), and then apply the verified CoreDSC configuration package. If an object with the expected name already exists, CoreDSC stops and asks the operator to switch to `USE_EXISTING` and provide the exact Discord ID instead of silently adopting it.

Every preset mutation creates an immutable CoreDSC rollback snapshot. `/coredsc rollback use <snapshot-id>` is confirmation-gated through `/coredsc confirm <code>` and creates an additional `before-rollback` safety snapshot. When restoring to a state before preset-created external resources existed, CoreDSC removes only resources recorded as `CREATED` by that preset; reused administrator resources are never included in that cleanup plan. If external cleanup cannot complete, the CoreDSC files/state remain restored and the warning is surfaced explicitly.

Presets remain declarative. They cannot execute downloaded Java/JAR, Python, shell commands or arbitrary filesystem operations. Package writes still use the normal configuration allowlist, revisions, validation, backups and atomic replacement. Reused Discord/LuckPerms resources are not mutated by preset v2 because those external changes cannot yet be losslessly restored.

## Hosted media without R2

R2 is not used. Dashboard image uploads are restricted to PNG, JPEG, WebP or GIF, at most 512 KiB. The Worker validates the declared type and file signature, sends the image as Base64 only to the authenticated local agent, and does not persist the image body in D1 or audit records. The plugin stores accepted media locally under its own data directory and returns a content-addressed `coredsc-media://` reference.

The plugin revalidates the stored digest, file signature and size on resolution, rejects symbolic links, and uses bounded reads. Base64 is a transport encoding, not free cloud object storage; the strict size limit avoids unbounded Worker, Durable Object, D1 and WebSocket costs.

## Default safety posture

The official CoreDSC build enables the outbound hosted control-plane connection by default and points it at `wss://dash.coredsc.workers.dev/api/v1/agent/connect`, so `/coredsc editor` works on a fresh installation without a manual endpoint edit. Operators can set `enabled: false` to opt out or override the endpoint when intentionally self-hosting. Remote console execution remains disabled by default and still requires its local allowlist plus the cloud-side role/approval checks.

The default remote command allowlist is limited to:

```text
list
tps
mspt
say
whitelist
```

Review `plugin/src/main/resources/modules/cloud-control.yml` before enabling the agent.

## Documentation

- [SETUP.md](SETUP.md) — local build, server installation, Cloudflare deployment order, Discord OAuth and pairing.
- [REFERENCE.md](REFERENCE.md) — commands, permissions, roles, operations, bindings, migrations and default configuration.
- [CHANGELOG.md](CHANGELOG.md) — release changes, completed checks and remaining external verification.

## Verification status of this source delivery

The dependency-free dashboard/Worker syntax gate and **115 local automated tests** pass for this source package. The full control-plane `tsc --noEmit` gate and production Panel build require successful lockfile installation. Coverage includes D1-compatible approval and retry flows, canonical approval payloads, persistent idempotency and replay results, repeated network rollouts, ownership recovery, stale revisions, offline cached reads, OAuth state/session/CSRF handling, exact role matrices, rate limits, bounded media transport, Durable Object socket replacement/reconnect behavior, dashboard-operation policy coverage, concurrent-submission guards, bounded shutdown drains, capability separation, fail-closed defaults and release-version consistency.

A dependency-free Java 21 release harness also passes with `-Xlint:all -Werror`. It executes strict JSON parser/encoder checks, canonical local idempotency fingerprints, WebSocket fragment and UTF-8 boundary checks, persistent Ed25519 identity validation, content-addressed media integrity checks, symlink rejection, concurrent duplicate installation and all supported image signatures.

The execution environment could not complete the full Maven build or either lockfile installation: Maven was not installed and the configured package infrastructure could not provide the required artifacts. Therefore this source tree is internally versioned as plugin `3.4.2` and Panel `1.3.1`, but this delivery must not be represented as having passed any gate that was not actually executed, including real Paper/Folia, Cloudflare-account or Discord-account tests. See `CHANGELOG.md` for the precise limitations.

## License

CoreDSC is licensed under the HubertStudios Source License in [LICENSE](LICENSE). It is source-available, not open source. Third-party dependencies remain under their respective licenses.
