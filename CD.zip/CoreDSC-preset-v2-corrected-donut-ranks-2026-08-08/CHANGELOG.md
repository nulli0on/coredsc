# Changelog

## 3.4.2 / Panel 1.3.1 preset v2 bootstrap + global rollback — 2026-08-08

- Added format-2 preset descriptors with `enable`, `status`, `preview`, `apply` and `repair` lifecycle commands while retaining the existing data-only official registry package model.
- Upgraded the verified DonutSMP-inspired preset to **0.4.0** with bounded Discord role/category/channel bootstrap, explicit `CREATE_MISSING` / `USE_EXISTING` modes, managed role ordering, bot-safe channel permissions, generated information messages and the independent DonutRanks-style LuckPerms groups from the supplied export. Discord activity level roles are now explicitly Discord-only and are not synchronized into Minecraft.
- Existing Discord objects are never silently adopted: matching names cause an actionable conflict that asks for the exact ID under `USE_EXISTING`. Reused resources are not mutated by preset v2.
- Added durable preset resource ownership and operation journals so repeated apply/repair is idempotent and distinguishes `CREATED` from `REUSED`.
- Added CoreDSC-wide immutable rollback snapshots plus `/coredsc rollback list`, `/coredsc rollback use <id>` and confirmation-gated `/coredsc confirm <code>`. Restores create a `before-rollback` safety snapshot first.
- Rollback reconciliation now removes only CoreDSC-created Discord messages/channels/categories/roles and LuckPerms groups that were absent from the target snapshot; reused administrator resources are excluded. Cleanup warnings are surfaced instead of being hidden.
- Updated the dashboard/control-plane preset operations for descriptor status, enable/disable, preview, apply and repair.
- Fixed strict-compile blockers discovered during this work, including an invalid Java regex escape and a missing format parser helper.
- `npm run release:local` passes with **115/115** control-plane/contract tests; focused service compilation passes with Java 21 `-Xlint:all -Werror`.

## 3.4.2 / Panel 1.3.1 pre-release regression hardening — 2026-08-07

- Reject stale Tickets V2 panel buttons and stale Self Role selectors by validating the active configured channel/message before mutating state.
- Ignore Discord DMs in the activity-level listener and make tied-XP leaderboard positions use the same competition ranking as `/rank`.
- Reconcile the configured verification role when Discord `/link` is used by an already-linked user; diagnose missing Manage Roles / bot-role hierarchy before assignment.
- Persist preset descriptor and ownership state through durable same-directory temporary files with atomic replacement where supported.
- Add guarded Tickets V2 `panel.publish-on-startup`; Donut preset 0.3 enables it so its support panel publishes/updates when Discord becomes ready without concurrent duplicate publishes.
- Expanded regression coverage to **109/109 passing control-plane/contract tests**.

## 3.4.2 / Panel 1.3.1 Donut preset 0.3 feature checkpoint — 2026-08-07

- Added bidirectional account-link code flows with `MINECRAFT_TO_DISCORD`, `DISCORD_TO_MINECRAFT` and `BOTH`; the Donut preset uses Discord `/link` → ephemeral code → Minecraft `/link CODE`.
- Extended the link-code persistence schema so Discord-first and Minecraft-first codes remain direction-bound, expiring and single-use.
- Added the generic `self-roles` module with managed Discord select panels, single/multiple selection modes, emoji options, persistent panel message IDs, role-hierarchy checks and Discord-side `/roles setup|add-group|add-option|remove-option|reload|publish` administration.
- Added the generic `discord-levels` module with persistent anti-spam activity XP, configurable XP curve, `/rank`, `!rank`, `/levels`, leaderboard positions and `HIGHEST_ONLY`/`CUMULATIVE` milestone-role reconciliation.
- Bumped the local SQLite schema to 14 for link-direction state, self-role panel state and Discord-level persistence.
- Upgraded the verified `donutsmp` preset to **0.3.0**, composing Discord-first verification, linked chat, Tickets V2, Platform/Age/Region/Notification self roles and level roles at 1/3/5/10/20/30/40/50/60/70/80.
- Grouped the large Donut preset setup form in the dashboard and use discovered guild/channel/category/role selectors where possible; raw IDs remain a fallback.
- Fixed the Tickets V2 dashboard role selector so discovered Discord roles are actually loaded into the editor.
- Strict focused Java 21 compilation with `-Xlint:all -Werror` passes for the Discord-first link path, Self Roles, Discord Levels and schema changes.
- `npm run release:local` passes with the full **98/98** dependency-free control-plane/contract suite.

## 3.4.2 / Panel 1.3.1 Tickets V2 rework checkpoint — 2026-08-07

- Replaced the single-parent ticket flow with typed **Tickets V2** configuration: reusable ticket types, button panels, category channels or legacy threads, per-type staff roles, dynamic Discord modal fields and per-type link requirements.
- Added Discord `/ticket setup` administration with channel/category/role selectors, panel publishing, type/content/routing editing and question management.
- Added a hosted-dashboard **Tickets** editor for panel lifecycle, ticket types, Discord destinations, staff roles and modal fields.
- Added `ticket.view` / `ticket.manage` cloud capabilities and explicit deny-by-default operation policy entries.
- Added upgrade-safe `ticket_type` and `form_data` persistence while retaining legacy 3.4.x thread configuration as a synthetic legacy type.
- Added lifecycle logs, bounded closing transcripts, configurable LOCK/DELETE close behavior and optional closed-ticket category routing.
- Ticket type removal now refuses to delete a type with active tickets, and historical form rendering uses the immutable submission snapshot rather than the current editable form schema.
- Ticket configuration changes use ConfigManager optimistic revisions, backups, reload/rollback, and CoreDSC-owned bounded asynchronous scheduling instead of the JVM common pool.
- Extended Discord discovery with manageable roles so the dashboard can use actual role selectors instead of requiring raw snowflake IDs.
- Updated the verified `donutsmp` preset to 0.2.0 with Ban Appeal, Bug Report and Other Tickets V2 flows.
- Expanded the dependency-free control-plane/contract suite to **95/95 passing tests**.

## 3.4.2 / Panel 1.3.1 preset-platform + dashboard-reliability checkpoint — 2026-08-07

- Added the approved CoreDSC preset registry and single-file descriptors under `plugins/CoreDSC/configs/`.
- Added `/coredsc preset browse|list|install|update|remove|reload` and the `coredsc.preset` permission.
- Added the dashboard **Configs** marketplace/manager with required-variable setup, install, update and removal actions.
- Added the first `donutsmp` foundation preset for linking, linked chat and the existing ticket module; it deliberately does not advertise the still-unimplemented Donut-style level/self-role/Ticket V2 features.
- Preset packages are data-only, same-host HTTPS downloads with bounded responses and SHA-256 integrity checks; file/path/value changes are restricted to the normal CoreDSC configuration allowlist.
- Preset updates now perform a three-way comparison and preserve administrator values changed after installation.
- Separated preset HTTP completion work from the single-thread preset transaction executor, preventing a synchronous install from starving its own HTTP client.
- Configuration **Save & apply** now sends the transaction backup, waits for the agent to reconnect and confirms a fresh snapshot before reporting success.
- Failed hosted configuration applies restore the structured-edit backup and reload the previous configuration when a transaction backup is available.
- Preset install/update/remove paths use the same reload-or-restore behavior, preventing a failed runtime reload from leaving a bad disk configuration behind.
- Added bounded GET timeouts/retries and retry-stable mutation idempotency to the dashboard API path.
- Updated user-facing dashboard terminology and the separate documentation bundle for the hosted control plane and preset system.
- Expanded the dependency-free control-plane/contract suite to **91/91 passing tests**.

## 3.4.2 / Panel 1.3.1 production-audit hotfix — 2026-08-07

- Restored Durable Object instance identity across WebSocket hibernation so resumed agent traffic cannot mutate D1 with an empty server identity.
- Made first-agent registration race-safe and stopped misclassifying unrelated D1 failures as nonce replays.
- Added a Java single-flight guard for outbound cloud WebSocket handshakes.
- Added `cloud-control` to the bStats module-adoption chart.
- Changed the official packaged cloud-control defaults to enabled with `wss://dash.coredsc.workers.dev/api/v1/agent/connect`; remote console remains disabled and locally allowlisted.
- Fixed `/coredsc setup <enable|disable>` drift so `cloud-control`, `competitive`, `economy-market`, and `lore-sync` are supported like the runtime module registry.
- Added regression contracts for the hosted endpoint and setup-module registry alignment.
- The dependency-free control-plane/contract suite passes **85/85** after this hotfix.
- Fixed pairing-page lifecycle handling so only a real `401` is shown as a Discord sign-in requirement and expired links stop polling with an actionable message instead of waiting forever.
- Made cloud-agent shutdown idempotent even before `start()`, preventing executor leakage when initialization fails between construction and connection startup.
- Made asynchronous cloud-module initialization failures unregister listeners, cancel scheduled tasks, clear runtime references, and surface the actual failed state instead of pretending the agent is still initializing.

## Plugin 3.4.2 / Panel 1.3.1 — 2026-08-04

- Separated the release identifiers: the Minecraft plugin is now `3.4.2`, while the hosted Panel and control plane are `1.3.1`.
- Updated Maven metadata, `plugin.yml`, generated configuration markers, dashboard fallbacks, package manifests, lockfiles and the control-plane health response.
- Included the `CONTROL_PLANE -> coredsc-control-plane` service binding in `vite.config.ts` so a clean deployment no longer requires a manual source edit.
- Replaced the deployment guide with a browser-only GitHub Codespaces and Cloudflare workflow for users without a local PC.
- Documented safe update order, existing D1 recovery, Cloudflare web-secret management, Codespaces plugin builds, Wrangler configuration conflicts and hosted-editor verification.

## 3.4.1 hosted-editor correction — 2026-08-04

- Removed the separate loopback WebEditor module, `/coredsc webeditor`, its permission, static local UI and modular configuration. `/coredsc editor` is now the only editor entry point.
- Kept first-owner pairing on the hosted dashboard with Discord sign-in and local-console confirmation, and added a full create/claim/confirm regression test for the agent path.
- Removed the misleading pre-confirmation dashboard link: the pairing page now shows one console command, waits for confirmation, and opens the server automatically.
- Added a packaged Python-bot README template that CoreDSC writes automatically to `plugins/CoreDSC/bot/README.md` on first start.
- Rebuilt the unauthenticated dashboard as a compact editor workspace instead of a marketing-style landing page.
- Made the control-plane test runner enumerate tests directly and run them sequentially for deterministic local results.

## 3.4.1 — 2026-08-03

### Dashboard editor redesign

- Replaced the previous card-based dashboard structure with an editor-style application frame inspired by the LuckPerms web editor: a compact resource browser, grouped server tools and one focused workspace.
- Matched the CoreDSC documentation palette, logo, system typography, neutral surfaces, thin borders and restrained red accents instead of applying a color-only theme change.
- Rebuilt the server list, network workspace, per-server navigation, configuration editor, pairing flow, empty states, tables and mobile layout around the new information architecture.
- Rewrote public and dashboard copy in plain administrative language and removed internal implementation terms from normal user-facing pages.
- Added friendly labels for roles, operations, outcomes, connection states and server runtime details while leaving backend identifiers unchanged.
- Preserved every existing backend route, operation, role and capability check.

### Reliability corrections

- Preserved active maintenance join and chat restrictions across plugin restarts instead of automatically cancelling persisted maintenance state.
- Made Incident Mode channel restoration operation-owned, retryable after partial restoration and resistant to restoring snapshots created by unrelated channel operations.
- Added rollback for partially applied incident channel locks when incident startup fails; if rollback or state cleanup fails, the persisted incident remains active for an authorized restoration retry.
- Prevented Incident Mode and Maintenance from cancelling each other's chat-pause ownership.
- Prevented a late WebSocket open callback from reconnecting the cloud agent after plugin shutdown.
- Completed reversible slowmode operations with an authorized `channel.slowmode.restore` path in the dashboard, Worker policy and local agent.
- Deleted a newly created Discord scheduled event when local persistence fails, avoiding an unmanaged remote event.
- Prevented stale/replaced Durable Object agent sockets from delivering messages or disconnecting the current agent.
- Waited a bounded three seconds for the Discord shutdown event before module and JDA teardown, while retaining the existing bounded SQLite drain.
- Prevented rapid duplicate dashboard mutations, network rollouts, staff changes and approval decisions from issuing concurrent requests with different operation identities.

### Portability and verification fixes

- Removed the hardcoded original Codespace path from the release-contract tests; project discovery now derives the source root from `import.meta.url`.
- Decoded filesystem URLs with `fileURLToPath` so validation works from folders containing spaces instead of looking for literal `%20` paths.
- Made the optional plugin safety harness skip explicitly in the dashboard/control-plane-only archive while remaining mandatory whenever plugin sources are present.
- Clarified that npm audit findings are separate from Worker test failures and must not be force-upgraded without advisory review.
- Made nested build scripts run explicitly through Bash so ZIP extraction cannot cause `sites-env.sh: Permission denied`.
- Added an explicit Node.js and archive-completeness check before control-plane TypeScript and test execution.

### Control-plane hardening

- Made first-owner pairing claims conditional and atomic so concurrent claims cannot overwrite an existing owner.
- Canonicalized approval payload storage/comparison and repaired replay responses so retries return the original operation result and audit identifier.
- Replaced unbounded JSON text decoding with a bounded streaming read and fatal UTF-8 validation.
- Rejected OAuth return paths containing backslashes or control characters.

### Verification added

- Added OAuth state-binding, one-time-use, redirect-sanitization, session-expiry, CSRF logout and owned-server pairing authorization tests.
- Added exact role/capability matrices, repeated rollout idempotency, media-boundary/signature, D1 migration, active Durable Object socket and duplicate/reconnect tests.
- Added source contracts for overlapping incident/maintenance restoration, retry-safe incident restoration, scheduled-event rollback, stale configuration revisions, configuration allowlists, backup/rollback, protected identities, Discord hierarchy, command allowlists, payload bounds, optional-module isolation, bounded SQLite shutdown and late WebSocket open handling.
- The dashboard TypeScript syntax gate, global TypeScript no-emit gate, Java 21 release safety harness and **75/75** dependency-free control-plane/contract tests pass.

### Verification not completed in this environment

- `mvn -e clean verify`, JUnit execution, shading and JAR inspection were not run because `mvn` was unavailable and the available package infrastructure could not supply Maven artifacts.
- Root `npm ci` failed because the configured registry could not provide the locked `zod-validation-error@4.0.2` tarball; root lint, production build and rendered-page tests therefore did not run.
- `control-plane/npm ci` failed because the configured registry could not provide the locked `youch-core@0.3.3` tarball; Wrangler checks, migration execution and local Worker preview therefore did not run.
- Browser QA, realistic Paper/Folia runtime tests and optional-integration runtime matrix tests were not performed.
- Cloudflare and Discord account tests remain external because no deployment credentials or test guild were provided.

## 3.4.0 — 2026-08-02

### Release conversion

- Removed the CoreDSC prerelease suffix from the Maven project, plugin metadata, package manifests, lockfiles, control-plane health response, dashboard fallbacks, managed configuration templates, tests and documentation.
- The distributable plugin filename is now `CoreDSC-3.4.0.jar`.
- Added automated release-contract checks that reject inconsistent CoreDSC versions, prerelease markers in release-owned surfaces, additional Markdown documentation, R2 runtime bindings and missing WebSocket/media hardening.

### Added

- Hosted CoreDSC Operations dashboard with authenticated server, moderation, channel, incident, maintenance, event, AutoMod, Smart Console, approval and network surfaces.
- Cloudflare control plane with Discord OAuth, first-party sessions, D1 persistence, Durable Object agent rooms, audit history, health tracking and scheduled cleanup/retry work.
- Explicit capability roles: `OWNER`, `SERVER_ADMIN`, `MODERATOR`, `CONSOLE_VIEWER`, `CONSOLE_OPERATOR`, `SUPPORT` and `VIEWER`.
- Outbound authenticated TLS WebSocket agent with Ed25519 request authentication, replay-resistant nonces and bounded reconnect/backoff behavior.
- Server pairing with local console confirmation.
- Dedicated ownership recovery initiated only from the unbound local server console, with a second local confirmation, atomic owner replacement and audit entry.
- Persistent operation fingerprints and idempotency records for duplicate/retry protection.
- Local SQLite schema 13, adding canonical request fingerprints to completed cloud-operation records while retaining compatibility with legacy rows.
- Approval dispatch leases for restart/crash recovery without duplicate execution.
- D1-backed rate limiting for OAuth, pairing, operations, approvals, staff, uploads and network changes.
- Streaming request-body limits that reject oversized chunked image uploads before unbounded buffering.
- D1 migration `0006_ownership_recovery.sql`.
- Local, content-addressed dashboard media storage through the customer agent.
- Hosted moderation-case history and case-note controls backed by the local cases module.
- Dashboard live-channel reconnect with bounded exponential backoff and visible connection state.
- Dependency-free Java 21 release safety harness under `scripts/java-release-check.sh`.

### Changed

- Removed the R2 dependency and binding.
- Media uploads use bounded Base64 transport only. The Worker accepts PNG, JPEG, WebP and GIF up to 512 KiB, validates magic bytes, forwards the image to the authenticated local agent and does not store the image body in D1 or audit records.
- Cloud control remains disabled by default and uses a deliberately non-routable example endpoint until the operator configures a real deployment. A missing modular setting also fails closed.
- Replaced a decorative landing-page Setup Doctor button with non-operational status text so visible operational controls correspond to real backend calls.
- Separated `case.manage` from `moderation.manage`: SUPPORT may inspect history and add notes without receiving sanction authority; SERVER_ADMIN and MODERATOR retain both capabilities.
- Kept approval rejection available while the Minecraft agent is offline because rejection is a cloud-side final decision and does not dispatch an agent operation.
- Distinguished authentication failures from dashboard/backend outages instead of presenting every load failure as a Discord sign-in requirement.
- Consolidated project documentation into exactly `README.md`, `SETUP.md`, `REFERENCE.md` and `CHANGELOG.md`.
- Removed the obsolete continuation-file reference from the README.

### Fixed and hardened

- Fixed three Java compilation defects found by the first full Maven compile: the DiscordSRV migration now carries its detected plugin instance into linked-account import, the JDA 6 audit permission uses `VIEW_AUDIT_LOGS`, and scheduled-event cancellation retrieves the event before invoking its supported `delete()` action.
- Rejected duplicate JSON object keys instead of silently overwriting security-sensitive fields.
- Rejected raw control characters, non-finite numbers and unpaired Unicode surrogates in the dependency-free JSON codec.
- Added JSON nesting, value-count and string-size limits to stop stack and memory exhaustion; cyclic output structures are rejected.
- Replaced repeated whole-buffer WebSocket UTF-8 rescans with a bounded fragment assembler that correctly handles surrogate pairs split across frames.
- Replaced outbound UTF-8 size checks with allocation-free incremental byte counting and early rejection above the one-megabyte protocol limit.
- Cleared partial WebSocket text on open, close, error and shutdown, and ignored callbacks from replaced sockets so stale fragments cannot contaminate a reconnected session.
- Revalidated local media digest, signature and size before reuse or resolution.
- Rejected symbolic-link media roots/files and used bounded no-follow reads.
- Preserved idempotent concurrent installation of identical content-addressed media.
- Bound persistent and in-flight local idempotency keys to a canonical SHA-256 fingerprint of the operation, payload and audited reason, rejecting same-key request substitution even if the control plane is faulty.
- Hardened the persistent Ed25519 identity file with bounded no-follow reads, create-only writes, key-pair self-validation, strict file-size limits and temporary key-byte clearing.
- Preserved the no-inbound-port architecture and local custody of Discord bot tokens.
- Preserved deny-by-default named operations; arbitrary file access and arbitrary remote commands are not exposed.
- Preserved stale network template revision rejection, rollout idempotency, protected identities, Discord hierarchy, command allowlists, payload limits and feature-switch enforcement.
- Ensured cloud Setup Doctor checks and network announcements cross the appropriate Bukkit scheduler boundary before Bukkit API access.

### Automated checks completed

```text
Control-plane TypeScript no-emit check
51/51 Node tests
Java 21 release safety harness with -Xlint:all -Werror
Git whitespace/error check
```

The passing tests cover:

- approval creation, second-person approval, rejection, expiry and crash/lease retry;
- retryable versus permanent failures;
- direct and approved-operation idempotency;
- duplicate Durable Object messages, disconnects and heartbeats;
- offline redacted configuration cache;
- stale network template revisions and rollout keys;
- owner-only staff changes, ownership recovery and audit writes;
- request-size, parser, media-type, media-size, digest and symlink bounds;
- D1 migration ordering and schema assertions;
- rate limits, role policy and case-note capability separation;
- dashboard operation-to-policy coverage, reconnect behavior and offline approval rejection;
- plugin dependency scopes, fail-closed defaults and static cloud scheduler/Player-boundary contracts;
- complete `3.4.0` release-version consistency across source and runtime surfaces.

### Not verified in this delivery

- A user-side Maven compile reached the Java compiler and exposed three source errors; those exact errors are corrected in this archive. A complete post-fix `mvn -e clean verify`, JUnit run, shading pass and JAR inspection still require execution in an environment with Maven and dependency access.
- Root dashboard `npm ci`, lint, production build and rendered-page tests could not complete because the available npm registry proxy returned HTTP 404 for a locked package tarball. The source does not ship an unsafe dependency workaround.
- Desktop, tablet and mobile browser QA was not performed.
- Real Paper and Folia server tests, optional-integration matrix tests and shutdown-under-load tests were not performed.
- Real Cloudflare deployment, Sites `CONTROL_PLANE` binding, D1, Durable Objects and scheduled triggers require the operator's account and were not executed.
- Real Discord OAuth, guild permissions, role hierarchy and bot behavior require operator credentials and a test guild and were not executed.

Plugin `3.4.2` and Panel/control-plane `1.3.1` are the current release identifiers. This changelog records only checks actually executed; it does not claim that software is defect-free or that unperformed local or external gates passed.
