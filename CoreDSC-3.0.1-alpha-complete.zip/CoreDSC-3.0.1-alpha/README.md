# CoreDSC 3.0.1-alpha complete source bundle

This archive contains the complete editable CoreDSC 3.0.1-alpha source release and its matching documentation site.

## Contents

- `source/` — Java source, tests, Maven metadata, plugin resources, WebEditor assets, migration notes, release notes and verification reports.
- `documentation/` — Docusaurus source, configuration reference, matching default YAML snapshots, scripts, lockfile and attribution notices.

Generated Maven output (`target/`), documentation dependency caches (`node_modules/`) and generated documentation output (`build/`, `.docusaurus/`) are intentionally excluded. They are reproducible build products and the available Maven output belonged to the preceding release checkpoint.

## Release identity

- Maven version: `3.0.1-alpha`
- Bukkit plugin version: `3.0.1-alpha`
- Documentation package version: `3.0.1-alpha`
- Managed configuration marker: `3.0.1-alpha`

## Verification boundary

The Java source parser, WebEditor JavaScript syntax check, documentation validator, release-metadata audit and scheduler-boundary searches passed in the preparation workspace. Per the project owner's request, this exact release was not compiled, tested through Maven, packaged as a JAR or run on a live Paper/Folia/Spigot server here.

Read `source/VERIFICATION-REPORT-3.0.1-alpha.md` before deployment. The owner should run the normal local build and the documented multi-region Folia qualification matrix before treating this alpha as production-certified.
