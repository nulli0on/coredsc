# Folia hardening delta

Date: 2026-08-02

This delta addresses two independent failure classes: cross-region Bukkit access and SQLite contention/backlog. It does not claim live Folia certification; the final source delta is intentionally left for the project owner to compile and run in the server matrix.

## Enforced invariants

| Boundary | Invariant |
|---|---|
| Event to persistence | Event-owned `Player`/`Entity` references are reduced to UUID/name/value snapshots before an asynchronous future starts. |
| Async to player | Callers pass a UUID to `runForPlayer`/`callForPlayer`; only the scheduler implementation resolves a live player and transfers work to its entity scheduler. |
| Async result | Player callbacks return detached values or a delivery boolean. A retired/offline player yields an empty/non-delivery result. |
| Location work | World/block operations remain on `runAtLocation`/`callAtLocation`. |
| Global work | The global scheduler is used for lifecycle, registry and server-wide operations, not as ownership of arbitrary entities. |
| SQLite connection | Only `CoreDSC-SQLite` may open, use, checkpoint or close the persistent JDBC connection. |
| SQLite admission | A bounded FIFO accepts work; saturation fails the future and never blocks/runs JDBC on the caller's Folia region. |
| SQLite transaction | Every transaction executes as one queue entry, so no second CoreDSC operation can interleave before commit/rollback. |
| Shutdown | New database admission stops, accepted work drains in order, WAL is checkpointed, then the connection closes on its owner thread. |

## Main implementation points

- `CoreScheduler`, `PaperFoliaCoreScheduler` and the Spigot fallback now provide UUID-based player re-entry.
- Scheduler-owned futures are completed exceptionally during shutdown instead of being stranded by task cancellation.
- `PlayerDeathListener` is a dedicated primitive hand-off adapter; `CompetitiveModule` receives only its immutable `DeathSnapshot`.
- Economy inventory, report rendering/delivery, workflow placeholders/actions, Python player commands/broadcasts, custom commands, tickets, applications, appeals, voice topology and voice output use detached results or UUID re-entry in their asynchronous paths.
- `SQLiteStorage` owns one connection and a fair bounded `ArrayBlockingQueue`. WAL, NORMAL synchronous mode and foreign keys are verified at startup.
- Queue depth, capacity, peak and rejected count are visible in `/coredsc status` and `/coredsc doctor`.
- `storage.sqlite.queue-capacity` defaults to `8192` and is validated between `256` and `65536`.

## Why HikariCP was not added

SQLite remains a single-writer embedded database. CoreDSC already benefits from one persistent connection and strict serialization. A Hikari pool capped at one would add connection-acquisition and shutdown state without increasing safe write concurrency. The bounded owner queue solves the relevant Folia risks directly: it prevents concurrent writers, caller-thread blocking and unbounded backlog growth.

## Static evidence

- All Java files pass the parser-based syntax check.
- Direct Bukkit/Paper scheduler calls occur only in `PaperCoreScheduler` and `PaperFoliaCoreScheduler`.
- The audited async hand-off paths contain no `CompletableFuture<Player>`, `CompletableFuture<Entity>`, `Optional<Player>` or stored Bukkit entity record.
- Documentation validation passes with 65 pages/routes/sidebar entries.

## Required local gates

1. Run the normal local Maven build and unit suite.
2. Start a disposable Folia instance with players in at least two distant regions.
3. Exercise death/ELO, Discord-to-player delivery, inventory, reports, workflows, Python/custom commands, voice topology, teleport/logout and plugin shutdown.
4. Generate a database burst and confirm tick/region threads never show JDBC frames; inspect queue health through `/coredsc doctor`.
5. Run a shutdown during queued writes, restart, then execute `PRAGMA integrity_check;` against a copy of `data.db`.
