# CoreDSC 2.6.0-alpha.1

This checkpoint prioritizes reliability, security and configuration usability. WebEditor is intentionally labeled alpha and disabled by default.

## Release-blocking defect fixed

Fresh configuration initialization requested the bundled resource `bot/README.md`, while 2.5.2 shipped `bot/READ ME.md`. The mismatch could abort startup before storage or Discord initialized. The resource now has the exact path used by `ConfigManager`.

## WebEditor alpha

- New opt-in `web-editor` module and local-console-only `/coredsc webeditor` session command; RCON is explicitly rejected.
- Loopback binding is mandatory; public addresses are rejected by both configuration validation and module startup.
- Sessions use 256-bit random capabilities, retain only SHA-256 token digests in WebEditor session state and expire after at most 60 minutes.
- The capability is kept in the URL fragment and sent to APIs only through the `Authorization` header.
- The full URL must be shown once in the server console; Paper or hosting-panel logs may retain that console output until rotation, so stop the session immediately after use.
- `secrets.yml`, databases, runtime files, Python scripts and arbitrary paths are excluded by a fixed server-side allowlist.
- Drafts are checked as YAML and validated in the context of the complete modular configuration.
- SHA-256 revisions reject stale browser saves instead of overwriting concurrent panel/SSH edits.
- Every changed file receives a timestamped backup before a same-directory atomic move where supported, with a replacement fallback for other filesystems.
- Saves do not automatically reload modules or reconnect Discord.
- The self-contained UI has no CDN or third-party runtime assets.

## Additional hardening

- Discord remote console can no longer dispatch CoreDSC `reload`, `setup`, `migrate` or `webeditor` administration commands, including common wrapped/namespaced forms.
- WebEditor capability URLs are always redacted from the Discord console feed, even when an administrator removes configurable redaction patterns.
- Configuration writes retain POSIX permissions where supported and force temporary-file content to storage before replacement.
- Module/configuration/metrics registries now include `web-editor` consistently.

## Configuration and compatibility

- Plugin version: `2.6.0-alpha.1`
- Configuration schema: unchanged at `4`
- New file: `plugins/CoreDSC/modules/web-editor.yml`
- Default: disabled; no WebEditor listener starts automatically
- Java: 21
- Platform target: Paper as declared by the project

## Verification boundary

Completed in this checkpoint:

- dependency-independent parse of all Java source files;
- strict YAML parse of bundled YAML files;
- module/resource/selection registry consistency checks;
- managed-resource path checks;
- JavaScript syntax check for the browser client;
- documentation route/link/sidebar validation;
- archive integrity, path-traversal and checksum checks.

Not performed by design:

- Maven or `javac` compilation;
- Paper startup or reload;
- Discord login/API calls;
- browser-to-live-plugin WebEditor test;
- live Redis, Simple Voice Chat, Python worker or license requests.

Do not publish this alpha as a production-ready JAR until the release gates in `COMPETITOR-READINESS.md` pass on a separate test server.
