# CoreDSC 3.0 architecture

CoreDSC 3.0 separates the Minecraft data plane, Discord I/O plane and local configuration control plane. The purpose is not to create one giant feature plugin. The core owns lifecycle, scheduling, storage, configuration and public contracts; optional modules own policy and presentation.

## System boundaries

```mermaid
flowchart TD
  MC["Minecraft events and commands"] --> OWN["Ownership-safe snapshots"]
  DC["Discord interactions"] --> MOD["Independent feature modules"]
  WEB["Local Web Control Center"] --> CFG["Validated config transaction"]
  OWN --> MOD
  CFG --> MOD
  MOD --> IO["Async Discord and SQLite I/O"]
```

| Boundary | Responsibility | Blocking policy |
|---|---|---|
| `CoreScheduler` | Global, entity, region and async task ownership | Bukkit work never waits for Discord or SQLite |
| `ConfigManager` | Defaults, environment overlays, migration, validation and active snapshot | File I/O occurs outside event hot paths |
| `SQLiteStorage` and repositories | Bounded, single-owner SQLite operations and schema migration | Futures cross back to modules; no scheduler `.join()` |
| `DiscordService` | JDA lifecycle, guild resolution and command reconciliation | REST actions are submitted asynchronously |
| `ModuleManager` | Isolated enable/disable, health and command/listener ownership | A failed optional module does not take down the core |
| `CoreDSCApi` | Stable integration contracts | Implementations remain private to modules |

## Folia and Paper threading model

Folia has no universal server main thread. A global-region callback is not permission to access an arbitrary player or a chunk in another region. CoreDSC therefore uses four distinct scheduler operations:

| API | Owner | Examples |
|---|---|---|
| `runGlobal` / `callGlobal` | Global region | module lifecycle, server-wide snapshots, command registration |
| `runForEntity` / `callForEntity` | Entity | inventory, location, permissions, PlaceholderAPI, player messaging |
| `runForPlayer` / `callForPlayer` | UUID-resolved entity | re-entry after database, Discord or other asynchronous work without retaining a `Player` |
| `runAtLocation` / `callAtLocation` | Region | location-owned world or block access |
| `runAsync` / `runAsyncLater` | Async scheduler | non-Bukkit computation and I/O coordination |

`PaperFoliaCoreScheduler` uses Paper's scheduler family directly. It detects Folia for diagnostics, tracks cancellable tasks, handles retired entities and cancels global/async work during shutdown. `PaperCoreScheduler` is the classic Spigot fallback and is selected reflectively so Paper-only scheduler classes do not break class loading on Spigot.

Cross-player operations use capture and fan-out. A global task captures the current player identities; each player-owned value is then collected on that player's entity scheduler. Discord, database and rendering work receives immutable values. This pattern is used for Discord-to-Minecraft broadcasts, PlaceholderAPI, inventory inspection, link enforcement, report context and proximity-voice reconciliation.

Event adapters follow primitive hand-off. For example, `PlayerDeathListener` reads UUIDs, names and the timestamp while `PlayerDeathEvent` is owned by its region, then discards both `Player` references before the competitive repository future begins. Optional ELO feedback returns through `runForPlayer(UUID, ...)`; an offline or retired player produces a non-delivery result instead of a cross-region access.

## SQLite single-owner funnel

`SQLiteStorage` deliberately does not use HikariCP. CoreDSC owns one persistent SQLite connection and only the `CoreDSC-SQLite` worker can access it. Pooling a single-writer embedded database would add acquisition and lifecycle states without creating write concurrency.

- `journal_mode=WAL`, `synchronous=NORMAL` and foreign keys are set and verified during startup.
- Every read, write and transaction enters one fair, bounded FIFO queue. Transactions cannot interleave.
- Queue overflow fails the returned future with an actionable `DatabaseQueueFullException`; JDBC work is never pushed back onto a Folia caller/region thread.
- `/coredsc status` and `/coredsc doctor` expose current depth, capacity, peak depth and rejected-operation count.
- Shutdown stops admission, drains accepted work in order, checkpoints the WAL and closes the connection on its owner thread without blocking Minecraft.
- `storage.sqlite.queue-capacity` defaults to 8192 and accepts 256-65536. The database file must remain on a local writable disk.

## WebEditor control plane

The editor uses the secure-local-token option requested for servers where OAuth2 would add deployment and secret-management complexity.

1. The module is disabled by default and binds only to a loopback address.
2. An operator starts an expiring session from the physical server console.
3. A random capability is delivered in the URL fragment, moved into `sessionStorage`, removed from browser history and sent as a bearer header.
4. The backend exposes only allowlisted configuration documents and typed dashboard metadata. It never exposes `secrets.yml`, the database, Python files or arbitrary paths.
5. Guilds and usable text channels come from the already-authenticated JDA connection. No bot token is sent to the browser.
6. Visual edits are represented as allowlisted typed patches. Every file carries an optimistic revision.
7. The server constructs a complete candidate configuration, performs contextual validation, creates a timestamped backup, writes all temporary files, fsyncs them and replaces the originals as one transaction. Any failed replacement rolls back the changed set.
8. Save and apply are separate. A successful save can be inspected before the guarded session asks CoreDSC to reload modules.

The UI includes module toggles, live guild/channel selectors, Discord-style lifecycle-embed previews, native and hex color controls, draggable color swatches, HTTPS thumbnail/image inputs, raw YAML for advanced settings and clear validation/conflict messages.

## Gameplay modules

### Economy & Market Terminal

Vault is resolved reflectively and remains a soft dependency. Linked Discord identity is the default authorization boundary. Balance and inventory responses are ephemeral by default; inventory is captured only while the linked player is online and on that entity's scheduler. Staff lookup is a separate opt-in and requires Discord Manage Server.

The market is deliberately read-only. Static YAML listings work immediately, while `EconomyMarketProvider` lets an external shop plugin supply authoritative listings. CoreDSC displays a purchase hint rather than bypassing the shop's own transaction and permission model.

### Lore Sync

`/lore <profile> <message>` and `CoreDSCApi.triggerLoreEvent(...)` resolve a configured NPC persona, validate permission/cooldown/length, neutralize mass mentions and render a cinematic embed. Managed webhooks are reused rather than created per message. If webhook creation or permission is unavailable, an explicit bot fallback can publish the same embed. Avatar, thumbnail and image URLs require HTTPS.

### Competitive ELO

Built-in mode listens to valid player-versus-player deaths. Both ratings and statistics are read and written in one SQLite transaction. Provisional/established K-factors and a rating floor are configurable. Service mode delegates authority to a registered `CompetitiveRatingProvider` for minigame or arena integrations.

The leaderboard maintains one persisted Discord message. Update requests are coalesced; a burst of matches cannot create parallel edit storms. If the message is deleted, the module creates one replacement and persists its identity. Slash commands provide on-demand rating and leaderboard views.

## Smart Console

Smart Console is an incident pipeline, not a raw log mirror:

1. Input passes secret redaction and configured include/exclude rules.
2. A bounded queue drops excess noise rather than consuming unbounded memory.
3. Spam patterns suppress known repetitive lines; informational output is opt-in unless an alert keyword matches.
4. Stack traces are compacted, incidents are fingerprinted and repeats are counted within a deduplication window.
5. Warnings and severe records become severity-colored embeds with compact diagnostic context and remediation guidance.
6. Developer roles are mentioned only for explicit alert-keyword matches and only after a per-incident cooldown. Mentions use an exact allowlist.

Remote execution remains separate from the feed. It defaults to off, supports allowlist mode, enforces role/rate/length controls, audits commands and hard-denies CoreDSC administration and sensitive/destructive patterns even in acknowledged full mode.

## Persistence and configuration

- Managed YAML schema: 5.
- SQLite schema: 11.
- Secrets may come from `secrets.yml` or configured environment variables; Discord, Redis and voice-relay credentials are not required in public configuration.
- Future schema versions fail closed instead of being silently downgraded.
- Missing defaults are merged conservatively; unknown keys are retained and reported.
- Reload keeps the previous active snapshot and module set available for rollback.

## Public API

`CoreDSCApi` is registered through Bukkit's `ServicesManager`. Consumers integrate through interfaces under `com.hubertstudios.coredsc.api`, including `EconomyMarketProvider` and `CompetitiveRatingProvider`, instead of depending on internal module classes. The API exposes lore triggering and competitive operations as asynchronous results.

## Throughput strategy

Chat and console paths copy minimal immutable input at the source, sanitize and batch away from entity/global schedulers, then submit non-blocking JDA actions. Bounded queues and update coalescing provide load shedding: under a burst, CoreDSC sacrifices redundant presentation updates before server tick health. Persistent delivery remains available where loss would violate the module's semantics.

## Deliberate release boundary

The 3.0.1-alpha source was parser-checked and statically audited. At the project owner's request it was intentionally left for a local compile, unit run and package step. A live server was not available, so runtime certification still requires the Paper/Folia/Spigot and Discord matrix in `VERIFICATION-REPORT-3.0.1-alpha.md`.
