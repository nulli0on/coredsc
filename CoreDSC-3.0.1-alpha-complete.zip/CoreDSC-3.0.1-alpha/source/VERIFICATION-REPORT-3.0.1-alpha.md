# CoreDSC 3.0.1-alpha verification report

Date: 2026-08-02

This report distinguishes completed static evidence from the owner's pending build and required live qualification. The user explicitly requested that this workspace not compile the final release.

## Completed in this workspace

| Check | Result | Evidence |
|---|---|---|
| Java source parser | Pass | All source files parsed successfully |
| Folia declaration | Pass | `plugin.yml` contains `folia-supported: true` |
| Frontend JavaScript syntax | Pass | `node --check` exited 0 |
| Documentation consistency | Pass | 65 pages, routes and sidebar entries; 35 static files |
| Direct legacy scheduler search | Pass with boundary | Bukkit scheduler calls remain only inside scheduler implementations |
| Blocking-call search | Pass with documented worker boundary | No Discord `complete()` or database `.join()` on Minecraft scheduler paths |
| Managed defaults | Pass | Schema 5 resources include all new module files |
| Release metadata | Pass | Maven, Bukkit, documentation package and shipped defaults identify `3.0.1-alpha` |

No Maven lifecycle, unit suite, shaded JAR or live server was run for 3.0.1-alpha in this workspace. Those results remain pending the project owner's local build.

## Folia hardening evidence

The UUID player scheduler, primitive `PlayerDeathListener`, bounded SQLite funnel and related module refactors are present in this source release. All Java sources passed the parser-based syntax check and the ownership searches below; the owner will perform the local build.

- No `Player`/`Entity` field or future remains in the refactored death, workflow, report-rendering, economy-inventory, Python-broadcast or custom-command hand-off paths.
- Direct Bukkit/Paper scheduler calls remain isolated to the scheduler implementations.
- UUID re-entry resolves on the server scheduler and runs work through the player's entity scheduler.
- SQLite has one connection owner, bounded admission, no caller-runs fallback and an ordered shutdown drain.

## Security properties reviewed statically

- WebEditor accepts loopback binding only, requires a bearer capability, expires sessions, rate-limits failed authentication and does not expose `secrets.yml`.
- Browser token arrives in the URL fragment and is removed from browser history.
- Typed visual patches use an explicit file/path allowlist and optimistic revisions.
- Multi-file saves validate first, back up originals, force temporary files and roll back partial replacement failures.
- Media fields require HTTPS; mass mentions are neutralized in Lore output.
- Smart Console uses bounded input, redaction, explicit alert patterns, notification cooldowns and exact role-mention allowlisting.
- Remote console defaults off and retains hard deny rules in full mode.

## Required live qualification before production

| Matrix | Required cases |
|---|---|
| Paper | Fresh install, reload, shutdown, all enabled modules, reconnect and rate-limit behavior |
| Folia | Players in distinct regions, teleports during scheduled work, entity retirement/logout, join/quit/death, inventory, PAPI, reports and voice reconciliation |
| Spigot | Class loading without Paper scheduler classes and clear diagnostics for Paper-only features |
| Upgrade | Last two public CoreDSC schemas, unknown keys, invalid config rollback, database backup and injected migration failure |
| Discord | Missing guild/channel/role, missing Manage Webhooks, deleted leaderboard message, command reconciliation and reconnect |
| WebEditor | Invalid/expired token, non-loopback bind, stale revision, oversized body, symlink/path traversal, interrupted multi-file save and apply rollback |
| Economy | Vault absent, provider absent, offline linked player, staff lookup disabled/enabled and inventory mutation during capture |
| Load | Chat bursts, console storms, rapid PvP deaths, Discord outage and 24-hour soak with heap/TPS measurements |

## Release decision

CoreDSC 3.0.1-alpha source status: **static checks passed; pending the owner's local compile/package**.

Production certification status: **not yet granted**, because this environment did not contain a runnable Paper/Folia server or live Discord guild. Complete the matrix above and attach logs/metrics to the release candidate before making comparative performance or universal production-support claims.
