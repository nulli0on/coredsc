# Migrating to CoreDSC 3.0

## Before starting

Stop the server cleanly and copy `plugins/CoreDSC/`, including `coredsc.db`. Do not perform the first migration on the only copy of a production server.

## Automated changes

- Maintained YAML files move to config schema 5.
- SQLite moves to schema 11 and gains competitive rating and leaderboard-message persistence.
- Missing defaults and new module files are generated with backups and atomic replacement.
- Existing unknown keys are preserved and reported; future schema versions are rejected.

New files:

- `modules/web-editor.yml`
- `modules/economy-market.yml`
- `modules/lore-sync.yml`
- `modules/competitive.yml`

They default to `enabled: false`.

## Folia migration

No configuration switch enables Folia. CoreDSC selects the Paper scheduler family at runtime and reports `FOLIA`, `PAPER` or `SPIGOT` in diagnostics. On Folia, verify any third-party dependencies independently; CoreDSC cannot make a non-Folia-compatible Vault economy, PlaceholderAPI expansion or shop provider safe.

Test with players in separate regions:

- chat and Discord-to-game broadcasts;
- join, quit and death embeds;
- link enforcement and rewards;
- report context capture;
- economy inventory lookup;
- PlaceholderAPI-rendered workflows and commands;
- voice-room reconciliation if enabled.

## WebEditor migration

Enable `modules/web-editor.yml`, reload CoreDSC and run `/coredsc webeditor start` from the physical server console. Do not publish port 8765. If the server is remote, forward it locally:

```bash
ssh -L 8765:127.0.0.1:8765 user@minecraft-host
```

The editor uses the bot's existing authenticated guild/channel view. If dropdowns are empty, fix the bot connection, guild ID and Discord channel visibility; no OAuth client secret is required.

## Module activation order

1. Configure and enable one new module.
2. Run `/coredsc reload`, `/coredsc doctor` and `/coredsc status`.
3. Test its permissions and failure paths.
4. Continue to the next module.

For Economy, install Vault plus exactly one functioning economy provider. For Lore managed webhooks, grant the bot Manage Webhooks in each target channel or retain `fallback-to-bot: true`. For Competitive service mode, register one `CompetitiveRatingProvider` before enabling the module. For Smart Console, begin with remote mode `OFF` and tune feed filters before considering command execution.

## Rollback

Stop the server, restore the backed-up plugin directory and restore the previous JAR together. Do not run an older CoreDSC JAR against a schema 11 database and assume it will downgrade safely.
