# CoreDSC 3.0.1-alpha release notes

CoreDSC 3.0.1-alpha is the first Folia-oriented control-plane candidate. It turns the experimental WebEditor into a visual administration surface, hardens every audited player hand-off and SQLite write boundary, and adds three independent gameplay modules plus a classified Smart Console.

## Highlights

- Folia ownership-safe scheduling for global, entity, region and asynchronous work, with Paper and Spigot runtime selection.
- UUID-based player re-entry and primitive-only PvP death snapshots so asynchronous work never retains event-owned Bukkit entities.
- A bounded single-owner SQLite funnel with verified WAL/NORMAL modes, load shedding, queue diagnostics and ordered WAL checkpoint shutdown.
- Visual Control Center for module toggles, authenticated Discord channel mapping, lifecycle embed design and guarded advanced YAML.
- Vault economy and market slash commands with linked-account privacy and an external shop-provider API.
- Cinematic Lore Sync personas through reused Discord webhooks or a safe bot fallback.
- Transactional built-in PvP ELO or external rating providers, plus one auto-updating persisted leaderboard message.
- Bounded Smart Console incidents with severity embeds, spam filtering, deduplication, remediation and keyword-only developer alerts.
- Schema 5 configuration and schema 11 database migration.

## Compatibility

- Compile target: Java 17 bytecode.
- Recommended runtime: Java 21 when required by the selected Minecraft 1.21 server.
- Compile API: Paper 1.21.11.
- Discord API: JDA 6.5.0.
- Optional integrations: Vault, PlaceholderAPI, LuckPerms, AuthMe and Simple Voice Chat.

The new modules default to disabled. Existing chat, link, moderation and synchronization behavior remains modular.

## Upgrade summary

1. Stop the server and back up the entire `plugins/CoreDSC` directory.
2. Replace the JAR and start once to migrate managed YAML to schema 5 and SQLite to schema 11.
3. Run `/coredsc doctor` and `/coredsc status`.
4. Review the four newly generated module files before enabling anything.
5. Stage the relevant Paper/Folia, Discord-permission and upgrade tests listed in the verification report.

## Security defaults

- WebEditor is off, loopback-only and console-started.
- Economy replies are linked-account and ephemeral by default.
- Lore requires an operator permission and uses HTTPS media URLs.
- Competitive mode is off until a server chooses its rating authority.
- Console remote execution is off; the feed and command-execution policy remain separate.
- Secrets and WebEditor capabilities are redacted from console delivery.

## Known release qualification gap

At the project owner's request, the final 3.0.1-alpha source was not compiled or packaged as a JAR in this workspace. It passed parser-based and repository-level static checks, but a live Minecraft/Discord harness was not available. Treat this as an alpha source candidate until the owner completes a clean local build and the runtime matrix in `VERIFICATION-REPORT-3.0.1-alpha.md`.
