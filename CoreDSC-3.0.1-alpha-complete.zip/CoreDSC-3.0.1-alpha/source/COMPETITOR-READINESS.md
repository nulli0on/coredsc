# CoreDSC 3.0 competitor readiness

The original comparison was limited to the supplied CoreDSC and DiscordSRV source archives. This revision records what the 3.0 implementation changes while retaining evidence-based release gates. It is an engineering assessment, not a marketing claim.

## Where CoreDSC now differentiates

- Visual local Control Center with live Discord channel discovery, module toggles, embed design, validation, optimistic conflicts, transaction backups and secret exclusion.
- Explicit Paper/Folia global, region, entity and async scheduler ownership with a Spigot fallback.
- Read-only, privacy-first Vault economy terminal and external market-provider contract.
- Cinematic Lore Sync personas with a public trigger API.
- Transactional built-in ELO, external rating-provider contract and one persistent live leaderboard.
- Classified, bounded Smart Console incidents instead of a raw log dump.
- Modular configuration and lifecycle isolation across chat, linking, synchronization, support, automation, network, Python and voice-room features.
- Explicit DiscordSRV migration preview/apply workflow.
- Persistent delivery queue and operational module health state.
- Transactional configuration reload/rollback and conservative database/config migration behavior.
- Privacy-bounded feature adoption metrics.

## Where DiscordSRV remains ahead

- A much older and broader production deployment history.
- More localization coverage in the supplied tree.
- Broader public event/API and ecosystem integration surface.
- A much larger established ecosystem of integrations and translated support material.
- Substantially more production history and third-party operational evidence.
- Broader automated coverage in the supplied tree; CoreDSC 3.0 starts with focused ELO tests but still needs integration and regression suites.

## Required release gates

CoreDSC cannot honestly be called better overall until all gates below have evidence attached to a release candidate.

1. Fresh Paper, Folia and Spigot installations reach `READY` with every default resource generated.
2. Folia tests cover separate regions, entity retirement, movement during scheduling and all player-owned feature paths.
3. Upgrade tests from the last two public CoreDSC releases preserve user values and prove rollback under injected failure.
4. Live Discord tests cover reconnects, missing permissions/resources, rate limits, command reconciliation, webhook reuse and leaderboard recreation.
5. WebEditor tests cover loopback enforcement, expired/invalid tokens, cross-origin requests, stale revisions, oversized bodies, symlinks and interrupted transactional saves.
6. Database migration tests cover every supported schema, duplicate-account failures and backup restoration.
7. Remote-console bypass tests cover namespaced, wrapper, whitespace and Unicode command variants.
8. A 24-hour soak covers chat/console bursts, rapid matches, Discord outages, reload and shutdown.
9. Performance comparisons use identical server, player simulation, module and Discord workloads with TPS, allocation, queue and API-rate evidence.
10. Installation and recovery documentation is tested by someone who did not implement the feature.

Passing those gates would support a defensible claim that CoreDSC is the stronger choice for its intended modern Minecraft-server audience. Until then, the accurate label is **differentiated, build-verified alpha candidate**.
