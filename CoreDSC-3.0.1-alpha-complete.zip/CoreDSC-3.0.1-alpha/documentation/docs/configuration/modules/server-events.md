---
sidebar_position: 5
---
# `modules/server-events.yml`

Publishes server lifecycle and player activity events to Discord.

See [Server events](/features/events-status) for setup and usage.

## Before enabling

- Configure the destination channel.
- Grant Send Messages and Embed Links when embeds are enabled.
- Keep rate limiting and batching enabled on busy servers.

## Event delivery

Every event has an independent switch and format. Join/quit batching reduces spam. Queue delivery can preserve important messages during temporary Discord failures.

## Default configuration

```yaml title="plugins/CoreDSC/modules/server-events.yml"
config-version: 5
generated-by-version: "3.0.1-alpha"

# CoreDSC module: server-events
enabled: false
channel-id: ''
use-delivery-queue: true
max-messages-per-minute: 60
suppress-quit-after-kick: true
embeds:
  enabled: true
  color: '#5865F2'
  title: 'CoreDSC • %server_name%'
  footer: ''
batching:
  enabled: true
  interval-ticks: 100
  maximum-names: 20
  join-format: '🟢 **%count%** joined: %players%'
  quit-format: '🔴 **%count%** left: %players%'
events:
  startup:
    enabled: true
    format: '🟢 **%server_name%** is online.'
    embed:
      title: 'Server online'
      description: '🟢 **%server_name%** is online.'
      color: '#57F287'
      thumbnail-url: ''
      image-url: ''
      footer: ''
  shutdown:
    enabled: true
    format: '🔴 **%server_name%** is stopping.'
    embed:
      title: 'Server offline'
      description: '🔴 **%server_name%** is stopping.'
      color: '#ED4245'
      thumbnail-url: ''
      image-url: ''
      footer: ''
  join:
    enabled: true
    format: '🟢 **%player%** joined the server.'
    embed:
      title: 'Player joined'
      description: '🟢 **%player%** joined the server.'
      color: '#57F287'
      thumbnail-url: 'https://mc-heads.net/avatar/%player%/128'
      image-url: ''
      footer: ''
  quit:
    enabled: true
    format: '🔴 **%player%** left the server.'
    embed:
      title: 'Player left'
      description: '🔴 **%player%** left the server.'
      color: '#FEE75C'
      thumbnail-url: 'https://mc-heads.net/avatar/%player%/128'
      image-url: ''
      footer: ''
  first-join:
    enabled: true
    format: '✨ **%player%** joined for the first time.'
  world:
    enabled: false
    format: '🌍 **%player%** moved from `%from_world%` to `%to_world%`.'
  death:
    enabled: true
    format: '☠️ %death_message%'
    embed:
      title: 'Player death'
      description: '☠️ %death_message%'
      color: '#ED4245'
      thumbnail-url: 'https://mc-heads.net/avatar/%player%/128'
      image-url: ''
      footer: ''
  advancement:
    enabled: false
    format: '🏆 **%player%** completed `%advancement%`.'
  kick:
    enabled: false
    format: '⚠️ **%player%** was kicked: %reason%'
  account-link:
    enabled: true
    format: '🔗 **%player%** linked Discord account `%discord_id%`.'
  account-unlink:
    enabled: true
    format: '⛓️‍💥 **%player%** unlinked Discord account `%discord_id%`.'
  ticket-create:
    enabled: false
    format: '🎫 Ticket **#%ticket_id%** created: %reason%'
  ticket-close:
    enabled: false
    format: '✅ Ticket **#%ticket_id%** closed by **%closed_by%**.'
  report-create:
    enabled: false
    format: '🚩 Report **#%report_id%**: **%reporter%** reported **%target%** for %reason%.'
```

[Download this default file](/default-configs/modules/server-events.yml).
