# `guis/report-gui.yml`

Controls the inventory used by staff to browse and manage reports. The GUI is relevant only when the reports module is enabled.

Keep the inventory size divisible by nine and within the normal Bukkit inventory limits. Verify material names against the server version.

```yaml title="plugins/CoreDSC/guis/report-gui.yml"
config-version: 5
generated-by-version: "3.0.1-alpha"

# CoreDSC report administration GUI
enabled: true
list:
  title: '&8Reports &7- &f%filter% &8(&f%page%&8/&f%pages%&8)'
  size: 54
  filters:
  - OPEN
  - UNCLAIMED
  - CLAIMED
  - CLOSED
  - ALL
  report-slots:
  - 10
  - 11
  - 12
  - 13
  - 14
  - 15
  - 16
  - 19
  - 20
  - 21
  - 22
  - 23
  - 24
  - 25
  - 28
  - 29
  - 30
  - 31
  - 32
  - 33
  - 34
  background:
    enabled: true
    material: GRAY_STAINED_GLASS_PANE
    name: ' '
  report-item:
    material: PAPER
    name: '&cReport #%id% &8[&f%status%&8]'
    glow: false
    lore:
    - '&7Reporter: &f%reporter_name%'
    - '&7Target: &f%target_name%'
    - '&7Priority: &f%priority%'
    - '&7Claimed by: &f%claimed_by%'
    - ''
    - '&7Reason: &f%reason%'
    - ''
    - '&eClick to open'
  controls:
    previous:
      slot: 45
      material: ARROW
      name: '&ePrevious page'
      lore:
      - '&7Page %page%/%pages%'
    filter:
      slot: 47
      material: HOPPER
      name: '&bFilter: &f%filter%'
      lore:
      - '&7Click to change'
    refresh:
      slot: 49
      material: CLOCK
      name: '&aRefresh'
      lore:
      - '&7Reload report data'
    close:
      slot: 51
      material: BARRIER
      name: '&cClose'
    next:
      slot: 53
      material: ARROW
      name: '&eNext page'
      lore:
      - '&7Page %page%/%pages%'
detail:
  title: '&8Report #&f%id%'
  size: 45
  background:
    enabled: true
    material: BLACK_STAINED_GLASS_PANE
    name: ' '
  info:
    slot: 13
    material: BOOK
    name: '&cReport #%id%'
    lore:
    - '&7Reporter: &f%reporter_name%'
    - '&7Target: &f%target_name%'
    - '&7Status: &f%status%'
    - '&7Priority: &f%priority%'
    - '&7Claimed by: &f%claimed_by%'
    - ''
    - '&7Reason: &f%reason%'
    - '&7Message: &f%message%'
  actions:
    claim:
      slot: 29
      material: NAME_TAG
      name: '&bClaim report'
      lore:
      - '&7Current: &f%claimed_by%'
    priority:
      slot: 31
      material: REDSTONE_TORCH
      name: '&ePriority: &f%priority%'
      lore:
      - '&7Click to cycle priority'
    close:
      slot: 33
      material: BARRIER
      name: '&cClose report'
      lore:
      - '&7Archives the Discord thread'
    back:
      slot: 36
      material: ARROW
      name: '&7Back'
```

[Download this default file](/default-configs/report-gui.yml).
