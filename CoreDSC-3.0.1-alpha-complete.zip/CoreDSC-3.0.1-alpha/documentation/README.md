# CoreDSC Documentation

Docusaurus documentation for CoreDSC 3.0.1-alpha.

## Install dependencies

This project uses Yarn 1 and includes `yarn.lock`.

```bash
corepack enable
yarn install --frozen-lockfile
```

Do not use `npm ci`: this project does not ship a `package-lock.json`.

## Local development

```bash
yarn start
```

## Validate documentation

```bash
yarn verify
```

The validator checks documentation routes, sidebar IDs, local links and static-file references without requiring a Docusaurus build.

## Production build

```bash
yarn clear
yarn build
```

The static site is written to `build/`. `yarn build` automatically runs the documentation validator first.

The project can be built from a plain ZIP or in Replit without a Git repository. Last-update author/time metadata is enabled automatically only when a local `.git` directory exists. To override this behavior, set `DOCS_SHOW_LAST_UPDATE=true` or `DOCS_SHOW_LAST_UPDATE=false`.

## Deployment settings

The default public URL is `https://hubertstudios.com` with `/` as the base path. Override these values when deploying elsewhere:

```bash
DOCS_SITE_URL='https://example.com' DOCS_BASE_URL='/' yarn build
```

`DOCS_BASE_URL` is normalized automatically, so `docs`, `/docs` and `/docs/` all become `/docs/`.

## Updating default configuration files

The exact CoreDSC 3.0.1-alpha defaults are stored under `static/default-configs/`. When a plugin release changes a shipped YAML file, update the matching file here and the relevant configuration page in the same commit.

## Attribution

The project structure and Docusaurus configuration were adapted from the DiscordSRV Documentation repository under the BSD 2-Clause License. The required notice is included in `LICENSE` and `THIRD-PARTY-NOTICES.md`. CoreDSC content and branding are not copied from DiscordSRV.
