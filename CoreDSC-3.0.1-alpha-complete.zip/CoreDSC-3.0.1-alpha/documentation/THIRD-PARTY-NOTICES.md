# Third-party notices

## DiscordSRV Documentation

The Docusaurus project structure, sidebar approach, deployment workflow and portions of the site configuration were adapted from the DiscordSRV Documentation repository.

Copyright © 2021 granny. Licensed under the BSD 2-Clause License. The full license text is reproduced in `LICENSE`.

No DiscordSRV branding, screenshots, configuration text or product claims are included as CoreDSC content.
