# CoreDSC competitor readiness

The comparison below is limited to the supplied CoreDSC 2.5.2 and DiscordSRV source archives. It is an engineering assessment, not a marketing claim.

## Where CoreDSC now differentiates

- Temporary local WebEditor with validation, revision conflicts, backups and secret exclusion.
- Modular configuration and lifecycle isolation across chat, linking, synchronization, support, automation, network, Python and voice-room features.
- Explicit DiscordSRV migration preview/apply workflow.
- Persistent delivery queue and operational module health state.
- Transactional configuration reload/rollback and conservative database/config migration behavior.
- Privacy-bounded feature adoption metrics.

## Where DiscordSRV remains ahead

- A much older and broader production deployment history.
- More localization coverage in the supplied tree.
- Broader public event/API and ecosystem integration surface.
- Declared Folia support; this CoreDSC checkpoint remains Paper-only.
- Existing automated tests in the supplied DiscordSRV tree; CoreDSC still needs a real automated test suite.

## Required release gates

CoreDSC cannot honestly be called better overall until all gates below have evidence attached to a release candidate.

1. Clean Java 21 build with warnings reviewed.
2. Fresh Paper installation reaches `READY` with every default resource generated.
3. Upgrade test from the last two public CoreDSC releases with byte-preserved user values and successful rollback injection.
4. Live Discord tests for reconnects, missing guild/channel/role, rate limits, command reconciliation and webhook recreation.
5. WebEditor tests for loopback enforcement, expired/invalid tokens, cross-origin requests, stale revisions, oversized bodies, symlink attempts and interrupted saves.
6. Database migration tests from every supported schema, including duplicate-account failure cases and backup restoration.
7. Remote-console bypass tests using namespaced and wrapper commands.
8. 24-hour soak with chat bursts, Discord disconnects, reloads and shutdown.
9. Performance comparison using the same Paper server, player simulation, modules and Discord workload.
10. Documentation/install test performed by someone who did not write the feature.

Passing those gates would support a defensible claim that CoreDSC is the stronger choice for its intended modern Paper-server audience. Until then, the accurate label is **differentiated alpha source checkpoint**.
