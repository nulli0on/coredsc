"use client";

import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Brand, Icon } from "../../ui";
import { api, CoreUser, csrfHeader, oauthUrl } from "../../lib/control-plane";

type Pairing = { serverName: string; instanceId: string; expiresAt: number; confirmationCode: string; command: string };

export default function PairingPage() {
  const params = useParams<{ token: string }>();
  const router = useRouter();
  const token = params.token;
  const [pairing, setPairing] = useState<Pairing | null>(null);
  const [user, setUser] = useState<CoreUser | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api<{ user: CoreUser; csrfToken: string }>("/v1/me")
      .then((identity) => {
        setUser(identity.user);
        return api<{ pairing: Pairing }>("/v1/pairings/claim", {
          method: "POST",
          headers: csrfHeader(identity.csrfToken),
          body: JSON.stringify({ token }),
        });
      })
      .then((result) => setPairing(result.pairing))
      .catch((failure: unknown) => setError(failure instanceof Error ? failure.message : "Pairing failed"))
      .finally(() => setLoading(false));
  }, [token]);

  useEffect(() => {
    if (!pairing) return;
    const timer = window.setInterval(() => {
      api<{ confirmed: boolean; instanceId: string }>(`/v1/pairings/status?token=${encodeURIComponent(token)}`)
        .then((status) => {
          if (status.confirmed) {
            window.clearInterval(timer);
            router.replace(`/dashboard/${status.instanceId}`);
          }
        })
        .catch(() => undefined);
    }, 2_000);
    return () => window.clearInterval(timer);
  }, [pairing, router, token]);

  if (loading) return <main className="center-state"><span className="loading-mark"><Brand compact /></span><p>Opening pairing link…</p></main>;
  if (error && !user) {
    return <main className="pair-shell"><Brand /><div className="pair-card"><span className="pair-icon"><Icon name="discord" /></span><h1>Sign in to claim this link</h1><p>Sign in with Discord, then confirm the command on the Minecraft server.</p><a className="button button-primary full" href={oauthUrl(`/link/${token}`)}>Continue with Discord</a></div></main>;
  }
  if (error || !pairing) return <main className="pair-shell"><Brand /><div className="pair-card error-card"><span className="pair-icon red"><Icon name="alert" /></span><h1>Pairing unavailable</h1><p>{error || "The link is invalid or expired."}</p><Link className="button button-secondary full" href="/dashboard">Return to dashboard</Link></div></main>;

  return (
    <main className="pair-shell">
      <Brand />
      <div className="pair-card wide">
        <span className="pair-icon green"><Icon name="shield" /></span>
        <span className="eyebrow">Signed in with Discord</span>
        <h1>Confirm {pairing.serverName}</h1>
        <p>Signed in as <strong>{user?.displayName}</strong>. Run this exact command in the local Minecraft server console. Run it directly on the Minecraft server.</p>
        <div className="command-box"><code>{pairing.command}</code><button onClick={() => navigator.clipboard.writeText(pairing.command)}>Copy command</button></div>
        <div className="pair-waiting" role="status" aria-live="polite"><span className="status-dot warning" /><div><strong>Waiting for confirmation</strong><p>Keep this page open. It will continue automatically after the command succeeds.</p></div></div>
        <div className="pair-checks"><span><Icon name="check" /> Link expires automatically</span><span><Icon name="check" /> Bot token stays local</span><span><Icon name="check" /> Changes are recorded</span></div>
        <p className="muted-small">There is no second editor link. The command above completes this pairing and opens the hosted dashboard.</p>
      </div>
    </main>
  );
}
