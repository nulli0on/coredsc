# CoreDSC plugin 3.4.2 and Panel 1.3.1

CoreDSC is a source-available Minecraft and Discord operations platform for Paper/Folia servers. This source package contains CoreDSC plugin 3.4.2 and CoreDSC Panel/control-plane 1.3.1.

The Java plugin and its generated configuration templates use version `3.4.2`. The dashboard and control-plane package manifests and live health response use version `1.3.1`. Stage changes on a recoverable test server, review local policy and keep verified backups.

## Components

- `plugin/` — Java 21 Paper/Folia plugin, local Discord bot, SQLite persistence, configuration validation, moderation, incidents, maintenance, scheduling, AutoMod, Smart Console and network operations.
- `app/`, `worker/` — editor-style hosted dashboard and first-party API proxy for the Sites workflow declared in `.openai/hosting.json`.
- `control-plane/` — Cloudflare Worker with Discord OAuth, D1, Durable Objects, server pairing, role/capability enforcement, approvals, idempotency, audit records and health tracking.
- `control-plane/migrations/` — ordered D1 schema migrations.

## Security model

The customer server remains the authority for every remote operation.

- The plugin opens one outbound TLS WebSocket. No inbound Minecraft-server port is required.
- The Discord bot token stays on the customer server and is never sent through the cloud protocol.
- The protocol exposes only named operations. It does not expose arbitrary files, `secrets.yml`, databases, backups or private keys.
- The Worker checks sessions, first-party origin, CSRF, grants, capabilities, payload bounds, rate limits, approvals and idempotency.
- The plugin independently checks capabilities, feature switches, command allowlists, protected identities, Discord hierarchy, configuration paths, revisions and payload bounds.
- Configuration writes require validation, an allowlisted path, a current revision, a local backup and local application.
- High-risk operations use two-person approval where configured. The requester cannot approve their own request.
- Bukkit/Paper access must re-enter the proper global, region or entity scheduler. Player objects are not retained across database, Discord, cloud or asynchronous callbacks.

## Hosted media without R2

R2 is not used. Dashboard image uploads are restricted to PNG, JPEG, WebP or GIF, at most 512 KiB. The Worker validates the declared type and file signature, sends the image as Base64 only to the authenticated local agent, and does not persist the image body in D1 or audit records. The plugin stores accepted media locally under its own data directory and returns a content-addressed `coredsc-media://` reference.

The plugin revalidates the stored digest, file signature and size on resolution, rejects symbolic links, and uses bounded reads. Base64 is a transport encoding, not free cloud object storage; the strict size limit avoids unbounded Worker, Durable Object, D1 and WebSocket costs.

## Default safety posture

Cloud control and remote console execution are disabled by default. The default cloud endpoint is deliberately non-routable (`coredsc.example.invalid`) so a fresh installation does not reconnect endlessly before a hosted endpoint has been configured.

The default remote command allowlist is limited to:

```text
list
tps
mspt
say
whitelist
```

Review `plugin/src/main/resources/modules/cloud-control.yml` before enabling the agent.

## Documentation

- [SETUP.md](SETUP.md) — local build, server installation, Cloudflare deployment order, Discord OAuth and pairing.
- [REFERENCE.md](REFERENCE.md) — commands, permissions, roles, operations, bindings, migrations and default configuration.
- [CHANGELOG.md](CHANGELOG.md) — release changes, completed checks and remaining external verification.

## Verification status of this source delivery

The dependency-free dashboard/Worker syntax gate and **75 local automated tests** pass for this source package. The full control-plane `tsc --noEmit` gate and production Panel build require successful lockfile installation. Coverage includes D1-compatible approval and retry flows, canonical approval payloads, persistent idempotency and replay results, repeated network rollouts, ownership recovery, stale revisions, offline cached reads, OAuth state/session/CSRF handling, exact role matrices, rate limits, bounded media transport, Durable Object socket replacement/reconnect behavior, dashboard-operation policy coverage, concurrent-submission guards, bounded shutdown drains, capability separation, fail-closed defaults and release-version consistency.

A dependency-free Java 21 release harness also passes with `-Xlint:all -Werror`. It executes strict JSON parser/encoder checks, canonical local idempotency fingerprints, WebSocket fragment and UTF-8 boundary checks, persistent Ed25519 identity validation, content-addressed media integrity checks, symlink rejection, concurrent duplicate installation and all supported image signatures.

The execution environment could not complete the full Maven build or either lockfile installation: Maven was not installed and the configured package infrastructure could not provide the required artifacts. Therefore this source tree is internally versioned as plugin `3.4.2` and Panel `1.3.1`, but this delivery must not be represented as having passed any gate that was not actually executed, including real Paper/Folia, Cloudflare-account or Discord-account tests. See `CHANGELOG.md` for the precise limitations.

## License

CoreDSC is licensed under the HubertStudios Source License in [LICENSE](LICENSE). It is source-available, not open source. Third-party dependencies remain under their respective licenses.
