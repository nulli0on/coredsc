import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import test from "node:test";

import { lookupOperationCapability } from "../src/policy.ts";

const dashboard = readFileSync(new URL("../../app/dashboard/[serverId]/page.tsx", import.meta.url), "utf8");
const dashboardIndex = readFileSync(new URL("../../app/dashboard/page.tsx", import.meta.url), "utf8");
const landing = readFileSync(new URL("../../app/page.tsx", import.meta.url), "utf8");
const styles = readFileSync(new URL("../../app/globals.css", import.meta.url), "utf8");
const javaRouterPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudOperationRouter.java", import.meta.url);
const javaModuleManagerPath = new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/module/ModuleManager.java", import.meta.url);
const javaRouter = existsSync(javaRouterPath) ? readFileSync(javaRouterPath, "utf8") : "";
const javaModuleManager = existsSync(javaModuleManagerPath) ? readFileSync(javaModuleManagerPath, "utf8") : "";

const dashboardOperations = [
  "health.snapshot", "setup.doctor", "setup.createChannels", "discord.guilds", "discord.channels",
  "config.snapshot", "config.patch", "config.apply", "moderation.ban", "moderation.unban",
  "moderation.kick", "moderation.timeout", "moderation.warn", "moderation.note", "moderation.history",
  "channel.snapshot", "channel.lock", "channel.unlock", "channel.slowmode", "channel.slowmode.restore", "channel.purge",
  "channel.hide", "channel.reveal", "incident.status", "incident.start", "incident.resolve",
  "maintenance.status", "maintenance.start", "maintenance.cancel", "event.list", "event.create",
  "event.cancel", "automod.rules", "automod.upsert", "automod.delete", "console.snapshot",
  "console.execute",
] as const;

test("every dashboard operation has an explicit deny-by-default policy entry", () => {
  for (const operation of dashboardOperations) {
    assert.ok(lookupOperationCapability(operation), `${operation} is missing from the Worker policy`);
  }
});

test("dashboard live updates reconnect with bounded backoff and approvals remain rejectable offline", () => {
  assert.match(dashboard, /Math\.min\(30_000/u);
  assert.match(dashboard, /setLiveState\("reconnecting"\)/u);
  assert.match(dashboard, /canDecide=\{hasCapability\(capabilities, "approval\.decide"\)\}/u);
  assert.doesNotMatch(dashboard, /canDecide=\{agentOnline\s*&&/u);
});

test("dashboard retries preserve the original idempotency key", () => {
  assert.match(dashboard, /type RetryRequest = \{[^}]*idempotencyKey: string/u);
  assert.match(dashboard, /executeOperation\(retryRequest\)/u);
  assert.match(dashboard, /body: JSON\.stringify\(\{ operation, payload, reason, idempotencyKey \}\)/u);
  assert.doesNotMatch(dashboard, /body: JSON\.stringify\(\{ operation, payload, reason, idempotencyKey: crypto\.randomUUID\(\) \}\)/u);
});


test("dashboard suppresses concurrent mutations before creating a second idempotency key", () => {
  assert.match(dashboard, /const mutationInFlight = useRef\(false\)/u);
  assert.match(dashboard, /if \(mutation && mutationInFlight\.current\)/u);
  assert.match(dashboard, /if \(mutation\) mutationInFlight\.current = true/u);
  assert.match(dashboard, /finally \{[\s\S]{0,120}mutationInFlight\.current = false/u);
});


test("network, staff and approval controls reject rapid duplicate submissions", () => {
  assert.match(dashboardIndex, /const busyRef = useRef\(false\)/u);
  assert.match(dashboardIndex, /if \(busyRef\.current\) return/u);
  assert.match(dashboard, /const busyRef = useRef\(false\)/u);
  assert.match(dashboard, /const decidingRef = useRef\(""\)/u);
  assert.match(dashboard, /if \(decidingRef\.current\) return/u);
});

test("Worker and plugin agree that notes use case authority rather than sanction authority", () => {
  if (!javaRouter) {
    return;
  }
  assert.match(javaRouter, /values\.put\("moderation\.note", "case\.manage"\)/u);
  assert.match(javaRouter, /"MODERATOR"[\s\S]*?"case\.manage"/u);
  assert.match(javaRouter, /"SUPPORT"[\s\S]*?"case\.manage"/u);
});


test("cloud control fails closed when its modular setting is absent", () => {
  if (!javaModuleManager) {
    return;
  }
  assert.match(javaModuleManager, /getBoolean\("modules\.cloud-control", false\)/u);
  assert.doesNotMatch(javaModuleManager, /getBoolean\("modules\.cloud-control", true\)/u);
});


test("slowmode mutation has an authorized dashboard restore path", () => {
  assert.match(dashboard, /perform\("channel\.slowmode\.restore"/u);
  if (!javaRouter) {
    return;
  }
  assert.match(javaRouter, /"slowmode\.restore"/u);
});


test("dashboard uses the documentation palette and an editor workspace layout", () => {
  assert.match(styles, /--bg:\s*#0b0d12/u);
  assert.match(styles, /--surface:\s*#12151c/u);
  assert.match(styles, /--primary:\s*#ff6b6b/u);
  assert.match(dashboardIndex, /className="resource-browser"/u);
  assert.match(dashboardIndex, /className="editor-workspace"/u);
  assert.match(dashboard, /className="resource-browser server-browser"/u);
  assert.match(dashboard, /className="workspace-content"/u);
});

test("public copy avoids internal protocol and security implementation jargon", () => {
  const copy = `${landing}\n${dashboardIndex}\n${dashboard}`;
  assert.doesNotMatch(copy, /Ed25519|final authority|replay-resistant|outbound-only|capability-gated|JDA bot|idempotent cross-platform|deterministic restoration|orchestration|incident identity|permission overwrites|restart-safe/iu);
  assert.doesNotMatch(dashboard, /label="Discord gateway"|label="Database queue"|<dt>Scheduler<\/dt>|<dt>Last heartbeat<\/dt>|title="Guild rules"/u);
  assert.match(landing, /className="public-resource-browser"/u);
  assert.match(landing, /className="public-workspace"/u);
  assert.match(landing, /Manage your CoreDSC servers/u);
  assert.match(landing, /Continue with Discord/u);
  assert.doesNotMatch(landing, /welcome-layout|welcome-main|start-panel/u);
  const pairingPage = readFileSync(new URL("../../app/link/[token]/page.tsx", import.meta.url), "utf8");
  assert.match(pairingPage, /Waiting for confirmation/u);
  assert.match(pairingPage, /There is no second editor link/u);
  assert.doesNotMatch(pairingPage, />Open dashboard<\/Link>/u);
  assert.match(dashboardIndex, /Pair a server/u);
  assert.match(dashboard, /Activity history/u);
  assert.match(dashboard, /function roleLabel\(/u);
  assert.match(dashboard, /Server administrator/u);
});
