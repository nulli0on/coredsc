import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { join, relative } from "node:path";
import test from "node:test";

const root = new URL("../../", import.meta.url);
const workspaceRoot = fileURLToPath(root);
const PANEL_VERSION = "1.3.1";
const PLUGIN_VERSION = "3.4.2";

function read(relativePath: string): string {
  return readFileSync(new URL(relativePath, root), "utf8");
}

function optionalRead(relativePath: string): string | null {
  try {
    return read(relativePath);
  } catch {
    return null;
  }
}

function json(relativePath: string): Record<string, unknown> {
  return JSON.parse(read(relativePath)) as Record<string, unknown>;
}

function projectFiles(directory: string): string[] {
  const absolute = join(workspaceRoot, directory);
  const results: string[] = [];
  const visit = (current: string): void => {
    for (const entry of readdirSync(current, { withFileTypes: true })) {
      if ([".git", ".sites-runtime", "node_modules", "target", "dist", ".next", ".wrangler"].includes(entry.name)) continue;
      const path = join(current, entry.name);
      if (entry.isDirectory()) visit(path);
      else results.push(path);
    }
  };
  visit(absolute);
  return results;
}

test("release version is consistent across build, runtime, dashboard and lockfiles", () => {
  assert.equal(json("package.json").version, PANEL_VERSION);
  assert.equal(json("package-lock.json").version, PANEL_VERSION);
  assert.equal((json("package-lock.json").packages as Record<string, { version?: string }>)[""].version, PANEL_VERSION);
  assert.equal(json("control-plane/package.json").version, PANEL_VERSION);
  assert.equal(json("control-plane/package-lock.json").version, PANEL_VERSION);
  assert.equal((json("control-plane/package-lock.json").packages as Record<string, { version?: string }>)[""].version,
    PANEL_VERSION);

  assert.match(read("control-plane/src/index.ts"), /version: "1\.3\.1"/u);
  assert.match(read("app/page.tsx"), /CoreDSC Panel 1\.3\.1/u);
  assert.match(read("app/dashboard/page.tsx"), /server\.pluginVersion \|\| "3\.4\.2"/u);
  assert.match(read("app/dashboard\/\[serverId\]/page.tsx"), /instance\.plugin_version \?\? "3\.4\.2"/u);
  assert.match(read("vite.config.ts"), /binding: "CONTROL_PLANE"[\s\S]{0,120}service: "coredsc-control-plane"/u);

  const pluginPom = optionalRead("plugin/pom.xml");
  const pluginYml = optionalRead("plugin/src/main/resources/plugin.yml");
  if (pluginPom && pluginYml) {
    assert.match(pluginPom, /<artifactId>coredsc<\/artifactId>\s*<version>3\.4\.2<\/version>/u);
    assert.match(pluginYml, /^version: 3\.4\.2$/mu);
  }
});

test("all generated configuration templates identify the release", () => {
  const resources = projectFiles(".")
    .filter((path) => path.endsWith(".yml"))
    .map((path) => readFileSync(path, "utf8"))
    .filter((content) => content.includes("generated-by-version:"));

  if (resources.length === 0) {
    return;
  }
  for (const content of resources) {
    assert.match(content, /^generated-by-version: ["']3\.4\.2["']$/mu);
  }
});

test("the source tree has exactly the four approved Markdown documents", () => {
  const markdown = projectFiles(".")
    .filter((path) => path.endsWith(".md"))
    .map((path) => relative(workspaceRoot, path).replaceAll("\\", "/"))
    .sort();

  assert.deepEqual(markdown, ["CHANGELOG.md", "README.md", "REFERENCE.md", "SETUP.md"]);
  for (const path of markdown) assert.doesNotMatch(read(path), /CONTINUE-PROMPT\.txt/u);
});

test("release-owned version markers contain no prerelease suffix", () => {
  const ownedFiles = [
    "README.md", "SETUP.md", "REFERENCE.md", "CHANGELOG.md", "package.json",
    "control-plane/package.json", "control-plane/src/index.ts", "app/page.tsx", "app/dashboard/page.tsx",
    "app/dashboard/[serverId]/page.tsx",
  ];
  for (const path of ownedFiles) {
    assert.doesNotMatch(read(path), /3\.4(?:\.0)?[- ]beta/iu, `${path} still identifies CoreDSC as beta`);
  }
  const optionalPluginFiles = ["plugin/pom.xml", "plugin/src/main/resources/plugin.yml"];
  for (const path of optionalPluginFiles) {
    const content = optionalRead(path);
    if (content) {
      assert.doesNotMatch(content, /3\.4(?:\.0)?[- ]beta/iu, `${path} still identifies CoreDSC as beta`);
    }
  }
});


test("build helpers do not depend on ZIP-preserved execute permissions", () => {
  for (const path of ["scripts/build-verified.sh", "scripts/install-ci.sh", "scripts/validate-artifact.sh"]) {
    const script = read(path);
    assert.match(script, /exec bash "\$\{script_dir\}\/sites-env\.sh" -- bash "\$0" "\$@"/u, `${path} executes sites-env.sh directly`);
  }
});

test("R2 is absent and local media and identity state enforce bounded no-follow storage", () => {
  const wrangler = read("control-plane/wrangler.jsonc");
  const media = read("control-plane/src/media.ts");
  const localStore = optionalRead("plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudMediaStore.java");
  const identity = optionalRead("plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudIdentity.java");

  assert.doesNotMatch(wrangler, /r2_buckets|R2Bucket/u);
  assert.match(media, /MAX_MEDIA_BYTES\s*=\s*512\s*\*\s*1024/u);
  if (localStore && identity) {
    assert.match(localStore, /MAX_MEDIA_BYTES\s*=\s*512\s*\*\s*1024/u);
    assert.match(localStore, /LinkOption\.NOFOLLOW_LINKS/u);
    assert.match(localStore, /digest\.equals\(sha256\(bytes\)\)/u);
    assert.match(identity, /MAXIMUM_IDENTITY_BYTES\s*=\s*8_192/u);
    assert.match(identity, /LinkOption\.NOFOLLOW_LINKS/u);
    assert.match(identity, /StandardOpenOption\.CREATE_NEW/u);
    assert.match(identity, /identity public\/private keys do not match/u);
  }
});

test("local idempotency binds each key to a canonical request fingerprint", () => {
  const router = optionalRead("plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudOperationRouter.java");
  const repository = optionalRead("plugin/src/main/java/com/hubertstudios/coredsc/storage/CloudOperationRepository.java");
  const storage = optionalRead("plugin/src/main/java/com/hubertstudios/coredsc/storage/SQLiteStorage.java");
  const fingerprint = optionalRead("plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudRequestFingerprint.java");

  if (!router || !repository || !storage || !fingerprint) {
    return;
  }
  assert.match(router, /CloudRequestFingerprint\.calculate/u);
  assert.match(router, /Idempotency key was already used for a different local request/u);
  assert.match(router, /Idempotency key is already executing a different local request/u);
  assert.match(repository, /request_fingerprint/u);
  assert.match(storage, /SCHEMA_VERSION\s*=\s*13/u);
  assert.match(storage, /addColumnIfMissing\(connection, "cloud_operation_results", "request_fingerprint"/u);
  assert.match(fingerprint, /keys\.sort\(String::compareTo\)/u);
  assert.match(fingerprint, /SHA-256/u);
});

test("WebSocket fragment state is reset and stale socket callbacks are ignored", () => {
  const agent = optionalRead("plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudEditorAgent.java");
  const assembler = optionalRead("plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudTextFrameAssembler.java");
  const limits = optionalRead("plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudProtocolLimits.java");

  if (!agent || !assembler || !limits) {
    return;
  }
  assert.match(agent, /if \(socket\.get\(\) != webSocket\) return CompletableFuture\.completedFuture\(null\)/u);
  assert.ok((agent.match(/receivedText\.reset\(\)/gu) ?? []).length >= 4);
  assert.match(assembler, /pendingHighSurrogate/u);
  assert.match(assembler, /candidateBytes > maximumBytes/u);
  assert.doesNotMatch(limits, /getBytes\(/u);
  assert.match(limits, /Character\.isHighSurrogate/u);
  assert.match(limits, /bytes > MAXIMUM_MESSAGE_BYTES/u);
});
