import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { DatabaseSync, type StatementSync } from "node:sqlite";

import { InstanceRoom } from "../src/instance-room.ts";
import type { Env } from "../src/types.ts";

const here = dirname(fileURLToPath(import.meta.url));
const INSTANCE = "11111111-1111-4111-8111-111111111111";

class SqliteStatement {
  private readonly statement: StatementSync;
  private values: unknown[] = [];
  constructor(statement: StatementSync) { this.statement = statement; }
  bind(...values: unknown[]): SqliteStatement { this.values = values; return this; }
  async first<T>(): Promise<T | null> { return (this.statement.get(...this.values) as T | undefined) ?? null; }
  async run<T>(): Promise<{ results: T[]; success: boolean; meta: { changes: number } }> {
    const result = this.statement.run(...this.values);
    return { results: [], success: true, meta: { changes: Number(result.changes) } };
  }
  async all<T>(): Promise<{ results: T[]; success: boolean; meta: { changes: number } }> {
    return { results: this.statement.all(...this.values) as T[], success: true, meta: { changes: 0 } };
  }
  async raw<T>(): Promise<T[]> { return this.statement.all(...this.values).map((row) => Object.values(row)) as T[]; }
}

class SqliteD1 {
  private readonly db: DatabaseSync;
  constructor(db: DatabaseSync) { this.db = db; }
  prepare(query: string): SqliteStatement { return new SqliteStatement(this.db.prepare(query)); }
  async batch<T>(statements: SqliteStatement[]): Promise<Array<{ results: T[]; success: boolean; meta: { changes: number } }>> {
    const results = [];
    this.db.exec("BEGIN");
    try {
      for (const statement of statements) results.push(await statement.run<T>());
      this.db.exec("COMMIT");
      return results;
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
  }
  async exec(query: string): Promise<{ count: number; duration: number }> {
    this.db.exec(query);
    return { count: 0, duration: 0 };
  }
}

class FakeSocket {
  readonly sent: string[] = [];
  readonly closes: Array<{ code?: number; reason?: string }> = [];
  private readonly role: "agent" | "browser";
  constructor(role: "agent" | "browser") { this.role = role; }
  deserializeAttachment(): { role: string } { return { role: this.role }; }
  serializeAttachment(): void {}
  send(message: string): void { this.sent.push(message); }
  close(code?: number, reason?: string): void { this.closes.push({ code, reason }); }
}

class TestState {
  agents: FakeSocket[] = [];
  browsers: FakeSocket[] = [];
  setWebSocketAutoResponse(): void {}
  acceptWebSocket(): void {}
  getWebSockets(tag?: string): WebSocket[] {
    if (tag === "agent") return this.agents as unknown as WebSocket[];
    if (tag === "browser") return this.browsers as unknown as WebSocket[];
    return [...this.agents, ...this.browsers] as unknown as WebSocket[];
  }
}

function database(): DatabaseSync {
  const db = new DatabaseSync(":memory:");
  const migrationDirectory = join(here, "..", "migrations");
  for (const name of readdirSync(migrationDirectory).filter((value) => /^\d+_.+\.sql$/u.test(value)).sort()) {
    db.exec(readFileSync(join(migrationDirectory, name), "utf8"));
  }
  const now = Date.now();
  db.prepare(`INSERT INTO instances(id,public_key,display_name,plugin_version,minecraft_version,scheduler_runtime,status,
    approval_mode,last_seen_at,created_at) VALUES (?,?,?,?,?,?,?,1,?,?)`)
    .run(INSTANCE, "key", "Test Server", "old", "old", "PAPER", "OFFLINE", now - 60_000, now);
  db.prepare(`INSERT INTO health_incidents(id,instance_id,kind,status,detail,detected_at)
    VALUES (?,?,?,?,?,?)`).run(crypto.randomUUID(), INSTANCE, "AGENT_HEARTBEAT_LOST", "OPEN", "lost", now - 30_000);
  return db;
}

function environment(db: DatabaseSync): Env {
  return {
    COREDSC_DB: new SqliteD1(db),
    INSTANCE_ROOMS: {},
    APP_ORIGIN: "https://dashboard.example.test",
    PUBLIC_APP_URL: "https://dashboard.example.test",
    DISCORD_CLIENT_ID: "client",
    DISCORD_CLIENT_SECRET: "secret",
    DISCORD_REDIRECT_URI: "https://dashboard.example.test/api/v1/auth/discord/callback",
    COOKIE_SECRET: "test-cookie-secret-with-at-least-32-bytes",
    SESSION_TTL_SECONDS: "3600",
  } as unknown as Env;
}

function commandRequest(timeoutMillis = 30_000): Request {
  return new Request(`https://room/command?instance=${INSTANCE}`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({
      operation: "status.snapshot",
      payload: {},
      actor: { discordUserId: "100000000000000", displayName: "Owner" },
      idempotencyKey: crypto.randomUUID(),
      timeoutMillis,
    }),
  });
}

Object.assign(globalThis, {
  WebSocketRequestResponsePair: class WebSocketRequestResponsePair {
    constructor(_request: string, _response: string) {}
  },
});

test("agent response resolves one pending command and duplicate responses are ignored", async () => {
  const db = database();
  const state = new TestState();
  const agent = new FakeSocket("agent");
  state.agents = [agent];
  const room = new InstanceRoom(state as unknown as DurableObjectState, environment(db));

  const responsePromise = room.fetch(commandRequest());
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(agent.sent.length, 1);
  const request = JSON.parse(agent.sent[0]) as { requestId: string };
  const reply = JSON.stringify({ v: 1, type: "response", requestId: request.requestId, ok: true, payload: { online: true } });
  await room.webSocketMessage(agent as unknown as WebSocket, reply);
  await room.webSocketMessage(agent as unknown as WebSocket, reply);

  const response = await responsePromise;
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), { ok: true, payload: { online: true } });
  db.close();
});

test("disconnect fails pending commands immediately instead of waiting for their timeout", async () => {
  const db = database();
  const state = new TestState();
  const agent = new FakeSocket("agent");
  state.agents = [agent];
  const room = new InstanceRoom(state as unknown as DurableObjectState, environment(db));

  const started = Date.now();
  const responsePromise = room.fetch(commandRequest(30_000));
  await new Promise((resolve) => setImmediate(resolve));
  // Cloudflare may still expose the closing socket during the close callback.
  // The room must explicitly exclude that socket rather than reselecting it.
  room.webSocketClose(agent as unknown as WebSocket);
  const response = await responsePromise;
  assert.ok(Date.now() - started < 500, "disconnect should not wait for the command deadline");
  assert.equal(response.status, 503);
  assert.deepEqual(await response.json(), {
    ok: false,
    error: { code: "INSTANCE_OFFLINE", message: "Server connection closed", retryable: true },
  });
  db.close();
});

test("a stale replaced socket cannot fail or answer commands sent to the current agent", async () => {
  const db = database();
  const state = new TestState();
  const stale = new FakeSocket("agent");
  const current = new FakeSocket("agent");
  state.agents = [stale, current];
  const room = new InstanceRoom(state as unknown as DurableObjectState, environment(db));

  const responsePromise = room.fetch(commandRequest());
  await new Promise((resolve) => setImmediate(resolve));
  assert.equal(stale.sent.length, 0);
  assert.equal(current.sent.length, 1);
  const request = JSON.parse(current.sent[0]) as { requestId: string };

  room.webSocketError(stale as unknown as WebSocket);
  await room.webSocketMessage(stale as unknown as WebSocket, JSON.stringify({
    v: 1, type: "response", requestId: request.requestId, ok: false,
    error: { code: "STALE", message: "stale reply", retryable: true },
  }));
  await room.webSocketMessage(current as unknown as WebSocket, JSON.stringify({
    v: 1, type: "response", requestId: request.requestId, ok: true, payload: { current: true },
  }));

  const response = await responsePromise;
  assert.equal(response.status, 200);
  assert.deepEqual(await response.json(), { ok: true, payload: { current: true } });
  db.close();
});

test("heartbeat updates presence metadata and resolves a heartbeat-loss incident", async () => {
  const db = database();
  const state = new TestState();
  const agent = new FakeSocket("agent");
  const browser = new FakeSocket("browser");
  state.agents = [agent];
  state.browsers = [browser];
  const room = new InstanceRoom(state as unknown as DurableObjectState, environment(db));
  await room.fetch(new Request(`https://room/status?instance=${INSTANCE}`));

  await room.webSocketMessage(agent as unknown as WebSocket, JSON.stringify({
    v: 1,
    type: "heartbeat",
    payload: { pluginVersion: "3.4.2", minecraftVersion: "1.21.11", scheduler: "FOLIA" },
  }));

  const instance = db.prepare("SELECT status,plugin_version,minecraft_version,scheduler_runtime FROM instances WHERE id=?")
    .get(INSTANCE)!;
  assert.equal(instance.status, "ONLINE");
  assert.equal(instance.plugin_version, "3.4.2");
  assert.equal(instance.minecraft_version, "1.21.11");
  assert.equal(instance.scheduler_runtime, "FOLIA");
  const incident = db.prepare("SELECT status,resolved_at FROM health_incidents WHERE instance_id=?").get(INSTANCE)!;
  assert.equal(incident.status, "RESOLVED");
  assert.equal(typeof incident.resolved_at, "number");
  assert.equal(browser.sent.length, 1);
  assert.equal((JSON.parse(browser.sent[0]) as { type: string }).type, "heartbeat");
  db.close();
});

test("protocol bounds use UTF-8 bytes and the Durable Object rejects identity confusion", async () => {
  const db = database();
  const state = new TestState();
  const agent = new FakeSocket("agent");
  state.agents = [agent];
  const room = new InstanceRoom(state as unknown as DurableObjectState, environment(db));
  const initial = await room.fetch(new Request(`https://room/status?instance=${INSTANCE}`));
  assert.equal(initial.status, 200);
  const mismatch = await room.fetch(new Request("https://room/status?instance=22222222-2222-4222-8222-222222222222"));
  assert.equal(mismatch.status, 409);

  const oversized = `{"v":1,"type":"heartbeat","payload":"${"é".repeat(525_000)}"}`;
  assert.ok(oversized.length < 1_048_576);
  await room.webSocketMessage(agent as unknown as WebSocket, oversized);
  assert.deepEqual(agent.closes.at(-1), { code: 1009, reason: "Message too large" });
  db.close();
});
