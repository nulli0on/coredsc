# Changelog

## Plugin 3.4.2 / Panel 1.3.1 — 2026-08-04

- Separated the release identifiers: the Minecraft plugin is now `3.4.2`, while the hosted Panel and control plane are `1.3.1`.
- Updated Maven metadata, `plugin.yml`, generated configuration markers, dashboard fallbacks, package manifests, lockfiles and the control-plane health response.
- Included the `CONTROL_PLANE -> coredsc-control-plane` service binding in `vite.config.ts` so a clean deployment no longer requires a manual source edit.
- Replaced the deployment guide with a browser-only GitHub Codespaces and Cloudflare workflow for users without a local PC.
- Documented safe update order, existing D1 recovery, Cloudflare web-secret management, Codespaces plugin builds, Wrangler configuration conflicts and hosted-editor verification.

## 3.4.1 hosted-editor correction — 2026-08-04

- Removed the separate loopback WebEditor module, `/coredsc webeditor`, its permission, static local UI and modular configuration. `/coredsc editor` is now the only editor entry point.
- Kept first-owner pairing on the hosted dashboard with Discord sign-in and local-console confirmation, and added a full create/claim/confirm regression test for the agent path.
- Removed the misleading pre-confirmation dashboard link: the pairing page now shows one console command, waits for confirmation, and opens the server automatically.
- Added a packaged Python-bot README template that CoreDSC writes automatically to `plugins/CoreDSC/bot/README.md` on first start.
- Rebuilt the unauthenticated dashboard as a compact editor workspace instead of a marketing-style landing page.
- Made the control-plane test runner enumerate tests directly and run them sequentially for deterministic local results.

## 3.4.1 — 2026-08-03

### Dashboard editor redesign

- Replaced the previous card-based dashboard structure with an editor-style application frame inspired by the LuckPerms web editor: a compact resource browser, grouped server tools and one focused workspace.
- Matched the CoreDSC documentation palette, logo, system typography, neutral surfaces, thin borders and restrained red accents instead of applying a color-only theme change.
- Rebuilt the server list, network workspace, per-server navigation, configuration editor, pairing flow, empty states, tables and mobile layout around the new information architecture.
- Rewrote public and dashboard copy in plain administrative language and removed internal implementation terms from normal user-facing pages.
- Added friendly labels for roles, operations, outcomes, connection states and server runtime details while leaving backend identifiers unchanged.
- Preserved every existing backend route, operation, role and capability check.

### Reliability corrections

- Preserved active maintenance join and chat restrictions across plugin restarts instead of automatically cancelling persisted maintenance state.
- Made Incident Mode channel restoration operation-owned, retryable after partial restoration and resistant to restoring snapshots created by unrelated channel operations.
- Added rollback for partially applied incident channel locks when incident startup fails; if rollback or state cleanup fails, the persisted incident remains active for an authorized restoration retry.
- Prevented Incident Mode and Maintenance from cancelling each other's chat-pause ownership.
- Prevented a late WebSocket open callback from reconnecting the cloud agent after plugin shutdown.
- Completed reversible slowmode operations with an authorized `channel.slowmode.restore` path in the dashboard, Worker policy and local agent.
- Deleted a newly created Discord scheduled event when local persistence fails, avoiding an unmanaged remote event.
- Prevented stale/replaced Durable Object agent sockets from delivering messages or disconnecting the current agent.
- Waited a bounded three seconds for the Discord shutdown event before module and JDA teardown, while retaining the existing bounded SQLite drain.
- Prevented rapid duplicate dashboard mutations, network rollouts, staff changes and approval decisions from issuing concurrent requests with different operation identities.

### Portability and verification fixes

- Removed the hardcoded original Codespace path from the release-contract tests; project discovery now derives the source root from `import.meta.url`.
- Decoded filesystem URLs with `fileURLToPath` so validation works from folders containing spaces instead of looking for literal `%20` paths.
- Made the optional plugin safety harness skip explicitly in the dashboard/control-plane-only archive while remaining mandatory whenever plugin sources are present.
- Clarified that npm audit findings are separate from Worker test failures and must not be force-upgraded without advisory review.
- Made nested build scripts run explicitly through Bash so ZIP extraction cannot cause `sites-env.sh: Permission denied`.
- Added an explicit Node.js and archive-completeness check before control-plane TypeScript and test execution.

### Control-plane hardening

- Made first-owner pairing claims conditional and atomic so concurrent claims cannot overwrite an existing owner.
- Canonicalized approval payload storage/comparison and repaired replay responses so retries return the original operation result and audit identifier.
- Replaced unbounded JSON text decoding with a bounded streaming read and fatal UTF-8 validation.
- Rejected OAuth return paths containing backslashes or control characters.

### Verification added

- Added OAuth state-binding, one-time-use, redirect-sanitization, session-expiry, CSRF logout and owned-server pairing authorization tests.
- Added exact role/capability matrices, repeated rollout idempotency, media-boundary/signature, D1 migration, active Durable Object socket and duplicate/reconnect tests.
- Added source contracts for overlapping incident/maintenance restoration, retry-safe incident restoration, scheduled-event rollback, stale configuration revisions, configuration allowlists, backup/rollback, protected identities, Discord hierarchy, command allowlists, payload bounds, optional-module isolation, bounded SQLite shutdown and late WebSocket open handling.
- The dashboard TypeScript syntax gate, global TypeScript no-emit gate, Java 21 release safety harness and **75/75** dependency-free control-plane/contract tests pass.

### Verification not completed in this environment

- `mvn -e clean verify`, JUnit execution, shading and JAR inspection were not run because `mvn` was unavailable and the available package infrastructure could not supply Maven artifacts.
- Root `npm ci` failed because the configured registry could not provide the locked `zod-validation-error@4.0.2` tarball; root lint, production build and rendered-page tests therefore did not run.
- `control-plane/npm ci` failed because the configured registry could not provide the locked `youch-core@0.3.3` tarball; Wrangler checks, migration execution and local Worker preview therefore did not run.
- Browser QA, realistic Paper/Folia runtime tests and optional-integration runtime matrix tests were not performed.
- Cloudflare and Discord account tests remain external because no deployment credentials or test guild were provided.

## 3.4.0 — 2026-08-02

### Release conversion

- Removed the CoreDSC prerelease suffix from the Maven project, plugin metadata, package manifests, lockfiles, control-plane health response, dashboard fallbacks, managed configuration templates, tests and documentation.
- The distributable plugin filename is now `CoreDSC-3.4.0.jar`.
- Added automated release-contract checks that reject inconsistent CoreDSC versions, prerelease markers in release-owned surfaces, additional Markdown documentation, R2 runtime bindings and missing WebSocket/media hardening.

### Added

- Hosted CoreDSC Operations dashboard with authenticated server, moderation, channel, incident, maintenance, event, AutoMod, Smart Console, approval and network surfaces.
- Cloudflare control plane with Discord OAuth, first-party sessions, D1 persistence, Durable Object agent rooms, audit history, health tracking and scheduled cleanup/retry work.
- Explicit capability roles: `OWNER`, `SERVER_ADMIN`, `MODERATOR`, `CONSOLE_VIEWER`, `CONSOLE_OPERATOR`, `SUPPORT` and `VIEWER`.
- Outbound authenticated TLS WebSocket agent with Ed25519 request authentication, replay-resistant nonces and bounded reconnect/backoff behavior.
- Server pairing with local console confirmation.
- Dedicated ownership recovery initiated only from the unbound local server console, with a second local confirmation, atomic owner replacement and audit entry.
- Persistent operation fingerprints and idempotency records for duplicate/retry protection.
- Local SQLite schema 13, adding canonical request fingerprints to completed cloud-operation records while retaining compatibility with legacy rows.
- Approval dispatch leases for restart/crash recovery without duplicate execution.
- D1-backed rate limiting for OAuth, pairing, operations, approvals, staff, uploads and network changes.
- Streaming request-body limits that reject oversized chunked image uploads before unbounded buffering.
- D1 migration `0006_ownership_recovery.sql`.
- Local, content-addressed dashboard media storage through the customer agent.
- Hosted moderation-case history and case-note controls backed by the local cases module.
- Dashboard live-channel reconnect with bounded exponential backoff and visible connection state.
- Dependency-free Java 21 release safety harness under `scripts/java-release-check.sh`.

### Changed

- Removed the R2 dependency and binding.
- Media uploads use bounded Base64 transport only. The Worker accepts PNG, JPEG, WebP and GIF up to 512 KiB, validates magic bytes, forwards the image to the authenticated local agent and does not store the image body in D1 or audit records.
- Cloud control remains disabled by default and uses a deliberately non-routable example endpoint until the operator configures a real deployment. A missing modular setting also fails closed.
- Replaced a decorative landing-page Setup Doctor button with non-operational status text so visible operational controls correspond to real backend calls.
- Separated `case.manage` from `moderation.manage`: SUPPORT may inspect history and add notes without receiving sanction authority; SERVER_ADMIN and MODERATOR retain both capabilities.
- Kept approval rejection available while the Minecraft agent is offline because rejection is a cloud-side final decision and does not dispatch an agent operation.
- Distinguished authentication failures from dashboard/backend outages instead of presenting every load failure as a Discord sign-in requirement.
- Consolidated project documentation into exactly `README.md`, `SETUP.md`, `REFERENCE.md` and `CHANGELOG.md`.
- Removed the obsolete continuation-file reference from the README.

### Fixed and hardened

- Fixed three Java compilation defects found by the first full Maven compile: the DiscordSRV migration now carries its detected plugin instance into linked-account import, the JDA 6 audit permission uses `VIEW_AUDIT_LOGS`, and scheduled-event cancellation retrieves the event before invoking its supported `delete()` action.
- Rejected duplicate JSON object keys instead of silently overwriting security-sensitive fields.
- Rejected raw control characters, non-finite numbers and unpaired Unicode surrogates in the dependency-free JSON codec.
- Added JSON nesting, value-count and string-size limits to stop stack and memory exhaustion; cyclic output structures are rejected.
- Replaced repeated whole-buffer WebSocket UTF-8 rescans with a bounded fragment assembler that correctly handles surrogate pairs split across frames.
- Replaced outbound UTF-8 size checks with allocation-free incremental byte counting and early rejection above the one-megabyte protocol limit.
- Cleared partial WebSocket text on open, close, error and shutdown, and ignored callbacks from replaced sockets so stale fragments cannot contaminate a reconnected session.
- Revalidated local media digest, signature and size before reuse or resolution.
- Rejected symbolic-link media roots/files and used bounded no-follow reads.
- Preserved idempotent concurrent installation of identical content-addressed media.
- Bound persistent and in-flight local idempotency keys to a canonical SHA-256 fingerprint of the operation, payload and audited reason, rejecting same-key request substitution even if the control plane is faulty.
- Hardened the persistent Ed25519 identity file with bounded no-follow reads, create-only writes, key-pair self-validation, strict file-size limits and temporary key-byte clearing.
- Preserved the no-inbound-port architecture and local custody of Discord bot tokens.
- Preserved deny-by-default named operations; arbitrary file access and arbitrary remote commands are not exposed.
- Preserved stale network template revision rejection, rollout idempotency, protected identities, Discord hierarchy, command allowlists, payload limits and feature-switch enforcement.
- Ensured cloud Setup Doctor checks and network announcements cross the appropriate Bukkit scheduler boundary before Bukkit API access.

### Automated checks completed

```text
Control-plane TypeScript no-emit check
51/51 Node tests
Java 21 release safety harness with -Xlint:all -Werror
Git whitespace/error check
```

The passing tests cover:

- approval creation, second-person approval, rejection, expiry and crash/lease retry;
- retryable versus permanent failures;
- direct and approved-operation idempotency;
- duplicate Durable Object messages, disconnects and heartbeats;
- offline redacted configuration cache;
- stale network template revisions and rollout keys;
- owner-only staff changes, ownership recovery and audit writes;
- request-size, parser, media-type, media-size, digest and symlink bounds;
- D1 migration ordering and schema assertions;
- rate limits, role policy and case-note capability separation;
- dashboard operation-to-policy coverage, reconnect behavior and offline approval rejection;
- plugin dependency scopes, fail-closed defaults and static cloud scheduler/Player-boundary contracts;
- complete `3.4.0` release-version consistency across source and runtime surfaces.

### Not verified in this delivery

- A user-side Maven compile reached the Java compiler and exposed three source errors; those exact errors are corrected in this archive. A complete post-fix `mvn -e clean verify`, JUnit run, shading pass and JAR inspection still require execution in an environment with Maven and dependency access.
- Root dashboard `npm ci`, lint, production build and rendered-page tests could not complete because the available npm registry proxy returned HTTP 404 for a locked package tarball. The source does not ship an unsafe dependency workaround.
- Desktop, tablet and mobile browser QA was not performed.
- Real Paper and Folia server tests, optional-integration matrix tests and shutdown-under-load tests were not performed.
- Real Cloudflare deployment, Sites `CONTROL_PLANE` binding, D1, Durable Objects and scheduled triggers require the operator's account and were not executed.
- Real Discord OAuth, guild permissions, role hierarchy and bot behavior require operator credentials and a test guild and were not executed.

Plugin `3.4.2` and Panel/control-plane `1.3.1` are the current release identifiers. This changelog records only checks actually executed; it does not claim that software is defect-free or that unperformed local or external gates passed.
