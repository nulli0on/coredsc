import Link from "next/link";
import { Brand, Icon } from "./ui";

const capabilities = [
  ["pulse", "Live health", "Know when a server, Discord connection, or SQLite queue starts failing."],
  ["shield", "Unified moderation", "One reviewed action across Minecraft and Discord, backed by a single case."],
  ["sliders", "Visual configuration", "Map real channels, toggle modules, and build embeds without touching YAML."],
  ["alert", "Incident mode", "Lock down channels, pause chat, notify staff, and restore the exact previous state."],
  ["terminal", "Smart Console", "Collapsed incidents, targeted alerts, redaction, and capability-gated execution."],
  ["network", "Network control", "Operate every CoreDSC instance from one account and one consistent policy surface."],
] as const;

export default function Home() {
  return (
    <main className="landing-shell">
      <nav className="landing-nav">
        <Brand />
        <div className="landing-nav-links">
          <a href="#platform">Platform</a>
          <a href="#security">Security</a>
          <a href="#operations">Operations</a>
        </div>
        <Link className="button button-secondary button-small" href="/api/v1/auth/discord?return=/dashboard">
          Sign in with Discord
        </Link>
      </nav>

      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow"><span className="status-dot online" /> CoreDSC 3.4.0</span>
          <h1>Your Minecraft community. One operations center.</h1>
          <p>
            A hosted control plane for Folia-safe Minecraft automation, Discord moderation,
            incident response, configuration, and multi-server health—without exposing a port or bot token.
          </p>
          <div className="hero-actions">
            <Link className="button button-primary" href="/api/v1/auth/discord?return=/dashboard">
              <Icon name="discord" /> Open dashboard
            </Link>
            <a className="button button-ghost" href="#platform">See what it replaces</a>
          </div>
          <div className="trust-row">
            <span><Icon name="check" /> Outbound-only agent</span>
            <span><Icon name="check" /> Discord OAuth</span>
            <span><Icon name="check" /> No secrets in cloud</span>
          </div>
        </div>

        <div className="hero-console" aria-label="CoreDSC operations dashboard preview">
          <div className="preview-rail">
            <div className="preview-mark">C</div>
            {["grid", "pulse", "shield", "terminal", "sliders"].map((name, index) => (
              <span className={index === 0 ? "preview-icon active" : "preview-icon"} key={name}>
                <Icon name={name} />
              </span>
            ))}
          </div>
          <div className="preview-main">
            <div className="preview-topline"><span>CrimsonTide</span><span className="health-pill">All systems healthy</span></div>
            <div className="preview-heading"><div><small>OVERVIEW</small><h2>Good evening, Hubert.</h2></div><span className="preview-action">Setup Doctor ready</span></div>
            <div className="metric-grid">
              <div><span className="metric-icon violet"><Icon name="users" /></span><strong>124</strong><small>Online players</small></div>
              <div><span className="metric-icon blue"><Icon name="discord" /></span><strong>38 ms</strong><small>Discord gateway</small></div>
              <div><span className="metric-icon green"><Icon name="database" /></span><strong>0 / 8192</strong><small>SQLite queue</small></div>
            </div>
            <div className="preview-panel">
              <div className="panel-title"><div><strong>Server health</strong><small>Live agent telemetry</small></div><span>Last 30 min</span></div>
              <div className="chart-bars" aria-hidden="true">
                {[34,42,37,55,48,67,58,62,51,73,69,77,71,82,76,88,84,91,86,94,89,96].map((height, index) => (
                  <i key={index} style={{ height: `${height}%` }} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="landing-section" id="platform">
        <span className="eyebrow">Beyond chat bridging</span>
        <h2>Daily server management, not another log dump.</h2>
        <div className="feature-grid">
          {capabilities.map(([icon, title, body]) => (
            <article className="feature-card" key={title}>
              <span className="feature-icon"><Icon name={icon} /></span>
              <h3>{title}</h3>
              <p>{body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="security-section" id="security">
        <div>
          <span className="eyebrow">Local authority</span>
          <h2>The cloud asks. Your server decides.</h2>
          <p>Every configuration path and action is validated again by the plugin. Stale revisions, unknown operations, secrets, and unauthorized staff are rejected before they can touch the server.</p>
        </div>
        <ul>
          <li><Icon name="key" /><span><strong>Ed25519 instance identity</strong>Rotatable local key; signed replay-resistant WebSocket handshake.</span></li>
          <li><Icon name="lock" /><span><strong>Capability-based staff access</strong>Owners, admins, moderators, support, console operators, and viewers.</span></li>
          <li><Icon name="history" /><span><strong>Immutable accountability</strong>Actor, reason, request, outcome, and approval history for sensitive changes.</span></li>
        </ul>
      </section>

      <footer className="landing-footer" id="operations">
        <Brand />
        <p>CoreDSC Operations · Built for Paper, Folia, Discord, and serious communities.</p>
        <Link href="/api/v1/auth/discord?return=/dashboard">Launch dashboard →</Link>
      </footer>
    </main>
  );
}
