"use client";

import Image from "next/image";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { api, ApiError, CoreServer, CoreUser, csrfHeader, oauthUrl, relativeTime } from "../lib/control-plane";
import { Brand, Icon } from "../ui";

type CoreNetwork = { id: string; name: string; server_count: number; created_at: number };
type NetworkMember = {
  id: string;
  display_name: string;
  plugin_version: string;
  minecraft_version: string;
  scheduler_runtime: string;
  status: string;
  last_seen_at: number;
};
type NetworkTemplate = {
  id: string;
  name: string;
  patch: Record<string, unknown>;
  revision: number;
  updatedAt: number;
};
type NetworkDetails = {
  network: { id: string; name: string; createdAt: number };
  members: NetworkMember[];
  templates: NetworkTemplate[];
};

const TEMPLATE_EXAMPLE = JSON.stringify({
  changes: [
    { file: "modules/chat-sync.yml", path: "enabled", value: true },
    { file: "modules/server-events.yml", path: "events.death.enabled", value: true },
  ],
}, null, 2);

export default function DashboardPage() {
  const [user, setUser] = useState<CoreUser | null>(null);
  const [servers, setServers] = useState<CoreServer[]>([]);
  const [networks, setNetworks] = useState<CoreNetwork[]>([]);
  const [networkDetails, setNetworkDetails] = useState<NetworkDetails | null>(null);
  const [csrf, setCsrf] = useState("");
  const [networkName, setNetworkName] = useState("");
  const [selectedNetwork, setSelectedNetwork] = useState("");
  const [selectedServer, setSelectedServer] = useState("");
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [templateName, setTemplateName] = useState("");
  const [templateJson, setTemplateJson] = useState(TEMPLATE_EXAMPLE);
  const [applyReason, setApplyReason] = useState("");
  const [error, setError] = useState("");
  const [authRequired, setAuthRequired] = useState(false);
  const [actionError, setActionError] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      api<{ user: CoreUser; csrfToken: string }>("/v1/me"),
      api<{ servers: CoreServer[] }>("/v1/servers"),
      api<{ networks: CoreNetwork[] }>("/v1/networks"),
    ]).then(([identity, list, networkList]) => {
      setUser(identity.user);
      setCsrf(identity.csrfToken);
      setServers(list.servers);
      setNetworks(networkList.networks);
      const initialNetwork = networkList.networks[0]?.id ?? "";
      setSelectedNetwork(initialNetwork);
      setSelectedServer(list.servers.find((server) => server.role === "OWNER")?.id ?? "");
      if (initialNetwork) {
        void api<NetworkDetails>(`/v1/networks/${initialNetwork}`)
          .then(setNetworkDetails)
          .catch((failure: unknown) => setActionError(messageOf(failure)));
      }
    }).catch((failure: unknown) => {
      setAuthRequired(failure instanceof ApiError && failure.status === 401);
      setError(messageOf(failure));
    })
      .finally(() => setLoading(false));
  }, []);

  const online = useMemo(() => servers.filter((server) => server.online).length, [servers]);
  const ownedServers = useMemo(() => servers.filter((server) => server.role === "OWNER"), [servers]);
  const availableServers = useMemo(() => {
    const members = new Set(networkDetails?.members.map((member) => member.id) ?? []);
    return ownedServers.filter((server) => !members.has(server.id));
  }, [networkDetails, ownedServers]);

  async function refreshNetwork(networkId = selectedNetwork) {
    try {
      const details = await api<NetworkDetails>(`/v1/networks/${networkId}`);
      setNetworkDetails(details);
      const selected = details.templates.find((template) => template.id === selectedTemplate);
      if (!selected && selectedTemplate) setSelectedTemplate("");
    } catch (failure) {
      setActionError(messageOf(failure));
    }
  }

  async function perform(action: () => Promise<void>) {
    setBusy(true);
    setActionError("");
    setNotice("");
    try {
      await action();
    } catch (failure) {
      setActionError(messageOf(failure));
    } finally {
      setBusy(false);
    }
  }

  function chooseTemplate(templateId: string) {
    setSelectedTemplate(templateId);
    const template = networkDetails?.templates.find((item) => item.id === templateId);
    if (!template) {
      setTemplateName("");
      setTemplateJson(TEMPLATE_EXAMPLE);
      return;
    }
    setTemplateName(template.name);
    setTemplateJson(JSON.stringify(template.patch, null, 2));
  }

  async function createNetwork() {
    await perform(async () => {
      if (!networkName.trim()) throw new Error("Enter a network name first.");
      const result = await api<{ network: { id: string; name: string } }>("/v1/networks", {
        method: "POST", headers: csrfHeader(csrf), body: JSON.stringify({ name: networkName }),
      });
      const created: CoreNetwork = { ...result.network, server_count: 0, created_at: Date.now() };
      setNetworks((current) => [...current, created]);
      setSelectedNetwork(created.id);
      setNetworkName("");
      await refreshNetwork(created.id);
      setNotice(`Network “${created.name}” created.`);
    });
  }

  async function addServer() {
    await perform(async () => {
      if (!selectedNetwork || !selectedServer) throw new Error("Choose a network and an owned server.");
      const result = await api<{ added: boolean }>(`/v1/networks/${selectedNetwork}/members`, {
        method: "POST", headers: csrfHeader(csrf), body: JSON.stringify({ instanceId: selectedServer }),
      });
      if (result.added) {
        setNetworks((current) => current.map((network) => network.id === selectedNetwork
          ? { ...network, server_count: Number(network.server_count) + 1 } : network));
      }
      await refreshNetwork();
      setNotice(result.added ? "Server added to the network." : "That server is already a member.");
    });
  }

  async function removeServer(instanceId: string) {
    await perform(async () => {
      await api(`/v1/networks/${selectedNetwork}/members/${instanceId}`, {
        method: "DELETE", headers: csrfHeader(csrf),
      });
      setNetworks((current) => current.map((network) => network.id === selectedNetwork
        ? { ...network, server_count: Math.max(0, Number(network.server_count) - 1) } : network));
      await refreshNetwork();
      setNotice("Server removed from the network. Its local configuration was not changed.");
    });
  }

  async function saveTemplate() {
    await perform(async () => {
      if (!selectedNetwork) throw new Error("Create or select a network first.");
      if (!templateName.trim()) throw new Error("Enter a template name.");
      const patch = parseTemplate(templateJson);
      const current = networkDetails?.templates.find((template) => template.id === selectedTemplate);
      if (current) {
        await api(`/v1/networks/${selectedNetwork}/templates/${current.id}`, {
          method: "PUT",
          headers: csrfHeader(csrf),
          body: JSON.stringify({ name: templateName, patch, revision: current.revision }),
        });
        setNotice("Template revision saved.");
      } else {
        const created = await api<{ template: NetworkTemplate }>(`/v1/networks/${selectedNetwork}/templates`, {
          method: "POST", headers: csrfHeader(csrf), body: JSON.stringify({ name: templateName, patch }),
        });
        setSelectedTemplate(created.template.id);
        setNotice("Reviewed configuration template created.");
      }
      await refreshNetwork();
    });
  }

  async function deleteTemplate() {
    await perform(async () => {
      if (!selectedTemplate) throw new Error("Choose a saved template first.");
      await api(`/v1/networks/${selectedNetwork}/templates/${selectedTemplate}`, {
        method: "DELETE", headers: csrfHeader(csrf),
      });
      setSelectedTemplate("");
      setTemplateName("");
      setTemplateJson(TEMPLATE_EXAMPLE);
      await refreshNetwork();
      setNotice("Template deleted. No server configuration was changed.");
    });
  }

  async function applyTemplate() {
    await perform(async () => {
      if (!selectedTemplate) throw new Error("Save or choose a template first.");
      if (!applyReason.trim()) throw new Error("An audited reason is required.");
      const result = await api<{ targets: Array<{ approvalRequired?: boolean }> }>(
        `/v1/networks/${selectedNetwork}/templates/${selectedTemplate}/apply`, {
          method: "POST", headers: csrfHeader(csrf), body: JSON.stringify({ reason: applyReason, rolloutId: crypto.randomUUID() }),
        },
      );
      const approvals = result.targets.filter((target) => target.approvalRequired).length;
      setApplyReason("");
      setNotice(`${result.targets.length} server(s) accepted the template request${approvals
        ? `; ${approvals} require a second staff approval` : " and scheduled a safe local reload"}.`);
    });
  }

  if (loading) return <LoadingScreen />;
  if (error) return authRequired ? <SignInState error={error} /> : <UnavailableState error={error} />;

  return (
    <main className="app-shell">
      <aside className="app-sidebar">
        <Brand />
        <nav>
          <span className="nav-label">CONTROL CENTER</span>
          <Link className="nav-item active" href="/dashboard"><Icon name="grid" /> Servers</Link>
          <a className="nav-item" href="#network"><Icon name="network" /> Networks</a>
          <a className="nav-item" href="#pair-help"><Icon name="plus" /> Pair a server</a>
        </nav>
        <div className="sidebar-account">
          <Avatar user={user} />
          <div><strong>{user?.displayName}</strong><small>@{user?.username}</small></div>
        </div>
      </aside>

      <section className="app-content">
        <header className="app-header">
          <div><span className="breadcrumb">CoreDSC / Servers</span><h1>Your servers</h1></div>
          <a className="button button-primary button-small" href="#pair-help"><Icon name="plus" /> Pair server</a>
        </header>

        <div className="summary-strip">
          <div><span className="summary-icon green"><Icon name="server" /></span><p><strong>{online}</strong><small>Online agents</small></p></div>
          <div><span className="summary-icon violet"><Icon name="network" /></span><p><strong>{servers.length}</strong><small>Paired servers</small></p></div>
          <div><span className="summary-icon blue"><Icon name="shield" /></span><p><strong>{servers.filter((server) => server.approvalMode).length}</strong><small>Approval protected</small></p></div>
        </div>

        <div className="section-heading">
          <div><h2>Managed instances</h2><p>Every plugin connects outward. No customer port is exposed.</p></div>
          <div className="filter-chip"><span className="status-dot online" /> {online} online</div>
        </div>
        {servers.length === 0 ? <EmptyServers /> : <div className="server-grid">
          {servers.map((server) => <ServerCard server={server} key={server.id} />)}
        </div>}

        <section className="pair-callout" id="pair-help">
          <span className="summary-icon violet"><Icon name="key" /></span>
          <div><h3>Pair another CoreDSC server</h3><p>Run <code>/coredsc editor</code> as an in-game linked administrator or from the local console. Open the temporary HTTPS link, sign in with Discord, then confirm the displayed code locally with <code>/coredsc editor auth CODE</code>.</p></div>
        </section>

        <section className="network-workspace" id="network">
          <div className="section-heading"><div><h2>Network operations</h2><p>Group owned servers and roll out allowlisted, revisioned configuration templates.</p></div></div>
          {actionError && <div className="inline-alert error">{actionError}</div>}
          {notice && <div className="inline-alert success">{notice}</div>}
          <div className="network-grid">
            <div className="network-list">
              {networks.length ? networks.map((network) => (
                <button type="button" key={network.id} className={selectedNetwork === network.id ? "network-card selected" : "network-card"} onClick={() => { setSelectedNetwork(network.id); setNetworkDetails(null); void refreshNetwork(network.id); }}>
                  <span className="feature-icon"><Icon name="network" /></span>
                  <div><strong>{network.name}</strong><small>{network.server_count} server(s) · created {relativeTime(network.created_at)}</small></div>
                </button>
              )) : <div className="empty-inline"><Icon name="network" /> No network groups yet.</div>}
            </div>
            <div className="network-controls">
              <h3>Create network</h3>
              <div className="inline-fields"><input maxLength={80} value={networkName} onChange={(event) => setNetworkName(event.target.value)} placeholder="CrimsonTide Network" /><button type="button" className="button button-primary button-small" disabled={busy} onClick={() => void createNetwork()}>Create</button></div>
              <h3>Add an owned server</h3>
              <div className="inline-fields"><select value={selectedServer} onChange={(event) => setSelectedServer(event.target.value)}><option value="">Choose a server</option>{availableServers.map((server) => <option value={server.id} key={server.id}>{server.name}</option>)}</select><button type="button" className="button button-secondary button-small" disabled={busy || !selectedNetwork || !selectedServer} onClick={() => void addServer()}>Add server</button></div>
            </div>
          </div>

          {networkDetails && <div className="network-detail-grid">
            <section className="network-panel">
              <div className="panel-title"><div><h3>Member servers</h3><p>Ownership is checked again before every rollout.</p></div><span className="filter-chip">{networkDetails.members.length} members</span></div>
              <div className="member-list">{networkDetails.members.length ? networkDetails.members.map((member) => <div className="network-member" key={member.id}><span className="server-avatar compact">{member.display_name.slice(0, 2).toUpperCase()}</span><div><strong>{member.display_name}</strong><small>{member.scheduler_runtime} · CoreDSC {member.plugin_version || "unknown"} · {relativeTime(member.last_seen_at)}</small></div><span className={member.status === "ONLINE" ? "state-badge online" : "state-badge offline"}>{member.status.toLowerCase()}</span><button type="button" className="text-button danger" disabled={busy} onClick={() => void removeServer(member.id)}>Remove</button></div>) : <div className="empty-inline">Add an owned server to start.</div>}</div>
            </section>

            <section className="network-panel template-panel">
              <div className="panel-title"><div><h3>Configuration templates</h3><p>Only the plugin&apos;s strict structured-edit allowlist is accepted. Secrets and raw files are rejected.</p></div></div>
              <label>Saved template<select value={selectedTemplate} onChange={(event) => chooseTemplate(event.target.value)}><option value="">New template</option>{networkDetails.templates.map((template) => <option value={template.id} key={template.id}>{template.name} · r{template.revision}</option>)}</select></label>
              <label>Template name<input maxLength={80} value={templateName} onChange={(event) => setTemplateName(event.target.value)} placeholder="Production baseline" /></label>
              <label>Structured changes<textarea rows={10} spellCheck={false} value={templateJson} onChange={(event) => setTemplateJson(event.target.value)} /></label>
              <div className="template-actions"><button type="button" className="button button-secondary button-small" disabled={busy} onClick={() => void saveTemplate()}>{selectedTemplate ? "Save revision" : "Create template"}</button>{selectedTemplate && <button type="button" className="text-button danger" disabled={busy} onClick={() => void deleteTemplate()}>Delete</button>}</div>
              <label>Audited rollout reason<input maxLength={500} value={applyReason} onChange={(event) => setApplyReason(event.target.value)} placeholder="Enable the reviewed production baseline" /></label>
              <button type="button" className="button button-primary" disabled={busy || !selectedTemplate || !networkDetails.members.length} onClick={() => void applyTemplate()}><Icon name="shield" /> Apply to all members</button>
              <small className="security-note">Servers with approval mode enabled create a second-person approval instead of applying immediately. Every server validates, backs up, writes, and reloads locally.</small>
            </section>
          </div>}
        </section>
      </section>
    </main>
  );
}

function parseTemplate(value: string): Record<string, unknown> {
  let parsed: unknown;
  try { parsed = JSON.parse(value); } catch { throw new Error("Template changes must be valid JSON."); }
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("Template root must be a JSON object.");
  return parsed as Record<string, unknown>;
}

function messageOf(failure: unknown) {
  return failure instanceof Error ? failure.message : "The request could not be completed.";
}

function ServerCard({ server }: { server: CoreServer }) {
  return <Link className="server-card" href={`/dashboard/${server.id}`}>
    <div className="server-card-top"><span className="server-avatar">{server.name.slice(0, 2).toUpperCase()}</span><span className={server.online ? "state-badge online" : "state-badge offline"}><span className={server.online ? "status-dot online" : "status-dot"} /> {server.online ? "Online" : "Offline"}</span></div>
    <h3>{server.name}</h3><p>{server.minecraftVersion || "Minecraft version pending"} · CoreDSC {server.pluginVersion || "3.4.0"}</p>
    <div className="server-meta"><span><Icon name="pulse" /> {server.scheduler || "Agent"}</span><span><Icon name="history" /> {relativeTime(server.lastSeenAt)}</span></div>
    <div className="server-card-footer"><span>{server.role.replaceAll("_", " ")}</span><strong>Open control center <Icon name="chevron" /></strong></div>
  </Link>;
}

function Avatar({ user }: { user: CoreUser | null }) {
  if (user?.avatar) return <Image unoptimized width={32} height={32} className="account-avatar" alt="" src={`https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=64`} />;
  return <span className="account-avatar fallback">{user?.displayName?.slice(0, 1).toUpperCase() ?? "?"}</span>;
}

function LoadingScreen() { return <main className="center-state"><span className="brand-mark loading-mark">C</span><p>Connecting to CoreDSC Operations…</p></main>; }
function SignInState({ error }: { error: string }) { return <main className="center-state"><Brand /><h1>Discord sign-in required</h1><p>{error}</p><a className="button button-primary" href={oauthUrl("/dashboard")}><Icon name="discord" /> Sign in with Discord</a></main>; }
function UnavailableState({ error }: { error: string }) { return <main className="center-state"><Brand /><h1>Dashboard unavailable</h1><p>{error}</p><button className="button button-secondary" onClick={() => window.location.reload()}>Retry</button></main>; }
function EmptyServers() { return <div className="empty-state"><span className="empty-icon"><Icon name="server" /></span><h3>No paired servers yet</h3><p>Run <code>/coredsc editor</code> on your Minecraft server, then open its temporary link.</p></div>; }
