"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { Brand, Icon } from "../../ui";
import { api, CoreUser, csrfHeader, liveUrl, relativeTime } from "../../lib/control-plane";

type Tab = "overview" | "setup" | "editor" | "moderation" | "channels" | "incident" | "console" | "maintenance" | "events" | "automod" | "staff" | "approvals" | "audit";
type HealthIncident = { id: string; kind: string; status: string; detail: string; detected_at: number; resolved_at?: number | null };
type Overview = { instance: Record<string, unknown>; presence: { online?: boolean }; incidents?: HealthIncident[]; role: string; capabilities: string[] };
type OperationResult = { ok?: boolean; payload?: unknown; error?: { message?: string }; approvalRequired?: boolean; approvalId?: string };
type AuditEvent = { id: string; actor_display_name: string; operation: string; reason: string; outcome: string; created_at: number };
type Approval = { id: string; requester_name: string; operation: string; reason: string; status: string; created_at: number; expires_at: number };
type ModerationCase = { id: number; action: string; targetName: string; executor: string; reason: string; duration: string; status: string; createdAt: number };
type LiveState = "connecting" | "connected" | "reconnecting";
type RetryRequest = { operation: string; payload: Record<string, unknown>; reason: string; idempotencyKey: string };

const navigation: { label?: string; tab: Tab; icon: string; name: string; capability: string }[] = [
  { label: "SERVER", tab: "overview", icon: "grid", name: "Overview", capability: "server.view" },
  { tab: "setup", icon: "pulse", name: "Setup Doctor", capability: "server.manage" },
  { tab: "editor", icon: "sliders", name: "Configuration", capability: "config.view" },
  { label: "OPERATIONS", tab: "moderation", icon: "shield", name: "Moderation", capability: "moderation.view" },
  { tab: "channels", icon: "channel", name: "Channels", capability: "channel.view" },
  { tab: "incident", icon: "alert", name: "Incident Mode", capability: "incident.view" },
  { tab: "console", icon: "terminal", name: "Smart Console", capability: "console.view" },
  { label: "AUTOMATION", tab: "maintenance", icon: "settings", name: "Maintenance", capability: "maintenance.view" },
  { tab: "events", icon: "calendar", name: "Events", capability: "event.view" },
  { tab: "automod", icon: "bot", name: "AutoMod", capability: "automod.view" },
  { label: "ACCESS", tab: "staff", icon: "users", name: "Staff", capability: "staff.view" },
  { tab: "approvals", icon: "check", name: "Approvals", capability: "approval.view" },
  { tab: "audit", icon: "history", name: "Audit trail", capability: "server.view" },
];

function hasCapability(capabilities: string[], capability: string): boolean {
  return capabilities.includes("*") || capabilities.includes(capability);
}

function isReadOperation(operation: string): boolean {
  return operation.endsWith(".snapshot") || operation.endsWith(".status")
    || operation.endsWith(".list") || operation.endsWith(".rules")
    || operation.endsWith(".history") || operation === "discord.channels"
    || operation === "discord.guilds" || operation === "setup.doctor";
}

export default function ServerPage() {
  const { serverId } = useParams<{ serverId: string }>();
  const [tab, setTab] = useState<Tab>("overview");
  const [user, setUser] = useState<CoreUser | null>(null);
  const [csrf, setCsrf] = useState("");
  const [overview, setOverview] = useState<Overview | null>(null);
  const [health, setHealth] = useState<Record<string, unknown>>({});
  const [error, setError] = useState("");
  const [toast, setToast] = useState("");
  const [toastError, setToastError] = useState(false);
  const [retryRequest, setRetryRequest] = useState<RetryRequest | null>(null);
  const [liveState, setLiveState] = useState<LiveState>("connecting");
  const overviewReady = overview !== null;

  useEffect(() => {
    Promise.all([
      api<{ user: CoreUser; csrfToken: string }>("/v1/me"),
      api<Overview>(`/v1/servers/${serverId}/overview`),
    ]).then(([identity, details]) => {
      setUser(identity.user); setCsrf(identity.csrfToken); setOverview(details);
      return performOperation(serverId, identity.csrfToken, "health.snapshot", {}, "Dashboard health refresh");
    }).then((result) => {
      if (result?.ok && result.payload && typeof result.payload === "object") setHealth(result.payload as Record<string, unknown>);
    }).catch((failure: unknown) => setError(failure instanceof Error ? failure.message : "Server unavailable"));
  }, [serverId]);

  useEffect(() => {
    if (!overviewReady) return;
    let stopped = false;
    let socket: WebSocket | null = null;
    let reconnectTimer: number | undefined;
    let attempt = 0;

    const connect = () => {
      if (stopped) return;
      setLiveState(attempt === 0 ? "connecting" : "reconnecting");
      socket = new WebSocket(liveUrl(`/v1/servers/${serverId}/live`));
      socket.addEventListener("open", () => {
        attempt = 0;
        setLiveState("connected");
      });
      socket.addEventListener("message", (event) => {
        try {
          const message = JSON.parse(String(event.data)) as Record<string, unknown>;
          if (message.type === "presence") {
            setOverview((current) => current ? {
              ...current,
              presence: { ...current.presence, online: message.online === true },
            } : current);
          }
          if (message.type === "heartbeat" && message.health && typeof message.health === "object") {
            setHealth(message.health as Record<string, unknown>);
            setOverview((current) => current ? {
              ...current,
              presence: { ...current.presence, online: true },
              incidents: current.incidents?.map((incident) => incident.status === "OPEN"
                ? { ...incident, status: "RESOLVED", resolved_at: Date.now() } : incident),
            } : current);
          }
          if (message.type === "health-incident" && message.incident && typeof message.incident === "object") {
            const incident = message.incident as HealthIncident;
            setOverview((current) => current ? {
              ...current,
              presence: { ...current.presence, online: false },
              incidents: [incident, ...(current.incidents ?? []).filter((item) => item.id !== incident.id)].slice(0, 10),
            } : current);
          }
        } catch {
          // A malformed live frame is ignored; authenticated HTTP operations remain authoritative.
        }
      });
      socket.addEventListener("error", () => socket?.close(1011, "Live channel error"));
      socket.addEventListener("close", (event) => {
        if (stopped || event.code === 1000) return;
        attempt += 1;
        setLiveState("reconnecting");
        const delay = Math.min(30_000, 1_000 * (2 ** Math.min(attempt - 1, 5))) + Math.floor(Math.random() * 250);
        reconnectTimer = window.setTimeout(connect, delay);
      });
    };

    connect();
    return () => {
      stopped = true;
      if (reconnectTimer !== undefined) window.clearTimeout(reconnectTimer);
      socket?.close(1000, "Dashboard closed");
    };
  }, [overviewReady, serverId]);

  const executeOperation = useCallback(async (request: RetryRequest, token = csrf): Promise<OperationResult> => {
    try {
      const result = await performOperation(serverId, token, request.operation, request.payload, request.reason,
        request.idempotencyKey);
      if (result.approvalRequired) {
        setToast(`Approval ${result.approvalId?.slice(0, 8)} created. A second administrator must approve it.`);
      } else if (!result.ok) {
        throw new Error(result.error?.message ?? "Server rejected the action");
      } else if (!isReadOperation(request.operation)) {
        setToast("Operation completed and recorded in the audit trail.");
      }
      setRetryRequest(null);
      setToastError(false);
      return result;
    } catch (failure) {
      const message = failure instanceof Error ? failure.message : "The operation could not be completed.";
      setRetryRequest(request);
      setToast(message);
      setToastError(true);
      return { ok: false, error: { message } };
    }
  }, [csrf, serverId]);

  const perform = useCallback(async (operation: string, payload: Record<string, unknown>, reason: string,
    token = csrf): Promise<OperationResult> => executeOperation({ operation, payload, reason,
      idempotencyKey: crypto.randomUUID() }, token), [csrf, executeOperation]);

  const instance = overview?.instance ?? {};
  const serverName = String(instance.display_name ?? "CoreDSC server");
  if (error) return <main className="center-state"><Brand /><h1>Server unavailable</h1><p>{error}</p><Link className="button button-secondary" href="/dashboard">Back to servers</Link></main>;
  if (!overview) return <main className="center-state"><span className="brand-mark loading-mark">C</span><p>Opening secure control channel…</p></main>;
  const capabilities = overview.capabilities;
  const agentOnline = overview.presence.online === true;
  const visibleNavigation = navigation.filter((item) => hasCapability(capabilities, item.capability));
  const refreshHealth = async () => {
    const result = await perform("health.snapshot", {}, "Manual health refresh");
    if (result.ok && result.payload && typeof result.payload === "object") {
      setHealth(result.payload as Record<string, unknown>);
    }
  };

  return (
    <main className="app-shell server-shell">
      <aside className="app-sidebar server-sidebar">
        <Brand />
        <Link className="back-link" href="/dashboard">← All servers</Link>
        <div className="selected-server"><span>{serverName.slice(0, 2).toUpperCase()}</span><div><strong>{serverName}</strong><small><i className={overview.presence.online ? "status-dot online" : "status-dot"} /> {overview.presence.online ? "Connected" : "Offline"}</small></div></div>
        <nav>
          {visibleNavigation.map((item) => <div key={item.tab}>{item.label && <span className="nav-label">{item.label}</span>}<button className={tab === item.tab ? "nav-item active" : "nav-item"} onClick={() => setTab(item.tab)}><Icon name={item.icon} /> {item.name}</button></div>)}
        </nav>
        <div className="sidebar-account"><UserAvatar user={user} /><div><strong>{user?.displayName}</strong><small>{overview.role.replaceAll("_", " ")}</small></div></div>
      </aside>

      <section className="app-content server-content">
        <header className="app-header compact-header"><div><span className="breadcrumb">Servers / {serverName}</span><h1>{navigation.find((item) => item.tab === tab)?.name}</h1></div><div className="header-health" title={`Live updates: ${liveState}`}><span className={overview.presence.online ? "status-dot online" : "status-dot"} /> Agent {overview.presence.online ? "online" : "offline"} · live {liveState}</div></header>
        {toast && <div className={toastError ? "toast error" : "toast"}><Icon name={toastError ? "alert" : "check"} /><span>{toast}</span>{toastError && retryRequest && <button className="text-button" onClick={() => void executeOperation(retryRequest)}>Retry safely</button>}<button aria-label="Dismiss notification" onClick={() => { setToast(""); setRetryRequest(null); }}>×</button></div>}
        {tab === "overview" && <OverviewPanel health={health} instance={instance} incidents={overview.incidents ?? []} refresh={refreshHealth} />}
        {tab === "setup" && <SetupDoctor perform={perform} agentOnline={agentOnline} />}
        {tab === "editor" && <ConfigurationEditor perform={perform} serverId={serverId} csrf={csrf} canEdit={agentOnline && hasCapability(capabilities, "config.edit")} canApply={agentOnline && hasCapability(capabilities, "config.apply")} />}
        {tab === "moderation" && <ModerationPanel perform={perform} canManage={agentOnline && hasCapability(capabilities, "moderation.manage")} canManageCases={agentOnline && hasCapability(capabilities, "case.manage")} />}
        {tab === "channels" && <ChannelsPanel perform={perform} canManage={agentOnline && hasCapability(capabilities, "channel.manage")} />}
        {tab === "incident" && <IncidentPanel perform={perform} canManage={agentOnline && hasCapability(capabilities, "incident.manage")} />}
        {tab === "console" && <ConsolePanel perform={perform} canExecute={agentOnline && hasCapability(capabilities, "console.execute")} />}
        {tab === "maintenance" && <MaintenancePanel perform={perform} canManage={agentOnline && hasCapability(capabilities, "maintenance.manage")} />}
        {tab === "events" && <EventsPanel perform={perform} canManage={agentOnline && hasCapability(capabilities, "event.manage")} />}
        {tab === "automod" && <AutoModPanel perform={perform} canManage={agentOnline && hasCapability(capabilities, "automod.manage")} />}
        {tab === "staff" && <StaffPanel serverId={serverId} csrf={csrf} canManage={overview.role === "OWNER"} />}
        {tab === "approvals" && <ApprovalsPanel serverId={serverId} csrf={csrf} canDecide={hasCapability(capabilities, "approval.decide")} />}
        {tab === "audit" && <AuditPanel serverId={serverId} />}
      </section>
    </main>
  );
}

function OverviewPanel({ health, instance, incidents, refresh }: { health: Record<string, unknown>; instance: Record<string, unknown>; incidents: HealthIncident[]; refresh: () => Promise<void> }) {
  const modules = Number(health.enabledModules ?? 0);
  const queue = Number(health.databaseQueue ?? 0);
  const activeIncident = incidents.find((incident) => incident.status === "OPEN");
  return <>
    {activeIncident && <div className="incident-banner active health-alert"><Icon name="alert" /><div><strong>Unexpected agent disconnect detected</strong><small>{activeIncident.detail} · {relativeTime(activeIncident.detected_at)}</small></div></div>}
    <div className="metric-grid dashboard-metrics">
      <Metric icon="users" tone="violet" value={String(health.onlinePlayers ?? "—")} label="Online players" />
      <Metric icon="discord" tone="blue" value={String(health.discordState ?? "Pending")} label="Discord gateway" />
      <Metric icon="database" tone={queue > 0 ? "amber" : "green"} value={`${queue} / ${health.databaseCapacity ?? "8192"}`} label="SQLite queue" />
      <Metric icon="sliders" tone="cyan" value={String(modules || "—")} label="Enabled modules" />
    </div>
    <div className="content-grid two-one">
      <Panel title="Service health" subtitle="Detached primitives reported by the local agent" action={<button className="text-button" onClick={() => void refresh()}>Refresh</button>}>
        <HealthRow label="Minecraft server" value={String(health.serverState ?? "Online")} healthy />
        <HealthRow label="Folia scheduler" value={String(health.scheduler ?? instance.scheduler_runtime ?? "Unknown")} healthy={String(health.scheduler).includes("FOLIA")} />
        <HealthRow label="Discord bot" value={String(health.discordState ?? "Waiting")} healthy={health.discordState === "READY"} />
        <HealthRow label="Database worker" value={String(health.storageState ?? "Waiting")} healthy={health.storageState === "READY"} />
        <HealthRow label="Delivery backlog" value={String(health.deliveryBacklog ?? 0)} healthy={Number(health.deliveryBacklog ?? 0) < 100} />
      </Panel>
      <Panel title="Instance" subtitle="Authenticated agent identity">
        <dl className="detail-list"><div><dt>CoreDSC</dt><dd>{String(instance.plugin_version ?? "3.4.0")}</dd></div><div><dt>Minecraft</dt><dd>{String(instance.minecraft_version ?? "—")}</dd></div><div><dt>Scheduler</dt><dd>{String(instance.scheduler_runtime ?? "—")}</dd></div><div><dt>Last heartbeat</dt><dd>{relativeTime(Number(instance.last_seen_at ?? 0))}</dd></div></dl>
      </Panel>
    </div>
  </>;
}

function SetupDoctor({ perform, agentOnline }: { perform: OperationFn; agentOnline: boolean }) {
  const [checks, setChecks] = useState<Record<string, unknown>[]>([]);
  const [busy, setBusy] = useState(false);
  async function scan() { setBusy(true); try { const result = await perform("setup.doctor", {}, "Run guided setup diagnostics"); setChecks(Array.isArray((result.payload as Record<string, unknown>)?.checks) ? (result.payload as { checks: Record<string, unknown>[] }).checks : []); } finally { setBusy(false); } }
  return <div className="content-grid two-one"><Panel title="Guided Setup Doctor" subtitle="Checks local modules and the customer-owned Discord bot">{!agentOnline && <PermissionNotice text="The local agent must reconnect before diagnostics can run." />}<div className="doctor-hero"><span className="feature-icon"><Icon name="pulse" /></span><div><h3>Find configuration problems before players do.</h3><p>CoreDSC checks bot visibility, required permissions, deleted channel mappings, Vault, LuckPerms, the SQLite funnel, and the active scheduler.</p></div><button className="button button-primary" onClick={scan} disabled={busy || !agentOnline}>{busy ? "Scanning…" : "Run full scan"}</button></div>{checks.length > 0 && <div className="check-list">{checks.map((check, index) => <HealthRow key={index} label={String(check.label ?? check.id ?? "Check")} value={String(check.detail ?? check.status ?? "Complete")} healthy={check.healthy === true} />)}</div>}</Panel><Panel title="Recommended structure" subtitle="Created only after explicit confirmation"><div className="channel-tree"><strong>CoreDSC</strong>{["minecraft-chat", "server-events", "staff-console", "reports", "tickets", "leaderboard"].map((name) => <span key={name}># {name}</span>)}</div><button type="button" className="button button-secondary button-small" disabled={!agentOnline} onClick={() => void perform("setup.createChannels", { names: ["minecraft-chat", "server-events", "staff-console", "reports", "tickets", "leaderboard"] }, "Create the recommended CoreDSC channel structure")}>Create missing channels</button></Panel></div>;
}

type EmbedDraft = { event: string; enabled: boolean; title: string; description: string; color: string; thumbnail: string; image: string; footer: string };

function ConfigurationEditor({ perform, serverId, csrf, canEdit, canApply }: {
  perform: OperationFn;
  serverId: string;
  csrf: string;
  canEdit: boolean;
  canApply: boolean;
}) {
  const [snapshot, setSnapshot] = useState<Record<string, unknown> | null>(null);
  const [changes, setChanges] = useState<Record<string, unknown>[]>([]);
  const [channelOptions, setChannelOptions] = useState<Record<string, unknown>[]>([]);
  const [guildId, setGuildId] = useState("");
  const [embed, setEmbed] = useState<EmbedDraft>({ event: "join", enabled: true, title: "", description: "", color: "#5865F2", thumbnail: "", image: "", footer: "" });
  const [mediaPreview, setMediaPreview] = useState<Partial<Record<"thumbnail" | "image", string>>>({});
  const [mediaMessage, setMediaMessage] = useState("");
  useEffect(() => {
    let cancelled = false;
    void perform("config.snapshot", {}, "Open visual configuration editor").then(async (result) => {
      if (cancelled || !result.ok || !result.payload || typeof result.payload !== "object") return;
      const value = result.payload as Record<string, unknown>;
      setSnapshot(value);
      setEmbed(embedFromSnapshot(value, "join"));
      const availableGuilds = Array.isArray(value.guilds) ? value.guilds as Record<string, unknown>[] : [];
      const configured = availableGuilds.find((guild) => guild.configured === true) ?? availableGuilds[0];
      const id = String(configured?.id ?? "");
      setGuildId(id);
      if (!id) { setChannelOptions([]); return; }
      const channels = await perform("discord.channels", { guildId: id }, "Load safe Discord channel choices");
      if (!cancelled && channels.ok && channels.payload && typeof channels.payload === "object") {
        const payload = channels.payload as Record<string, unknown>;
        setChannelOptions(Array.isArray(payload.channels) ? payload.channels as Record<string, unknown>[] : []);
      }
    });
    return () => { cancelled = true; };
  }, [perform]);
  const modules = Array.isArray(snapshot?.modules) ? snapshot.modules as Record<string, unknown>[] : [];
  const mappings = Array.isArray(snapshot?.mappings) ? snapshot.mappings as Record<string, unknown>[] : [];
  const guilds = Array.isArray(snapshot?.guilds) ? snapshot.guilds as Record<string, unknown>[] : [];
  function toggleModule(module: Record<string, unknown>) { if (!canEdit) return; const next = { file: module.file, path: module.path ?? "enabled", value: module.enabled !== true, revision: String(module.revision ?? "") }; setChanges((current) => [...current.filter((item) => item.file !== next.file || item.path !== next.path), next]); setSnapshot((current) => current ? { ...current, modules: modules.map((item) => item.id === module.id ? { ...item, enabled: !item.enabled } : item) } : current); }
  function selectMapping(mapping: Record<string, unknown>, value: string) { if (!canEdit) return; const next = { file: mapping.file, path: mapping.path, value, revision: String(mapping.revision ?? "") }; setChanges((current) => [...current.filter((item) => item.file !== next.file || item.path !== next.path), next]); setSnapshot((current) => current ? { ...current, mappings: mappings.map((item) => item.id === mapping.id ? { ...item, value } : item) } : current); }
  async function selectGuild(value: string) { setGuildId(value); const mapping = mappings.find((item) => item.id === "guild"); if (mapping) selectMapping(mapping, value); const result = await perform("discord.channels", { guildId: value }, "Refresh Discord channel choices"); if (result.ok && result.payload && typeof result.payload === "object") { const payload = result.payload as Record<string, unknown>; setChannelOptions(Array.isArray(payload.channels) ? payload.channels as Record<string, unknown>[] : []); } }
  function selectEvent(event: string) { setMediaPreview({}); if (snapshot) setEmbed(embedFromSnapshot(snapshot, event)); else setEmbed((current) => ({ ...current, event })); }
  async function upload(file: File | undefined, target: "thumbnail" | "image") {
    if (!file || !canEdit) return;
    setMediaMessage("");
    try {
      if (file.size > 524_288) throw new Error("Image exceeds the 512 KiB local-media limit");
      const uploaded = await api<{ url: string }>(`/v1/uploads?instance=${serverId}`, {
        method: "POST",
        headers: { "Content-Type": file.type, "X-CoreDSC-CSRF": csrf, "Idempotency-Key": crypto.randomUUID() },
        body: file,
      });
      const preview = await fileDataUrl(file);
      setMediaPreview((current) => ({ ...current, [target]: preview }));
      setEmbed((current) => ({ ...current, [target]: uploaded.url }));
      setMediaMessage("Image validated and installed on the connected server.");
    } catch (failure) {
      setMediaMessage(failure instanceof Error ? failure.message : "The image could not be installed.");
    }
  }
  async function save() { if (!canEdit) return; const revision = String((snapshot?.revisions as Record<string, unknown>)?.["modules/server-events.yml"] ?? ""); const embedChanges: Record<string, unknown>[] = [{ file: "modules/server-events.yml", path: `events.${embed.event}.enabled`, value: embed.enabled, revision }, ...["title", "description", "color", "thumbnail", "image", "footer"].map((key) => ({ file: "modules/server-events.yml", path: `events.${embed.event}.embed.${key === "thumbnail" ? "thumbnail-url" : key === "image" ? "image-url" : key}`, value: embed[key as keyof EmbedDraft], revision }))]; const result = await perform("config.patch", { changes: [...changes, ...embedChanges] }, "Save reviewed visual configuration changes"); if (!result.ok) return; const saved = result.payload as { revisions?: Record<string, string> } | undefined; if (saved?.revisions) setSnapshot((current) => current ? { ...current, revisions: { ...((current.revisions as Record<string, unknown>) ?? {}), ...saved.revisions }, modules: modules.map((item) => ({ ...item, revision: saved.revisions?.[String(item.file)] ?? item.revision })), mappings: mappings.map((item) => ({ ...item, revision: saved.revisions?.[String(item.file)] ?? item.revision })) } : current); setChanges([]); }
  return <><div className="editor-toolbar"><div><h2>Visual configuration</h2><p>Optimistic revisions and local validation protect every save.</p></div><div><span>{changes.length} pending setting(s)</span>{canEdit && <button className="button button-primary button-small" onClick={() => void save()}>Validate & save</button>}{canApply && <button className="button button-secondary button-small" onClick={() => void perform("config.apply", {}, "Apply saved configuration")}>Apply locally</button>}</div></div>{snapshot?.cached === true && <PermissionNotice text={`This is the last redacted snapshot cached ${relativeTime(Number(snapshot.cachedAt ?? 0))}. Reconnect the agent before saving.`} />}{!canEdit && snapshot?.cached !== true && <PermissionNotice text="Configuration controls are read-only because the agent is offline or your role lacks edit capability." />}<div className="content-grid config-grid"><Panel title="Module toggles" subtitle="The base remains lightweight; enable only what this server uses"><div className="module-toggle-list">{modules.length ? modules.map((module) => <label key={String(module.id)}><span><strong>{String(module.label ?? module.id)}</strong><small>{String(module.description ?? "Optional CoreDSC capability")}</small></span><input type="checkbox" disabled={!canEdit} checked={module.enabled === true} onChange={() => toggleModule(module)} /></label>) : <div className="empty-inline"><Icon name="settings" />No module data is available from the server snapshot.</div>}</div></Panel><Panel title="One-click channel mapping" subtitle="These choices come from the customer's local JDA bot; its token never leaves the server"><div className="embed-form"><label>Discord server<select value={guildId} onChange={(event) => void selectGuild(event.target.value)}>{guilds.map((guild) => <option key={String(guild.id)} value={String(guild.id)}>{String(guild.name)}</option>)}</select></label>{mappings.filter((mapping) => mapping.id !== "guild").map((mapping) => { const type = String(mapping.type ?? "text").toUpperCase(); const choices = channelOptions.filter((channel) => channel.type === type); return <label key={String(mapping.id)}>{String(mapping.label)}<select disabled={!canEdit} value={String(mapping.value ?? "")} onChange={(event) => selectMapping(mapping, event.target.value)}><option value="">Not mapped</option>{choices.map((channel) => <option key={String(channel.id)} value={String(channel.id)} disabled={channel.canSend === false}>{channel.category ? `${String(channel.category)} / ` : ""}{type === "TEXT" ? "#" : ""}{String(channel.name)}{channel.canSend === false ? " · missing permission" : ""}</option>)}</select></label>; })}</div></Panel><Panel title="Discord embed builder" subtitle="HTTPS URLs or local images up to 512 KiB; no cloud object storage"><fieldset disabled={!canEdit} className="editor-fieldset"><div className="embed-form"><label className="embed-enabled"><span>Publish this event</span><input type="checkbox" checked={embed.enabled} onChange={(event) => setEmbed({ ...embed, enabled: event.target.checked })} /></label><label>Event<select value={embed.event} onChange={(event) => selectEvent(event.target.value)}><option value="join">Player join</option><option value="quit">Player leave</option><option value="death">Player death</option><option value="startup">Server start</option><option value="shutdown">Server stop</option></select></label><label>Title<input maxLength={256} value={embed.title} onChange={(event) => setEmbed({ ...embed, title: event.target.value })} /></label><label>Description<textarea maxLength={4000} value={embed.description} onChange={(event) => setEmbed({ ...embed, description: event.target.value })} /></label><div className="form-row"><label>Accent color<input type="color" value={embed.color} onChange={(event) => setEmbed({ ...embed, color: event.target.value })} /></label><label>Thumbnail URL<input value={embed.thumbnail} onChange={(event) => { setMediaPreview((current) => ({ ...current, thumbnail: undefined })); setEmbed({ ...embed, thumbnail: event.target.value }); }} /></label></div><div className="form-row"><label>Image URL<input value={embed.image} onChange={(event) => { setMediaPreview((current) => ({ ...current, image: undefined })); setEmbed({ ...embed, image: event.target.value }); }} /></label><div className="upload-actions"><label className="button button-secondary button-small">Upload thumbnail<input type="file" accept="image/png,image/jpeg,image/webp,image/gif" onChange={(event) => void upload(event.target.files?.[0], "thumbnail")} /></label><label className="button button-secondary button-small">Upload image<input type="file" accept="image/png,image/jpeg,image/webp,image/gif" onChange={(event) => void upload(event.target.files?.[0], "image")} /></label></div></div><label>Footer<input value={embed.footer} onChange={(event) => setEmbed({ ...embed, footer: event.target.value })} /></label></div></fieldset>{mediaMessage && <div className="permission-notice">{mediaMessage}</div>}<DiscordPreview embed={embed} mediaPreview={mediaPreview} /></Panel></div></>;
}

function embedFromSnapshot(snapshot: Record<string, unknown>, event: string): EmbedDraft { const values = Array.isArray(snapshot.embeds) ? snapshot.embeds as Record<string, unknown>[] : []; const selected = values.find((item) => item.id === event) ?? {}; return { event, enabled: selected.enabled !== false, title: String(selected.title ?? ""), description: String(selected.description ?? ""), color: /^#[0-9a-f]{6}$/iu.test(String(selected.color ?? "")) ? String(selected.color) : "#5865F2", thumbnail: String(selected.thumbnail ?? ""), image: String(selected.image ?? ""), footer: String(selected.footer ?? "") }; }

function ModerationPanel({ perform, canManage, canManageCases }: { perform: OperationFn; canManage: boolean; canManageCases: boolean }) {
  const [form, setForm] = useState({ action: "ban", target: "", minecraftUuid: "", discordUserId: "", platform: "both", duration: "7d", reason: "" });
  const [cases, setCases] = useState<ModerationCase[]>([]);
  const [historyTarget, setHistoryTarget] = useState("");
  const [caseMessage, setCaseMessage] = useState("");
  useEffect(() => {
    if (!canManage && canManageCases) setForm((current) => ({ ...current, action: "note" }));
  }, [canManage, canManageCases]);
  async function loadCases() {
    if (!historyTarget.trim()) { setCaseMessage("Enter a player name or UUID first."); return; }
    const result = await perform("moderation.history", { target: historyTarget.trim(), limit: 20 }, "Read moderation case history");
    if (!result.ok) { setCaseMessage(result.error?.message ?? "Case history is unavailable."); return; }
    const payload = result.payload as { cases?: ModerationCase[] } | undefined;
    setCases(payload?.cases ?? []);
    setCaseMessage(payload?.cases?.length ? "" : "No local cases were found for this identity.");
  }
  const selectedCanManage = form.action === "note" ? canManageCases : canManage;
  return <div className="content-grid two-one"><Panel title="Unified moderation" subtitle="One action, one case, both identities when linked">{!canManage && !canManageCases && <PermissionNotice text="Your role can inspect moderation records but cannot issue punishments or notes." />}{!canManage && canManageCases && <PermissionNotice text="Support access can inspect history and add case notes, but cannot issue punishments." />}<div className="operation-form case-search"><Field label="Case history target"><input value={historyTarget} onChange={(event) => setHistoryTarget(event.target.value)} placeholder="Steve or UUID" /></Field><button className="button button-secondary" type="button" onClick={() => void loadCases()}>Load case history</button></div><fieldset disabled={!selectedCanManage} className="editor-fieldset"><form className="operation-form" onSubmit={(event) => { event.preventDefault(); void perform(`moderation.${form.action}`, form, form.reason); }}><div className="form-row"><Field label="Action"><select value={form.action} onChange={(e) => setForm({ ...form, action: e.target.value })}><option disabled={!canManage}>ban</option><option disabled={!canManage}>unban</option><option disabled={!canManage}>kick</option><option disabled={!canManage}>timeout</option><option disabled={!canManage}>warn</option><option disabled={!canManageCases}>note</option></select></Field><Field label="Platform"><select value={form.platform} onChange={(e) => setForm({ ...form, platform: e.target.value })}><option value="both">Minecraft + Discord</option><option value="minecraft">Minecraft</option><option value="discord">Discord</option></select></Field></div><Field label="Player name or UUID"><input required value={form.target} onChange={(e) => setForm({ ...form, target: e.target.value })} placeholder="Steve or UUID" /></Field><div className="form-row"><Field label="Minecraft UUID"><input value={form.minecraftUuid} onChange={(e) => setForm({ ...form, minecraftUuid: e.target.value })} placeholder="Optional when linked" /></Field><Field label="Discord user ID"><input value={form.discordUserId} onChange={(e) => setForm({ ...form, discordUserId: e.target.value })} placeholder="Optional when linked" /></Field></div><Field label="Duration"><input disabled={form.action === "note"} value={form.duration} onChange={(e) => setForm({ ...form, duration: e.target.value })} placeholder="7d, 30m, permanent" /></Field><Field label="Reason"><textarea required minLength={3} value={form.reason} onChange={(e) => setForm({ ...form, reason: e.target.value })} placeholder="Required for the case and audit trail" /></Field><button className="button button-danger" type="submit">Review and apply action</button></form></fieldset>{caseMessage && <div className="permission-notice">{caseMessage}</div>}{cases.length > 0 && <div className="approval-list case-list">{cases.map((item) => <article key={item.id}><div><span className="state-badge">{item.status}</span><h3>#{item.id} · {item.action}</h3><p>{item.reason}</p><small>{item.executor} · {item.duration || "no duration"} · {relativeTime(item.createdAt)}</small></div></article>)}</div>}</Panel><SafetyPanel items={["Protected owner and staff identities", "Discord role hierarchy validation", "Automatic sanction expiry", "Idempotent cross-platform execution", "Permanent bans require approval"]} /></div>;
}

function ChannelsPanel({ perform, canManage }: { perform: OperationFn; canManage: boolean }) {
  const [channelId, setChannelId] = useState(""); const [reason, setReason] = useState("");
  return <div className="content-grid two-one"><Panel title="Safe channel operations" subtitle="CoreDSC snapshots exact permission overwrites before mutation">{!canManage && <PermissionNotice text="Your role can view channel operations but cannot change Discord channels." />}<fieldset disabled={!canManage} className="editor-fieldset"><form className="operation-form" onSubmit={(e) => e.preventDefault()}><Field label="Discord channel ID"><input required pattern="[0-9]{15,22}" value={channelId} onChange={(e) => setChannelId(e.target.value)} placeholder="Select from channel mapping or paste ID" /></Field><Field label="Audit reason"><input required minLength={3} value={reason} onChange={(e) => setReason(e.target.value)} /></Field><div className="action-grid">{["lock", "unlock", "hide", "reveal"].map((action) => <ActionButton key={action} label={action[0].toUpperCase() + action.slice(1)} onClick={() => perform(`channel.${action}`, { channelId }, reason)} />)}<ActionButton label="Slowmode 30s" onClick={() => perform("channel.slowmode", { channelId, seconds: 30 }, reason)} /><ActionButton danger label="Purge 25" onClick={() => perform("channel.purge", { channelId, count: 25 }, reason)} /></div></form></fieldset></Panel><SafetyPanel items={["Exact allow/deny overwrite snapshot", "Unlock restores prior state", "Bot permission preflight", "Maximum purge of 100 messages", "Every mutation has an audit reason"]} /></div>;
}

function IncidentPanel({ perform, canManage }: { perform: OperationFn; canManage: boolean }) {
  const [reason, setReason] = useState("");
  const [kind, setKind] = useState("raid");
  const [status, setStatus] = useState<Record<string, unknown>>({ active: false });
  const refresh = useCallback(async () => {
    const result = await perform("incident.status", {}, "Read incident status");
    if (result.ok && result.payload && typeof result.payload === "object") {
      setStatus(result.payload as Record<string, unknown>);
    }
  }, [perform]);
  useEffect(() => { void perform("incident.status", {}, "Read incident status").then((result) => { if (result.ok && result.payload && typeof result.payload === "object") setStatus(result.payload as Record<string, unknown>); }); }, [perform]);
  const active = status.active === true;
  async function start() {
    const result = await perform("incident.start", {
      type: kind,
      scope: "server",
      lockConfiguredChannels: true,
      pauseChatBridge: true,
    }, reason);
    if (result.ok) await refresh();
  }
  async function resolve() {
    const summary = reason || "Resolved by staff";
    const result = await perform("incident.resolve", { summary }, summary);
    if (result.ok) await refresh();
  }
  return <div className="content-grid two-one"><Panel title="Incident Mode" subtitle="Coordinated lockdown with deterministic restoration"><div className={active ? "incident-banner active" : "incident-banner"}><Icon name="alert" /><div><strong>{active ? `${String(status.type ?? "Incident")} active` : "No active incident"}</strong><small>{active ? `${String(status.reason ?? "No reason supplied")} · started ${relativeTime(Number(status.startedAt ?? 0))}` : "Normal channel permissions and chat bridge state"}</small></div></div>{!canManage && <PermissionNotice text="Your role can follow incident state but cannot start or resolve an incident." />}<fieldset disabled={!canManage} className="editor-fieldset"><form className="operation-form" onSubmit={(e) => { e.preventDefault(); void start(); }}><Field label="Incident type"><select value={kind} onChange={(e) => setKind(e.target.value)}><option value="raid">Discord raid</option><option value="exploit">Active exploit</option><option value="grief">Minecraft griefing</option><option value="outage">Service outage</option></select></Field><Field label={active ? "Resolution summary" : "Reason"}><textarea required minLength={3} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="What happened and what staff should know" /></Field>{!active && <button className="button button-danger" type="submit">Start Incident Mode</button>}{active && <button className="button button-secondary" type="button" onClick={() => void resolve()}>Resolve and restore</button>}</form></fieldset></Panel><Panel title="Response playbook" subtitle="Each implemented step is recoverable"><ol className="playbook"><li>Persist incident identity and prior chat state</li><li>Snapshot exact channel permission overwrites</li><li>Lock configured public channels</li><li>Pause Discord → Minecraft chat</li><li>Publish an operations-channel incident embed</li><li>Restore permissions and chat state on resolution</li></ol></Panel></div>;
}

function ConsolePanel({ perform, canExecute }: { perform: OperationFn; canExecute: boolean }) {
  const [command, setCommand] = useState(""); const [reason, setReason] = useState(""); const [logs, setLogs] = useState<Record<string, unknown>[]>([]);
  return <><Panel title="Smart Console" subtitle="Severe events are classified, redacted, deduplicated, and grouped"><div className="console-window">{logs.length ? logs.map((log, index) => <div key={index}><span>{String(log.level ?? "INFO")}</span><code>{String(log.message ?? "")}</code></div>) : <div className="console-empty"><Icon name="terminal" /><span>No severe incidents in the current window.</span></div>}</div><button className="button button-secondary button-small" onClick={() => perform("console.snapshot", { limit: 100 }, "Refresh Smart Console viewer").then((result) => setLogs(Array.isArray((result.payload as Record<string, unknown>)?.entries) ? (result.payload as { entries: Record<string, unknown>[] }).entries : []))}>Refresh incidents</button></Panel>{canExecute && <Panel title="Capability-gated command" subtitle="Always requires a second administrator and the plugin's local allowlist"><form className="operation-form inline-operation" onSubmit={(e) => { e.preventDefault(); void perform("console.execute", { command }, reason); }}><Field label="Command"><input value={command} onChange={(e) => setCommand(e.target.value)} placeholder="whitelist add Steve" /></Field><Field label="Reason"><input value={reason} onChange={(e) => setReason(e.target.value)} required /></Field><button className="button button-danger" type="submit">Request approval</button></form></Panel>}</>;
}

function MaintenancePanel({ perform, canManage }: { perform: OperationFn; canManage: boolean }) {
  const [minutes, setMinutes] = useState(15);
  const [reason, setReason] = useState("");
  const [status, setStatus] = useState<Record<string, unknown>>({ active: false, scheduled: false });
  const refresh = useCallback(async () => {
    const result = await perform("maintenance.status", {}, "Read maintenance status");
    if (result.ok && result.payload && typeof result.payload === "object") setStatus(result.payload as Record<string, unknown>);
  }, [perform]);
  useEffect(() => { void perform("maintenance.status", {}, "Read maintenance status").then((result) => { if (result.ok && result.payload && typeof result.payload === "object") setStatus(result.payload as Record<string, unknown>); }); }, [perform]);
  const scheduled = status.scheduled === true;
  async function start() {
    const result = await perform("maintenance.start", { startsInMinutes: minutes, message: reason, blockNewJoins: true, pauseChatBridge: true, createDiscordEvent: true }, reason);
    if (result.ok) await refresh();
  }
  async function cancel() {
    const result = await perform("maintenance.cancel", {}, "Cancel maintenance and restore state");
    if (result.ok) await refresh();
  }
  return <div className="content-grid two-one"><Panel title="Maintenance orchestration" subtitle="Minecraft and Discord move through one coordinated state">{scheduled && <div className="incident-banner"><Icon name="settings" /><div><strong>{status.active === true ? "Maintenance active" : "Maintenance scheduled"}</strong><small>{String(status.message ?? "")} · {timeDistance(Number(status.startsAt ?? 0))}</small></div></div>}{!canManage && <PermissionNotice text="Your role can view the maintenance state but cannot schedule or cancel it." />}<fieldset disabled={!canManage} className="editor-fieldset"><form className="operation-form" onSubmit={(e) => { e.preventDefault(); void start(); }}><Field label="Starts in"><input type="number" min="1" max="1440" value={minutes} onChange={(e) => setMinutes(Number(e.target.value))} /></Field><Field label="Maintenance message"><textarea required minLength={3} maxLength={500} value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Updating to Minecraft 1.21.12" /></Field>{!scheduled && <button className="button button-primary" type="submit">Schedule maintenance</button>}{scheduled && <button type="button" className="button button-secondary" onClick={() => void cancel()}>Cancel / complete maintenance</button>}</form></fieldset></Panel><Panel title="Orchestration steps" subtitle="Restart-safe local state"><ol className="playbook"><li>Persist the maintenance window locally</li><li>Publish a Discord operations announcement</li><li>Create a Discord scheduled event when permitted</li><li>Send 60, 15, 5, and 1 minute player reminders</li><li>Pause chat and reject new logins at the deadline</li><li>Recover state after restart and publish completion</li></ol></Panel></div>;
}

function EventsPanel({ perform, canManage }: { perform: OperationFn; canManage: boolean }) {
  const [title, setTitle] = useState("");
  const [when, setWhen] = useState("");
  const [description, setDescription] = useState("");
  const [events, setEvents] = useState<Record<string, unknown>[]>([]);
  const refresh = useCallback(async () => {
    const result = await perform("event.list", {}, "Read synchronized events");
    if (result.ok && result.payload && typeof result.payload === "object") {
      const payload = result.payload as Record<string, unknown>;
      setEvents(Array.isArray(payload.events) ? payload.events as Record<string, unknown>[] : []);
    }
  }, [perform]);
  useEffect(() => { void perform("event.list", {}, "Read synchronized events").then((result) => { if (result.ok && result.payload && typeof result.payload === "object") { const payload = result.payload as Record<string, unknown>; setEvents(Array.isArray(payload.events) ? payload.events as Record<string, unknown>[] : []); } }); }, [perform]);
  async function create() {
    const startsAt = new Date(when).toISOString();
    const result = await perform("event.create", { title, startsAt, description }, `Schedule event: ${title}`);
    if (result.ok) { setTitle(""); setWhen(""); setDescription(""); await refresh(); }
  }
  async function cancel(eventId: string, name: string) {
    const result = await perform("event.cancel", { eventId }, `Cancel scheduled event: ${name}`);
    if (result.ok) await refresh();
  }
  return <div className="content-grid two-one"><Panel title="Minecraft + Discord events" subtitle="Create a Discord event and restart-safe in-game reminders through the connected plugin">{!canManage && <PermissionNotice text="Your role can see scheduled events but cannot create or cancel them." />}<fieldset disabled={!canManage} className="editor-fieldset"><form className="operation-form" onSubmit={(e) => { e.preventDefault(); void create(); }}><Field label="Title"><input required maxLength={100} value={title} onChange={(e) => setTitle(e.target.value)} /></Field><Field label="Start time"><input required type="datetime-local" value={when} onChange={(e) => setWhen(e.target.value)} /></Field><Field label="Description"><textarea required maxLength={1000} value={description} onChange={(e) => setDescription(e.target.value)} /></Field><button className="button button-primary" type="submit">Create synchronized event</button></form></fieldset></Panel><Panel title="Scheduled events" subtitle="Live from the configured Discord guild"><div className="approval-list compact-list">{events.length ? events.map((event) => <article key={String(event.id)}><div><span className="state-badge pending">{String(event.status ?? "scheduled")}</span><h3>{String(event.name ?? "Discord event")}</h3><small>{String(event.start ?? "Start pending")}</small></div>{canManage && <aside><button className="button button-secondary button-small" onClick={() => void cancel(String(event.id), String(event.name ?? "event"))}>Cancel</button></aside>}</article>) : <div className="empty-inline"><Icon name="calendar" /> No upcoming Discord events.</div>}</div></Panel></div>;
}

function AutoModPanel({ perform, canManage }: { perform: OperationFn; canManage: boolean }) {
  const [keywords, setKeywords] = useState("");
  const [mentions, setMentions] = useState(5);
  const [alertChannelId, setAlertChannelId] = useState("");
  const [rules, setRules] = useState<Record<string, unknown>[]>([]);
  const refresh = useCallback(async () => {
    const result = await perform("automod.rules", {}, "Read Discord AutoMod rules");
    if (result.ok && result.payload && typeof result.payload === "object") {
      const payload = result.payload as Record<string, unknown>;
      setRules(Array.isArray(payload.rules) ? payload.rules as Record<string, unknown>[] : []);
    }
  }, [perform]);
  useEffect(() => { void perform("automod.rules", {}, "Read Discord AutoMod rules").then((result) => { if (result.ok && result.payload && typeof result.payload === "object") { const payload = result.payload as Record<string, unknown>; setRules(Array.isArray(payload.rules) ? payload.rules as Record<string, unknown>[] : []); } }); }, [perform]);
  async function publish() {
    const result = await perform("automod.upsert", { ruleId: "coredsc-community", name: "Community Protection", blockedKeywords: keywords.split(",").map((value) => value.trim()).filter(Boolean), mentionLimit: mentions, alertChannelId, enabled: true }, "Update community AutoMod policy");
    if (result.ok) await refresh();
  }
  async function remove(ruleId: string, name: string) {
    const result = await perform("automod.delete", { ruleId }, `Delete CoreDSC AutoMod rule: ${name}`);
    if (result.ok) await refresh();
  }
  return <div className="content-grid two-one"><Panel title="Discord AutoMod" subtitle="Rules are managed through the customer's local JDA bot">{!canManage && <PermissionNotice text="Your role can inspect AutoMod rules but cannot publish or delete them." />}<fieldset disabled={!canManage} className="editor-fieldset"><form className="operation-form" onSubmit={(e) => { e.preventDefault(); void publish(); }}><Field label="Blocked keywords"><textarea value={keywords} onChange={(e) => setKeywords(e.target.value)} placeholder="Comma-separated terms" /></Field><Field label="Mention spam limit"><input type="number" min="0" max="50" value={mentions} onChange={(e) => setMentions(Number(e.target.value))} /></Field><Field label="Alert channel ID"><input pattern="[0-9]{15,22}" value={alertChannelId} onChange={(e) => setAlertChannelId(e.target.value)} placeholder="Optional" /></Field><button className="button button-primary" type="submit">Validate & publish policy</button></form></fieldset></Panel><Panel title="Guild rules" subtitle="Only bot-created CoreDSC rules can be deleted"><div className="approval-list compact-list">{rules.length ? rules.map((rule) => <article key={String(rule.id)}><div><span className={rule.managed === true ? "state-badge online" : "state-badge offline"}>{rule.managed === true ? "CoreDSC" : "External"}</span><h3>{String(rule.name)}</h3><small>{String(rule.trigger)} · {rule.enabled === true ? "enabled" : "disabled"}</small></div>{canManage && rule.managed === true && <aside><button className="button button-secondary button-small" onClick={() => void remove(String(rule.id), String(rule.name))}>Delete</button></aside>}</article>) : <div className="empty-inline"><Icon name="shield" /> No AutoMod rules visible to the bot.</div>}</div></Panel></div>;
}

function StaffPanel({ serverId, csrf, canManage }: { serverId: string; csrf: string; canManage: boolean }) {
  const [staff, setStaff] = useState<Record<string, unknown>[]>([]);
  const [discordId, setDiscordId] = useState("");
  const [role, setRole] = useState("MODERATOR");
  const [message, setMessage] = useState("");
  const load = useCallback(async () => {
    try {
      const result = await api<{ staff: Record<string, unknown>[] }>(`/v1/servers/${serverId}/staff`);
      setStaff(result.staff);
    } catch (failure) {
      setMessage(failure instanceof Error ? failure.message : "Could not load staff access.");
    }
  }, [serverId]);
  useEffect(() => { void api<{ staff: Record<string, unknown>[] }>(`/v1/servers/${serverId}/staff`).then((result) => setStaff(result.staff)).catch((failure: unknown) => setMessage(failure instanceof Error ? failure.message : "Could not load staff access.")); }, [serverId]);
  async function revoke(id: string) {
    try {
      await api(`/v1/servers/${serverId}/staff/${id}`, { method: "DELETE", headers: csrfHeader(csrf) });
      setMessage("Staff access revoked and recorded in the audit trail.");
      await load();
    } catch (failure) {
      setMessage(failure instanceof Error ? failure.message : "Could not revoke access.");
    }
  }
  async function grant() {
    try {
      await api(`/v1/servers/${serverId}/staff`, { method: "POST", headers: csrfHeader(csrf), body: JSON.stringify({ discordUserId: discordId, role }) });
      setDiscordId("");
      setMessage("Staff capability role granted.");
      await load();
    } catch (failure) {
      setMessage(failure instanceof Error ? failure.message : "Could not grant access.");
    }
  }
  return <div className="content-grid two-one"><Panel title="Staff access" subtitle="No editor links or owner credentials need to be shared">{message && <div className="permission-notice">{message}</div>}<div className="staff-list">{staff.map((person, index) => <div key={index}><span className="account-avatar fallback">{String(person.display_name ?? "?").slice(0, 1)}</span><p><strong>{String(person.display_name)}</strong><small>{String(person.discord_user_id)}</small></p><em>{String(person.role).replaceAll("_", " ")}</em>{canManage && person.role !== "OWNER" && <button className="text-button danger-text" onClick={() => void revoke(String(person.discord_user_id))}>Revoke</button>}</div>)}</div></Panel>{canManage ? <Panel title="Grant capability role" subtitle="The user must sign in once before access can be granted"><form className="operation-form" onSubmit={(e) => { e.preventDefault(); void grant(); }}><Field label="Discord user ID"><input required pattern="[0-9]{15,22}" value={discordId} onChange={(e) => setDiscordId(e.target.value)} /></Field><Field label="Role"><select value={role} onChange={(e) => setRole(e.target.value)}>{["SERVER_ADMIN", "MODERATOR", "CONSOLE_VIEWER", "CONSOLE_OPERATOR", "SUPPORT", "VIEWER"].map((value) => <option key={value}>{value}</option>)}</select></Field><button className="button button-primary" type="submit">Grant access</button></form></Panel> : <Panel title="Access policy" subtitle="Only the paired owner changes staff roles"><PermissionNotice text="You can inspect the current access list. Ask the paired owner to grant, change, or revoke a role." /></Panel>}</div>;
}

function ApprovalsPanel({ serverId, csrf, canDecide }: { serverId: string; csrf: string; canDecide: boolean }) { const [items, setItems] = useState<Approval[]>([]); const [message, setMessage] = useState(""); const load = useCallback(async () => { try { const result = await api<{ approvals: Approval[] }>(`/v1/servers/${serverId}/approvals`); setItems(result.approvals); } catch (failure) { setMessage(failure instanceof Error ? failure.message : "Could not load approvals."); } }, [serverId]); useEffect(() => { void api<{ approvals: Approval[] }>(`/v1/servers/${serverId}/approvals`).then((result) => setItems(result.approvals)).catch((failure: unknown) => setMessage(failure instanceof Error ? failure.message : "Could not load approvals.")); }, [serverId]); async function decide(id: string, decision: string) { try { await api(`/v1/approvals/${id}/decision`, { method: "POST", headers: csrfHeader(csrf), body: JSON.stringify({ decision, note: `${decision === "APPROVE" ? "Reviewed and approved" : "Rejected"} from the CoreDSC dashboard` }) }); setMessage(decision === "APPROVE" ? "Approval executed or dispatched to the server." : "Request rejected."); await load(); } catch (failure) { setMessage(failure instanceof Error ? failure.message : "Could not decide this request."); } } return <Panel title="Two-person approvals" subtitle="The requester can never approve their own dangerous action">{message && <div className="permission-notice">{message}</div>}<div className="approval-list">{items.length ? items.map((item) => <article key={item.id}><div><span className={`state-badge ${item.status === "PENDING" ? "pending" : ""}`}>{item.status}</span><h3>{item.operation}</h3><p>{item.reason}</p><small>Requested by {item.requester_name} · {relativeTime(item.created_at)} · expires {new Date(item.expires_at).toLocaleString()}</small></div>{canDecide && item.status === "PENDING" && <aside><button className="button button-primary button-small" onClick={() => void decide(item.id, "APPROVE")}>Approve</button><button className="button button-secondary button-small" onClick={() => void decide(item.id, "REJECT")}>Reject</button></aside>}</article>) : <div className="empty-inline"><Icon name="check" />No approval requests.</div>}</div></Panel>; }

function AuditPanel({ serverId }: { serverId: string }) { const [events, setEvents] = useState<AuditEvent[]>([]); const [loading, setLoading] = useState(true); const [message, setMessage] = useState(""); useEffect(() => { let cancelled = false; setLoading(true); setMessage(""); void api<{ events: AuditEvent[] }>(`/v1/servers/${serverId}/audit`).then((result) => { if (!cancelled) setEvents(result.events); }).catch((failure: unknown) => { if (!cancelled) setMessage(failure instanceof Error ? failure.message : "Could not load the audit trail."); }).finally(() => { if (!cancelled) setLoading(false); }); return () => { cancelled = true; }; }, [serverId]); return <Panel title="Audit trail" subtitle="Cloud request and local result are recorded together">{message && <PermissionNotice text={message} />}{loading ? <div className="empty-inline"><Icon name="history" />Loading audit events…</div> : events.length ? <div className="audit-table"><div className="audit-head"><span>Operation</span><span>Actor</span><span>Reason</span><span>Outcome</span><span>Time</span></div>{events.map((event) => <div key={event.id}><strong>{event.operation}</strong><span>{event.actor_display_name}</span><span>{event.reason || "—"}</span><em className={event.outcome === "SUCCEEDED" ? "success" : ""}>{event.outcome}</em><span>{relativeTime(event.created_at)}</span></div>)}</div> : !message && <div className="empty-inline"><Icon name="history" />No audit events have been recorded.</div>}</Panel>; }

type OperationFn = (operation: string, payload: Record<string, unknown>, reason: string, token?: string) => Promise<OperationResult>;
async function performOperation(serverId: string, token: string, operation: string, payload: Record<string, unknown>, reason: string, idempotencyKey = crypto.randomUUID()): Promise<OperationResult> { return api<OperationResult>(`/v1/servers/${serverId}/operations`, { method: "POST", headers: csrfHeader(token), body: JSON.stringify({ operation, payload, reason, idempotencyKey }) }); }
function Panel({ title, subtitle, action, children }: { title: string; subtitle: string; action?: React.ReactNode; children: React.ReactNode }) { return <section className="dashboard-panel"><header><div><h2>{title}</h2><p>{subtitle}</p></div>{action}</header>{children}</section>; }
function Metric({ icon, tone, value, label }: { icon: string; tone: string; value: string; label: string }) { return <div><span className={`metric-icon ${tone}`}><Icon name={icon} /></span><strong>{value}</strong><small>{label}</small></div>; }
function HealthRow({ label, value, healthy }: { label: string; value: string; healthy: boolean }) { return <div className="health-row"><span><i className={healthy ? "status-dot online" : "status-dot warning"} />{label}</span><strong>{value}</strong></div>; }
function Field({ label, children }: { label: string; children: React.ReactNode }) { return <label>{label}{children}</label>; }
function ActionButton({ label, onClick, danger = false }: { label: string; onClick: () => unknown; danger?: boolean }) { return <button type="button" className={danger ? "button button-danger button-small" : "button button-secondary button-small"} onClick={onClick}>{label}</button>; }
function SafetyPanel({ items }: { items: string[] }) { return <Panel title="Safety policy" subtitle="Enforced again by the local server"><ul className="safety-list">{items.map((item) => <li key={item}><Icon name="check" />{item}</li>)}</ul></Panel>; }
function PermissionNotice({ text }: { text: string }) { return <div className="permission-notice"><Icon name="shield" />{text}</div>; }
function UserAvatar({ user }: { user: CoreUser | null }) { return <span className="account-avatar fallback">{user?.displayName?.slice(0, 1).toUpperCase() ?? "?"}</span>; }
function timeDistance(timestamp: number): string { if (!timestamp) return "time unavailable"; const delta = timestamp - Date.now(); if (delta <= 0) return `started ${relativeTime(timestamp)}`; const minutes = Math.max(1, Math.ceil(delta / 60_000)); if (minutes < 60) return `starts in ${minutes}m`; const hours = Math.ceil(minutes / 60); if (hours < 48) return `starts in ${hours}h`; return `starts ${new Date(timestamp).toLocaleString()}`; }
function DiscordPreview({ embed, mediaPreview }: { embed: EmbedDraft; mediaPreview: Partial<Record<"thumbnail" | "image", string>> }) { const preview = (value: string) => value.replaceAll("%player%", "Steve").replaceAll("%uuid%", "8667ba71-b85a-4004-af54-457a9734eed7").replaceAll("%server%", "CrimsonTide").replaceAll("%server_name%", "CrimsonTide").replaceAll("%online%", "124"); const image = mediaPreview.image ?? preview(embed.image); const thumbnail = mediaPreview.thumbnail ?? preview(embed.thumbnail); return <div className={`discord-preview ${embed.enabled ? "" : "disabled-preview"}`}><div className="discord-user"><span>C</span><strong>CoreDSC</strong><em>APP</em><small>Today at 14:32</small></div><div className="discord-embed" style={{ borderColor: embed.color }}><div className="embed-copy"><strong>{preview(embed.title)}</strong><p>{preview(embed.description)}</p>{image && <div className="embed-image" style={{ backgroundImage: `url(${JSON.stringify(image)})` }} />}{embed.footer && <small>{preview(embed.footer)}</small>}</div>{thumbnail && <div className="embed-thumb" style={{ backgroundImage: `url(${JSON.stringify(thumbnail)})` }} />}</div></div>; }

function fileDataUrl(file: File): Promise<string> { return new Promise((resolve, reject) => { const reader = new FileReader(); reader.onload = () => resolve(String(reader.result ?? "")); reader.onerror = () => reject(new Error("Could not preview the selected image")); reader.readAsDataURL(file); }); }
