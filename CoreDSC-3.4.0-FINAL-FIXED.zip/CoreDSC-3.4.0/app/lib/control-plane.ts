export const API_BASE = (process.env.NEXT_PUBLIC_COREDSC_API_BASE ?? "/api").replace(/\/$/u, "");

export type CoreUser = { id: string; username: string; displayName: string; avatar: string | null };
export type CoreServer = {
  id: string;
  name: string;
  pluginVersion: string;
  minecraftVersion: string;
  scheduler: string;
  online: boolean;
  status: string;
  lastSeenAt: number;
  cleanShutdownAt: number | null;
  approvalMode: boolean;
  role: string;
  capabilities: string[];
};

export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

export async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API_BASE}${path}`, { ...init, credentials: "include", headers: {
    Accept: "application/json",
    ...init.headers,
  } });
  const body = await response.json().catch(() => ({})) as Record<string, unknown>;
  if (!response.ok) throw new ApiError(response.status, typeof body.error === "string" ? body.error : "Request failed");
  return body as T;
}

export function csrfHeader(token: string): HeadersInit {
  return { "Content-Type": "application/json", "X-CoreDSC-CSRF": token };
}

export function oauthUrl(returnPath: string): string {
  return `${API_BASE}/v1/auth/discord?return=${encodeURIComponent(returnPath)}`;
}

export function liveUrl(path: string): string {
  if (typeof window === "undefined") return "";
  const base = new URL(API_BASE || "/", window.location.href);
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  base.pathname = `${base.pathname.replace(/\/$/u, "")}${normalizedPath}`;
  base.search = "";
  base.hash = "";
  base.protocol = base.protocol === "https:" ? "wss:" : "ws:";
  return base.toString();
}

export function relativeTime(timestamp: number): string {
  if (!timestamp) return "Never";
  const seconds = Math.max(0, Math.round((Date.now() - timestamp) / 1000));
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}
