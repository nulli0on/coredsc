# Changelog

## 3.4.0 — 2026-08-02

### Release conversion

- Removed the CoreDSC prerelease suffix from the Maven project, plugin metadata, package manifests, lockfiles, control-plane health response, dashboard fallbacks, managed configuration templates, tests and documentation.
- The distributable plugin filename is now `CoreDSC-3.4.0.jar`.
- Added automated release-contract checks that reject inconsistent CoreDSC versions, prerelease markers in release-owned surfaces, additional Markdown documentation, R2 runtime bindings and missing WebSocket/media hardening.

### Added

- Hosted CoreDSC Operations dashboard with authenticated server, moderation, channel, incident, maintenance, event, AutoMod, Smart Console, approval and network surfaces.
- Cloudflare control plane with Discord OAuth, first-party sessions, D1 persistence, Durable Object agent rooms, audit history, health tracking and scheduled cleanup/retry work.
- Explicit capability roles: `OWNER`, `SERVER_ADMIN`, `MODERATOR`, `CONSOLE_VIEWER`, `CONSOLE_OPERATOR`, `SUPPORT` and `VIEWER`.
- Outbound authenticated TLS WebSocket agent with Ed25519 request authentication, replay-resistant nonces and bounded reconnect/backoff behavior.
- Server pairing with local console confirmation.
- Dedicated ownership recovery initiated only from the unbound local server console, with a second local confirmation, atomic owner replacement and audit entry.
- Persistent operation fingerprints and idempotency records for duplicate/retry protection.
- Local SQLite schema 13, adding canonical request fingerprints to completed cloud-operation records while retaining compatibility with legacy rows.
- Approval dispatch leases for restart/crash recovery without duplicate execution.
- D1-backed rate limiting for OAuth, pairing, operations, approvals, staff, uploads and network changes.
- Streaming request-body limits that reject oversized chunked image uploads before unbounded buffering.
- D1 migration `0006_ownership_recovery.sql`.
- Local, content-addressed dashboard media storage through the customer agent.
- Hosted moderation-case history and case-note controls backed by the local cases module.
- Dashboard live-channel reconnect with bounded exponential backoff and visible connection state.
- Dependency-free Java 21 release safety harness under `scripts/java-release-check.sh`.

### Changed

- Removed the R2 dependency and binding.
- Media uploads use bounded Base64 transport only. The Worker accepts PNG, JPEG, WebP and GIF up to 512 KiB, validates magic bytes, forwards the image to the authenticated local agent and does not store the image body in D1 or audit records.
- Cloud control remains disabled by default and uses a deliberately non-routable example endpoint until the operator configures a real deployment. A missing modular setting also fails closed.
- Replaced a decorative landing-page Setup Doctor button with non-operational status text so visible operational controls correspond to real backend calls.
- Separated `case.manage` from `moderation.manage`: SUPPORT may inspect history and add notes without receiving sanction authority; SERVER_ADMIN and MODERATOR retain both capabilities.
- Kept approval rejection available while the Minecraft agent is offline because rejection is a cloud-side final decision and does not dispatch an agent operation.
- Distinguished authentication failures from dashboard/backend outages instead of presenting every load failure as a Discord sign-in requirement.
- Consolidated project documentation into exactly `README.md`, `SETUP.md`, `REFERENCE.md` and `CHANGELOG.md`.
- Removed the obsolete continuation-file reference from the README.

### Fixed and hardened

- Fixed three Java compilation defects found by the first full Maven compile: the DiscordSRV migration now carries its detected plugin instance into linked-account import, the JDA 6 audit permission uses `VIEW_AUDIT_LOGS`, and scheduled-event cancellation retrieves the event before invoking its supported `delete()` action.
- Rejected duplicate JSON object keys instead of silently overwriting security-sensitive fields.
- Rejected raw control characters, non-finite numbers and unpaired Unicode surrogates in the dependency-free JSON codec.
- Added JSON nesting, value-count and string-size limits to stop stack and memory exhaustion; cyclic output structures are rejected.
- Replaced repeated whole-buffer WebSocket UTF-8 rescans with a bounded fragment assembler that correctly handles surrogate pairs split across frames.
- Replaced outbound UTF-8 size checks with allocation-free incremental byte counting and early rejection above the one-megabyte protocol limit.
- Cleared partial WebSocket text on open, close, error and shutdown, and ignored callbacks from replaced sockets so stale fragments cannot contaminate a reconnected session.
- Revalidated local media digest, signature and size before reuse or resolution.
- Rejected symbolic-link media roots/files and used bounded no-follow reads.
- Preserved idempotent concurrent installation of identical content-addressed media.
- Bound persistent and in-flight local idempotency keys to a canonical SHA-256 fingerprint of the operation, payload and audited reason, rejecting same-key request substitution even if the control plane is faulty.
- Hardened the persistent Ed25519 identity file with bounded no-follow reads, create-only writes, key-pair self-validation, strict file-size limits and temporary key-byte clearing.
- Preserved the no-inbound-port architecture and local custody of Discord bot tokens.
- Preserved deny-by-default named operations; arbitrary file access and arbitrary remote commands are not exposed.
- Preserved stale network template revision rejection, rollout idempotency, protected identities, Discord hierarchy, command allowlists, payload limits and feature-switch enforcement.
- Ensured cloud Setup Doctor checks and network announcements cross the appropriate Bukkit scheduler boundary before Bukkit API access.

### Automated checks completed

```text
Control-plane TypeScript no-emit check
51/51 Node tests
Java 21 release safety harness with -Xlint:all -Werror
Git whitespace/error check
```

The passing tests cover:

- approval creation, second-person approval, rejection, expiry and crash/lease retry;
- retryable versus permanent failures;
- direct and approved-operation idempotency;
- duplicate Durable Object messages, disconnects and heartbeats;
- offline redacted configuration cache;
- stale network template revisions and rollout keys;
- owner-only staff changes, ownership recovery and audit writes;
- request-size, parser, media-type, media-size, digest and symlink bounds;
- D1 migration ordering and schema assertions;
- rate limits, role policy and case-note capability separation;
- dashboard operation-to-policy coverage, reconnect behavior and offline approval rejection;
- plugin dependency scopes, fail-closed defaults and static cloud scheduler/Player-boundary contracts;
- complete `3.4.0` release-version consistency across source and runtime surfaces.

### Not verified in this delivery

- A user-side Maven compile reached the Java compiler and exposed three source errors; those exact errors are corrected in this archive. A complete post-fix `mvn -e clean verify`, JUnit run, shading pass and JAR inspection still require execution in an environment with Maven and dependency access.
- Root dashboard `npm ci`, lint, production build and rendered-page tests could not complete because the available npm registry proxy returned HTTP 404 for a locked package tarball. The source does not ship an unsafe dependency workaround.
- Desktop, tablet and mobile browser QA was not performed.
- Real Paper and Folia server tests, optional-integration matrix tests and shutdown-under-load tests were not performed.
- Real Cloudflare deployment, Sites `CONTROL_PLANE` binding, D1, Durable Objects and scheduled triggers require the operator's account and were not executed.
- Real Discord OAuth, guild permissions, role hierarchy and bot behavior require operator credentials and a test guild and were not executed.

`3.4.0` is the stable version identifier. This changelog records only checks actually executed; it does not claim that software is defect-free or that unperformed external gates passed.
