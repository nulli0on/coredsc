import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";
import test from "node:test";

const root = new URL("../../", import.meta.url);
const pom = readFileSync(new URL("plugin/pom.xml", root), "utf8");
const pluginYml = readFileSync(new URL("plugin/src/main/resources/plugin.yml", root), "utf8");
const cloudConfig = readFileSync(new URL("plugin/src/main/resources/modules/cloud-control.yml", root), "utf8");
const cloudDirectory = new URL("plugin/src/main/java/com/hubertstudios/coredsc/cloud/", root);
const cloudSources = readdirSync(cloudDirectory).filter((name) => name.endsWith(".java"))
  .map((name) => readFileSync(join(cloudDirectory.pathname, name), "utf8")).join("\n");

test("plugin metadata and dependency boundaries match 3.4.0", () => {
  assert.match(pom, /<version>3\.4\.0<\/version>/u);
  assert.match(pluginYml, /^version: 3\.4\.0$/mu);
  assert.match(pluginYml, /^folia-supported: true$/mu);
  for (const artifact of ["paper-api", "slf4j-api", "api", "voicechat-api"]) {
    const dependency = new RegExp(`<artifactId>${artifact.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&")}<\\/artifactId>[\\s\\S]{0,180}<scope>provided<\\/scope>`, "u");
    assert.match(pom, dependency, `${artifact} must remain provided`);
  }
  for (const artifact of ["sqlite-jdbc", "bstats-bukkit", "JDA"]) {
    const dependency = new RegExp(`<artifactId>${artifact.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&")}<\\/artifactId>[\\s\\S]{0,220}<scope>provided<\\/scope>`, "u");
    assert.doesNotMatch(pom, dependency, `${artifact} must remain packaged for runtime`);
  }
});

test("cloud and remote-console defaults fail closed", () => {
  assert.match(cloudConfig, /^enabled: false$/mu);
  assert.match(cloudConfig, /^endpoint: ['"]wss:\/\/coredsc\.example\.invalid\/api\/v1\/agent\/connect['"]$/mu);
  assert.match(cloudConfig, /remote-execution:[\s\S]{0,180}\n\s+enabled: false/u);
  assert.doesNotMatch(cloudConfig, /(^|\s)\*($|\s)/mu);
});

test("cloud package does not retain Player objects and scheduler-wraps direct Bukkit operations", () => {
  assert.doesNotMatch(cloudSources, /import org\.bukkit\.entity\.Player;/u);
  assert.doesNotMatch(cloudSources, /(?:private|protected|public)\s+(?:final\s+)?Player\s+/u);
  assert.match(cloudSources, /plugin\.callSync\(\(\) -> Bukkit\.dispatchCommand/u);
  assert.match(cloudSources, /plugin\.callSync\(\(\) -> Optional\.ofNullable\(Bukkit\.getOfflinePlayer/u);
  assert.match(cloudSources, /plugin\.runForPlayer\(uuid/u);
});

