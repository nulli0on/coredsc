import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import test from "node:test";

import { lookupOperationCapability } from "../src/policy.ts";

const dashboard = readFileSync(new URL("../../app/dashboard/[serverId]/page.tsx", import.meta.url), "utf8");
const javaRouter = readFileSync(new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudOperationRouter.java", import.meta.url), "utf8");
const javaModuleManager = readFileSync(new URL("../../plugin/src/main/java/com/hubertstudios/coredsc/module/ModuleManager.java", import.meta.url), "utf8");

const dashboardOperations = [
  "health.snapshot", "setup.doctor", "setup.createChannels", "discord.guilds", "discord.channels",
  "config.snapshot", "config.patch", "config.apply", "moderation.ban", "moderation.unban",
  "moderation.kick", "moderation.timeout", "moderation.warn", "moderation.note", "moderation.history",
  "channel.snapshot", "channel.lock", "channel.unlock", "channel.slowmode", "channel.purge",
  "channel.hide", "channel.reveal", "incident.status", "incident.start", "incident.resolve",
  "maintenance.status", "maintenance.start", "maintenance.cancel", "event.list", "event.create",
  "event.cancel", "automod.rules", "automod.upsert", "automod.delete", "console.snapshot",
  "console.execute",
] as const;

test("every dashboard operation has an explicit deny-by-default policy entry", () => {
  for (const operation of dashboardOperations) {
    assert.ok(lookupOperationCapability(operation), `${operation} is missing from the Worker policy`);
  }
});

test("dashboard live updates reconnect with bounded backoff and approvals remain rejectable offline", () => {
  assert.match(dashboard, /Math\.min\(30_000/u);
  assert.match(dashboard, /setLiveState\("reconnecting"\)/u);
  assert.match(dashboard, /canDecide=\{hasCapability\(capabilities, "approval\.decide"\)\}/u);
  assert.doesNotMatch(dashboard, /canDecide=\{agentOnline\s*&&/u);
});

test("dashboard retries preserve the original idempotency key", () => {
  assert.match(dashboard, /type RetryRequest = \{[^}]*idempotencyKey: string/u);
  assert.match(dashboard, /executeOperation\(retryRequest\)/u);
  assert.match(dashboard, /body: JSON\.stringify\(\{ operation, payload, reason, idempotencyKey \}\)/u);
  assert.doesNotMatch(dashboard, /body: JSON\.stringify\(\{ operation, payload, reason, idempotencyKey: crypto\.randomUUID\(\) \}\)/u);
});

test("Worker and plugin agree that notes use case authority rather than sanction authority", () => {
  assert.match(javaRouter, /values\.put\("moderation\.note", "case\.manage"\)/u);
  assert.match(javaRouter, /"MODERATOR"[\s\S]*?"case\.manage"/u);
  assert.match(javaRouter, /"SUPPORT"[\s\S]*?"case\.manage"/u);
});


test("cloud control fails closed when its modular setting is absent", () => {
  assert.match(javaModuleManager, /getBoolean\("modules\.cloud-control", false\)/u);
  assert.doesNotMatch(javaModuleManager, /getBoolean\("modules\.cloud-control", true\)/u);
});
