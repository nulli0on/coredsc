import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import { DatabaseSync } from "node:sqlite";

const here = dirname(fileURLToPath(import.meta.url));
const migrationDirectory = join(here, "..", "migrations");
const migrationFiles = readdirSync(migrationDirectory).filter((name) => /^\d+_.+\.sql$/u.test(name)).sort();

function apply(db: DatabaseSync, names = migrationFiles): void {
  for (const name of names) db.exec(readFileSync(join(migrationDirectory, name), "utf8"));
}

function seedIdentity(db: DatabaseSync): void {
  db.prepare("INSERT INTO users VALUES (?,?,?,?,?,?)").run("100000000000000", "owner", "Owner", null, 1, 1);
  db.prepare("INSERT INTO users VALUES (?,?,?,?,?,?)").run("200000000000000", "admin", "Admin", null, 1, 1);
  db.prepare(`INSERT INTO instances(id,public_key,display_name,plugin_version,minecraft_version,scheduler_runtime,status,
    approval_mode,last_seen_at,created_at) VALUES (?,?,?,?,?,?,?,1,?,?)`)
    .run("11111111-1111-4111-8111-111111111111", "key", "Server", "3.4.0", "1.21.11", "FOLIA", "ONLINE", 1, 1);
}

test("migrations apply in lexical order to an empty D1-compatible SQLite database", () => {
  assert.deepEqual(migrationFiles, [
    "0001_initial.sql",
    "0002_health_incidents.sql",
    "0003_operation_reliability.sql",
    "0004_rate_limits.sql",
    "0005_idempotency_fingerprints.sql",
    "0006_ownership_recovery.sql",
  ]);
  const db = new DatabaseSync(":memory:");
  apply(db);
  const columns = db.prepare("PRAGMA table_info(audit_events)").all().map((row) => String(row.name));
  assert.ok(columns.includes("attempted_at"));
  assert.ok(columns.includes("request_hash"));
  const approvalColumns = db.prepare("PRAGMA table_info(approvals)").all().map((row) => String(row.name));
  assert.ok(approvalColumns.includes("execution_started_at"));
  assert.ok(approvalColumns.includes("attempt_count"));
  const pairingColumns = db.prepare("PRAGMA table_info(pairing_links)").all().map((row) => String(row.name));
  assert.ok(pairingColumns.includes("ownership_recovery"));
  db.close();
});

test("reliability migration preserves legacy duplicate approvals and enforces future uniqueness", () => {
  const db = new DatabaseSync(":memory:");
  apply(db, ["0001_initial.sql", "0002_health_incidents.sql"]);
  seedIdentity(db);
  const insert = db.prepare(`INSERT INTO approvals(id,instance_id,requester_id,operation,payload_json,reason,idempotency_key,status,created_at,expires_at)
    VALUES (?,?,?,?,?,?,?,'PENDING',?,?)`);
  insert.run("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", "11111111-1111-4111-8111-111111111111", "100000000000000",
    "channel.purge", "{}", "reason", "same-key", 1, 1000);
  insert.run("bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb", "11111111-1111-4111-8111-111111111111", "100000000000000",
    "channel.purge", "{}", "reason", "same-key", 2, 1000);
  apply(db, ["0003_operation_reliability.sql"]);
  const keys = db.prepare("SELECT idempotency_key FROM approvals ORDER BY created_at,id").all().map((row) => String(row.idempotency_key));
  assert.equal(keys[0], "same-key");
  assert.match(keys[1], /^same-key:legacy:/u);
  assert.throws(() => insert.run("cccccccc-cccc-4ccc-8ccc-cccccccccccc", "11111111-1111-4111-8111-111111111111",
    "100000000000000", "channel.purge", "{}", "reason", "same-key", 3, 1000), /UNIQUE/u);
  db.close();
});

test("approval lifecycle supports rejection, retry release and execution without self-approval", () => {
  const db = new DatabaseSync(":memory:");
  apply(db);
  seedIdentity(db);
  db.prepare(`INSERT INTO grants(instance_id,discord_user_id,role,granted_by,created_at,revoked_at)
    VALUES (?,?,?,?,?,NULL)`).run("11111111-1111-4111-8111-111111111111", "100000000000000", "OWNER", "100000000000000", 1);
  db.prepare(`INSERT INTO grants(instance_id,discord_user_id,role,granted_by,created_at,revoked_at)
    VALUES (?,?,?,?,?,NULL)`).run("11111111-1111-4111-8111-111111111111", "200000000000000", "SERVER_ADMIN", "100000000000000", 1);
  db.prepare(`INSERT INTO approvals(id,instance_id,requester_id,operation,payload_json,reason,idempotency_key,status,created_at,expires_at)
    VALUES (?,?,?,?,?,?,?,'PENDING',?,?)`).run("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
      "11111111-1111-4111-8111-111111111111", "100000000000000", "console.execute", "{}", "review", "key", 1, 999999);
  const claim = db.prepare(`UPDATE approvals SET status='APPROVED',decided_by=?,decided_at=?,execution_started_at=?,attempt_count=attempt_count+1
    WHERE id=? AND status='PENDING' AND requester_id<>?`).run("200000000000000", 2, 2,
      "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", "200000000000000");
  assert.equal(claim.changes, 1);
  const selfClaim = db.prepare(`UPDATE approvals SET status='APPROVED' WHERE id=? AND status='PENDING' AND requester_id<>?`)
    .run("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", "100000000000000");
  assert.equal(selfClaim.changes, 0);
  db.prepare(`UPDATE approvals SET status='PENDING',decided_by=NULL,decided_at=NULL,execution_started_at=NULL
    WHERE id=? AND status='APPROVED'`).run("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa");
  db.prepare("UPDATE approvals SET status='EXECUTED',result_json=? WHERE id=? AND status='PENDING'")
    .run('{"ok":true}', "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa");
  const row = db.prepare("SELECT status,attempt_count,result_json FROM approvals WHERE id=?")
    .get("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa") as Record<string, unknown>;
  assert.equal(row.status, "EXECUTED");
  assert.equal(row.attempt_count, 1);
  assert.equal(row.result_json, '{"ok":true}');
  db.close();
});


test("rate-limit migration increments fixed-window buckets atomically", () => {
  const db = new DatabaseSync(":memory:");
  apply(db);
  const statement = db.prepare(`INSERT INTO rate_limits(bucket,window_start,request_count,expires_at) VALUES (?,?,1,?)
    ON CONFLICT(bucket,window_start) DO UPDATE SET request_count=request_count+1 RETURNING request_count`);
  assert.equal((statement.get("operation:user", 1_000, 121_000) as Record<string, unknown>).request_count, 1);
  assert.equal((statement.get("operation:user", 1_000, 121_000) as Record<string, unknown>).request_count, 2);
  assert.equal((statement.get("operation:user", 61_000, 181_000) as Record<string, unknown>).request_count, 1);
  db.close();
});
