import assert from "node:assert/strict";
import test from "node:test";

import { lookupOperationCapability, operationNeedsApproval, roleHas } from "../src/policy.ts";
import { MAX_MEDIA_BYTES, validateMediaBytes } from "../src/media.ts";
import {
  canonicalJson,
  dispatchLeaseExpired,
  networkRolloutKey,
  operationFingerprintInput,
  retryableResult,
  utf8ByteLength,
} from "../src/reliability.ts";

test("role capabilities stay least-privilege", () => {
  assert.equal(roleHas("OWNER", "console.execute"), true);
  assert.equal(roleHas("SERVER_ADMIN", "console.execute"), false);
  assert.equal(roleHas("MODERATOR", "moderation.manage"), true);
  assert.equal(roleHas("MODERATOR", "case.manage"), true);
  assert.equal(roleHas("CONSOLE_VIEWER", "console.execute"), false);
  assert.equal(roleHas("CONSOLE_OPERATOR", "console.execute"), true);
  assert.equal(roleHas("SUPPORT", "config.edit"), false);
  assert.equal(roleHas("SUPPORT", "case.manage"), true);
  assert.equal(roleHas("SUPPORT", "moderation.manage"), false);
  assert.equal(roleHas("VIEWER", "channel.manage"), false);
});

test("case notes are separate from sanction authority", () => {
  assert.equal(lookupOperationCapability("moderation.note"), "case.manage");
  assert.equal(lookupOperationCapability("moderation.history"), "moderation.view");
  assert.equal(lookupOperationCapability("moderation.ban"), "moderation.manage");
});

test("dangerous operations require second-person approval", () => {
  assert.equal(operationNeedsApproval("channel.purge", { count: 1 }), true);
  assert.equal(operationNeedsApproval("console.execute", { command: "list" }), true);
  assert.equal(operationNeedsApproval("network.template.apply", {}), true);
  assert.equal(operationNeedsApproval("moderation.ban", { duration: "permanent" }), true);
  assert.equal(operationNeedsApproval("moderation.ban", { duration: "7d" }), false);
  assert.equal(operationNeedsApproval("incident.start", { scope: "network" }), true);
  assert.equal(operationNeedsApproval("incident.start", { scope: "server" }), false);
});

test("network rollout keys distinguish new rollouts but remain retry-stable", () => {
  const instance = "11111111-1111-4111-8111-111111111111";
  assert.equal(networkRolloutKey("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", instance),
    networkRolloutKey("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", instance));
  assert.notEqual(networkRolloutKey("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", instance),
    networkRolloutKey("bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb", instance));
});

test("dispatch lease and retryability are explicit", () => {
  const now = 1_000_000;
  assert.equal(dispatchLeaseExpired(now - 119_999, now), false);
  assert.equal(dispatchLeaseExpired(now - 120_000, now), true);
  assert.equal(dispatchLeaseExpired(null, now), true);
  assert.equal(retryableResult({ error: { retryable: true } }), true);
  assert.equal(retryableResult({ error: { retryable: false } }), false);
  assert.equal(retryableResult({ ok: true }), false);
});

test("payload byte counting uses UTF-8 bytes rather than JavaScript characters", () => {
  assert.equal(utf8ByteLength("abc"), 3);
  assert.equal(utf8ByteLength("€"), 3);
  assert.equal(utf8ByteLength("😀"), 4);
});

test("media validation checks declared type, magic and bounds", () => {
  const png = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0]);
  assert.deepEqual(validateMediaBytes(png, "image/png"), { mimeType: "image/png", extension: "png" });
  assert.throws(() => validateMediaBytes(png, "image/jpeg"), /do not match/u);
  assert.throws(() => validateMediaBytes(new Uint8Array(), "image/png"), /empty/u);
  assert.throws(() => validateMediaBytes(new Uint8Array(MAX_MEDIA_BYTES + 1), "image/png"), /exceeds/u);
  assert.throws(() => validateMediaBytes(png, "image/svg+xml"), /Only PNG/u);
});

test("idempotency fingerprints are stable across object key order and bind the reason", () => {
  assert.equal(canonicalJson({ b: 2, a: 1 }), canonicalJson({ a: 1, b: 2 }));
  assert.equal(
    operationFingerprintInput("config.patch", { changes: [{ value: true, path: "x" }] }, "reason"),
    operationFingerprintInput("config.patch", { changes: [{ path: "x", value: true }] }, "reason"),
  );
  assert.notEqual(
    operationFingerprintInput("config.patch", { changes: [] }, "first"),
    operationFingerprintInput("config.patch", { changes: [] }, "second"),
  );
});
