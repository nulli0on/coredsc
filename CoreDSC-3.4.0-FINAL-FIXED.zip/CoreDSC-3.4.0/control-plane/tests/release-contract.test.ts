import assert from "node:assert/strict";
import { readFileSync, readdirSync } from "node:fs";
import { join, relative } from "node:path";
import test from "node:test";

const root = new URL("../../", import.meta.url);
const EXPECTED_VERSION = "3.4.0";

function read(relativePath: string): string {
  return readFileSync(new URL(relativePath, root), "utf8");
}

function json(relativePath: string): Record<string, unknown> {
  return JSON.parse(read(relativePath)) as Record<string, unknown>;
}

function projectFiles(directory: string): string[] {
  const absolute = new URL(directory, root).pathname;
  const results: string[] = [];
  const visit = (current: string): void => {
    for (const entry of readdirSync(current, { withFileTypes: true })) {
      if ([".git", ".sites-runtime", "node_modules", "target", "dist", ".next", ".wrangler"].includes(entry.name)) continue;
      const path = join(current, entry.name);
      if (entry.isDirectory()) visit(path);
      else results.push(path);
    }
  };
  visit(absolute);
  return results;
}

test("release version is consistent across build, runtime, dashboard and lockfiles", () => {
  assert.equal(json("package.json").version, EXPECTED_VERSION);
  assert.equal(json("package-lock.json").version, EXPECTED_VERSION);
  assert.equal((json("package-lock.json").packages as Record<string, { version?: string }>)[""].version, EXPECTED_VERSION);
  assert.equal(json("control-plane/package.json").version, EXPECTED_VERSION);
  assert.equal(json("control-plane/package-lock.json").version, EXPECTED_VERSION);
  assert.equal((json("control-plane/package-lock.json").packages as Record<string, { version?: string }>)[""].version,
    EXPECTED_VERSION);

  assert.match(read("plugin/pom.xml"), /<artifactId>coredsc<\/artifactId>\s*<version>3\.4\.0<\/version>/u);
  assert.match(read("plugin/src/main/resources/plugin.yml"), /^version: 3\.4\.0$/mu);
  assert.match(read("control-plane/src/index.ts"), /version: "3\.4\.0"/u);
  assert.match(read("app/page.tsx"), /CoreDSC 3\.4\.0/u);
  assert.match(read("app/dashboard/page.tsx"), /server\.pluginVersion \|\| "3\.4\.0"/u);
  assert.match(read("app/dashboard\/\[serverId\]/page.tsx"), /instance\.plugin_version \?\? "3\.4\.0"/u);
});

test("all generated configuration templates identify the stable release", () => {
  const resources = projectFiles("plugin/src/main/resources/")
    .filter((path) => path.endsWith(".yml"))
    .map((path) => readFileSync(path, "utf8"))
    .filter((content) => content.includes("generated-by-version:"));

  assert.ok(resources.length >= 25, "expected the managed YAML template set");
  for (const content of resources) {
    assert.match(content, /^generated-by-version: ["']3\.4\.0["']$/mu);
  }
});

test("the source tree has exactly the four approved Markdown documents", () => {
  const markdown = projectFiles("./")
    .filter((path) => path.endsWith(".md"))
    .map((path) => relative(new URL("./", root).pathname, path).replaceAll("\\", "/"))
    .sort();

  assert.deepEqual(markdown, ["CHANGELOG.md", "README.md", "REFERENCE.md", "SETUP.md"]);
  for (const path of markdown) assert.doesNotMatch(read(path), /CONTINUE-PROMPT\.txt/u);
});

test("release-owned version markers contain no prerelease suffix", () => {
  const ownedFiles = [
    "README.md", "SETUP.md", "REFERENCE.md", "CHANGELOG.md", "package.json",
    "plugin/pom.xml", "plugin/src/main/resources/plugin.yml", "control-plane/package.json",
    "control-plane/src/index.ts", "app/page.tsx", "app/dashboard/page.tsx",
    "app/dashboard/[serverId]/page.tsx",
  ];
  for (const path of ownedFiles) {
    assert.doesNotMatch(read(path), /3\.4(?:\.0)?[- ]beta/iu, `${path} still identifies CoreDSC as beta`);
  }
});

test("R2 is absent and local media and identity state enforce bounded no-follow storage", () => {
  const wrangler = read("control-plane/wrangler.jsonc");
  const media = read("control-plane/src/media.ts");
  const localStore = read("plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudMediaStore.java");
  const identity = read("plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudIdentity.java");

  assert.doesNotMatch(wrangler, /r2_buckets|R2Bucket/u);
  assert.match(media, /MAX_MEDIA_BYTES\s*=\s*512\s*\*\s*1024/u);
  assert.match(localStore, /MAX_MEDIA_BYTES\s*=\s*512\s*\*\s*1024/u);
  assert.match(localStore, /LinkOption\.NOFOLLOW_LINKS/u);
  assert.match(localStore, /digest\.equals\(sha256\(bytes\)\)/u);
  assert.match(identity, /MAXIMUM_IDENTITY_BYTES\s*=\s*8_192/u);
  assert.match(identity, /LinkOption\.NOFOLLOW_LINKS/u);
  assert.match(identity, /StandardOpenOption\.CREATE_NEW/u);
  assert.match(identity, /identity public\/private keys do not match/u);
});

test("local idempotency binds each key to a canonical request fingerprint", () => {
  const router = read("plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudOperationRouter.java");
  const repository = read("plugin/src/main/java/com/hubertstudios/coredsc/storage/CloudOperationRepository.java");
  const storage = read("plugin/src/main/java/com/hubertstudios/coredsc/storage/SQLiteStorage.java");
  const fingerprint = read("plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudRequestFingerprint.java");

  assert.match(router, /CloudRequestFingerprint\.calculate/u);
  assert.match(router, /Idempotency key was already used for a different local request/u);
  assert.match(router, /Idempotency key is already executing a different local request/u);
  assert.match(repository, /request_fingerprint/u);
  assert.match(storage, /SCHEMA_VERSION\s*=\s*13/u);
  assert.match(storage, /addColumnIfMissing\(connection, "cloud_operation_results", "request_fingerprint"/u);
  assert.match(fingerprint, /keys\.sort\(String::compareTo\)/u);
  assert.match(fingerprint, /SHA-256/u);
});

test("WebSocket fragment state is reset and stale socket callbacks are ignored", () => {
  const agent = read("plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudEditorAgent.java");
  const assembler = read("plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudTextFrameAssembler.java");
  const limits = read("plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudProtocolLimits.java");

  assert.match(agent, /if \(socket\.get\(\) != webSocket\) return CompletableFuture\.completedFuture\(null\)/u);
  assert.ok((agent.match(/receivedText\.reset\(\)/gu) ?? []).length >= 4);
  assert.match(assembler, /pendingHighSurrogate/u);
  assert.match(assembler, /candidateBytes > maximumBytes/u);
  assert.doesNotMatch(limits, /getBytes\(/u);
  assert.match(limits, /Character\.isHighSurrogate/u);
  assert.match(limits, /bytes > MAXIMUM_MESSAGE_BYTES/u);
});
