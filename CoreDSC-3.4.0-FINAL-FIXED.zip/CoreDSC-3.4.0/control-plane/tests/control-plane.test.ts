import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { DatabaseSync, type StatementSync } from "node:sqlite";

import controlPlane from "../src/index.ts";
import { csrfTokenFor, sha256 } from "../src/security.ts";
import type { AgentResult, Env } from "../src/types.ts";

const here = dirname(fileURLToPath(import.meta.url));
const INSTANCE = "11111111-1111-4111-8111-111111111111";
const OWNER = "100000000000000";
const ADMIN = "200000000000000";
const VIEWER = "300000000000000";
const ORIGIN = "https://dashboard.example.test";
const SECRET = "test-cookie-secret-with-at-least-32-bytes";

type RoomHandler = (command: Record<string, unknown>) => AgentResult | Promise<AgentResult>;

class SqliteStatement {
  private readonly statement: StatementSync;
  private values: unknown[] = [];
  constructor(statement: StatementSync) { this.statement = statement; }
  bind(...values: unknown[]): SqliteStatement { this.values = values; return this; }
  async first<T>(): Promise<T | null> { return (this.statement.get(...this.values) as T | undefined) ?? null; }
  async run<T>(): Promise<{ results: T[]; success: boolean; meta: { changes: number } }> {
    const result = this.statement.run(...this.values);
    return { results: [], success: true, meta: { changes: Number(result.changes) } };
  }
  async all<T>(): Promise<{ results: T[]; success: boolean; meta: { changes: number } }> {
    return { results: this.statement.all(...this.values) as T[], success: true, meta: { changes: 0 } };
  }
  async raw<T>(): Promise<T[]> { return this.statement.all(...this.values).map((row) => Object.values(row)) as T[]; }
}

class SqliteD1 {
  private readonly db: DatabaseSync;
  constructor(db: DatabaseSync) { this.db = db; }
  prepare(query: string): SqliteStatement { return new SqliteStatement(this.db.prepare(query)); }
  async batch<T>(statements: SqliteStatement[]): Promise<Array<{ results: T[]; success: boolean; meta: { changes: number } }>> {
    const results = [];
    this.db.exec("BEGIN");
    try {
      for (const statement of statements) results.push(await statement.run<T>());
      this.db.exec("COMMIT");
      return results;
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
  }
  async exec(query: string): Promise<{ count: number; duration: number }> { this.db.exec(query); return { count: 0, duration: 0 }; }
}

class RoomStub {
  calls: Record<string, unknown>[] = [];
  online = true;
  handler: RoomHandler = () => ({ ok: true, payload: { accepted: true } });
  async fetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
    const request = input instanceof Request ? input : new Request(input, init);
    const path = new URL(request.url).pathname;
    if (path === "/status") return Response.json({ online: this.online });
    if (path === "/command") {
      const command = await request.json<Record<string, unknown>>();
      this.calls.push(command);
      const result = await this.handler(command);
      return Response.json(result, { status: result.ok ? 200 : result.error?.retryable ? 503 : 422 });
    }
    return Response.json({ error: "unsupported test room path" }, { status: 404 });
  }
}

interface Fixture {
  db: DatabaseSync;
  env: Env;
  room: RoomStub;
  sessions: Record<string, { cookie: string; csrf: string }>;
}

async function fixture(): Promise<Fixture> {
  const db = new DatabaseSync(":memory:");
  const migrationDirectory = join(here, "..", "migrations");
  for (const name of readdirSync(migrationDirectory).filter((value) => /^\d+_.+\.sql$/u.test(value)).sort()) {
    db.exec(readFileSync(join(migrationDirectory, name), "utf8"));
  }
  const now = Date.now();
  const insertUser = db.prepare("INSERT INTO users VALUES (?,?,?,?,?,?)");
  insertUser.run(OWNER, "owner", "Owner", null, now, now);
  insertUser.run(ADMIN, "admin", "Admin", null, now, now);
  insertUser.run(VIEWER, "viewer", "Viewer", null, now, now);
  db.prepare(`INSERT INTO instances(id,public_key,display_name,plugin_version,minecraft_version,scheduler_runtime,status,
    approval_mode,last_seen_at,created_at) VALUES (?,?,?,?,?,?,?,1,?,?)`)
    .run(INSTANCE, "key", "Test Server", "3.4.0", "1.21.11", "FOLIA", "ONLINE", now, now);
  const grant = db.prepare(`INSERT INTO grants(instance_id,discord_user_id,role,granted_by,created_at,revoked_at)
    VALUES (?,?,?,?,?,NULL)`);
  grant.run(INSTANCE, OWNER, "OWNER", OWNER, now);
  grant.run(INSTANCE, ADMIN, "SERVER_ADMIN", OWNER, now);
  grant.run(INSTANCE, VIEWER, "VIEWER", OWNER, now);

  const sessions: Record<string, { cookie: string; csrf: string }> = {};
  for (const [id, label] of [[OWNER, "owner"], [ADMIN, "admin"], [VIEWER, "viewer"]] as const) {
    const cookie = `session-${label}`;
    const sessionId = `aaaaaaaa-aaaa-4aaa-8aaa-${id.slice(0, 12)}`;
    const csrf = await csrfTokenFor(SECRET, sessionId);
    db.prepare("INSERT INTO sessions VALUES (?,?,?,?,?,?,?)")
      .run(sessionId, await sha256(cookie), await sha256(csrf), id, now, now + 3_600_000, now);
    sessions[id] = { cookie, csrf };
  }

  const room = new RoomStub();
  const database = new SqliteD1(db);
  const env = {
    COREDSC_DB: database,
    INSTANCE_ROOMS: { idFromName: (name: string) => ({ toString: () => name }), get: () => room },
    APP_ORIGIN: ORIGIN,
    PUBLIC_APP_URL: ORIGIN,
    DISCORD_CLIENT_ID: "client",
    DISCORD_CLIENT_SECRET: "secret",
    DISCORD_REDIRECT_URI: `${ORIGIN}/api/v1/auth/discord/callback`,
    COOKIE_SECRET: SECRET,
    SESSION_TTL_SECONDS: "3600",
  } as unknown as Env;
  return { db, env, room, sessions };
}

function authenticatedRequest(
  path: string,
  session: { cookie: string; csrf: string },
  init: RequestInit = {},
): Request {
  const headers = new Headers(init.headers);
  headers.set("Origin", ORIGIN);
  headers.set("Cookie", `__Host-coredsc_session=${session.cookie}`);
  headers.set("CF-Connecting-IP", "203.0.113.40");
  if (init.method && init.method !== "GET") headers.set("X-CoreDSC-CSRF", session.csrf);
  return new Request(`${ORIGIN}${path}`, { ...init, headers });
}

async function operation(
  fx: Fixture,
  actor: string,
  operationName: string,
  payload: Record<string, unknown>,
  reason: string,
  idempotencyKey: string,
): Promise<Response> {
  return controlPlane.fetch!(authenticatedRequest(`/v1/servers/${INSTANCE}/operations`, fx.sessions[actor], {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ operation: operationName, payload, reason, idempotencyKey }),
  }), fx.env, { waitUntil() {}, passThroughOnException() {} });
}

async function decide(fx: Fixture, actor: string, approvalId: string, decision = "APPROVE"): Promise<Response> {
  return controlPlane.fetch!(authenticatedRequest(`/v1/approvals/${approvalId}/decision`, fx.sessions[actor], {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ decision, note: `${decision.toLowerCase()} test` }),
  }), fx.env, { waitUntil() {}, passThroughOnException() {} });
}

test("dangerous operations persist one replay-safe approval and reject key reuse", async () => {
  const fx = await fixture();
  const key = "approval-key";
  const first = await operation(fx, OWNER, "console.execute", { command: "list" }, "Inspect server", key);
  assert.equal(first.status, 202);
  const firstBody = await first.json<{ approvalId: string; replay: boolean }>();
  assert.equal(firstBody.replay, false);
  const replay = await operation(fx, OWNER, "console.execute", { command: "list" }, "Inspect server", key);
  const replayBody = await replay.json<{ approvalId: string; replay: boolean }>();
  assert.equal(replay.status, 202);
  assert.equal(replayBody.approvalId, firstBody.approvalId);
  assert.equal(replayBody.replay, true);
  const conflict = await operation(fx, OWNER, "console.execute", { command: "tps" }, "Different request", key);
  assert.equal(conflict.status, 409);
  assert.equal(Number(fx.db.prepare("SELECT COUNT(*) AS count FROM approvals").get()!.count), 1);
  fx.db.close();
});

test("approval requires a second capable person and executes exactly once", async () => {
  const fx = await fixture();
  const created = await operation(fx, OWNER, "console.execute", { command: "list" }, "Operational check", "two-person");
  const { approvalId } = await created.json<{ approvalId: string }>();
  assert.equal((await decide(fx, OWNER, approvalId)).status, 403);
  const approved = await decide(fx, ADMIN, approvalId);
  assert.equal(approved.status, 200);
  assert.equal(fx.room.calls.length, 1);
  assert.equal(fx.db.prepare("SELECT status FROM approvals WHERE id=?").get(approvalId)!.status, "EXECUTED");
  assert.equal((await decide(fx, ADMIN, approvalId)).status, 409);
  fx.db.close();
});

test("retryable approval failures return to pending while permanent failures stop", async () => {
  const retry = await fixture();
  let attempts = 0;
  retry.room.handler = () => {
    attempts += 1;
    return attempts === 1
      ? { ok: false, error: { code: "AGENT_TIMEOUT", message: "timeout", retryable: true } }
      : { ok: true, payload: { recovered: true } };
  };
  const created = await operation(retry, OWNER, "console.execute", { command: "list" }, "Retry test", "retry-approval");
  const { approvalId } = await created.json<{ approvalId: string }>();
  assert.equal((await decide(retry, ADMIN, approvalId)).status, 503);
  assert.equal(retry.db.prepare("SELECT status FROM approvals WHERE id=?").get(approvalId)!.status, "PENDING");
  assert.equal((await decide(retry, ADMIN, approvalId)).status, 200);
  assert.equal(retry.db.prepare("SELECT status,attempt_count FROM approvals WHERE id=?").get(approvalId)!.status, "EXECUTED");
  assert.equal(retry.db.prepare("SELECT attempt_count FROM approvals WHERE id=?").get(approvalId)!.attempt_count, 2);
  retry.db.close();

  const permanent = await fixture();
  permanent.room.handler = () => ({ ok: false, error: { code: "LOCAL_POLICY", message: "blocked", retryable: false } });
  const permanentCreated = await operation(permanent, OWNER, "console.execute", { command: "list" }, "Permanent test", "permanent-approval");
  const permanentId = (await permanentCreated.json<{ approvalId: string }>()).approvalId;
  assert.equal((await decide(permanent, ADMIN, permanentId)).status, 422);
  assert.equal(permanent.db.prepare("SELECT status FROM approvals WHERE id=?").get(permanentId)!.status, "FAILED");
  assert.equal((await decide(permanent, ADMIN, permanentId)).status, 409);
  permanent.db.close();
});

test("direct operation idempotency replays permanent results and retries transient failures", async () => {
  const fx = await fixture();
  fx.room.handler = () => ({ ok: true, payload: { healthy: true } });
  const first = await operation(fx, OWNER, "health.snapshot", {}, "", "health-key");
  assert.equal(first.status, 200);
  const replay = await operation(fx, OWNER, "health.snapshot", {}, "", "health-key");
  assert.equal(replay.status, 200);
  assert.equal((await replay.json<{ replay?: boolean }>()).replay, true);
  assert.equal(fx.room.calls.length, 1);

  let attempts = 0;
  fx.room.handler = () => {
    attempts += 1;
    return attempts === 1
      ? { ok: false, error: { code: "INSTANCE_OFFLINE", message: "offline", retryable: true } }
      : { ok: true, payload: { healthy: true } };
  };
  assert.equal((await operation(fx, OWNER, "health.snapshot", {}, "", "retry-key")).status, 503);
  assert.equal((await operation(fx, OWNER, "health.snapshot", {}, "", "retry-key")).status, 200);
  assert.equal(attempts, 2);
  fx.db.close();
});

test("offline configuration reads use the latest redacted cache but remain read-only", async () => {
  const fx = await fixture();
  fx.room.handler = () => ({ ok: false, error: { code: "INSTANCE_OFFLINE", message: "offline", retryable: true } });
  const cachedAt = Date.now() - 10_000;
  fx.db.prepare(`INSERT INTO configuration_snapshots(id,instance_id,revision,redacted_json,created_by,created_at)
    VALUES (?,?,?,?,?,?)`).run("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa", INSTANCE, "r1",
      JSON.stringify({ modules: [{ id: "chat-sync", enabled: true }] }), OWNER, cachedAt);
  const response = await operation(fx, OWNER, "config.snapshot", {}, "", "cache-key");
  assert.equal(response.status, 200);
  const body = await response.json<{ ok: boolean; payload: { cached: boolean; cachedAt: number } }>();
  assert.equal(body.ok, true);
  assert.equal(body.payload.cached, true);
  assert.equal(body.payload.cachedAt, cachedAt);
  const viewerEdit = await operation(fx, VIEWER, "config.patch", { changes: [] }, "Try edit", "viewer-edit");
  assert.equal(viewerEdit.status, 403);
  fx.db.close();
});

test("only the owner can grant staff roles and every change is audited", async () => {
  const fx = await fixture();
  const payload = JSON.stringify({ discordUserId: VIEWER, role: "MODERATOR" });
  const adminAttempt = await controlPlane.fetch!(authenticatedRequest(`/v1/servers/${INSTANCE}/staff`, fx.sessions[ADMIN], {
    method: "POST", headers: { "Content-Type": "application/json" }, body: payload,
  }), fx.env, { waitUntil() {}, passThroughOnException() {} });
  assert.equal(adminAttempt.status, 403);
  const ownerGrant = await controlPlane.fetch!(authenticatedRequest(`/v1/servers/${INSTANCE}/staff`, fx.sessions[OWNER], {
    method: "POST", headers: { "Content-Type": "application/json" }, body: payload,
  }), fx.env, { waitUntil() {}, passThroughOnException() {} });
  assert.equal(ownerGrant.status, 200);
  assert.equal(fx.db.prepare("SELECT role FROM grants WHERE instance_id=? AND discord_user_id=?").get(INSTANCE, VIEWER)!.role, "MODERATOR");
  assert.equal(Number(fx.db.prepare("SELECT COUNT(*) AS count FROM audit_events WHERE operation='staff.grant'").get()!.count), 1);
  fx.db.close();
});


test("ownership recovery pairing can be claimed by a new Discord owner without an existing grant", async () => {
  const fx = await fixture();
  const token = "ownership-recovery-link";
  const now = Date.now();
  fx.db.prepare("UPDATE grants SET revoked_at=? WHERE instance_id=? AND discord_user_id=?")
    .run(now, INSTANCE, VIEWER);
  fx.db.prepare(`INSERT INTO pairing_links
    (id,instance_id,link_hash,code_hash,requested_minecraft_uuid,requested_minecraft_name,
     requested_discord_user_id,claimed_discord_user_id,status,created_at,expires_at,confirmed_at,ownership_recovery)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,1)`)
    .run("bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb", INSTANCE, await sha256(token), await sha256("ABCD-EFGH"),
      null, "Local console", null, null, "CREATED", now, now + 900_000, null);

  const response = await controlPlane.fetch!(authenticatedRequest("/v1/pairings/claim", fx.sessions[VIEWER], {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ token }),
  }), fx.env, { waitUntil() {}, passThroughOnException() {} });
  assert.equal(response.status, 200);
  const body = await response.json<{ pairing: { ownershipRecovery: boolean; instanceId: string } }>();
  assert.equal(body.pairing.ownershipRecovery, true);
  assert.equal(body.pairing.instanceId, INSTANCE);
  const row = fx.db.prepare("SELECT status,claimed_discord_user_id FROM pairing_links WHERE link_hash=?")
    .get(await sha256(token))!;
  assert.equal(row.status, "AWAITING_CONFIRM");
  assert.equal(row.claimed_discord_user_id, VIEWER);
  fx.db.close();
});

test("approval rejection is final and never dispatches an agent command", async () => {
  const fx = await fixture();
  const created = await operation(fx, OWNER, "console.execute", { command: "list" }, "Reject test", "reject-approval");
  const { approvalId } = await created.json<{ approvalId: string }>();
  const rejected = await decide(fx, ADMIN, approvalId, "REJECT");
  assert.equal(rejected.status, 200);
  assert.equal(fx.room.calls.length, 0);
  const row = fx.db.prepare("SELECT status,decided_by,decision_note FROM approvals WHERE id=?").get(approvalId)!;
  assert.equal(row.status, "REJECTED");
  assert.equal(row.decided_by, ADMIN);
  assert.match(String(row.decision_note), /reject test/u);
  assert.equal((await decide(fx, ADMIN, approvalId, "APPROVE")).status, 409);
  fx.db.close();
});

test("scheduled maintenance expires abandoned approvals and releases stale execution leases", async () => {
  const fx = await fixture();
  const now = Date.now();
  const insert = fx.db.prepare(`INSERT INTO approvals
    (id,instance_id,requester_id,operation,payload_json,reason,idempotency_key,status,created_at,expires_at,
     decided_by,decided_at,decision_note,execution_started_at,attempt_count)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  insert.run("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1", INSTANCE, OWNER, "console.execute", "{}", "expired",
    "scheduled-expire", "PENDING", now - 600_000, now - 1, null, null, "", null, 0);
  insert.run("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2", INSTANCE, OWNER, "console.execute", "{}", "recover",
    "scheduled-recover", "APPROVED", now - 600_000, now + 600_000, ADMIN, now - 300_000, "approved",
    now - 180_000, 1);
  let maintenance: Promise<unknown> | undefined;
  controlPlane.scheduled!({ scheduledTime: now, cron: "* * * * *", noRetry() {} }, fx.env, {
    waitUntil(promise) { maintenance = promise; },
    passThroughOnException() {},
  });
  assert.ok(maintenance);
  await maintenance;
  const expired = fx.db.prepare("SELECT status FROM approvals WHERE id=?")
    .get("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1")!;
  assert.equal(expired.status, "EXPIRED");
  const recovered = fx.db.prepare("SELECT status,decided_by,decided_at,decision_note,execution_started_at,attempt_count FROM approvals WHERE id=?")
    .get("aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2")!;
  assert.equal(recovered.status, "PENDING");
  assert.equal(recovered.decided_by, null);
  assert.equal(recovered.decided_at, null);
  assert.equal(recovered.decision_note, "");
  assert.equal(recovered.execution_started_at, null);
  assert.equal(recovered.attempt_count, 1);
  fx.db.close();
});

test("network templates reject stale revisions instead of overwriting newer edits", async () => {
  const fx = await fixture();
  const createNetworkResponse = await controlPlane.fetch!(authenticatedRequest("/v1/networks", fx.sessions[OWNER], {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: "Primary network" }),
  }), fx.env, { waitUntil() {}, passThroughOnException() {} });
  assert.equal(createNetworkResponse.status, 201);
  const networkId = (await createNetworkResponse.json<{ network: { id: string } }>()).network.id;
  const createTemplateResponse = await controlPlane.fetch!(authenticatedRequest(`/v1/networks/${networkId}/templates`, fx.sessions[OWNER], {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name: "Safe defaults", patch: { changes: [{ path: "modules.chat-sync.enabled", value: true }] } }),
  }), fx.env, { waitUntil() {}, passThroughOnException() {} });
  assert.equal(createTemplateResponse.status, 201);
  const templateId = (await createTemplateResponse.json<{ template: { id: string } }>()).template.id;
  const update = (revision: number, name: string) => controlPlane.fetch!(authenticatedRequest(
    `/v1/networks/${networkId}/templates/${templateId}`,
    fx.sessions[OWNER],
    { method: "PUT", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, revision, patch: { changes: [{ path: "modules.chat-sync.enabled", value: false }] } }) },
  ), fx.env, { waitUntil() {}, passThroughOnException() {} });
  assert.equal((await update(1, "Safe defaults v2")).status, 200);
  assert.equal((await update(1, "Stale overwrite")).status, 409);
  const row = fx.db.prepare("SELECT name,revision FROM configuration_templates WHERE id=?").get(templateId)!;
  assert.equal(row.name, "Safe defaults v2");
  assert.equal(row.revision, 2);
  fx.db.close();
});

test("media upload transports bounded base64 to the agent without persisting image bytes in D1", async () => {
  const fx = await fixture();
  fx.room.handler = (command) => {
    assert.equal(command.operation, "media.install");
    const payload = command.payload as Record<string, unknown>;
    assert.equal(payload.mimeType, "image/png");
    assert.equal(payload.extension, "png");
    assert.equal(typeof payload.dataBase64, "string");
    return { ok: true, payload: { reference: "coredsc-media://aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa.png" } };
  };
  const png = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0]);
  const response = await controlPlane.fetch!(authenticatedRequest(`/v1/uploads?instance=${INSTANCE}`, fx.sessions[OWNER], {
    method: "POST",
    headers: { "Content-Type": "image/png", "Idempotency-Key": "media-test" },
    body: png,
  }), fx.env, { waitUntil() {}, passThroughOnException() {} });
  assert.equal(response.status, 201);
  const body = await response.json<{ url: string }>();
  assert.match(body.url, /^coredsc-media:\/\/[0-9a-f]{64}\.png$/u);
  const audit = fx.db.prepare("SELECT request_json,result_json FROM audit_events WHERE idempotency_key=?").get("media-test")!;
  assert.doesNotMatch(String(audit.request_json), /dataBase64|iVBOR/u);
  assert.match(String(audit.request_json), /encodedBytes/u);
  fx.db.close();
});
