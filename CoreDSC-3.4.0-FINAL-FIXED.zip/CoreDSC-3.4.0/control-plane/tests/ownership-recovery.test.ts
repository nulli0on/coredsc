import assert from "node:assert/strict";
import { readdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import test from "node:test";
import { fileURLToPath } from "node:url";
import { DatabaseSync, type StatementSync } from "node:sqlite";

import { InstanceRoom } from "../src/instance-room.ts";
import { confirmationCode } from "../src/security.ts";
import type { Env } from "../src/types.ts";

const here = dirname(fileURLToPath(import.meta.url));
const INSTANCE = "11111111-1111-4111-8111-111111111111";
const OLD_OWNER = "100000000000000";
const NEW_OWNER = "200000000000000";
const SECRET = "test-cookie-secret-with-at-least-32-bytes";

class SqliteStatement {
  private readonly statement: StatementSync;
  private values: unknown[] = [];
  constructor(statement: StatementSync) { this.statement = statement; }
  bind(...values: unknown[]): SqliteStatement { this.values = values; return this; }
  async first<T>(): Promise<T | null> { return (this.statement.get(...this.values) as T | undefined) ?? null; }
  async run<T>(): Promise<{ results: T[]; success: boolean; meta: { changes: number } }> {
    const result = this.statement.run(...this.values);
    return { results: [], success: true, meta: { changes: Number(result.changes) } };
  }
  async all<T>(): Promise<{ results: T[]; success: boolean; meta: { changes: number } }> {
    return { results: this.statement.all(...this.values) as T[], success: true, meta: { changes: 0 } };
  }
  async raw<T>(): Promise<T[]> { return this.statement.all(...this.values).map((row) => Object.values(row)) as T[]; }
}

class SqliteD1 {
  private readonly db: DatabaseSync;
  constructor(db: DatabaseSync) { this.db = db; }
  prepare(query: string): SqliteStatement { return new SqliteStatement(this.db.prepare(query)); }
  async batch<T>(statements: SqliteStatement[]): Promise<Array<{ results: T[]; success: boolean; meta: { changes: number } }>> {
    const results = [];
    this.db.exec("BEGIN");
    try {
      for (const statement of statements) results.push(await statement.run<T>());
      this.db.exec("COMMIT");
      return results;
    } catch (error) {
      this.db.exec("ROLLBACK");
      throw error;
    }
  }
  async exec(query: string): Promise<{ count: number; duration: number }> {
    this.db.exec(query);
    return { count: 0, duration: 0 };
  }
}

class TestState {
  setWebSocketAutoResponse(): void {}
  acceptWebSocket(): void {}
  getWebSockets(): WebSocket[] { return []; }
}

interface PairingAccess {
  instanceId: string;
  createPairing(payload: unknown): Promise<Record<string, unknown>>;
  confirmPairing(payload: unknown): Promise<Record<string, unknown>>;
}

function database(): DatabaseSync {
  const db = new DatabaseSync(":memory:");
  const migrationDirectory = join(here, "..", "migrations");
  for (const name of readdirSync(migrationDirectory).filter((value) => /^\d+_.+\.sql$/u.test(value)).sort()) {
    db.exec(readFileSync(join(migrationDirectory, name), "utf8"));
  }
  const now = Date.now();
  db.prepare("INSERT INTO users VALUES (?,?,?,?,?,?)").run(OLD_OWNER, "old-owner", "Old Owner", null, now, now);
  db.prepare("INSERT INTO users VALUES (?,?,?,?,?,?)").run(NEW_OWNER, "new-owner", "New Owner", null, now, now);
  db.prepare(`INSERT INTO instances(id,public_key,display_name,plugin_version,minecraft_version,scheduler_runtime,status,
    approval_mode,last_seen_at,created_at) VALUES (?,?,?,?,?,?,?,1,?,?)`)
    .run(INSTANCE, "key", "Recovery Server", "3.4.0", "1.21.11", "FOLIA", "ONLINE", now, now);
  db.prepare(`INSERT INTO grants(instance_id,discord_user_id,role,granted_by,created_at,revoked_at)
    VALUES (?,?,?,?,?,NULL)`).run(INSTANCE, OLD_OWNER, "OWNER", OLD_OWNER, now);
  return db;
}

test("local-console ownership recovery atomically revokes the prior owner and audits the transfer", async () => {
  Object.assign(globalThis, {
    WebSocketRequestResponsePair: class WebSocketRequestResponsePair {
      constructor(_request: string, _response: string) {}
    },
  });
  const db = database();
  const env = {
    COREDSC_DB: new SqliteD1(db),
    INSTANCE_ROOMS: {},
    APP_ORIGIN: "https://dashboard.example.test",
    PUBLIC_APP_URL: "https://dashboard.example.test",
    DISCORD_CLIENT_ID: "client",
    DISCORD_CLIENT_SECRET: "secret",
    DISCORD_REDIRECT_URI: "https://dashboard.example.test/api/v1/auth/discord/callback",
    COOKIE_SECRET: SECRET,
    SESSION_TTL_SECONDS: "3600",
  } as unknown as Env;
  const room = new InstanceRoom(new TestState() as unknown as DurableObjectState, env) as unknown as PairingAccess;
  room.instanceId = INSTANCE;

  const created = await room.createPairing({ ownershipRecovery: true, minecraftName: "Local console" });
  assert.equal(created.ownershipRecovery, true);
  const row = db.prepare("SELECT id,ownership_recovery,status FROM pairing_links WHERE instance_id=?").get(INSTANCE)!;
  assert.equal(row.ownership_recovery, 1);
  assert.equal(row.status, "CREATED");

  db.prepare("UPDATE pairing_links SET claimed_discord_user_id=?,status='AWAITING_CONFIRM' WHERE id=?")
    .run(NEW_OWNER, row.id);
  const code = await confirmationCode(SECRET, String(row.id));
  const confirmed = await room.confirmPairing({ code });
  assert.equal(confirmed.confirmed, true);
  assert.equal(confirmed.ownershipRecovery, true);
  assert.equal(confirmed.discordUserId, NEW_OWNER);

  const oldGrant = db.prepare("SELECT revoked_at FROM grants WHERE instance_id=? AND discord_user_id=?")
    .get(INSTANCE, OLD_OWNER)!;
  assert.equal(typeof oldGrant.revoked_at, "number");
  const newGrant = db.prepare("SELECT role,revoked_at FROM grants WHERE instance_id=? AND discord_user_id=?")
    .get(INSTANCE, NEW_OWNER)!;
  assert.equal(newGrant.role, "OWNER");
  assert.equal(newGrant.revoked_at, null);
  const audit = db.prepare("SELECT operation,outcome,request_json,result_json FROM audit_events WHERE instance_id=?")
    .get(INSTANCE)!;
  assert.equal(audit.operation, "ownership.recover");
  assert.equal(audit.outcome, "SUCCEEDED");
  assert.match(String(audit.request_json), new RegExp(OLD_OWNER, "u"));
  assert.match(String(audit.result_json), new RegExp(NEW_OWNER, "u"));
  db.close();
});
