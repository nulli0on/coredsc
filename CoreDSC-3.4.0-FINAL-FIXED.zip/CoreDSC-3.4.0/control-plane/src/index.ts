import { allCapabilities, capabilityForOperation, operationNeedsApproval, requireCapability } from "./capabilities.ts";
import { enforceRateLimit, json, readBytes, readJson, requireCsrf, requireGrant, requireSession, responseJson, safeText, uuid } from "./database.ts";
import { assertTrustedOrigin, clearCookie, confirmationCode, cookie, csrfTokenFor, HttpError, randomToken, secureCookie, sha256, verifyAgentSignature } from "./security.ts";
import type { AgentCommand, AgentResult, Env, SessionUser, StaffRole } from "./types.ts";
import { MAX_MEDIA_BYTES, validateMediaBytes } from "./media.ts";
import {
  dispatchLeaseExpired,
  networkRolloutKey,
  operationFingerprintInput,
  retryableResult,
  utf8ByteLength,
} from "./reliability.ts";
export { InstanceRoom } from "./instance-room.ts";

interface InstanceRow {
  id: string;
  display_name: string;
  plugin_version: string;
  minecraft_version: string;
  scheduler_runtime: string;
  status: string;
  last_seen_at: number;
  clean_shutdown_at: number | null;
  approval_mode: number;
  role: StaffRole;
}

interface OperationRequest extends Record<string, unknown> {
  operation: string;
  payload?: Record<string, unknown>;
  reason?: string;
  idempotencyKey?: string;
}

interface PairingRow {
  id: string;
  instance_id: string;
  display_name: string;
  status: string;
  expires_at: number;
  requested_discord_user_id: string | null;
  claimed_discord_user_id: string | null;
  owner_id: string | null;
  ownership_recovery: number;
}

const SESSION_COOKIE = "__Host-coredsc_session";
const OAUTH_COOKIE = "__Host-coredsc_oauth";
const ALLOWED_ROLES = new Set<StaffRole>([
  "SERVER_ADMIN", "MODERATOR", "CONSOLE_VIEWER", "CONSOLE_OPERATOR", "SUPPORT", "VIEWER",
]);

export default {
  async fetch(request: Request, env: Env, context: ExecutionContext): Promise<Response> {
    try {
      if (request.method === "OPTIONS") return corsPreflight(request, env);
      const url = new URL(request.url);
      let response: Response;

      if (url.pathname === "/health" && request.method === "GET") {
        response = responseJson({ ok: true, service: "CoreDSC Control Plane", protocol: 1, version: "3.4.0" });
      } else if (url.pathname === "/v1/auth/discord" && request.method === "GET") {
        response = await beginDiscordOAuth(request, url, env);
      } else if (url.pathname === "/v1/auth/discord/callback" && request.method === "GET") {
        response = await finishDiscordOAuth(request, url, env);
      } else if (url.pathname === "/v1/auth/logout" && request.method === "POST") {
        response = await logout(request, env);
      } else if (url.pathname === "/v1/me" && request.method === "GET") {
        response = await me(request, env);
      } else if (url.pathname === "/v1/agent/connect" && request.method === "GET") {
        response = await connectAgent(request, env);
      } else if (url.pathname === "/v1/pairings/claim" && request.method === "POST") {
        response = await claimPairing(request, env);
      } else if (url.pathname === "/v1/pairings/status" && request.method === "GET") {
        response = await pairingStatus(request, url, env);
      } else if (url.pathname === "/v1/servers" && request.method === "GET") {
        response = await listServers(request, env);
      } else if (url.pathname === "/v1/networks" && request.method === "GET") {
        response = await listNetworks(request, env);
      } else if (url.pathname === "/v1/networks" && request.method === "POST") {
        response = await createNetwork(request, env);
      } else if (url.pathname === "/v1/uploads" && request.method === "POST") {
        response = await uploadMedia(request, env);
      } else {
        response = await routeScoped(request, url, env, context);
      }
      return withCors(response, request, env);
    } catch (error) {
      const status = error instanceof HttpError ? error.status : 500;
      if (!(error instanceof HttpError)) console.error("CoreDSC control-plane failure", error);
      const message = error instanceof HttpError ? error.message : "The control plane could not complete this request";
      return withCors(responseJson({ error: message }, status), request, env);
    }
  },
  scheduled(_controller: ScheduledController, env: Env, context: ExecutionContext): void {
    context.waitUntil(runScheduledMaintenance(env));
  },
} satisfies ExportedHandler<Env>;

async function routeScoped(request: Request, url: URL, env: Env, context: ExecutionContext): Promise<Response> {
  const serverMatch = url.pathname.match(/^\/v1\/servers\/([0-9a-f-]{36})(?:\/(.+))?$/u);
  if (serverMatch) {
    const instanceId = uuid(serverMatch[1], "instance ID");
    const action = serverMatch[2] ?? "overview";
    if (action === "overview" && request.method === "GET") return serverOverview(request, env, instanceId);
    if (action === "live" && request.method === "GET") return browserLive(request, env, instanceId);
    if (action === "operations" && request.method === "POST") return submitOperation(request, env, instanceId);
    if (action === "audit" && request.method === "GET") return auditEvents(request, url, env, instanceId);
    if (action === "approvals" && request.method === "GET") return listApprovals(request, env, instanceId);
    if (action === "staff" && request.method === "GET") return listStaff(request, env, instanceId);
    if (action === "staff" && request.method === "POST") return grantStaff(request, env, instanceId);
    const staffMember = action.match(/^staff\/(\d{15,22})$/u);
    if (staffMember && request.method === "DELETE") {
      return revokeStaff(request, env, instanceId, staffMember[1]);
    }
  }

  const approvalMatch = url.pathname.match(/^\/v1\/approvals\/([0-9a-f-]{36})\/decision$/u);
  if (approvalMatch && request.method === "POST") {
    return decideApproval(request, env, uuid(approvalMatch[1], "approval ID"));
  }

  const networkMemberMatch = url.pathname.match(/^\/v1\/networks\/([0-9a-f-]{36})\/members$/u);
  if (networkMemberMatch && request.method === "POST") {
    return addNetworkMember(request, env, uuid(networkMemberMatch[1], "network ID"));
  }
  const networkMatch = url.pathname.match(/^\/v1\/networks\/([0-9a-f-]{36})(?:\/(.+))?$/u);
  if (networkMatch) {
    const networkId = uuid(networkMatch[1], "network ID");
    const action = networkMatch[2] ?? "details";
    if (action === "details" && request.method === "GET") return networkDetails(request, env, networkId);
    const member = action.match(/^members\/([0-9a-f-]{36})$/u);
    if (member && request.method === "DELETE") {
      return removeNetworkMember(request, env, networkId, uuid(member[1], "instance ID"));
    }
    if (action === "templates" && request.method === "POST") return createNetworkTemplate(request, env, networkId);
    const template = action.match(/^templates\/([0-9a-f-]{36})$/u);
    if (template && request.method === "PUT") {
      return updateNetworkTemplate(request, env, networkId, uuid(template[1], "template ID"));
    }
    if (template && request.method === "DELETE") {
      return deleteNetworkTemplate(request, env, networkId, uuid(template[1], "template ID"));
    }
    const applyTemplate = action.match(/^templates\/([0-9a-f-]{36})\/apply$/u);
    if (applyTemplate && request.method === "POST") {
      return applyNetworkTemplate(request, env, networkId, uuid(applyTemplate[1], "template ID"));
    }
  }
  void context;
  throw new HttpError(404, "API route not found");
}

async function beginDiscordOAuth(request: Request, url: URL, env: Env): Promise<Response> {
  await enforceRateLimit(request, env, "oauth-begin", "anonymous", 20, 10 * 60_000);
  const state = randomToken(32);
  const returnPath = safeReturnPath(url.searchParams.get("return") ?? "/dashboard");
  const now = Date.now();
  await env.COREDSC_DB.batch([
    env.COREDSC_DB.prepare("DELETE FROM oauth_states WHERE expires_at<?").bind(now),
    env.COREDSC_DB.prepare(
      "INSERT INTO oauth_states(state_hash,return_path,created_at,expires_at) VALUES (?,?,?,?)",
    ).bind(await sha256(state), returnPath, now, now + 10 * 60_000),
  ]);
  const authorize = new URL("https://discord.com/oauth2/authorize");
  authorize.searchParams.set("client_id", env.DISCORD_CLIENT_ID);
  authorize.searchParams.set("redirect_uri", env.DISCORD_REDIRECT_URI);
  authorize.searchParams.set("response_type", "code");
  authorize.searchParams.set("scope", "identify");
  authorize.searchParams.set("state", state);
  const headers = new Headers({ Location: authorize.toString() });
  headers.append("Set-Cookie", secureCookie(OAUTH_COOKIE, state, 10 * 60));
  return new Response(null, { status: 302, headers });
}

async function finishDiscordOAuth(request: Request, url: URL, env: Env): Promise<Response> {
  await enforceRateLimit(request, env, "oauth-callback", "anonymous", 20, 10 * 60_000);
  const state = safeText(url.searchParams.get("state"), 128, "OAuth state", true);
  const code = safeText(url.searchParams.get("code"), 512, "OAuth code", true);
  const browserState = cookie(request, OAUTH_COOKIE);
  if (!browserState || browserState !== state) {
    throw new HttpError(400, "Discord login was not started in this browser or the OAuth state expired");
  }
  const stateHash = await sha256(state);
  const stored = await env.COREDSC_DB.prepare(
    "SELECT return_path FROM oauth_states WHERE state_hash=? AND expires_at>?",
  ).bind(stateHash, Date.now()).first<{ return_path: string }>();
  if (!stored) throw new HttpError(400, "Discord login expired or was already used");
  await env.COREDSC_DB.prepare("DELETE FROM oauth_states WHERE state_hash=?").bind(stateHash).run();

  const tokenResponse = await fetch("https://discord.com/api/v10/oauth2/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      client_id: env.DISCORD_CLIENT_ID,
      client_secret: env.DISCORD_CLIENT_SECRET,
      grant_type: "authorization_code",
      code,
      redirect_uri: env.DISCORD_REDIRECT_URI,
    }),
  });
  if (!tokenResponse.ok) throw new HttpError(502, "Discord rejected the OAuth exchange");
  const token = await tokenResponse.json<{ access_token?: string }>();
  if (!token.access_token) throw new HttpError(502, "Discord OAuth response did not contain an access token");
  const identityResponse = await fetch("https://discord.com/api/v10/users/@me", {
    headers: { Authorization: `Bearer ${token.access_token}` },
  });
  if (!identityResponse.ok) throw new HttpError(502, "Discord identity lookup failed");
  const identity = await identityResponse.json<{
    id?: string; username?: string; global_name?: string | null; avatar?: string | null;
  }>();
  if (!identity.id || !/^\d{15,22}$/u.test(identity.id)) throw new HttpError(502, "Discord returned an invalid identity");

  const now = Date.now();
  const sessionToken = randomToken(32);
  const sessionId = crypto.randomUUID();
  const csrfToken = await csrfTokenFor(env.COOKIE_SECRET, sessionId);
  const ttl = boundedInteger(env.SESSION_TTL_SECONDS, 3600, 2_592_000, 604_800);
  await env.COREDSC_DB.batch([
    env.COREDSC_DB.prepare(
      `INSERT INTO users(discord_user_id,username,display_name,avatar,created_at,updated_at)
       VALUES (?,?,?,?,?,?) ON CONFLICT(discord_user_id) DO UPDATE SET
       username=excluded.username,display_name=excluded.display_name,avatar=excluded.avatar,updated_at=excluded.updated_at`,
    ).bind(identity.id, identity.username ?? "Discord user", identity.global_name ?? identity.username ?? "Discord user",
      identity.avatar ?? null, now, now),
    env.COREDSC_DB.prepare(
      "INSERT INTO sessions(id,token_hash,csrf_hash,discord_user_id,created_at,expires_at,last_seen_at) VALUES (?,?,?,?,?,?,?)",
    ).bind(sessionId, await sha256(sessionToken), await sha256(csrfToken), identity.id, now, now + ttl * 1000, now),
  ]);
  const destination = new URL(safeReturnPath(stored.return_path), env.PUBLIC_APP_URL);
  const headers = new Headers({ Location: destination.toString() });
  headers.append("Set-Cookie", secureCookie(SESSION_COOKIE, sessionToken, ttl));
  headers.append("Set-Cookie", clearCookie(OAUTH_COOKIE));
  headers.append("Set-Cookie", "coredsc_csrf=; Path=/; Max-Age=0; Secure; SameSite=Lax");
  return new Response(null, { status: 302, headers });
}

async function logout(request: Request, env: Env): Promise<Response> {
  const user = await requireSession(request, env);
  await requireCsrf(request, env, user);
  await env.COREDSC_DB.prepare("DELETE FROM sessions WHERE id=?").bind(user.sessionId).run();
  const headers = new Headers();
  headers.append("Set-Cookie", clearCookie(SESSION_COOKIE));
  headers.append("Set-Cookie", "coredsc_csrf=; Path=/; Max-Age=0; Secure; SameSite=Lax");
  return responseJson({ signedOut: true }, 200, headers);
}

async function me(request: Request, env: Env): Promise<Response> {
  const user = await requireSession(request, env);
  return responseJson({
    user: { id: user.id, username: user.username, displayName: user.displayName, avatar: user.avatar },
    csrfToken: await csrfTokenFor(env.COOKIE_SECRET, user.sessionId),
  });
}

async function connectAgent(request: Request, env: Env): Promise<Response> {
  await enforceRateLimit(request, env, "agent-connect", request.headers.get("X-CoreDSC-Instance") ?? "missing", 30, 60_000);
  if (request.headers.get("Upgrade")?.toLowerCase() !== "websocket") {
    throw new HttpError(426, "WebSocket upgrade required");
  }
  const instanceId = uuid(request.headers.get("X-CoreDSC-Instance"), "X-CoreDSC-Instance");
  const timestamp = safeText(request.headers.get("X-CoreDSC-Timestamp"), 20, "timestamp", true);
  const nonce = safeText(request.headers.get("X-CoreDSC-Nonce"), 128, "nonce", true);
  const publicKey = safeText(request.headers.get("X-CoreDSC-Public-Key"), 256, "public key", true);
  const signature = safeText(request.headers.get("X-CoreDSC-Signature"), 256, "signature", true);
  const timestampMillis = Number(timestamp);
  if (!Number.isSafeInteger(timestampMillis) || Math.abs(Date.now() - timestampMillis) > 120_000) {
    throw new HttpError(401, "Agent timestamp is outside the two-minute authentication window");
  }
  if (!/^[A-Za-z0-9_-]{32,128}$/u.test(nonce)) throw new HttpError(401, "Invalid agent nonce");
  if (!await verifyAgentSignature(instanceId, timestamp, nonce, publicKey, signature)) {
    throw new HttpError(401, "Agent signature verification failed");
  }
  const existing = await env.COREDSC_DB.prepare("SELECT public_key FROM instances WHERE id=?")
    .bind(instanceId).first<{ public_key: string }>();
  if (existing && existing.public_key !== publicKey) {
    throw new HttpError(401, "This instance ID is already bound to a different local identity key");
  }
  const now = Date.now();
  if (!existing) {
    await env.COREDSC_DB.prepare(
      `INSERT INTO instances(id,public_key,display_name,plugin_version,minecraft_version,scheduler_runtime,status,
       approval_mode,last_seen_at,created_at) VALUES (?,?,?,?,?,?,'UNPAIRED',1,?,?)`,
    ).bind(
      instanceId,
      publicKey,
      safeText(request.headers.get("X-CoreDSC-Name"), 80, "server name") || "CoreDSC Server",
      safeText(request.headers.get("X-CoreDSC-Version"), 40, "plugin version"),
      safeText(request.headers.get("X-CoreDSC-Minecraft"), 80, "Minecraft version"),
      safeText(request.headers.get("X-CoreDSC-Scheduler"), 20, "scheduler runtime"),
      now,
      now,
    ).run();
  }
  const nonceHash = await sha256(nonce);
  try {
    await env.COREDSC_DB.batch([
      env.COREDSC_DB.prepare("DELETE FROM instance_nonces WHERE expires_at<?").bind(now),
    env.COREDSC_DB.prepare("DELETE FROM rate_limits WHERE expires_at<?").bind(now),
      env.COREDSC_DB.prepare("INSERT INTO instance_nonces(instance_id,nonce_hash,expires_at) VALUES (?,?,?)")
        .bind(instanceId, nonceHash, now + 5 * 60_000),
      env.COREDSC_DB.prepare("UPDATE instances SET last_seen_at=? WHERE id=?").bind(now, instanceId),
    ]);
  } catch {
    throw new HttpError(401, "Agent authentication nonce was already used");
  }
  const room = env.INSTANCE_ROOMS.get(env.INSTANCE_ROOMS.idFromName(instanceId));
  const headers = new Headers(request.headers);
  headers.set("X-CoreDSC-Instance", instanceId);
  return room.fetch(new Request("https://instance.internal/agent", { headers }));
}

async function claimPairing(request: Request, env: Env): Promise<Response> {
  const user = await requireSession(request, env);
  await requireCsrf(request, env, user);
  await enforceRateLimit(request, env, "pairing-claim", user.id, 10, 5 * 60_000);
  const body = await readJson<Record<string, unknown>>(request, 4096);
  const token = safeText(body.token, 128, "pairing token", true);
  const row = await env.COREDSC_DB.prepare(
    `SELECT p.id,p.instance_id,p.status,p.expires_at,p.requested_discord_user_id,p.claimed_discord_user_id,
            p.ownership_recovery,i.display_name,
            (SELECT discord_user_id FROM grants g WHERE g.instance_id=p.instance_id AND g.role='OWNER'
              AND g.revoked_at IS NULL LIMIT 1) AS owner_id
       FROM pairing_links p JOIN instances i ON i.id=p.instance_id WHERE p.link_hash=?`,
  ).bind(await sha256(token)).first<PairingRow>();
  if (!row || row.expires_at <= Date.now() || !["CREATED", "AWAITING_CONFIRM"].includes(row.status)) {
    throw new HttpError(404, "Pairing link is invalid, expired, or already used");
  }
  if (row.requested_discord_user_id && row.requested_discord_user_id !== user.id) {
    throw new HttpError(403, "This link is bound to a different linked Discord account");
  }
  if (row.claimed_discord_user_id && row.claimed_discord_user_id !== user.id) {
    throw new HttpError(409, "Another Discord account already claimed this link");
  }
  if (row.owner_id && row.ownership_recovery !== 1) await requireGrant(env, row.instance_id, user.id);
  await env.COREDSC_DB.prepare(
    "UPDATE pairing_links SET claimed_discord_user_id=?,status='AWAITING_CONFIRM' WHERE id=?",
  ).bind(user.id, row.id).run();
  return responseJson({
    pairing: {
      id: row.id,
      instanceId: row.instance_id,
      serverName: row.display_name,
      expiresAt: row.expires_at,
      confirmationCode: await confirmationCode(env.COOKIE_SECRET, row.id),
      command: `/coredsc editor auth ${await confirmationCode(env.COOKIE_SECRET, row.id)}`,
      ownershipRecovery: row.ownership_recovery === 1,
    },
  });
}

async function pairingStatus(request: Request, url: URL, env: Env): Promise<Response> {
  const user = await requireSession(request, env);
  await enforceRateLimit(request, env, "pairing-status", user.id, 60, 60_000);
  const token = safeText(url.searchParams.get("token"), 128, "pairing token", true);
  const row = await env.COREDSC_DB.prepare(
    `SELECT instance_id,status,expires_at,claimed_discord_user_id,ownership_recovery
       FROM pairing_links WHERE link_hash=?`,
  ).bind(await sha256(token)).first<{
    instance_id: string; status: string; expires_at: number; claimed_discord_user_id: string | null;
    ownership_recovery: number;
  }>();
  if (!row || row.claimed_discord_user_id !== user.id) {
    throw new HttpError(404, "Pairing link was not claimed by this Discord account");
  }
  return responseJson({
    status: row.expires_at <= Date.now() && row.status !== "CONFIRMED" ? "EXPIRED" : row.status,
    instanceId: row.instance_id,
    confirmed: row.status === "CONFIRMED",
    ownershipRecovery: row.ownership_recovery === 1,
  });
}

async function listServers(request: Request, env: Env): Promise<Response> {
  const user = await requireSession(request, env);
  const rows = await env.COREDSC_DB.prepare(
    `SELECT i.id,i.display_name,i.plugin_version,i.minecraft_version,i.scheduler_runtime,i.status,
            i.last_seen_at,i.clean_shutdown_at,i.approval_mode,g.role
       FROM grants g JOIN instances i ON i.id=g.instance_id
      WHERE g.discord_user_id=? AND g.revoked_at IS NULL ORDER BY i.display_name COLLATE NOCASE`,
  ).bind(user.id).all<InstanceRow>();
  const now = Date.now();
  return responseJson({ servers: rows.results.map((row) => ({
    id: row.id,
    name: row.display_name,
    pluginVersion: row.plugin_version,
    minecraftVersion: row.minecraft_version,
    scheduler: row.scheduler_runtime,
    online: now - row.last_seen_at < 90_000 && row.status !== "OFFLINE",
    status: row.status,
    lastSeenAt: row.last_seen_at,
    cleanShutdownAt: row.clean_shutdown_at,
    approvalMode: row.approval_mode === 1,
    role: row.role,
    capabilities: allCapabilities(row.role),
  })) });
}

async function serverOverview(request: Request, env: Env, instanceId: string): Promise<Response> {
  const user = await requireSession(request, env);
  const role = await requireGrant(env, instanceId, user.id);
  requireCapability(role, "server.view");
  const instance = await env.COREDSC_DB.prepare(
    "SELECT id,display_name,plugin_version,minecraft_version,scheduler_runtime,status,last_seen_at,clean_shutdown_at,approval_mode FROM instances WHERE id=?",
  ).bind(instanceId).first<Record<string, unknown>>();
  if (!instance) throw new HttpError(404, "Server not found");
  const incidents = await env.COREDSC_DB.prepare(
    `SELECT id,kind,status,detail,detected_at,resolved_at
       FROM health_incidents WHERE instance_id=? ORDER BY detected_at DESC LIMIT 10`,
  ).bind(instanceId).all();
  const room = env.INSTANCE_ROOMS.get(env.INSTANCE_ROOMS.idFromName(instanceId));
  const presence = await room.fetch(new Request(`https://instance.internal/status?instance=${instanceId}`)).then((r) => r.json());
  return responseJson({ instance, presence, incidents: incidents.results, role, capabilities: allCapabilities(role) });
}

async function browserLive(request: Request, env: Env, instanceId: string): Promise<Response> {
  assertTrustedOrigin(request, env);
  const user = await requireSession(request, env);
  const role = await requireGrant(env, instanceId, user.id);
  requireCapability(role, "server.view");
  if (request.headers.get("Upgrade")?.toLowerCase() !== "websocket") throw new HttpError(426, "WebSocket upgrade required");
  const room = env.INSTANCE_ROOMS.get(env.INSTANCE_ROOMS.idFromName(instanceId));
  return room.fetch(new Request(`https://instance.internal/browser?instance=${instanceId}`, {
    headers: { Upgrade: "websocket", "X-CoreDSC-Instance": instanceId },
  }));
}

async function submitOperation(request: Request, env: Env, instanceId: string): Promise<Response> {
  const user = await requireSession(request, env);
  await requireCsrf(request, env, user);
  await enforceRateLimit(request, env, "operation", `${user.id}:${instanceId}`, 120, 60_000);
  const role = await requireGrant(env, instanceId, user.id);
  const body = await readJson<OperationRequest>(request);
  const operation = safeText(body.operation, 80, "operation", true);
  const capability = capabilityForOperation(operation);
  requireCapability(role, capability);
  const payload = objectPayload(body.payload);
  const reason = safeText(body.reason, 500, "reason", isMutation(operation));
  const idempotencyKey = safeText(body.idempotencyKey, 100, "idempotencyKey") || crypto.randomUUID();
  validatePayload(operation, payload);

  const instance = await env.COREDSC_DB.prepare("SELECT approval_mode FROM instances WHERE id=?")
    .bind(instanceId).first<{ approval_mode: number }>();
  if (!instance) throw new HttpError(404, "Server not found");
  if (instance.approval_mode === 1 && operationNeedsApproval(operation, payload)) {
    const approval = await getOrCreateApproval(env, instanceId, user.id, operation, payload, reason, idempotencyKey);
    const pending = approval.status === "PENDING" || approval.status === "APPROVED";
    return responseJson({ approvalRequired: pending, approvalId: approval.id, expiresAt: approval.expires_at,
      status: approval.status, replay: approval.replay, result: parseStoredJson(approval.result_json) }, pending ? 202 : 200);
  }
  return executeAndAudit(env, instanceId, user, role, operation, payload, reason, idempotencyKey);
}

interface ApprovalIdentity {
  id: string;
  requester_id: string;
  operation: string;
  payload_json: string;
  reason: string;
  status: string;
  expires_at: number;
  result_json: string;
  replay: boolean;
}

async function getOrCreateApproval(
  env: Env,
  instanceId: string,
  requesterId: string,
  operation: string,
  payload: Record<string, unknown>,
  reason: string,
  idempotencyKey: string,
): Promise<ApprovalIdentity> {
  const payloadJson = json(payload);
  const existing = await env.COREDSC_DB.prepare(
    `SELECT id,requester_id,operation,payload_json,reason,status,expires_at,result_json
       FROM approvals WHERE instance_id=? AND idempotency_key=?`,
  ).bind(instanceId, idempotencyKey).first<Omit<ApprovalIdentity, "replay">>();
  if (existing) {
    if (existing.requester_id !== requesterId || existing.operation !== operation
        || existing.payload_json !== payloadJson || existing.reason !== reason) {
      throw new HttpError(409, "This approval idempotency key was already used for a different request");
    }
    if (existing.status === "PENDING" && existing.expires_at <= Date.now()) {
      await env.COREDSC_DB.prepare(
        "UPDATE approvals SET status='EXPIRED' WHERE id=? AND status='PENDING' AND expires_at<=?",
      ).bind(existing.id, Date.now()).run();
      existing.status = "EXPIRED";
    }
    return { ...existing, replay: true };
  }

  const approvalId = crypto.randomUUID();
  const now = Date.now();
  await env.COREDSC_DB.prepare(
    `INSERT OR IGNORE INTO approvals(id,instance_id,requester_id,operation,payload_json,reason,idempotency_key,status,created_at,expires_at)
     VALUES (?,?,?,?,?,?,?,'PENDING',?,?)`,
  ).bind(approvalId, instanceId, requesterId, operation, payloadJson, reason, idempotencyKey, now, now + 30 * 60_000).run();
  const created = await env.COREDSC_DB.prepare(
    `SELECT id,requester_id,operation,payload_json,reason,status,expires_at,result_json
       FROM approvals WHERE instance_id=? AND idempotency_key=?`,
  ).bind(instanceId, idempotencyKey).first<Omit<ApprovalIdentity, "replay">>();
  if (!created) throw new HttpError(500, "Approval request could not be persisted");
  if (created.requester_id !== requesterId || created.operation !== operation
      || created.payload_json !== payloadJson || created.reason !== reason) {
    throw new HttpError(409, "This approval idempotency key was claimed by a different request");
  }
  return { ...created, replay: created.id !== approvalId };
}

async function executeAndAudit(
  env: Env,
  instanceId: string,
  user: SessionUser,
  role: StaffRole,
  operation: string,
  payload: Record<string, unknown>,
  reason: string,
  idempotencyKey: string,
  auditReason = reason,
): Promise<Response> {
  const requestHash = await sha256(operationFingerprintInput(operation, payload, reason));
  const existing = await env.COREDSC_DB.prepare(
    `SELECT id,operation,outcome,result_json,attempted_at,request_hash
       FROM audit_events WHERE instance_id=? AND idempotency_key=?`,
  ).bind(instanceId, idempotencyKey).first<{
    id: string; operation: string; outcome: string; result_json: string; attempted_at: number | null;
    request_hash: string;
  }>();
  if (existing && (existing.operation !== operation
      || (existing.request_hash && existing.request_hash !== requestHash))) {
    throw new HttpError(409, "This idempotency key was already used for a different request");
  }
  const previousResult = existing ? parseStoredJson(existing.result_json) : {};
  if (existing?.outcome === "DISPATCHED" && !dispatchLeaseExpired(existing.attempted_at)) {
    throw new HttpError(409, "An operation with this idempotency key is still in progress");
  }
  if (existing && existing.outcome !== "DISPATCHED"
      && (existing.outcome !== "FAILED" || !retryableResult(previousResult))) {
    return responseJson({ replay: true, outcome: existing.outcome, result: previousResult });
  }

  const auditId = existing?.id ?? crypto.randomUUID();
  const now = Date.now();
  if (existing) {
    const claimed = await env.COREDSC_DB.prepare(
      `UPDATE audit_events SET actor_discord_user_id=?,actor_display_name=?,reason=?,request_json=?,request_hash=?,
              result_json='{}',outcome='DISPATCHED',completed_at=NULL,attempted_at=?
        WHERE id=? AND ((outcome='FAILED') OR (outcome='DISPATCHED' AND (attempted_at IS NULL OR attempted_at<=?)))`,
    ).bind(user.id, user.displayName, auditReason, json(summarizePayload(operation, payload)), requestHash, now,
      auditId, now - 120_000).run();
    if (claimed.meta.changes !== 1) throw new HttpError(409, "This operation retry was claimed by another request");
  } else {
    await env.COREDSC_DB.prepare(
      `INSERT INTO audit_events(id,instance_id,actor_discord_user_id,actor_display_name,operation,reason,
        idempotency_key,request_json,request_hash,outcome,created_at,attempted_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
    ).bind(auditId, instanceId, user.id, user.displayName, operation, auditReason, idempotencyKey,
      json(summarizePayload(operation, payload)), requestHash, "DISPATCHED", now, now).run();
  }

  const room = env.INSTANCE_ROOMS.get(env.INSTANCE_ROOMS.idFromName(instanceId));
  const command: AgentCommand = {
    operation,
    payload,
    actor: { discordUserId: user.id, displayName: user.displayName, role, reason },
    idempotencyKey,
    timeoutMillis: operation.startsWith("config.") || operation === "media.install" ? 30_000 : 15_000,
  };
  let result: AgentResult;
  let responseStatus: number;
  try {
    const agentResponse = await room.fetch(new Request("https://instance.internal/command", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-CoreDSC-Instance": instanceId },
      body: JSON.stringify(command),
    }));
    result = await agentResponse.json<AgentResult>();
    responseStatus = agentResponse.status;
  } catch (error) {
    result = { ok: false, error: { code: "CONTROL_PLANE_DISPATCH",
      message: error instanceof Error ? error.message.slice(0, 500) : "Agent dispatch failed", retryable: true } };
    responseStatus = 503;
  }

  let freshConfigurationSnapshot = false;
  if (operation === "config.snapshot" && !result.ok && result.error?.code === "INSTANCE_OFFLINE") {
    const cached = await env.COREDSC_DB.prepare(
      `SELECT redacted_json,created_at FROM configuration_snapshots
        WHERE instance_id=? ORDER BY created_at DESC LIMIT 1`,
    ).bind(instanceId).first<{ redacted_json: string; created_at: number }>();
    if (cached) {
      const stored = objectPayload(parseStoredJson(cached.redacted_json));
      result = { ok: true, payload: { ...stored, cached: true, cachedAt: cached.created_at } };
      responseStatus = 200;
    }
  } else if (operation === "config.snapshot" && result.ok && result.payload) {
    freshConfigurationSnapshot = true;
  }
  const outcome = result.ok ? "SUCCEEDED" : "FAILED";
  await env.COREDSC_DB.prepare(
    "UPDATE audit_events SET result_json=?,outcome=?,completed_at=? WHERE id=?",
  ).bind(json(result), outcome, Date.now(), auditId).run();
  if (freshConfigurationSnapshot && result.payload) {
    await env.COREDSC_DB.prepare(
      "INSERT INTO configuration_snapshots(id,instance_id,revision,redacted_json,created_by,created_at) VALUES (?,?,?,?,?,?)",
    ).bind(crypto.randomUUID(), instanceId, await sha256(json(result.payload)), json(result.payload), user.id, Date.now()).run();
  }
  return responseJson({ auditId, ...result }, responseStatus);
}

async function auditEvents(request: Request, url: URL, env: Env, instanceId: string): Promise<Response> {
  const user = await requireSession(request, env);
  const role = await requireGrant(env, instanceId, user.id);
  requireCapability(role, "server.view");
  const limit = Math.min(100, Math.max(1, Number(url.searchParams.get("limit") ?? "50")));
  const rows = await env.COREDSC_DB.prepare(
    `SELECT id,actor_discord_user_id,actor_display_name,operation,reason,outcome,created_at,completed_at
       FROM audit_events WHERE instance_id=? ORDER BY created_at DESC LIMIT ?`,
  ).bind(instanceId, limit).all();
  return responseJson({ events: rows.results });
}

async function listApprovals(request: Request, env: Env, instanceId: string): Promise<Response> {
  const user = await requireSession(request, env);
  const role = await requireGrant(env, instanceId, user.id);
  requireCapability(role, "approval.view");
  const rows = await env.COREDSC_DB.prepare(
    `SELECT a.id,a.requester_id,u.display_name AS requester_name,a.operation,a.reason,a.status,a.created_at,
            a.expires_at,a.decided_by,a.decided_at,a.decision_note
       FROM approvals a JOIN users u ON u.discord_user_id=a.requester_id
      WHERE a.instance_id=? ORDER BY a.created_at DESC LIMIT 100`,
  ).bind(instanceId).all();
  return responseJson({ approvals: rows.results });
}

async function decideApproval(request: Request, env: Env, approvalId: string): Promise<Response> {
  const user = await requireSession(request, env);
  await requireCsrf(request, env, user);
  await enforceRateLimit(request, env, "approval-decision", user.id, 60, 60_000);
  const body = await readJson<Record<string, unknown>>(request, 8192);
  const decision = safeText(body.decision, 16, "decision", true).toUpperCase();
  if (decision !== "APPROVE" && decision !== "REJECT") throw new HttpError(400, "decision must be APPROVE or REJECT");
  const note = safeText(body.note, 500, "note", true);
  const row = await env.COREDSC_DB.prepare(
    `SELECT a.instance_id,a.requester_id,a.operation,a.payload_json,a.reason,a.idempotency_key,a.status,a.expires_at,
            a.execution_started_at,u.username,u.display_name,u.avatar
       FROM approvals a JOIN users u ON u.discord_user_id=a.requester_id WHERE a.id=?`,
  ).bind(approvalId).first<{
    instance_id: string; requester_id: string; operation: string; payload_json: string; reason: string;
    idempotency_key: string; status: string; expires_at: number; execution_started_at: number | null;
    username: string; display_name: string; avatar: string | null;
  }>();
  if (!row) throw new HttpError(404, "Approval request not found");
  const role = await requireGrant(env, row.instance_id, user.id);
  requireCapability(role, "approval.decide");
  if (row.requester_id === user.id) throw new HttpError(403, "A second staff member must decide this request");

  if (row.status === "APPROVED" && dispatchLeaseExpired(row.execution_started_at)) {
    const released = await env.COREDSC_DB.prepare(
      `UPDATE approvals SET status='PENDING',decided_by=NULL,decided_at=NULL,decision_note='',execution_started_at=NULL
        WHERE id=? AND status='APPROVED' AND (execution_started_at IS NULL OR execution_started_at<=?)`,
    ).bind(approvalId, Date.now() - 120_000).run();
    if (released.meta.changes === 1) row.status = "PENDING";
  }
  if (row.status !== "PENDING" || row.expires_at <= Date.now()) throw new HttpError(409, "Approval is no longer pending");
  if (decision === "REJECT") {
    const rejected = await env.COREDSC_DB.prepare(
      "UPDATE approvals SET status='REJECTED',decided_by=?,decided_at=?,decision_note=? WHERE id=? AND status='PENDING' AND expires_at>?",
    ).bind(user.id, Date.now(), note, approvalId, Date.now()).run();
    if (rejected.meta.changes !== 1) throw new HttpError(409, "Approval was already decided");
    return responseJson({ approvalId, status: "REJECTED" });
  }

  const requesterRole = await requireGrant(env, row.instance_id, row.requester_id);
  requireCapability(requesterRole, capabilityForOperation(row.operation));
  const room = env.INSTANCE_ROOMS.get(env.INSTANCE_ROOMS.idFromName(row.instance_id));
  const presence = await room.fetch(new Request(
    `https://instance.internal/status?instance=${row.instance_id}`,
  )).then((response) => response.json<{ online?: boolean }>());
  if (presence.online !== true) {
    throw new HttpError(409, "The server agent is offline; this approval remains pending until it reconnects");
  }

  const startedAt = Date.now();
  const approved = await env.COREDSC_DB.prepare(
    `UPDATE approvals SET status='APPROVED',decided_by=?,decided_at=?,decision_note=?,execution_started_at=?,attempt_count=attempt_count+1
      WHERE id=? AND status='PENDING' AND expires_at>?`,
  ).bind(user.id, startedAt, note, startedAt, approvalId, startedAt).run();
  if (approved.meta.changes !== 1) throw new HttpError(409, "Approval was already decided");
  const requester: SessionUser = {
    id: row.requester_id, username: row.username, displayName: row.display_name, avatar: row.avatar,
    sessionId: "approval", csrfHash: "",
  };

  let executed: Response;
  try {
    executed = await executeAndAudit(env, row.instance_id, requester, requesterRole, row.operation,
      objectPayload(parseStoredJson(row.payload_json)), row.reason, row.idempotency_key,
      `${row.reason} [approved by ${user.displayName}: ${note}]`);
  } catch (error) {
    const retryable = error instanceof HttpError && (error.status === 409 || error.status >= 500);
    await env.COREDSC_DB.prepare(
      `UPDATE approvals SET status=?,result_json=?,execution_started_at=NULL,
         decided_by=CASE WHEN ? THEN NULL ELSE decided_by END,
         decided_at=CASE WHEN ? THEN NULL ELSE decided_at END,
         decision_note=CASE WHEN ? THEN '' ELSE decision_note END
       WHERE id=? AND status='APPROVED'`,
    ).bind(retryable ? "PENDING" : "FAILED", json({ error: error instanceof Error ? error.message : "Execution failed", retryable }),
      retryable ? 1 : 0, retryable ? 1 : 0, retryable ? 1 : 0, approvalId).run();
    throw error;
  }

  const resultText = await executed.clone().text();
  let retryableFailure = false;
  if (!executed.ok) {
    try {
      const parsed = JSON.parse(resultText) as { error?: { retryable?: boolean } };
      retryableFailure = parsed.error?.retryable === true;
    } catch { retryableFailure = false; }
  }
  await env.COREDSC_DB.prepare(
    `UPDATE approvals SET status=?,result_json=?,execution_started_at=NULL,
       decided_by=CASE WHEN ? THEN NULL ELSE decided_by END,
       decided_at=CASE WHEN ? THEN NULL ELSE decided_at END,
       decision_note=CASE WHEN ? THEN '' ELSE decision_note END
      WHERE id=?`,
  ).bind(executed.ok ? "EXECUTED" : retryableFailure ? "PENDING" : "FAILED",
    resultText.slice(0, 64_000), retryableFailure ? 1 : 0, retryableFailure ? 1 : 0,
    retryableFailure ? 1 : 0, approvalId).run();
  return executed;
}

async function listStaff(request: Request, env: Env, instanceId: string): Promise<Response> {
  const user = await requireSession(request, env);
  const role = await requireGrant(env, instanceId, user.id);
  requireCapability(role, "staff.view");
  const rows = await env.COREDSC_DB.prepare(
    `SELECT g.discord_user_id,u.username,u.display_name,u.avatar,g.role,g.granted_by,g.created_at
       FROM grants g JOIN users u ON u.discord_user_id=g.discord_user_id
      WHERE g.instance_id=? AND g.revoked_at IS NULL ORDER BY CASE g.role WHEN 'OWNER' THEN 0 ELSE 1 END,u.display_name`,
  ).bind(instanceId).all();
  return responseJson({ staff: rows.results });
}

async function grantStaff(request: Request, env: Env, instanceId: string): Promise<Response> {
  const user = await requireSession(request, env);
  await requireCsrf(request, env, user);
  await enforceRateLimit(request, env, "staff-grant", `${user.id}:${instanceId}`, 30, 60_000);
  const actorRole = await requireGrant(env, instanceId, user.id);
  if (actorRole !== "OWNER") throw new HttpError(403, "Only the server owner can change staff access");
  const body = await readJson<Record<string, unknown>>(request, 8192);
  const discordUserId = safeText(body.discordUserId, 22, "discordUserId", true);
  if (!/^\d{15,22}$/u.test(discordUserId)) throw new HttpError(400, "discordUserId must be a Discord snowflake");
  const role = safeText(body.role, 32, "role", true).toUpperCase() as StaffRole;
  if (!ALLOWED_ROLES.has(role)) throw new HttpError(400, "Unsupported staff role; ownership changes require the ownership reset flow");
  const target = await env.COREDSC_DB.prepare("SELECT 1 AS found FROM users WHERE discord_user_id=?")
    .bind(discordUserId).first();
  if (!target) throw new HttpError(404, "That Discord user must sign in to CoreDSC once before being granted access");
  await env.COREDSC_DB.prepare(
    `INSERT INTO grants(instance_id,discord_user_id,role,granted_by,created_at,revoked_at)
     VALUES (?,?,?,?,?,NULL) ON CONFLICT(instance_id,discord_user_id) DO UPDATE SET
     role=excluded.role,granted_by=excluded.granted_by,created_at=excluded.created_at,revoked_at=NULL`,
  ).bind(instanceId, discordUserId, role, user.id, Date.now()).run();
  await recordCloudAudit(env, instanceId, user, "staff.grant", "Grant dashboard access",
    { discordUserId, role }, { granted: true });
  return responseJson({ granted: true, discordUserId, role });
}

async function revokeStaff(
  request: Request,
  env: Env,
  instanceId: string,
  discordUserId: string,
): Promise<Response> {
  const user = await requireSession(request, env);
  await requireCsrf(request, env, user);
  await enforceRateLimit(request, env, "staff-revoke", `${user.id}:${instanceId}`, 30, 60_000);
  const actorRole = await requireGrant(env, instanceId, user.id);
  if (actorRole !== "OWNER") throw new HttpError(403, "Only the server owner can revoke staff access");
  if (discordUserId === user.id) throw new HttpError(400, "Ownership cannot be revoked through the staff screen");
  const target = await env.COREDSC_DB.prepare(
    "SELECT role FROM grants WHERE instance_id=? AND discord_user_id=? AND revoked_at IS NULL",
  ).bind(instanceId, discordUserId).first<{ role: StaffRole }>();
  if (!target) throw new HttpError(404, "Active staff grant not found");
  if (target.role === "OWNER") throw new HttpError(403, "Ownership requires the dedicated reset flow");
  const changed = await env.COREDSC_DB.prepare(
    "UPDATE grants SET revoked_at=? WHERE instance_id=? AND discord_user_id=? AND revoked_at IS NULL",
  ).bind(Date.now(), instanceId, discordUserId).run();
  if (changed.meta.changes !== 1) throw new HttpError(409, "Staff grant was already changed");
  await recordCloudAudit(env, instanceId, user, "staff.revoke", "Revoke dashboard access",
    { discordUserId, previousRole: target.role }, { revoked: true });
  return responseJson({ revoked: true, discordUserId });
}

async function listNetworks(request: Request, env: Env): Promise<Response> {
  const user = await requireSession(request, env);
  const rows = await env.COREDSC_DB.prepare(
    `SELECT n.id,n.name,n.created_at,COUNT(m.instance_id) AS server_count
       FROM network_groups n LEFT JOIN network_members m ON m.network_id=n.id
      WHERE n.owner_discord_user_id=? GROUP BY n.id ORDER BY n.name COLLATE NOCASE`,
  ).bind(user.id).all();
  return responseJson({ networks: rows.results });
}

async function createNetwork(request: Request, env: Env): Promise<Response> {
  const user = await requireSession(request, env);
  await requireCsrf(request, env, user);
  await enforceRateLimit(request, env, "network-create", user.id, 10, 60 * 60_000);
  const body = await readJson<Record<string, unknown>>(request, 8192);
  const name = safeText(body.name, 80, "name", true);
  const id = crypto.randomUUID();
  await env.COREDSC_DB.prepare(
    "INSERT INTO network_groups(id,name,owner_discord_user_id,created_at) VALUES (?,?,?,?)",
  ).bind(id, name, user.id, Date.now()).run();
  return responseJson({ network: { id, name } }, 201);
}

async function addNetworkMember(request: Request, env: Env, networkId: string): Promise<Response> {
  const user = await requireSession(request, env);
  await requireCsrf(request, env, user);
  await enforceRateLimit(request, env, "network-member-add", `${user.id}:${networkId}`, 60, 60_000);
  await requireNetworkOwner(env, networkId, user.id);
  const body = await readJson<Record<string, unknown>>(request, 8192);
  const instanceId = uuid(body.instanceId, "instanceId");
  const role = await requireGrant(env, instanceId, user.id);
  if (role !== "OWNER") throw new HttpError(403, "You must own a server before adding it to a network");
  const inserted = await env.COREDSC_DB.prepare(
    "INSERT OR IGNORE INTO network_members(network_id,instance_id,created_at) VALUES (?,?,?)",
  ).bind(networkId, instanceId, Date.now()).run();
  return responseJson({ added: inserted.meta.changes === 1, networkId, instanceId });
}

async function networkDetails(request: Request, env: Env, networkId: string): Promise<Response> {
  const user = await requireSession(request, env);
  const network = await requireNetworkOwner(env, networkId, user.id);
  const members = await env.COREDSC_DB.prepare(
    `SELECT i.id,i.display_name,i.plugin_version,i.minecraft_version,i.scheduler_runtime,
            i.status,i.last_seen_at,m.created_at
       FROM network_members m JOIN instances i ON i.id=m.instance_id
      WHERE m.network_id=? ORDER BY i.display_name COLLATE NOCASE`,
  ).bind(networkId).all();
  const templates = await env.COREDSC_DB.prepare(
    `SELECT id,name,patch_json,revision,created_by,created_at,updated_at
       FROM configuration_templates WHERE network_id=? ORDER BY name COLLATE NOCASE`,
  ).bind(networkId).all<{
    id: string; name: string; patch_json: string; revision: number; created_by: string;
    created_at: number; updated_at: number;
  }>();
  return responseJson({
    network: { id: networkId, name: network.name, createdAt: network.created_at },
    members: members.results,
    templates: templates.results.map((template) => ({
      id: template.id,
      name: template.name,
      patch: parseStoredJson(template.patch_json),
      revision: template.revision,
      createdBy: template.created_by,
      createdAt: template.created_at,
      updatedAt: template.updated_at,
    })),
  });
}

async function removeNetworkMember(
  request: Request,
  env: Env,
  networkId: string,
  instanceId: string,
): Promise<Response> {
  const user = await requireSession(request, env);
  await requireCsrf(request, env, user);
  await enforceRateLimit(request, env, "network-member-remove", `${user.id}:${networkId}`, 60, 60_000);
  await requireNetworkOwner(env, networkId, user.id);
  const removed = await env.COREDSC_DB.prepare(
    "DELETE FROM network_members WHERE network_id=? AND instance_id=?",
  ).bind(networkId, instanceId).run();
  if (removed.meta.changes !== 1) throw new HttpError(404, "Server is not a member of this network");
  return responseJson({ removed: true, networkId, instanceId });
}

async function createNetworkTemplate(request: Request, env: Env, networkId: string): Promise<Response> {
  const user = await requireSession(request, env);
  await requireCsrf(request, env, user);
  await enforceRateLimit(request, env, "network-template-create", `${user.id}:${networkId}`, 30, 60_000);
  await requireNetworkOwner(env, networkId, user.id);
  const body = await readJson<Record<string, unknown>>(request, 131_072);
  const name = safeText(body.name, 80, "name", true);
  const patch = objectPayload(body.patch);
  validatePayload("network.template.validate", patch);
  const id = crypto.randomUUID();
  const now = Date.now();
  await env.COREDSC_DB.prepare(
    `INSERT INTO configuration_templates(id,network_id,name,patch_json,revision,created_by,created_at,updated_at)
     VALUES (?,?,?,?,1,?,?,?)`,
  ).bind(id, networkId, name, json(patch), user.id, now, now).run();
  return responseJson({ template: { id, name, patch, revision: 1, createdAt: now, updatedAt: now } }, 201);
}

async function updateNetworkTemplate(
  request: Request,
  env: Env,
  networkId: string,
  templateId: string,
): Promise<Response> {
  const user = await requireSession(request, env);
  await requireCsrf(request, env, user);
  await enforceRateLimit(request, env, "network-template-update", `${user.id}:${networkId}`, 60, 60_000);
  await requireNetworkOwner(env, networkId, user.id);
  const body = await readJson<Record<string, unknown>>(request, 131_072);
  const name = safeText(body.name, 80, "name", true);
  const patch = objectPayload(body.patch);
  validatePayload("network.template.validate", patch);
  const revision = Number(body.revision);
  if (!Number.isSafeInteger(revision) || revision < 1) throw new HttpError(400, "revision must be a positive integer");
  const updated = await env.COREDSC_DB.prepare(
    `UPDATE configuration_templates SET name=?,patch_json=?,revision=revision+1,updated_at=?
      WHERE id=? AND network_id=? AND revision=?`,
  ).bind(name, json(patch), Date.now(), templateId, networkId, revision).run();
  if (updated.meta.changes !== 1) throw new HttpError(409, "Template changed or no longer exists; refresh before saving");
  return responseJson({ template: { id: templateId, name, patch, revision: revision + 1 } });
}

async function deleteNetworkTemplate(
  request: Request,
  env: Env,
  networkId: string,
  templateId: string,
): Promise<Response> {
  const user = await requireSession(request, env);
  await requireCsrf(request, env, user);
  await enforceRateLimit(request, env, "network-template-delete", `${user.id}:${networkId}`, 30, 60_000);
  await requireNetworkOwner(env, networkId, user.id);
  const removed = await env.COREDSC_DB.prepare(
    "DELETE FROM configuration_templates WHERE id=? AND network_id=?",
  ).bind(templateId, networkId).run();
  if (removed.meta.changes !== 1) throw new HttpError(404, "Template not found");
  return responseJson({ removed: true, templateId });
}

async function applyNetworkTemplate(
  request: Request,
  env: Env,
  networkId: string,
  templateId: string,
): Promise<Response> {
  const user = await requireSession(request, env);
  await requireCsrf(request, env, user);
  await enforceRateLimit(request, env, "network-template-apply", `${user.id}:${networkId}`, 20, 60_000);
  await requireNetworkOwner(env, networkId, user.id);
  const body = await readJson<Record<string, unknown>>(request, 32_768);
  const reason = safeText(body.reason, 500, "reason", true);
  const rolloutId = body.rolloutId == null ? crypto.randomUUID() : uuid(body.rolloutId, "rolloutId");
  const selected = Array.isArray(body.instanceIds)
    ? body.instanceIds.map((value) => uuid(value, "instance ID"))
    : [];
  if (selected.length > 100) throw new HttpError(400, "At most 100 servers can be selected");
  const uniqueSelected = new Set(selected);
  const template = await env.COREDSC_DB.prepare(
    "SELECT patch_json,revision,name FROM configuration_templates WHERE id=? AND network_id=?",
  ).bind(templateId, networkId).first<{ patch_json: string; revision: number; name: string }>();
  if (!template) throw new HttpError(404, "Template not found");
  const patch = objectPayload(parseStoredJson(template.patch_json));
  validatePayload("network.template.apply", patch);
  const members = await env.COREDSC_DB.prepare(
    `SELECT i.id,i.approval_mode FROM network_members m JOIN instances i ON i.id=m.instance_id
      WHERE m.network_id=?`,
  ).bind(networkId).all<{ id: string; approval_mode: number }>();
  const targets = members.results.filter((member) => uniqueSelected.size === 0 || uniqueSelected.has(member.id));
  if (targets.length === 0) throw new HttpError(400, "Select at least one current network server");
  if (uniqueSelected.size > 0 && targets.length !== uniqueSelected.size) {
    throw new HttpError(400, "One or more selected servers are not network members");
  }
  for (const target of targets) {
    const role = await requireGrant(env, target.id, user.id);
    if (role !== "OWNER") throw new HttpError(403, "You must still own every selected server");
  }

  const results: Array<Record<string, unknown>> = [];
  for (const target of targets) {
    const idempotencyKey = networkRolloutKey(rolloutId, target.id);
    if (target.approval_mode === 1) {
      const approval = await getOrCreateApproval(env, target.id, user.id, "network.template.apply",
        patch, reason, idempotencyKey);
      results.push({ instanceId: target.id, approvalRequired: approval.status === "PENDING" || approval.status === "APPROVED",
        approvalId: approval.id, status: approval.status, replay: approval.replay });
      continue;
    }
    const executed = await executeAndAudit(env, target.id, user, "OWNER", "network.template.apply",
      patch, reason, idempotencyKey, `${reason} [network template ${template.name} r${template.revision}]`);
    results.push({ instanceId: target.id, status: executed.status, result: await executed.json() });
  }
  return responseJson({ templateId, revision: template.revision, rolloutId, targets: results }, 202);
}

async function requireNetworkOwner(
  env: Env,
  networkId: string,
  discordUserId: string,
): Promise<{ name: string; created_at: number }> {
  const network = await env.COREDSC_DB.prepare(
    "SELECT name,created_at,owner_discord_user_id FROM network_groups WHERE id=?",
  ).bind(networkId).first<{ name: string; created_at: number; owner_discord_user_id: string }>();
  if (!network) throw new HttpError(404, "Network not found");
  if (network.owner_discord_user_id !== discordUserId) throw new HttpError(403, "Only the network owner can manage this network");
  return { name: network.name, created_at: network.created_at };
}

async function uploadMedia(request: Request, env: Env): Promise<Response> {
  const user = await requireSession(request, env);
  await requireCsrf(request, env, user);
  await enforceRateLimit(request, env, "media-upload", user.id, 12, 60_000);
  const instanceId = uuid(new URL(request.url).searchParams.get("instance"), "instance");
  const role = await requireGrant(env, instanceId, user.id);
  requireCapability(role, "config.edit");
  let bytes: Uint8Array;
  try { bytes = await readBytes(request, MAX_MEDIA_BYTES); }
  catch (error) {
    if (error instanceof HttpError && error.status === 413) {
      throw new HttpError(413, `Image exceeds the ${MAX_MEDIA_BYTES / 1024} KiB limit`);
    }
    throw error;
  }
  let media: ReturnType<typeof validateMediaBytes>;
  try { media = validateMediaBytes(bytes, request.headers.get("Content-Type") ?? ""); }
  catch (error) { throw new HttpError(error instanceof Error && error.message.startsWith("Only") ? 415 : 400,
    error instanceof Error ? error.message : "Invalid image"); }
  const idempotencyKey = safeText(request.headers.get("Idempotency-Key"), 100, "Idempotency-Key") || crypto.randomUUID();
  const execution = await executeAndAudit(env, instanceId, user, role, "media.install", {
    mimeType: media.mimeType,
    extension: media.extension,
    dataBase64: bytesToBase64(bytes),
  }, "Install a validated dashboard image in the local CoreDSC media store", idempotencyKey);
  const result = await execution.json<{ auditId?: string; ok?: boolean; payload?: unknown; error?: unknown }>();
  if (!execution.ok || result.ok !== true) return responseJson(result, execution.status);
  const payload = objectPayload(result.payload);
  const url = safeText(payload.reference, 128, "media reference", true);
  return responseJson({ url, auditId: result.auditId }, 201);
}

function bytesToBase64(bytes: Uint8Array): string {
  let binary = "";
  const chunk = 0x8000;
  for (let offset = 0; offset < bytes.length; offset += chunk) {
    binary += String.fromCharCode(...bytes.subarray(offset, Math.min(bytes.length, offset + chunk)));
  }
  return btoa(binary);
}

function validatePayload(operation: string, payload: Record<string, unknown>): void {
  const serialized = JSON.stringify(payload);
  const maximumBytes = operation === "media.install" ? 800_000 : 120_000;
  if (utf8ByteLength(serialized) > maximumBytes) throw new HttpError(413, "Operation payload is too large");
  const forbidden = /(?:^|[._-])(token|secret|password|private[-_]?key)(?:$|[._-])/iu;
  const walk = (value: unknown, depth: number): void => {
    if (depth > 12) throw new HttpError(400, "Operation payload is nested too deeply");
    if (!value || typeof value !== "object") return;
    if (Array.isArray(value)) {
      if (value.length > 500) throw new HttpError(400, "Operation payload contains too many items");
      value.forEach((item) => walk(item, depth + 1));
      return;
    }
    for (const [key, child] of Object.entries(value as Record<string, unknown>)) {
      if (forbidden.test(key)) throw new HttpError(403, `The cloud protocol refuses secret-bearing key '${key}'`);
      walk(child, depth + 1);
    }
  };
  walk(payload, 0);
  if (operation === "channel.purge") {
    const count = Number(payload.count);
    if (!Number.isInteger(count) || count < 1 || count > 100) throw new HttpError(400, "Purge count must be between 1 and 100");
  }
  if (operation === "media.install") {
    const encoded = safeText(payload.dataBase64, 750_000, "dataBase64", true);
    if (!/^[A-Za-z0-9+/]+={0,2}$/u.test(encoded)) throw new HttpError(400, "Image base64 is invalid");
  }
}

function summarizePayload(operation: string, payload: Record<string, unknown>): unknown {
  if (operation === "media.install") {
    return { mimeType: payload.mimeType, extension: payload.extension, encodedBytes: String(payload.dataBase64 ?? "").length };
  }
  if (operation.startsWith("config.")) {
    const changes = Array.isArray(payload.changes) ? payload.changes : [];
    return { files: [...new Set(changes.map((item) => item && typeof item === "object" ? String((item as Record<string, unknown>).file ?? "") : ""))],
      changeCount: changes.length };
  }
  return payload;
}

function isMutation(operation: string): boolean {
  return !operation.endsWith(".snapshot") && !operation.endsWith(".status") && !operation.endsWith(".list")
    && !operation.endsWith(".history") && !operation.endsWith(".rules") && operation !== "discord.channels" && operation !== "discord.guilds";
}

function objectPayload(value: unknown): Record<string, unknown> {
  return value && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : {};
}

function parseStoredJson(value: string): unknown {
  try { return JSON.parse(value) as unknown; } catch { return {}; }
}

async function recordCloudAudit(
  env: Env,
  instanceId: string,
  user: SessionUser,
  operation: string,
  reason: string,
  request: unknown,
  result: unknown,
): Promise<void> {
  const now = Date.now();
  await env.COREDSC_DB.prepare(
    `INSERT INTO audit_events(id,instance_id,actor_discord_user_id,actor_display_name,operation,reason,
      idempotency_key,request_json,result_json,outcome,created_at,completed_at)
     VALUES (?,?,?,?,?,?,?,?,?,'SUCCEEDED',?,?)`,
  ).bind(crypto.randomUUID(), instanceId, user.id, user.displayName, operation, reason,
    crypto.randomUUID(), json(request), json(result), now, now).run();
}

function boundedInteger(value: string, minimum: number, maximum: number, fallback: number): number {
  const parsed = Number(value);
  return Number.isInteger(parsed) && parsed >= minimum && parsed <= maximum ? parsed : fallback;
}

function safeReturnPath(value: string): string {
  return value.startsWith("/") && !value.startsWith("//") && value.length <= 512 ? value : "/dashboard";
}

function withCors(response: Response, request: Request, env: Env): Response {
  // A WebSocket upgrade response carries a runtime-only webSocket handle.
  // Reconstructing it as a normal Response would silently drop that handle.
  if (response.status === 101) return response;
  const origin = request.headers.get("Origin");
  if (origin !== env.APP_ORIGIN) return response;
  const headers = new Headers(response.headers);
  headers.set("Access-Control-Allow-Origin", origin);
  headers.set("Access-Control-Allow-Credentials", "true");
  headers.set("Vary", "Origin");
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}

function corsPreflight(request: Request, env: Env): Response {
  if (request.headers.get("Origin") !== env.APP_ORIGIN) throw new HttpError(403, "Untrusted request origin");
  return new Response(null, { status: 204, headers: {
    "Access-Control-Allow-Origin": env.APP_ORIGIN,
    "Access-Control-Allow-Credentials": "true",
    "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type,X-CoreDSC-CSRF,Idempotency-Key",
    "Access-Control-Max-Age": "86400",
    Vary: "Origin",
  } });
}

async function runScheduledMaintenance(env: Env): Promise<void> {
  const now = Date.now();
  const staleBefore = now - 120_000;
  await env.COREDSC_DB.batch([
    env.COREDSC_DB.prepare("DELETE FROM sessions WHERE expires_at<?").bind(now),
    env.COREDSC_DB.prepare("DELETE FROM oauth_states WHERE expires_at<?").bind(now),
    env.COREDSC_DB.prepare("DELETE FROM instance_nonces WHERE expires_at<?").bind(now),
    env.COREDSC_DB.prepare("DELETE FROM rate_limits WHERE expires_at<?").bind(now),
    env.COREDSC_DB.prepare(
      "UPDATE pairing_links SET status='EXPIRED' WHERE status IN ('CREATED','AWAITING_CONFIRM') AND expires_at<?",
    ).bind(now),
    env.COREDSC_DB.prepare(
      "UPDATE approvals SET status='EXPIRED' WHERE status='PENDING' AND expires_at<?",
    ).bind(now),
    env.COREDSC_DB.prepare(
      `UPDATE approvals SET status='PENDING',decided_by=NULL,decided_at=NULL,decision_note='',execution_started_at=NULL
        WHERE status='APPROVED' AND (execution_started_at IS NULL OR execution_started_at<?) AND expires_at>?`,
    ).bind(now - 120_000, now),
    env.COREDSC_DB.prepare(
      "DELETE FROM health_incidents WHERE status='RESOLVED' AND resolved_at<?",
    ).bind(now - 90 * 86_400_000),
  ]);

  const stale = await env.COREDSC_DB.prepare(
    `SELECT id,display_name,last_seen_at FROM instances
      WHERE status='ONLINE' AND last_seen_at<? ORDER BY last_seen_at LIMIT 500`,
  ).bind(staleBefore).all<{ id: string; display_name: string; last_seen_at: number }>();
  for (const instance of stale.results) {
    const changed = await env.COREDSC_DB.prepare(
      "UPDATE instances SET status='OFFLINE_UNEXPECTED' WHERE id=? AND status='ONLINE' AND last_seen_at<?",
    ).bind(instance.id, staleBefore).run();
    if (changed.meta.changes !== 1) continue;
    const incidentId = crypto.randomUUID();
    const detail = `${instance.display_name} stopped sending authenticated heartbeats; last seen ${new Date(instance.last_seen_at).toISOString()}`;
    await env.COREDSC_DB.prepare(
      `INSERT OR IGNORE INTO health_incidents(id,instance_id,kind,status,detail,detected_at)
       VALUES (?,?,'AGENT_HEARTBEAT_LOST','OPEN',?,?)`,
    ).bind(incidentId, instance.id, detail, now).run();
    const room = env.INSTANCE_ROOMS.get(env.INSTANCE_ROOMS.idFromName(instance.id));
    await room.fetch(new Request(`https://instance.internal/cloud-event?instance=${instance.id}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-CoreDSC-Instance": instance.id },
      body: JSON.stringify({ type: "health-incident", incident: {
        id: incidentId, kind: "AGENT_HEARTBEAT_LOST", status: "OPEN", detail, detected_at: now,
      } }),
    }));
  }
}
