#!/usr/bin/env bash
set -euo pipefail

project_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
temporary="$(mktemp -d)"
trap 'rm -rf "${temporary}"' EXIT

mkdir -p "${temporary}/src/com/hubertstudios/coredsc" \
  "${temporary}/src/com/hubertstudios/coredsc/storage" "${temporary}/classes"
cat > "${temporary}/src/com/hubertstudios/coredsc/CoreDSCPlugin.java" <<'JAVA'
package com.hubertstudios.coredsc;

import java.io.File;

public class CoreDSCPlugin {
    public File getDataFolder() {
        throw new UnsupportedOperationException("release-check stub");
    }

    public java.util.logging.Logger getLogger() {
        return java.util.logging.Logger.getLogger("CoreDSC-Release-Check");
    }
}
JAVA

cat > "${temporary}/src/com/hubertstudios/coredsc/storage/SQLiteStorage.java" <<'JAVA'
package com.hubertstudios.coredsc.storage;

import java.sql.Connection;
import java.util.concurrent.CompletableFuture;

public final class SQLiteStorage {
    @FunctionalInterface
    public interface SqlOperation<T> {
        T execute(Connection connection) throws Exception;
    }

    public <T> CompletableFuture<T> execute(SqlOperation<T> operation) {
        throw new UnsupportedOperationException("release-check stub");
    }
}
JAVA

javac --release 21 -Xlint:all -Werror \
  -d "${temporary}/classes" \
  "${temporary}/src/com/hubertstudios/coredsc/CoreDSCPlugin.java" \
  "${temporary}/src/com/hubertstudios/coredsc/storage/SQLiteStorage.java" \
  "${project_root}/plugin/src/main/java/com/hubertstudios/coredsc/scripting/MiniJson.java" \
  "${project_root}/plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudProtocolLimits.java" \
  "${project_root}/plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudRequestFingerprint.java" \
  "${project_root}/plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudTextFrameAssembler.java" \
  "${project_root}/plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudMediaStore.java" \
  "${project_root}/plugin/src/main/java/com/hubertstudios/coredsc/cloud/CloudIdentity.java" \
  "${project_root}/plugin/src/main/java/com/hubertstudios/coredsc/storage/CloudOperationRepository.java" \
  "${project_root}/scripts/java-release-check/ReleaseSafetyChecks.java"

java -ea -cp "${temporary}/classes" com.hubertstudios.coredsc.cloud.ReleaseSafetyChecks
