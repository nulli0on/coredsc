# CoreDSC Setup

## 1. Requirements

### Minecraft plugin

- Java 21
- Maven 3.9 or newer to build from source
- Paper or Folia 1.21.x; the project currently compiles against Paper API `1.21.11-R0.1-SNAPSHOT`
- A Discord application and bot for local Discord features
- Optional integrations only when their modules are enabled: LuckPerms 5.4 API-compatible plugin, PlaceholderAPI, AuthMe, Vault and Simple Voice Chat 2.6 API-compatible plugin

### Dashboard and control plane

- Node.js `>=22.13.0`
- npm with lockfile installs
- Cloudflare Workers, Durable Objects and D1
- A Cloudflare-hosted dashboard using the Sites workflow in `.openai/hosting.json`
- A Discord OAuth2 application

R2 is not required or used.

## 2. Build the plugin locally

From the repository root:

```bash
cd plugin
mvn -e clean verify
```

A successful build should produce:

```text
plugin/target/CoreDSC-3.4.0.jar
```

Before distributing that JAR, inspect it and confirm that it contains JDA, SQLite JDBC and relocated bStats classes, while Paper, SLF4J, LuckPerms and Simple Voice Chat APIs remain provided dependencies.

### Local dependency-free safety gate

Before the full Maven build, the release-critical dependency-free utilities can be checked with Java 21:

```bash
./scripts/java-release-check.sh
```

The script compiles its dependency-free release boundary with all Java lint warnings treated as errors. It exercises strict JSON handling, canonical request fingerprints, bounded WebSocket fragment assembly, persistent Ed25519 identity validation, media integrity, symlink rejection and concurrent idempotent media installation; it also type-checks the local cloud-operation repository against a minimal JDBC funnel stub.

For this source delivery, the complete Maven build could not be executed because Maven and its package mirrors were unavailable in the execution environment. Run this gate successfully before publishing a binary release.

## 3. Install the plugin

1. Stop the Paper/Folia server.
2. Copy `CoreDSC-3.4.0.jar` into `plugins/`.
3. Start the server once to generate configuration files.
4. Stop the server and review:
   - `plugins/CoreDSC/config.yml`
   - `plugins/CoreDSC/secrets.yml`
   - `plugins/CoreDSC/modules/*.yml`
   - `plugins/CoreDSC/guis/*.yml`
5. Prefer the `COREDSC_BOT_TOKEN` environment variable. Leave `secrets.yml` empty unless `discord.token-source` is explicitly set to `SECRETS.YML`.
6. Set the Discord guild ID and required channel/role IDs.
7. Keep `modules/cloud-control.yml` disabled until the hosted endpoint is deployed.
8. Start the server and run:

```text
/coredsc doctor
/coredsc status
```

## 4. Discord bot setup

Create a Discord application and bot in the Discord Developer Portal. Enable only the gateway intents required by the enabled CoreDSC modules. Invite the bot with the permissions required for the configured actions; do not grant Administrator merely to bypass configuration mistakes.

The bot token belongs only on the Minecraft server:

```bash
export COREDSC_BOT_TOKEN='replace-with-the-local-bot-token'
```

Do not configure the token as a Cloudflare secret. The hosted control plane uses Discord OAuth client credentials, not the customer's bot token.

## 5. Deploy the Cloudflare control plane

All examples below are run from `control-plane/`.

### 5.1 Install and authenticate

```bash
npm ci
npx wrangler login
```

### 5.2 Create D1

```bash
npx wrangler d1 create coredsc-control-plane
```

Copy the returned database ID into `control-plane/wrangler.jsonc` at `d1_databases[0].database_id`.

### 5.3 Configure public URLs

Set these values in `control-plane/wrangler.jsonc` to the final dashboard origin:

```text
APP_ORIGIN=https://your-dashboard.example
PUBLIC_APP_URL=https://your-dashboard.example
DISCORD_REDIRECT_URI=https://your-dashboard.example/api/v1/auth/discord/callback
SESSION_TTL_SECONDS=604800
```

`APP_ORIGIN` must be the exact browser origin. It is used for CORS and mutation-origin checks. Do not use a wildcard.

### 5.4 Add Worker secrets

```bash
npx wrangler secret put DISCORD_CLIENT_ID
npx wrangler secret put DISCORD_CLIENT_SECRET
npx wrangler secret put COOKIE_SECRET
```

`COOKIE_SECRET` must be a high-entropy secret. It signs deterministic CSRF material and pairing confirmation codes.

### 5.5 Apply D1 migrations in order

Validate locally first:

```bash
npm run db:local
```

Then apply to the intended remote D1 database:

```bash
npm run db:remote
```

Wrangler applies the numbered migrations from `0001_initial.sql` through `0006_ownership_recovery.sql` in lexical order.

### 5.6 Run local checks

```bash
npm run check
npm run dev
```

### 5.7 Deploy the control plane

```bash
npm run deploy
```

The Worker requires these bindings:

- D1: `COREDSC_DB`
- Durable Object namespace: `INSTANCE_ROOMS`, class `InstanceRoom`
- Cron: every minute for expiry, retry and cleanup maintenance

## 6. Deploy the hosted dashboard

From the repository root:

```bash
npm ci
npm run lint
npm test
```

The dashboard uses the Sites workflow declared by `.openai/hosting.json`. Configure a Cloudflare service binding named `CONTROL_PLANE` that targets the deployed `coredsc-control-plane` Worker. This binding is mandatory for `/api/*`; without it, the dashboard returns HTTP 503 for API requests.

The dashboard Worker removes the `/api` prefix before forwarding requests. Therefore the first-party OAuth callback is:

```text
https://your-dashboard.example/api/v1/auth/discord/callback
```

The dashboard and API must share the same public origin so the `__Host-coredsc_session` and `__Host-coredsc_oauth` cookies remain first-party, Secure, HttpOnly and SameSite=Lax.

## 7. Configure Discord OAuth

In the Discord application, add this exact redirect URI:

```text
https://your-dashboard.example/api/v1/auth/discord/callback
```

It must exactly match `DISCORD_REDIRECT_URI`. The OAuth scope used by the control plane is identity-only; server authorization comes from CoreDSC grants, not from the OAuth login itself.

## 8. Connect the Minecraft agent

Edit `plugins/CoreDSC/modules/cloud-control.yml`:

```yaml
enabled: true
endpoint: 'wss://your-dashboard.example/api/v1/agent/connect'
```

The first-party dashboard route is recommended when `CONTROL_PLANE` is configured. A direct Worker endpoint can instead use:

```text
wss://your-control-plane-worker.example/v1/agent/connect
```

No inbound server port is opened. The plugin generates or loads its local Ed25519 identity and authenticates the outbound WebSocket with a timestamp, nonce and signature.

## 9. Pair the first owner

From the Minecraft server console:

```text
/coredsc editor open
```

Open the returned URL, sign in with Discord and claim the pairing. The dashboard then displays a short confirmation command. Run that command from the same server console:

```text
/coredsc editor auth XXXX-XXXX
```

The first completed pairing creates the `OWNER` grant. Pairing links expire and cannot be replayed.

## 10. Ownership recovery

Ownership recovery is intentionally separate from normal pairing and can be initiated only from the local server console; player and RCON senders are rejected.

```text
/coredsc editor recover
```

After the new Discord account claims the link, run the displayed `/coredsc editor auth` command locally. On successful confirmation, existing active `OWNER` grants for that instance are revoked, the claimant becomes the new `OWNER`, and the change is audited.

## 11. Staff and approvals

The owner can add supported staff roles from the dashboard. Capabilities are enforced in the dashboard, Worker and plugin. Dangerous operations such as remote console execution, channel purge and network template application require two-person approval. Permanent bans and network-scoped incident activation also require approval.

Remote console execution remains disabled until both conditions are met:

1. `console.remote-execution.enabled: true` in the local cloud-control configuration.
2. The requested root command is present in the local allowlist.

## 12. Local verification commands

```bash
# Dashboard
npm ci
npm run lint
npm test

# Control plane
cd control-plane
npm ci
npm run check
npm run db:local

# Plugin
cd ../plugin
mvn -e clean verify
```

Real deployment validation still requires the final Cloudflare bindings/domain, Discord OAuth credentials, a Discord test guild and Paper/Folia test servers. Never use production credentials in local fixtures.
