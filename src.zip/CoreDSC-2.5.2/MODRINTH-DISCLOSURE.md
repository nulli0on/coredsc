# Metrics disclosure for the Modrinth project page

CoreDSC optionally uses the official bStats Bukkit service with plugin ID `32949`. CoreDSC custom charts report only fixed/bucketed configuration categories and bounded successful-feature counts.

Feature categories cover chat forwarding, link creation/linking/unlinking, queued deliveries, server events, tickets/reports/applications, custom commands, workflows, Python execution, status updates, role/nickname/ban synchronization, and booster rewards. Counts are capped and reset between collection intervals.

CoreDSC custom charts do not add player or Discord identities, guild/channel/role IDs, server names/addresses/MOTDs, messages, commands, support content, URLs, tokens, passwords, database values, script/workflow names, or arbitrary free-form values. CoreDSC has no private analytics endpoint and no remote license gate.

Server owners can disable CoreDSC charts in `plugins/CoreDSC/telemetry.yml` or disable bStats globally in `plugins/bStats/config.yml`. A valid opt-out from the obsolete `license.yml` is preserved during upgrade.

Local databases, migration backups, and the local Discord command-scope cleanup file may contain operational identifiers/content required by enabled features; they are not submitted through CoreDSC custom bStats charts. See `PRIVACY.md` and `BSTATS-METRICS.md`.
