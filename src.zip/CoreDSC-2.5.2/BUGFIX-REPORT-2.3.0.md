# CoreDSC 2.3.0 bug-fix report

Review date: 2026-07-13

## Fixed defects

| Area | Defect | Correction |
|---|---|---|
| Voice compilation | `javax.annotation.Nonnull` was imported without a declared annotation dependency | Removed the unnecessary annotations and imports |
| Doctor diagnostics | Queue counts returned `int[]`, while the doctor expected `long[]` | Added an explicit asynchronous conversion |
| Booster rewards | A reassigned timestamp was captured by a lambda | Normalized into an effectively final value |
| Ban synchronization | Paper name bans are unsupported for current profile-ban state | Ban detection now uses the linked Minecraft UUID/profile |
| Configuration migration | Legacy Python-worker settings could be discarded during modular migration | Migrates `modules.python-bot`, `bot`, and `python-bot` into `bot/config.yml` |
| Reports | The code referenced `reports.messages.help`, but the shipped module file did not define it | Added the default help lines |
| Build diagnostics | Compiler warnings and module descriptor collisions were obscured | Enabled full lint output and excluded shaded module descriptors |
| Regression coverage | The original audit did not catch descriptor or migration regressions | Added command, permission, module, annotation, ban API and migration checks |

## Verification performed

- Java 21 compilation of all 71 source files
- Maven `clean verify`
- Shaded JAR creation and ZIP integrity
- Required JAR entries and provided-API exclusion checks
- Full javac lint output
- 29 YAML files
- Four Python files
- `pom.xml`
- SQLite schema version 10, 39 migration statements and 96 fixed prepared statements
- Voice topology split, merge, hysteresis and world-isolation test
- Plugin command, permission and module-resource parity
- Search for TODO/FIXME, `printStackTrace`, and direct standard-output logging

## Remaining boundary

The build environment could not reach the PaperMC and MaxHenkel Maven hosts, so
compile-only stubs were used for those two provided APIs. No stub is bundled in
the output. No live Paper, Discord, Redis, Simple Voice Chat, AuthMe, LuckPerms,
PlaceholderAPI, license-server, load, reconnect, or rate-limit test was run.
PMD, SpotBugs and Maven dependency analysis could not complete because their
plugin artifacts were unavailable in the network-restricted environment; they
are not counted as passed checks.

The source is materially safer than the submitted archive, but a successful
staging deployment is still required before calling it a stable release.
