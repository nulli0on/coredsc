# Third-party notices

CoreDSC uses external libraries and APIs declared in `pom.xml`. Those projects
are not relicensed by the CoreDSC MIT License. Their original copyright notices
and license terms continue to apply.

## bStats

CoreDSC uses `org.bstats:bstats-bukkit:3.2.1` under the MIT License. The bStats
classes are shaded and relocated into CoreDSC during the Maven build to avoid
class-path conflicts with other plugins. CoreDSC uses bStats plugin ID `32949`.
Server owners retain bStats' global opt-out and CoreDSC also provides a local
`bstats.enabled` switch in `telemetry.yml`.

## Other dependencies

The build also declares Paper API, JDA, sqlite-jdbc, SLF4J API, LuckPerms API,
and Simple Voice Chat API. The Maven dependency metadata and corresponding
upstream projects are the source of truth for the exact version and license of
each dependency included in a particular build.

The DiscordSRV source supplied during development was used only as a behavioral
reference. CoreDSC does not include or redistribute DiscordSRV source code.
