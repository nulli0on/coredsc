# CoreDSC 2.5.2 recheck test report

## Executed tests

| Test | Result | Scope |
|---|---|---|
| `python3 tools/static_audit.py` | PASS | Java structure/import hygiene, YAML/XML, SQL simulation, descriptors, privacy/security/config invariants, voice topology self-test |
| `python3 tools/config_migration_self_test.py` | PASS | 28 current managed YAML resources, 27 version-2.4.3 fixtures, additive preservation, backup/rollback/future-schema/old-opt-out ordering invariants |
| `ConfigKeyInspectorSelfTest` | PASS | Pure Java unknown-key collapse and typo suggestion behavior |
| `python3 tools/scheduler_boundary_self_test.py` | PASS | Paper scheduler adapter compilation, global/async/entity/location execution, cancellable handles, close-state rejection |
| `python3 tools/module_health_self_test.py` | PASS | Module lifecycle compilation and operational success/failure timestamp counters |
| `python3 tools/python_worker_self_test.py` | PASS | Worker protocol, SDK shadow protection, failed-import rollback |
| `python3 tools/discordsrv_migration_self_test.py` | PASS | Focused Java 21 compilation and pure migration logic |
| `python3 tools/migration_conflict_self_test.py` | PASS | Duplicate legacy link/account detection without deletion/rewrite |
| Voice topology Java self-test | PASS | Compiled/executed by static audit |
| Focused `SQLiteStorage` Java 21 compile with local plugin stub | PASS | Local Java syntax/types independent of real sqlite-jdbc/Paper runtime |
| Focused `DiscordBotService` Java 21 compile with local API stubs | PASS | Local Java syntax/types independent of real JDA/Paper API compatibility |
| Dependency-free all-source javac diagnostic | Expected dependency failure | 2,369 diagnostics caused principally by absent external APIs; zero syntax-like diagnostics detected and no new non-dependency type diagnostic versus 2.5.1 |
| Archive/checksum validation | PASS | Input and final package integrity checks |
| Patch dry-run validation | PASS | 2.5.1 additions patch and full 2.4.3 patch apply with `patch -p1` |

## Audit totals

- 76 production Java source files inspected.
- 29 bundled YAML files parsed.
- 28 YAML resources managed by the migration system.
- 27 CoreDSC 2.4.3 YAML fixtures exercised.
- 5 Python files syntax-checked.
- 37 SQLite migration statements simulated.
- 96 fixed prepared statements exercised by the SQL simulation.
- 33 bStats custom chart IDs checked for uniqueness/documentation parity.

## What these results do not prove

Local API stubs intentionally test only CoreDSC-local typing and control flow. They do not prove that the real JDA/Paper APIs have identical signatures. Static/fixture tests do not execute Bukkit `YamlConfiguration`, JDA REST/gateway behavior, sqlite-jdbc, Redis, Simple Voice Chat, LuckPerms, AuthMe, or PlaceholderAPI.

Maven was unavailable, so `mvn clean verify` was not executed and no JAR was built.

## Mandatory pre-release runtime matrix

1. Clean Java 21/Maven build with a fresh dependency cache.
2. Fresh Paper installation with Discord disabled and enabled.
3. Upgrade of a real customized 2.4.3 data folder and database copy.
4. Forced YAML migration failure and byte-for-byte rollback verification.
5. SQLite legacy, current, future-schema, and duplicate-conflict cases.
6. Correct guild, wrong guild, bot absent, multiple guilds, and permission/hierarchy changes.
7. Guild/global command scope switches across restart; cleanup failure and retry.
8. Discord outage, resume, permanent shutdown, REST failure, and rate limiting.
9. Failed module during reload, including a runtime already containing a failed optional module.
10. Repeated reload/disable/enable checks for duplicate listeners/tasks/processes.
11. Link/reward idempotency and interrupted-claim recovery.
12. Queue persistence, expiry, retry, dead-letter, and high-volume behavior.
13. Python absent/present/bad executable/bad script/start/stop/restart.
14. Every optional integration advertised on the release page.
15. Multi-hour soak test with thread, heap, queue, DB connection, and duplicate-message monitoring.
