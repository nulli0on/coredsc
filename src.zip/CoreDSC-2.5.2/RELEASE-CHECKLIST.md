# CoreDSC 2.5.2 public release checklist

## Build

- [ ] Java 21 and Maven selected.
- [ ] Clean dependency resolution succeeds.
- [ ] `./tools/verify_build.sh` passes.
- [ ] Actual JAR contents/relocations are audited.
- [ ] Final JAR checksum recorded.

## Upgrade/data integrity

- [ ] Fresh data folder starts.
- [ ] Real customized 2.4.3 YAML/database copy migrates.
- [ ] YAML and database backups are valid.
- [ ] Forced YAML failure restores exact original files.
- [ ] Future YAML/database schemas are blocked without modification.
- [ ] Duplicate legacy account/link values stop without deletion.
- [ ] Reload rollback restores all previously working modules, including when another optional module was already failed.

## Discord reliability

- [ ] Correct guild resolves; wrong/non-member guild fails closed.
- [ ] Global mode works only when explicit.
- [ ] Scope switch cleanup persists across restart.
- [ ] Cleanup failure is visible and retried rather than reported READY.
- [ ] Command updates are not duplicated/out of order.
- [ ] Listener add/remove during startup does not double-attach.
- [ ] Permission/hierarchy/deleted-resource diagnostics are actionable.
- [ ] Outage, reconnect, permanent close, and rate-limit behavior pass.

## Lifecycle/security

- [ ] Repeated reload/disable/enable creates no duplicate listener/task/process.
- [ ] SQLite and Redis workers close cleanly.
- [ ] Queue/link/reward interruption/idempotency tests pass.
- [ ] Secrets are absent from logs/doctor/support bundles.
- [ ] Remote console stays OFF by default and security tests pass when enabled.
- [ ] Python remains optional/manual-start and runtime replacement rollback works.

## Telemetry/privacy

- [ ] New and migrated per-plugin opt-outs work.
- [ ] Global bStats opt-out works.
- [ ] Dashboard contains only documented fixed/bucketed values.
- [ ] Local state/database/backups are accurately disclosed and excluded from public bundles.

## Publication

- [ ] Supported Paper/Minecraft/integration versions match live tests.
- [ ] README, upgrade, privacy, security, and metrics documents match the built JAR.
- [ ] No Folia support claim.
- [ ] Known limitations and runtime test results published.
