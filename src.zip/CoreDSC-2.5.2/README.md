# CoreDSC 2.5.2

CoreDSC is a modular Discord integration for Paper servers. The 2.5.2 release is focused on deterministic startup, safe upgrades, explicit diagnostics, and recovery from Discord/configuration failures rather than adding niche features.

## 2.5.2 reliability changes

- Guild command registration is fail-closed. A missing or invisible configured guild no longer silently falls back to global slash commands.
- Guild resolution and slash-command registration have separate observable health states in `/coredsc status` and `/coredsc doctor`.
- Discord reconnect callbacks use the currently active configuration, including after an in-place reload.
- `/coredsc reload` is rollback-protected: a failed reload restores the previous active configuration and verifies that previously working modules returned.
- Every maintained YAML file has a schema version. Startup adds missing defaults, writes atomically, creates timestamped backups, and restores touched files if migration fails.
- `license.yml` is no longer active configuration. A valid former bStats preference is imported fail-safely into `telemetry.yml` during upgrade.
- bStats reports bounded feature categories and successful aggregate activity without IDs, messages, command text, tokens, URLs, or other free-form values.
- The optional Python worker defaults to manual start. Missing Python no longer creates a startup warning unless an administrator deliberately starts the worker.
- The startup banner supports full, compact, and disabled modes with optional console color.
- Unknown YAML keys are preserved and reported with conservative typo suggestions; obsolete settings are identified without silently deleting them.
- Startup prints a compact action summary only when unresolved warnings remain.
- `/coredsc doctor` reports each module's last successful action, successful-action count, and last recorded failure.
- All CoreDSC-owned scheduling is routed through one Paper scheduler boundary, preparing future Folia work without claiming Folia support.

## Requirements

- Java 21
- Paper compatible with the `paper-api` version declared in `pom.xml`
- A Discord bot for Discord-facing modules
- Python 3.8+ only when the optional worker is manually started or `bot.auto-start` is enabled
- Simple Voice Chat only for the optional Discord proximity-room module

CoreDSC does not contain remote license enforcement or a private analytics endpoint.

## Quick start

1. Build with `mvn clean verify` using Java 21, or install the published JAR.
2. Put the JAR in `plugins/` and start Paper once.
3. Stop Paper and set `COREDSC_BOT_TOKEN` in the server process environment.
4. Set the Discord guild ID in `plugins/CoreDSC/config.yml`.
5. Configure one module at a time under `plugins/CoreDSC/modules/`.
6. Start Paper and run:

```text
/coredsc doctor
/coredsc status
```

For a file-based token, set `discord.token-source: SECRETS.YML` and place the token in `plugins/CoreDSC/secrets.yml`. Environment variables are safer for production.

## Discord bot setup

CoreDSC requests gateway intents only when enabled features need them:

- **Message Content**: Discord-to-Minecraft chat, ticket/report messages, or remote console.
- **Server Members**: role, nickname, or booster synchronization.
- **Voice States**: Discord proximity rooms.
- **Moderation**: ban synchronization.

Grant only the permissions required by enabled modules. `/coredsc doctor` distinguishes an invalid guild, unavailable channel, missing permission, optional disabled module, and failed command registration.

## Configuration layout

```text
plugins/CoreDSC/
├── config.yml                     # global Discord, storage and banner settings
├── telemetry.yml                  # official bStats switches only
├── secrets.yml                    # optional local bot token file
├── messages.yml
├── backups/                       # timestamped configuration migration backups
├── modules/
│   ├── chat-sync.yml
│   ├── delivery-queue.yml
│   ├── status-channels.yml
│   └── ...
├── bot/
│   ├── config.yml                 # optional Python worker; manual start by default
│   ├── README.md
│   ├── runtime/                   # CoreDSC-owned worker files
│   └── scripts/                   # administrator-owned scripts
└── guis/
    └── report-gui.yml
```

Every maintained YAML file includes:

```yaml
config-version: 4
generated-by-version: "2.5.2"
```

At startup CoreDSC validates the schema, adds missing defaults, backs up files before migration, writes through temporary files, and rolls back touched files after a failed migration. A config created by a newer unknown schema is rejected instead of being downgraded. `/coredsc reload` does not run migrations; restart once after replacing configuration files from an older release.

An old `license.yml` is no longer active. Its valid Boolean bStats preference is imported only after `telemetry.yml` passes schema validation; a prior opt-out is never re-enabled. Remove the obsolete file after verifying the upgrade.

## Telemetry and privacy

See [BSTATS-METRICS.md](BSTATS-METRICS.md) and [PRIVACY.md](PRIVACY.md).

CoreDSC uses the official bStats Bukkit client with plugin ID `32949`. Custom charts report fixed categories and bounded counts, including enabled/active modules and successful feature activity such as chat forwarding, linking, queued delivery, support-item creation, custom-command execution, workflows, Python executions, status updates, synchronization paths, and booster rewards.

CoreDSC custom charts do not send:

- player names, UUIDs, IP addresses, or individual activity;
- server names, addresses, MOTDs, installation IDs, or file paths;
- Discord guild, channel, role, webhook, or user IDs;
- messages, command text, tickets, reports, applications, script names, or workflow names;
- tokens, webhook URLs, database credentials, or arbitrary configuration values.

Disable CoreDSC bStats charts in `plugins/CoreDSC/telemetry.yml`:

```yaml
bstats:
  enabled: false
  feature-activity: false
```

Disable bStats for every plugin in `plugins/bStats/config.yml`:

```yaml
enabled: false
```

Telemetry status is available through `/coredsc telemetry`; bStats is intentionally not promoted as a health item in the default doctor report.

## Python worker

The Python module is optional and disabled by default. When enabled, the module loads without spawning Python unless `bot.auto-start: true` or `/coredsc bot start` is used. This prevents an absent Python executable from degrading normal CoreDSC startup.

The worker validates its runtime script and script directory, tries the configured executable or common Python 3 executable names, isolates sensitive environment variables by default, and reports actionable startup errors. Python scripts remain administrator-trusted code, not a security sandbox.

See [PYTHON-INTEGRATIONS.md](PYTHON-INTEGRATIONS.md).

## Chat, delivery and server events

See [CHAT-SYNC.md](CHAT-SYNC.md).

- Minecraft-to-Discord sends use either the bot or optional player webhooks.
- Discord-to-Minecraft messages support independent linked/unlinked policies.
- Mass mentions are sanitized and bot/webhook loops are blocked.
- Important event messages can use the persistent bounded delivery queue.
- A failed webhook callback is not blindly resent through the bot because the first request may already have reached Discord.

## Status channels

Each configured status channel can have separate online/offline names:

```yaml
channels:
- id: '123456789012345678'
  type: voice
  online-name: 'Players Online: %online_players%/%max_players%'
  offline-name: 'Server is offline'
```

Offline status is published only during a clean Paper shutdown. A killed process, host crash, or network loss cannot execute shutdown code.

## DiscordSRV migration

See [DISCORDSRV-MIGRATION.md](DISCORDSRV-MIGRATION.md).

Run a read-only preview first:

```text
/coredsc migrate DiscordSRV preview
```

The importer preserves existing CoreDSC values, skips linked-account conflicts, creates backups, and never modifies or disables DiscordSRV. The final cutover remains an administrator action.

## VoiceChat

See [VOICECHAT.md](VOICECHAT.md).

CoreDSC supports Discord-only proximity rooms. Cross-platform Discord/Simple Voice Chat audio remains fail-closed because this release does not bundle a verified DAVE provider and its native runtime. Both audio direction toggles must remain false.

## Commands

```text
/coredsc status
/coredsc doctor
/coredsc doctor test <target>
/coredsc setup ...
/coredsc queue <status|retry|clear>
/coredsc bot <status|scripts|start|stop|restart>
/coredsc emit <event> [key=value ...]
/coredsc telemetry
/coredsc migrate DiscordSRV [preview]
/coredsc reload
```

Module-specific commands exist only while their module is enabled successfully.

## Building and verification

```bash
mvn clean verify
```

The Maven build shades JDA, sqlite-jdbc, and the official bStats client. Paper, LuckPerms, SLF4J, and Simple Voice Chat APIs remain provided dependencies.

Source-only checks are available when Maven repositories are unavailable:

```bash
python3 tools/static_audit.py
python3 tools/config_migration_self_test.py
python3 tools/python_worker_self_test.py
python3 tools/discordsrv_migration_self_test.py
```

These checks validate source structure, YAML/XML/Python parsing, SQLite migrations and prepared statements, dependency/security invariants, migration behavior, Python isolation, and the voice topology algorithm. They do not replace a full Maven build or a live Paper/Discord integration test.

## Security

- Tokens are never bundled and diagnostics redact secrets.
- Remote console defaults to `OFF`; narrow allowlists are strongly preferred over full access.
- Link codes are persistent, expiring, single-use, and rate-limit capable.
- Chat and webhooks sanitize mass mentions and untrusted formatting.
- Python executes in a separate local process but remains trusted administrator code.
- Configuration downgrade and silent guild/global fallbacks are blocked.

Read [SECURITY.md](SECURITY.md) before enabling remote commands or third-party scripts.

## License

CoreDSC source is distributed under the MIT License. Third-party dependencies retain their own licenses; see [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md).
