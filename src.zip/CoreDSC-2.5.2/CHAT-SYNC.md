# Chat Sync Setup

CoreDSC can bridge chat in both directions. Each direction can be enabled independently by setting its channel ID.

Configuration file:

```text
plugins/CoreDSC/modules/chat-sync.yml
```

## 1. Discord to Minecraft

Set the Discord text channel that should be mirrored into Minecraft:

```yaml
discord-to-minecraft:
  channel-id: '123456789012345678'
  allow-linked-users: true
  allow-unlinked-users: true
  linked-format: '&9[Discord] &b%minecraft_player% &8(%discord_user%)&f: %message%%attachments%%reply%'
  unlinked-format: '&9[Discord] &f%discord_user%: %message%%attachments%%reply%'
```

With the simple format below, players see messages such as `[Discord] Wumpus: Hi everyone`:

```yaml
  linked-format: '&9[Discord] &f%discord_user%: %message%'
  unlinked-format: '&9[Discord] &f%discord_user%: %message%'
```

### Linked-account policy

```yaml
allow-linked-users: true
allow-unlinked-users: false
```

This accepts only Discord users linked through CoreDSC. Set both to `true` to accept everyone in the configured channel. Set both to `false` only when intentionally pausing reverse chat.

A rejected user can optionally receive a reply:

```yaml
denied-notice:
  enabled: true
  message: 'Link your Minecraft account before using game chat.'
```

### Discord role policy

```yaml
allowed-role-ids:
  - '111111111111111111'
blocked-role-ids:
  - '222222222222222222'
```

An empty allowlist accepts every role. A blocked role always wins. Role checks occur before link-policy checks.

### Attachments and replies

```yaml
attachments:
  enabled: true
  maximum: 3
  format: ' &7[%name%: %url%]'
replies:
  enabled: true
  format: ' &8(reply to %reply_user%: %reply_message%)'
```

Discord attachments are represented by safe text links. Reply previews are truncated. CoreDSC does not download attachment contents.

### Reverse-chat placeholders

```text
%discord_user%       visible Discord name
%discord_name%       Discord account username
%discord_id%         Discord user ID
%top_role%           highest Discord role name
%minecraft_player%   linked Minecraft name or Discord name fallback
%minecraft_uuid%     linked Minecraft UUID or blank
%linked%              true or false
%message%             sanitized message body
%attachments%         rendered attachment suffix
%reply%               rendered reply suffix
```

Discord color codes are neutralized before broadcasting, so a user cannot inject Minecraft formatting through `&` or `§`.

## 2. Minecraft to Discord as the bot

```yaml
minecraft-to-discord:
  channel-id: '123456789012345678'
  format: '**%displayname%**: %message%'
  webhook:
    enabled: false
```

Available placeholders:

```text
%player%       account name
%displayname%  plain-text Minecraft display name
%uuid%         player UUID
%world%        current world
%server%       Bukkit server name
%message%      chat content
```

PlaceholderAPI placeholders are also applied when that module and plugin are available.

## 3. Minecraft to Discord with player webhooks

Webhook mode makes Discord display each Minecraft message under the player's name and avatar:

```yaml
minecraft-to-discord:
  channel-id: '123456789012345678'
  webhook:
    enabled: true
    auto-create: true
    fallback-to-bot: true
    name: CoreDSC Chat
    username-format: '%displayname%'
    avatar-url: 'https://mc-heads.net/avatar/%uuid%/128'
    message-format: '%message%'
```

Required channel permissions:

- View Channel
- Send Messages
- Manage Webhooks when `auto-create: true`

CoreDSC reuses a webhook with the configured name when it is owned by the bot and has an available token. When `fallback-to-bot` is true, the main bot is used only if webhook resolution, creation, or synchronous submission fails before an asynchronous request is in flight. An asynchronous send failure is logged without a second bot send because Discord may already have accepted the webhook message.

Leave `avatar-url` blank to avoid any external avatar provider. The URL must use HTTPS.

## 4. Loop protection

Keep these defaults unless you have a specific integration reason:

```yaml
ignore-bots: true
ignore-webhooks: true
```

CoreDSC always suppresses its own webhook messages. This prevents Minecraft chat from returning to Minecraft through the same Discord channel.

## 5. Canned responses

```yaml
canned-responses:
  - id: server-ip
    trigger: '!ip'
    match: EXACT
    response: 'play.example.net'
    cooldown-seconds: 30
    stop-forwarding: true
```

Match modes: `EXACT`, `PREFIX`, `CONTAINS`, `REGEX`.

## 6. Apply and test

```text
/coredsc reload
/coredsc doctor
/coredsc doctor test chat
```

Then test separately:

1. Send one plain Minecraft message and confirm it appears once in Discord.
2. Send one plain Discord message and confirm it appears once in Minecraft.
3. Test a linked and an unlinked Discord account against the selected policy.
4. Test an attachment and a reply.
5. If webhook mode is enabled, confirm the player's name/avatar and verify that no loop occurs.

If Discord-to-Minecraft messages do not arrive, ensure Message Content Intent is enabled in the Discord Developer Portal and that the channel ID is correct.
