# CoreDSC 2.5.2 bug ledger

| ID | Severity | Component | Status | Automated/source protection | Live verification needed |
|---|---|---|---|---|---|
| CDSC-001 | High | Guild command scope fallback | Fixed | Fail-closed source invariant | Yes |
| CDSC-002 | High | Reload recovery | Fixed | Config snapshot/restore invariant | Yes |
| CDSC-003 | Medium | Reconnect settings | Fixed | Current-settings source review | Yes |
| CDSC-004 | High | YAML migration | Fixed | 2.4.3 fixtures, schema/rollback invariants | Yes |
| CDSC-005 | Medium | Unnecessary YAML rewrites | Fixed | Plugin-version-only rewrite guard | Yes |
| CDSC-006 | Medium | License/metrics coupling | Fixed | No bundled/managed license config | Upgrade display only |
| CDSC-007 | Medium | Doctor relevance | Fixed | Guild/registration state checks | Yes |
| CDSC-008 | Medium | Optional Python startup | Fixed | Worker protocol + default check | Yes |
| CDSC-009 | Medium | Adoption metrics | Fixed | Allowlist and successful-path checks | Yes |
| CDSC-010 | Low | Permission diagnostics | Fixed | Conditional permission source check | Yes |
| CDSC-011 | Low | Startup banner | Fixed | Resource/source checks | Visual only |
| CDSC-012 | High | False rollback success | Fixed | Previously-working module restoration invariant | Yes |
| CDSC-013 | High | Stale commands after restart | Fixed | Persistent-scope/atomic-write checks | Yes |
| CDSC-014 | High | Python runtime overwrite | Fixed | Managed-resource transaction checks | Yes |
| CDSC-015 | High | Unsafe SQLite migration | Fixed | Snapshot/transaction/future-schema checks | Yes |
| CDSC-016 | High | Silent duplicate-row deletion | Fixed | Destructive-SQL ban + conflict fixture | Yes |
| CDSC-017 | Medium | Metrics disabled/stopped state | Fixed | State/clear invariants | Yes |
| CDSC-018 | High | Discord listener double-attach race | Fixed | Focused compile + lock invariant | Yes |
| CDSC-019 | Process | Overstated verification | Fixed | Explicit verification-tier reports | No |
| CDSC-020 | Medium | Lost old bStats opt-out | Fixed | Fail-safe opt-out fixture/source checks | Yes |
| CDSC-021 | High | Pre-existing failed module broke rollback | Fixed | Previously-enabled set restoration invariant | Yes |
| CDSC-022 | Medium | Hidden obsolete-command cleanup failure | Fixed | Cleanup-failure health/state invariant | Yes |
| CDSC-023 | Medium | Metrics failed-start counters | Fixed | Startup failure clear invariant | Yes |
| CDSC-024 | High | Future telemetry schema modified before validation | Fixed | Migration-order invariant | Yes |
| CDSC-025 | Low | Silent configuration typos | Fixed | Pure key-inspector test and YAML audit | Yes |
| CDSC-026 | Low | Startup warnings buried in logs | Fixed | Delayed-summary source invariant | Visual/timing only |
| CDSC-027 | Low | Enabled modules lacked operational evidence | Fixed | Module-health compile/self-test | Yes |
| CDSC-028 | Maintainability | Direct scheduler coupling | Fixed | Scheduler adapter test and direct-call ban | Paper runtime; Folia not claimed |
| CDSC-029 | Low | Reload warning snapshot mismatch | Fixed | Rollback source invariant restores values and warnings | Yes |

## Remaining unverified risks

These are not confirmed fixed by source inspection alone:

- exact compatibility with the declared real Paper/JDA and optional integration versions;
- command propagation/cleanup timing and Discord rate-limit recovery;
- every module combination during reload and shutdown;
- role hierarchy and permission changes in a real guild;
- sqlite-jdbc `VACUUM INTO`/transaction behavior on the target host and filesystem;
- high-volume queue, chat, support-flow, voice, Redis, and database behavior;
- Folia compatibility, which is not claimed.

A discovered live-test failure must be added to this ledger before a public binary release.
