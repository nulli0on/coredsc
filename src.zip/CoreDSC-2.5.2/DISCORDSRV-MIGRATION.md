# Migrating from DiscordSRV

CoreDSC 2.5.2 includes a local, non-destructive DiscordSRV importer. It exists to reduce manual setup for administrators who deliberately choose to switch plugins. It does not modify, disable, delete, or upload the DiscordSRV installation.

## Commands

Preview the migration without changing CoreDSC:

```text
/coredsc migrate DiscordSRV preview
```

Apply it:

```text
/coredsc migrate DiscordSRV
```

The command requires `coredsc.migrate`, which defaults to server operators. It is blocked through CoreDSC's Discord remote-console bridge.

## What is migrated

Where an equivalent CoreDSC setting exists, the importer can map:

- Discord bot token and guild ID
- Discord/Minecraft chat channels and directions
- Reverse-chat linked-account policy, bot/webhook filtering, and role filters
- Player webhook mode, username/message format, and compatible avatar URLs
- Discord canned responses
- Console feed channel, levels, batching, and safe allowlisted remote commands
- Startup, shutdown, join, first-join, quit, death, and advancement events
- Required account linking, invite URL, linked role, and not-linked message
- Nickname synchronization
- LuckPerms group/role mappings and authority direction
- Bidirectional ban synchronization
- Discord status-channel online/offline names
- DiscordSRV proximity-room category, lobby, distance, visibility, and update settings
- Linked accounts from the running DiscordSRV API, `accounts.aof`, or legacy `linkedaccounts.json`

## Safety behavior

- Existing custom CoreDSC values win over migrated defaults.
- Every changed CoreDSC file is backed up before replacement.
- Files are staged and moved into place only after they serialize successfully.
- If account import fails after configuration writes, CoreDSC restores the configuration backups.
- Existing linked-account pairs are kept.
- UUID or Discord-ID conflicts are skipped and reported; they are never overwritten.
- DiscordSRV files are read-only during migration.
- DiscordSRV is never disabled, deleted, renamed, or reconfigured.
- Unsupported or ambiguous settings are listed for manual review instead of guessed.

Reports and backups are written to:

```text
plugins/CoreDSC/migrations/discordsrv-YYYYMMDD-HHMMSS/
├── report.txt
└── backup/
```

Preview runs also create a report, but do not write configuration or account data.

## Important limitations

CoreDSC does not have exact equivalents for every DiscordSRV option. In particular:

- Discord user-ID blacklists are not imported.
- Role display-selection rules are not treated as access-control rules.
- One-way ban synchronization is reported but not automatically enabled, because CoreDSC's current ban module is bidirectional.
- Avatar formats containing DiscordSRV's `{texture}` placeholder keep CoreDSC's default avatar provider.
- JDBC-linked accounts are imported through the running DiscordSRV API. Keep DiscordSRV enabled during the migration preview/apply operation when its JDBC backend is in use.
- Migration writes configuration files but does not reload them automatically. Review the report and restart cleanly.

## Recommended cutover

1. Back up the complete server and database.
2. Keep DiscordSRV installed and running.
3. Run `/coredsc migrate DiscordSRV preview`.
4. Review the generated report and resolve warnings.
5. Run `/coredsc migrate DiscordSRV`.
6. Review the backups and migrated CoreDSC files.
7. Stop Paper cleanly.
8. Remove or disable DiscordSRV before starting Paper again.
9. Start with CoreDSC and run `/coredsc doctor` and `/coredsc status`.
10. Test linking, both chat directions, webhooks, status channels, role synchronization, and console policy.

Do not start both plugins with the same Discord bot token. Two active gateway clients and duplicate listeners can produce reconnect loops or duplicate messages.
