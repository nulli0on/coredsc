# CoreDSC privacy and local-data statement

## bStats

CoreDSC uses the official bStats Bukkit client when enabled. CoreDSC custom charts contain only fixed categories, numeric buckets, and capped aggregate activity counts. See `BSTATS-METRICS.md` for the exact registry.

CoreDSC custom charts do not add player/Discord identities, guild/channel/role IDs, server addresses/names, messages, commands, support content, URLs, tokens, passwords, database values, script/workflow names, or arbitrary configuration strings.

Disable CoreDSC charts in `plugins/CoreDSC/telemetry.yml` and all bStats collection in `plugins/bStats/config.yml`. A valid opt-out from the obsolete `license.yml` is preserved during upgrade.

## Local operational data

Depending on enabled modules, CoreDSC stores operational data locally, including account links, pending link codes, reward state, queue entries, moderation/support records, audit records, and workflow state. This data is required for those features and is not sent through CoreDSC custom bStats charts.

`plugins/CoreDSC/state/discord-command-scopes.txt` stores global/guild command scopes, including guild IDs, solely so stale commands can be cleaned after restart. It is local-only.

## Backups

Configuration and database migration backups can contain secrets, Discord/Minecraft identifiers, message/support content, and other production data. Restrict filesystem access, exclude them from public support bundles, and delete them only after the upgrade is accepted.

## Python and external services

Administrator-installed Python scripts are trusted local code and can access data available to the server process. Redis/network modules transmit configured operational events to the administrator's Redis infrastructure. Webhooks and external avatar templates send data to their configured external providers. These are feature operations, not CoreDSC bStats telemetry.
