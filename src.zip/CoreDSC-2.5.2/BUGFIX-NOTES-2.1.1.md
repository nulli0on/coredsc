# CoreDSC 2.1.1 bugfix notes

## Maven error addressed

The reported compiler error came from two JDA event classes imported from the
wrong package. In JDA 6.5.0 the role-add/remove event classes are under
`net.dv8tion.jda.api.events.guild.member`, not `.member.update`.

CoreDSC 2.1.1 deliberately uses `GuildMemberUpdateEvent` instead. JDA documents
this event as firing for every member update regardless of member cache, which
keeps the role synchronization compatible with `JDABuilder.createLight(...)`
without forcing a full Discord member cache.

## Additional corrections

- Retry pending role synchronization after Discord session resume.
- Guard asynchronous LuckPerms continuations during module reload/disable.
- Correct kick/quit duplicate suppression.
- Move JDA construction away from the Paper main thread.
- Close the listener-registration race introduced by asynchronous startup.
- Reduce the optional Redis worker count from four to two.

## Not claimed

This source was not compiled or run in this environment. A successful local
`mvn clean package` remains the authoritative compile check.
