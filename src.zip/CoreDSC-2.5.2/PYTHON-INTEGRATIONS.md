# Python and Plugin Integrations

CoreDSC's optional Python worker lets administrators add commands and event automation without embedding Python in the JVM. Scripts run in a separate local process and return a bounded list of actions that Java validates.

Configuration:

```text
plugins/CoreDSC/bot/config.yml
plugins/CoreDSC/bot/scripts/*.py
```

Enable the worker:

```yaml
enabled: true
python-executable: auto
```

Then run:

```text
/coredsc reload
/coredsc bot status
```

## Receive an event in Python

```python
from coredsc_api import event

@event("bossfight_started")
def bossfight_started(ctx):
    boss = ctx.event.data.get("boss", "Unknown boss")
    ctx.discord.send(
        "123456789012345678",
        f"A boss fight against **{boss}** has started!",
        durable=True,
        dedupe_key=f"boss-start:{boss}",
    )
```

For every custom event:

```text
ctx.event.name     normalized event name
ctx.event.source   coredsc, java-api, bukkit-event, or command:<sender>
ctx.event.data     JSON-safe event payload
```

Payload fields are also copied directly onto `ctx.event` for compatibility.

`ctx.plugins` contains installed plugin names with `enabled` and `version` values.

## Route 1 — Public Java API

Another Bukkit plugin can publish an event without depending on CoreDSC internals:

```java
CoreDSCApi api = Bukkit.getServicesManager().load(CoreDSCApi.class);
if (api != null) {
    api.publishPythonEvent("bossfight_started", Map.of(
            "boss", bossName,
            "arena", arenaName
    ));
}
```

The future resolves to `true` when a ready Python worker has at least one handler for that event. It resolves to `false` when the module or matching handler is unavailable.

Declare CoreDSC as a soft dependency when the integration is optional.

## Route 2 — Configurable Bukkit event adapter

This route requires no code changes in the third-party plugin. CoreDSC loads one explicitly named Bukkit event class from the configured source plugin and reads only listed public no-argument properties.

```yaml
integrations:
  bukkit-events:
    enabled: true
    registrations:
      - id: vote
        enabled: true
        plugin: NuVotifier
        event-class: com.vexsoftware.votifier.model.VotifierEvent
        python-event: vote_received
        priority: MONITOR
        ignore-cancelled: true
        include-metadata: true
        fields:
          username: vote.username
          service: vote.serviceName
```

The exact event class and accessor paths depend on the installed plugin version. Verify them in that plugin's official API or source. A wrong plugin name, class, or property is logged and skipped; it does not disable the entire Python module.

Property paths use public JavaBean accessors or record components. For `vote.username`, CoreDSC accepts `getVote()`/`isVote()` (or a `vote` record component), then `getUsername()`/`isUsername()` (or a `username` record component). Arbitrary no-argument method names are not invoked.

Security bounds:

- maximum 100 configured bridge registrations
- maximum 50 configured fields per bridge
- bridge IDs are limited to 64 safe characters and event class names to 256 characters
- maximum property depth 8
- only public no-argument non-void methods
- blocked reflective/object methods such as `getClass`, `wait`, and `notify`
- bounded collection/map size and nesting before JSON serialization

Example script:

```python
from coredsc_api import event

@event("vote_received")
def vote_received(ctx):
    user = ctx.event.data.get("username", "unknown")
    service = ctx.event.data.get("service", "unknown service")
    ctx.discord.send(
        "123456789012345678",
        f"**{user}** voted on {service}.",
        durable=True,
    )
```

## Route 3 — Command bridge

Many boss, vote, quest, or scheduler plugins can execute console commands when an event occurs. Configure them to run:

```text
coredsc emit bossfight_started boss=Infernal_Golem arena=volcano
```

Test manually:

```text
/coredsc emit bossfight_started boss=Infernal_Golem arena=volcano
```

Requirements:

- Python module enabled and ready
- a matching `@event("bossfight_started")` handler loaded
- `coredsc.emit` permission for player senders; console is permitted

Arguments use `key=value` with no spaces inside one value. Use underscores or let the external plugin provide its own placeholder formatting.

## Durable Discord messages

```python
ctx.discord.send(
    channel_id,
    "Important event",
    durable=True,
    dedupe_key="optional-stable-key",
)
```

When the delivery-queue module is enabled, durable messages are written to SQLite and retried with bounded backoff. When `durable=True` is requested while the delivery queue is disabled, the action fails explicitly. CoreDSC does not silently downgrade an important durable message to a best-effort immediate send.

Use a dedupe key only when repeated triggers should represent the same logical message. A unique event should use a unique key or no key.


## Script loading and SDK isolation

CoreDSC places its bundled runtime directory before administrator scripts on `sys.path`. A user file named `coredsc_api.py` therefore cannot replace the SDK imported by other scripts.

Script registration is transactional. If a script registers commands or events and then raises during import, those partial registrations are rolled back. A crashed or stopped worker publishes an empty command/event snapshot so stale commands are removed from Java.

The worker suppresses Python bytecode generation in the plugin data tree; release and test runs should not create `__pycache__` or `.pyc` files.

## Available action helpers

```python
ctx.reply("command reply")
ctx.log("message", level="INFO")
ctx.discord.send(channel_id, message, durable=False)
ctx.discord.add_role(role_id, user_id="")
ctx.discord.remove_role(role_id, user_id="")
ctx.minecraft.broadcast(message)
ctx.minecraft.send(message, player_uuid="")
ctx.minecraft.console(command_line)
ctx.ticket.create(reason, message, player_uuid="")
ctx.report.create(target, reason, message="", reporter_uuid="")
```

Sensitive actions are controlled in `bot/config.yml`. Console commands are disabled by default and must match an explicit prefix allowlist.

## Operational checks

```text
/coredsc bot scripts
/coredsc bot restart
/coredsc doctor
/coredsc status
```

`/coredsc doctor` reports active/configured event adapters. Read the server log for the exact reason a bridge was skipped.

## Trust boundary

Python scripts are administrator-trusted code. The worker isolates the message protocol and action validation, but it is not a hostile-code sandbox. Do not install scripts from unknown sources and do not enable console actions more broadly than necessary.
