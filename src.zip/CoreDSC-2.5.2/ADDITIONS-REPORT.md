# CoreDSC 2.5.2 additions report

This candidate adds four deliberately small reliability and maintenance improvements to the rechecked CoreDSC 2.5.1 source.

## 1. Configuration-key diagnostics

- Compares every managed YAML file with its bundled schema/default resource.
- Warns about unknown paths without deleting or rewriting them.
- Provides conservative typo suggestions only within the same YAML section.
- Collapses unknown subtrees into one warning to avoid console spam.
- Reports the obsolete `license.yml` and its former `metrics.enabled` path explicitly.
- Exposes warnings through startup output, `/coredsc status`, and `/coredsc doctor`.
- Restores both the prior runtime configuration and prior warning snapshot when reload rollback is required.

## 2. Startup action summary

- Runs ten seconds after CoreDSC reaches its internal READY state.
- Prints nothing when no unresolved action exists.
- Deduplicates configuration, module, Discord, guild-resolution, and command-registration warnings.
- Limits console output to twelve items and directs administrators to `/coredsc doctor` for the complete report.
- Does not treat intentionally disabled optional modules as failures.

## 3. Per-module operational health

For every enabled module, CoreDSC now tracks in memory:

- initial enable timestamp;
- most recent successful instrumented action;
- successful-action count since startup;
- most recent runtime failure and its concise cause.

The values are shown by `/coredsc doctor`. They are operational diagnostics, not persistent player analytics. No identifiers or message content are added.

## 4. Central scheduler boundary

- Added `CoreScheduler` and `CoreTask` interfaces.
- Added the current `PaperCoreScheduler` implementation.
- Routed CoreDSC-owned global, delayed, repeating, asynchronous, entity, and location scheduling through the boundary.
- Removed direct Bukkit scheduler calls from modules and services outside the scheduler package.
- Returned cancellable handles for queued work.

This makes later Folia work less invasive, but **CoreDSC 2.5.2 does not claim Folia support**. A real Folia implementation and regional ownership tests are still required.

## Verification completed here

The bundled source-only suite passes:

- static source/config/security audit;
- 2.4.3 configuration migration fixtures;
- pure configuration-key inspector compile/self-test;
- scheduler adapter compile/self-test, including entity/location queued handles;
- module operational-health compile/self-test;
- Python worker isolation test;
- DiscordSRV migration focused compile/self-test;
- duplicate database migration conflict fixture;
- dependency-free all-source diagnostic with no syntax-like error and no new non-dependency type diagnostic versus 2.5.1.

`tools/verify_build.sh` intentionally exits with code 127 after these passes because Maven is unavailable in this workspace.

## Verification not completed here

- Full `mvn clean verify` against real dependencies.
- A generated or runtime-tested JAR.
- Live Paper startup, reload, shutdown, and task cancellation.
- Live Discord guild/command/reconnect behavior.
- Folia execution.

A public binary should only be produced after those checks pass.
