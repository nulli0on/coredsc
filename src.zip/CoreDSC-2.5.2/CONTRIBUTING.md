# Contributing to CoreDSC

## Development requirements

- Java 21
- Maven
- Python 3.8+ for worker tests
- A disposable Paper test server for integration tests

## Workflow

1. Create a focused branch.
2. Keep modules opt-in when they introduce privileged behavior or external dependencies.
3. Add configuration comments and documentation for user-visible changes.
4. Run `python3 tools/static_audit.py`.
5. Run `mvn clean verify`.
6. Test the changed module on a disposable Paper server.

Do not commit Discord tokens, relay tokens, server databases, player data, or production configuration.

## Design rules

- Never block the Paper main thread on Discord, SQLite, network, or Python work.
- Route Bukkit API access back to the main thread unless the API explicitly allows asynchronous use.
- Bound queues, retries, payloads, and reflection.
- Avoid hard dependencies when an integration can use Bukkit services, events, or configuration.
- Preserve backward-compatible configuration fallbacks where practical.
- Log failures with actionable context without exposing secrets.

## Pull requests

Describe:

- the problem and intended behavior
- configuration changes
- security/threading implications
- tests performed
- known verification gaps

By contributing, you agree that your contribution is distributed under the repository's MIT License.
