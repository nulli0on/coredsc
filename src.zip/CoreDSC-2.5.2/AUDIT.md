# CoreDSC 2.5.2 recheck audit

## Result

The 2.5.0 source candidate was re-audited from the untouched 2.4.3 source instead of relying on its earlier report. The recheck found additional material defects. They are corrected in this 2.5.2 source candidate.

This package is **source-verified, not production-certified**. A dependency-resolved Maven build and live Paper/JDA tests were not available in this workspace, so no binary JAR is included.

## Scope

The review covered startup/shutdown, Discord lifecycle and slash-command scope handling, module reload recovery, configuration migration, SQLite migration, optional Python behavior, bStats privacy/state, listener/task ownership, source/resources, packaging, and documentation consistency. DiscordSRV was used only as a reliability reference.

## Material findings and corrections

| ID | Severity | Finding | Correction | Verification boundary |
|---|---|---|---|---|
| CDSC-001 | High | Guild command mode silently fell back to global commands when the configured guild was unavailable. | Removed the fallback. Guild mode resolves exactly the configured positive ID or reports failure. | Source checks pass; live JDA required. |
| CDSC-002 | High | Reload could leave configuration/modules partially switched. | Added rollback-protected reload with active-config snapshot and module restoration. | Source checks pass; live Paper required. |
| CDSC-003 | Medium | Reconnect callbacks could use settings captured before reload. | Lifecycle callbacks now resolve current active settings. | Source/focused review; live reconnect required. |
| CDSC-004 | High | YAML files lacked a complete schema/migration contract. | Added schema v4, additive defaults, future-version blocking, backups, atomic writes, and migration-session rollback. | Fixture/source tests pass; Paper YAML runtime required. |
| CDSC-005 | Medium | Patch-version-only YAML rewrites could unnecessarily destroy comments. | Current files are not rewritten solely to update `generated-by-version`. | Source/config tests pass. |
| CDSC-006 | Medium | bStats configuration was coupled to obsolete `license.yml`. | Removed bundled license configuration; active settings live in `telemetry.yml`. | Static/package checks pass. |
| CDSC-007 | Medium | Doctor output promoted bStats and blurred guild/command health. | Default doctor focuses on operational health; telemetry has separate status output. | Source checks pass; live rendering required. |
| CDSC-008 | Medium | Optional Python attempted startup by default and produced a misleading missing-executable failure. | Worker is manual-start by default and validates executable/script before spawn. | Protocol/isolation tests pass; OS runtime required. |
| CDSC-009 | Medium | Telemetry did not show broad feature adoption. | Added bounded, allowlisted successful-action categories without IDs/content. | Privacy/instrumentation checks pass; live bStats required. |
| CDSC-010 | Low | Manage Roles was reported as required even when no enabled feature needed it. | Requirement is now conditional on role-mutating features. | Source check; live guild test required. |
| CDSC-011 | Low | Startup banner lacked requested structured branding. | Added configurable full/compact/off banner and console-color option. | Source/resource check; visual runtime required. |
| CDSC-012 | High | Reload rollback could be reported successful even when previously working modules did not return. | Rollback verifies restoration of every previously working module. | Source invariant; live failure injection required. |
| CDSC-013 | High | Slash-command scope history existed only in memory, so old guild/global commands could survive a restart after scope changes. | Successful scopes persist atomically in `state/discord-command-scopes.txt` and are retried for cleanup. | Focused Java compile/source checks; live Discord required. |
| CDSC-014 | High | Core-owned Python runtime files were overwritten outside migration backup/rollback. | Runtime files now participate in the managed-resource migration transaction. | Source/config tests pass. |
| CDSC-015 | High | SQLite schema upgrades had no consistent pre-migration snapshot and no enclosing transaction. | Added `VACUUM INTO` snapshot, explicit transaction, rollback, and future-schema blocking. | Focused Java compile/source simulation; sqlite-jdbc runtime required. |
| CDSC-016 | High | Legacy duplicate link/account rows were silently deleted before uniqueness constraints. | Migration now stops without deleting data and reports the duplicate groups; the snapshot is retained. | Conflict fixture passes; sqlite-jdbc runtime required. |
| CDSC-017 | Medium | Feature counters could keep accumulating while metrics were disabled, stopped, or failed during startup. | Counters are disabled and cleared for disabled/failed/stopped states. | Static state checks pass. |
| CDSC-018 | High | A listener added while JDA was being built could be attached twice. | Listener publication/reconciliation is atomic under one lock. | Focused Java compile/source checks; live race test required. |
| CDSC-019 | Process | The 2.5.0 report overstated source checks as broader build/type verification. | Verification tiers are now explicit; unavailable compilation/runtime work is marked not run. | Report/package review. |
| CDSC-020 | Medium | A prior `license.yml` bStats opt-out could be reset to the new default. | A valid old `metrics.enabled: false` is preserved fail-safely in `telemetry.yml`; it never re-enables an existing opt-out. | Fixture/source checks pass; Paper migration required. |
| CDSC-021 | High | Rollback treated a module already failed before reload as a new fatal rollback failure. | Rollback protects the previously working module set instead of demanding that previously failed optional modules suddenly recover. | Source invariant; live degraded-runtime reload required. |
| CDSC-022 | Medium | Obsolete command cleanup failures were logged but the new registration could still be reported READY. | New commands may still register, but health is FAILED/degraded with exact cleanup/state-tracking problems and retained retry state. | Focused Java compile/source checks; live Discord required. |
| CDSC-023 | Medium | Metrics startup failure left activity collection enabled in memory. | Startup failure disables and clears counters. | Static state check. |
| CDSC-024 | High | Importing the old metrics switch could modify an unknown future `telemetry.yml` before schema validation. | `telemetry.yml` is validated/migrated first; only then is the obsolete preference imported. | Ordering invariant/config test passes. |
| CDSC-025 | Low | YAML typos and obsolete settings were difficult to distinguish from plugin defects. | Added non-destructive unknown-key detection with conservative same-section suggestions and explicit obsolete `license.yml` reporting. | Pure Java key-inspector self-test and source audit pass; Bukkit YAML runtime required. |
| CDSC-026 | Low | Administrators had to search the complete log for unresolved startup problems. | Added a delayed, deduplicated startup action summary that prints only unresolved warnings. | Source invariant passes; live timing/rendering required. |
| CDSC-027 | Low | Enabled module status did not show whether a module had actually performed work or recently failed. | Added per-module enable time, last success, successful-action count, and last failure state. | Module-health self-test passes; live module instrumentation requires runtime testing. |
| CDSC-028 | Maintainability | Scheduler calls were spread throughout modules, increasing future Folia migration cost. | Added a central Paper scheduler boundary and routed all current scheduler calls through it. | Scheduler self-test and no-direct-scheduler invariant pass; Folia support is not claimed. |

## Guild and slash-command behavior

Guild registration now:

1. parses the configured ID as a positive snowflake;
2. waits for the current JDA generation to be ready;
3. resolves exactly that guild;
4. never substitutes global registration;
5. serializes clear-and-register operations to avoid out-of-order REST completion;
6. persists known successful scopes for cleanup after restart;
7. reports incomplete cleanup/state persistence as a failed/degraded registration state.

Historical command scopes from releases that never wrote the state file cannot be inferred automatically when they are no longer configured or visible. Administrators may need to remove those once manually.

## Configuration migration contract

Every maintained YAML resource uses:

```yaml
config-version: 4
generated-by-version: "2.5.2"
```

Startup migration preserves existing values, adds missing defaults, blocks future schemas, backs up files before modification, writes through temporary replacement files, and restores touched/created files after a later migration failure. A genuine Bukkit YAML rewrite may not preserve all comments; the backup retains the exact original.

The old `license.yml` is not active configuration. Its former Boolean bStats choice is imported only after `telemetry.yml` passes schema validation. An old opt-out wins; an old opt-in never overrides an existing opt-out.

## SQLite migration contract

For an existing older database, CoreDSC creates a consistent snapshot under `plugins/CoreDSC/backups/`, then applies schema changes in a transaction. Unknown future schemas are blocked. Ambiguous duplicate account/link values stop migration without choosing or deleting a row.

Migration backups can contain player/Discord identifiers, support content, audit records, and other server data. Protect them like the primary database and delete them only after accepting the upgrade.

## Telemetry privacy boundary

CoreDSC custom charts use only fixed categories, numeric buckets, and bounded counters. They do not add guild/channel/role/user IDs, UUIDs, player names, server addresses, message/command/support content, tokens, webhook URLs, credentials, script/workflow names, or arbitrary values.

The local command-scope state file contains guild IDs required for cleanup and is not submitted to bStats. Local databases/configuration/backups may contain operational user data by design; they are not telemetry.

## Folia boundary

This release does not claim Folia support. CoreDSC-owned scheduling now passes through a central Paper adapter, including global, asynchronous, entity, and location entry points. The Paper adapter still uses Bukkit scheduling semantics; actual Folia support requires a separate Folia implementation plus regional ownership and runtime tests.

## Final verification boundary

Completed here:

- archive/resource/config/source hygiene;
- 76 Java lexical/package/import checks;
- 29 YAML parses and schema checks;
- 5 Python syntax checks;
- config migration fixture/invariant tests;
- Python worker protocol/isolation test;
- DiscordSRV migration focused compile/pure-logic test;
- voice topology focused compile/self-test;
- SQLite SQL simulation and duplicate-conflict fixture;
- focused Java 21 compilation of `SQLiteStorage` and `DiscordBotService` against local test stubs;
- dependency-free all-source javac diagnostic with zero syntax-like diagnostics.

Not completed here:

- full `mvn clean verify`;
- compilation against the real Paper/JDA/VoiceChat/LuckPerms/AuthMe/Redis dependency graph;
- live Paper startup/reload/shutdown;
- live Discord gateway, command propagation/cleanup, rate limits, permissions, and reconnects;
- real sqlite-jdbc migration execution;
- real 2.4.3 server-folder upgrade;
- load/soak testing.

No public JAR should be produced from this report alone.
