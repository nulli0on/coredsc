# VoiceChat Setup

CoreDSC 2.5.2 supports **Discord-only proximity rooms**. It creates temporary Discord voice channels and moves linked Discord users according to Minecraft proximity.

Configuration file:

```text
plugins/CoreDSC/modules/voicechat-sync.yml
```

## Current support boundary

Discord voice connections require a DAVE implementation. CoreDSC 2.5.2 does not bundle a verified, cross-platform DAVE provider and its platform-specific native libraries. Therefore:

- Discord-only proximity room creation and member movement are supported.
- Minecraft-to-Discord audio relay is disabled.
- Discord-to-Minecraft audio relay is disabled.
- Relay bot tokens are not used by this release.
- Enabling either audio direction is rejected safely and reported by `/coredsc doctor`.

Keep both audio directions disabled:

```yaml
audio:
  minecraft-to-discord:
    enabled: false
    gain: 1.0
  discord-to-minecraft:
    enabled: false
    gain: 1.0
```

This is intentional fail-closed behavior. It is safer than starting relay bots that cannot complete encrypted Discord voice negotiation on some hosts.

## Step 1 — Prepare Discord

Create:

1. A category such as `CoreDSC Proximity`.
2. A voice channel inside it such as `Proximity Lobby`.

Give the main CoreDSC bot these permissions on the category and lobby:

- View Channel
- Manage Channels
- Manage Permissions
- Move Members

No secondary relay bots are required for the supported mode.

## Step 2 — Enable the voice-state intent

Enable **Voice States Intent** in the Discord Developer Portal. CoreDSC requests `GUILD_VOICE_STATES` when `voicechat-sync` is enabled.

Server Members Intent is only needed when another enabled module uses member data.

## Step 3 — Set category and lobby IDs

Copy IDs with Discord Developer Mode and run:

```text
/coredsc setup set voice-category <category-id>
/coredsc setup set voice-lobby <lobby-channel-id>
```

Or edit:

```yaml
discord:
  guild-id: 0
  category-id: '123456789012345678'
  lobby-channel-id: '123456789012345679'
```

`guild-id: 0` uses `discord.guild-id` from `config.yml`.

## Step 4 — Recommended configuration

```yaml
enabled: true

discord:
  guild-id: 0
  category-id: '123456789012345678'
  lobby-channel-id: '123456789012345679'

proximity:
  horizontal-distance: 48.0
  vertical-distance: 24.0
  falloff: 6.0
  minimum-players: 2
  update-ticks: 10

rooms:
  maximum-active-rooms: 12
  name-prefix: coredsc-proximity
  channels-visible: true
  allow-linked-guests: true
  allow-unlinked-guests: false
  guest-role-ids: []
  create-solo-on-speech: false
  speech-activity-seconds: 4
  close-grace-seconds: 20
  cleanup-managed-channels-on-startup: true

relay-bots:
  token-environment-variables: []

audio:
  minecraft-to-discord:
    enabled: false
    gain: 1.0
  discord-to-minecraft:
    enabled: false
    gain: 1.0
  max-buffered-frames: 100
  max-mixed-sources-per-frame: 32

security:
  require-linked-accounts: true
  include-unlinked-minecraft-players: false
  require-discord-deafened-for-minecraft-relay: true
  opt-out-permission: coredsc.voice.optout
```

`create-solo-on-speech` must remain false in this release because Simple Voice Chat microphone relay is not active.

## Step 5 — Linking and lobby behavior

Automatic movement applies to linked online players who are in the configured lobby or another CoreDSC-managed room. CoreDSC does not pull users out of unrelated Discord voice channels.

Recommended defaults:

```yaml
security:
  require-linked-accounts: true
  include-unlinked-minecraft-players: false
```

`allow-linked-guests: true` can use `discord.link-role-id` as a guest role. Add other permitted Discord roles under `guest-role-ids`.

## Step 6 — Enable and verify

```text
/coredsc setup enable voicechat-sync
/coredsc reload
/coredsc doctor
/coredsc doctor test voice
/coredsc status
```

## Test checklist

1. Link two Minecraft players to two Discord accounts.
2. Put both Discord users in the proximity lobby.
3. Stand within the configured Minecraft distance.
4. Confirm a temporary room appears and both users are moved.
5. Move apart beyond distance plus falloff.
6. Confirm the room splits or closes after the grace period.
7. Set one audio direction to true temporarily and reload.
8. Confirm CoreDSC refuses the relay path, logs the DAVE capability error, and keeps room management running.
9. Restore both direction toggles to false.

## Troubleshooting

### Module fails with category/lobby error

The IDs are blank, invalid, from another guild, or not visible to the bot.

### Rooms appear but users are not moved

Check account linking, lobby membership, Voice States Intent, and Move Members permission. The bot's highest role must also be positioned appropriately.

### Doctor reports cross-platform audio disabled

One or both audio direction toggles are true. Set both to false. Relay tokens do not make the unsupported path available in 2.5.2.

### Too many temporary rooms

Lower proximity distance, raise `minimum-players`, or increase `maximum-active-rooms` only after checking Discord channel limits.

## Verification boundary

The repository includes a topology self-test for split, merge, hysteresis, and world isolation. A real release still requires a live Paper server, Discord guild, and multiple linked users. No live Discord voice audio relay is claimed for 2.5.2.
