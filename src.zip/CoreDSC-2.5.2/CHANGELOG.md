# Changelog

## 2.5.2 — Small reliability and maintenance improvements

- Added non-destructive warnings for unknown YAML keys with typo suggestions.
- Added explicit reporting for the obsolete `license.yml` metrics setting.
- Added a delayed startup action summary containing only unresolved warnings.
- Added per-module enable time, last successful action, successful-action count, and last failure details to `/coredsc doctor`.
- Added successful first-link reward activity tracking without collecting user identifiers.
- Added a central Paper scheduler boundary and routed existing CoreDSC scheduling through it.
- Added entity/location scheduling entry points for a future Folia implementation without claiming Folia support.
- Added pure config-key, scheduler-boundary, and module-health self-tests.

## 2.5.1 — Rechecked reliability candidate

### Fixed

- Removed silent guild-to-global slash-command fallback.
- Serialized slash-command cleanup/registration and made incomplete cleanup visible.
- Persisted successful command scopes for stale-command cleanup across restart.
- Prevented Discord listener double-attachment during JDA publication.
- Made reload rollback verify restoration of previously working modules without treating pre-existing failed optional modules as a new fatal rollback failure.
- Added YAML schema v4, future-version blocking, backups, atomic replacement, and migration-session rollback.
- Managed Core-owned Python runtime files through the same backup/rollback path.
- Preserved the obsolete `license.yml` bStats opt-out after validating `telemetry.yml`; future telemetry schemas are never modified first.
- Added SQLite pre-migration snapshot, transaction/rollback, future-schema blocking, and non-destructive duplicate conflict handling.
- Stopped/cleared feature counters when metrics are disabled, fail startup, or the plugin stops.
- Made the optional Python worker manual-start by default.
- Scoped Manage Roles diagnostics to features that actually mutate roles.
- Avoided YAML rewrites solely for patch-version metadata.

### Added

- Explicit guild-resolution and command-registration health states.
- Privacy-safe successful-feature counters using fixed categories.
- Configurable full/compact/off startup banner.
- Recheck audit, bug ledger, test report, privacy statement, migration conflict fixture, and stricter release checklist.

### Verification boundary

This source package passed the included offline/source tests and focused local compilations. It was not built against the full Maven dependency graph and was not run on Paper/Discord in this workspace. No JAR is included.

## 2.4.3 — DiscordSRV migration patch

### Added

- `/coredsc migrate DiscordSRV preview` for a read-only compatibility report.
- `/coredsc migrate DiscordSRV` for a local, non-destructive import of supported DiscordSRV settings and linked accounts.
- Mapping for chat channels/directions, webhook identity, reverse-chat policy, canned responses, console feed and allowlist, server events, linking enforcement, nickname/LuckPerms/ban synchronization, status updaters, and Discord-only proximity-room settings.
- Linked-account import through DiscordSRV's running account-link API, `accounts.aof`, or legacy `linkedaccounts.json`.
- Per-run reports and backups under `plugins/CoreDSC/migrations/`.
- A focused Java 21 migration compile/pure-logic regression test.

### Safety

- Existing CoreDSC custom values are preserved.
- Identical account links are retained; UUID/Discord-ID conflicts and invalid rows are skipped and reported.
- Configuration writes are staged and restored from backups if migration/account import fails.
- DiscordSRV files are never modified, disabled, deleted, renamed, or uploaded.
- Unsupported or ambiguous options are reported instead of guessed.
- Migration is unavailable through the Discord remote-console bridge.

### Verification note

- All supplied DiscordSRV configuration keys used by the importer were checked against the provided DiscordSRV source tree.
- Source audit, migration compile/self-test, Python worker test, topology test, YAML/XML/SQL checks, and packaging hygiene pass in this workspace.
- A full dependency-resolved Maven build and live Paper/Discord cutover test remain required before publishing a binary.

## 2.4.2 — Offline status and official bStats metrics patch

### Added

- Separate configurable `online-name` and `offline-name` templates for every Discord status channel.
- A configurable shutdown wait for publishing offline names before the Discord client stops.
- Official bStats Bukkit integration using plugin ID `32949`.
- Thirty-three bounded custom charts for module adoption, optional dependencies, chat/webhook configuration, account-link policy, networking, VoiceChat, Python extensions, workflows, support modules, and status-channel usage.
- Immutable chart snapshots captured on Paper's server thread so asynchronous bStats callbacks do not call Bukkit APIs.
- `BSTATS-METRICS.md` with the exact chart IDs/types, privacy boundary, website-registration checklist, and opt-out instructions.
- `/coredsc status` visibility for bStats state and the local-only license identifier state.

### Fixed

- Status channels no longer remain misleadingly named `Players Online: 0` after a normal Paper shutdown.
- Module reloads do not briefly publish the offline state.
- Existing `name:` status-channel configurations remain compatible as an alias for `online-name`.
- Offline status publishing is restricted to an actual Paper server shutdown, not plugin-only reload/disable operations.
- Removed the abandoned private telemetry endpoint prototype and its installation/license fingerprint design.

### License and metrics behavior

- No license validation or enforcement exists.
- The optional license value is never sent, hashed, fingerprinted, or used to unlock features.
- CoreDSC contacts only the official bStats collector through the unmodified bStats client.
- CoreDSC custom-chart values are fixed categories or count buckets; no player names/UUIDs, server addresses/domains, Discord IDs, chat, commands, URLs, secrets, or arbitrary free-form values are sent.
- The standard bStats client still follows the bStats privacy policy, including its pseudonymous server identifier and temporary IP processing for rate limiting.
- Metrics can be disabled per plugin in `license.yml` or globally in `plugins/bStats/config.yml`.
- Metrics failure or opt-out never blocks startup, disables CoreDSC, disables modules, or removes features.

### Verification note

- Static regression, YAML/XML/SQL/Python, worker isolation, topology, archive hygiene, bStats chart-registry, and targeted Java 21 compile checks pass in this workspace.
- Full Maven dependency resolution and live Paper/Discord/bStats submission testing remain required before publishing a binary.

## 2.4.1 — Second-pass correctness and fail-closed voice patch

### Fixed

- Fixed a Java compile blocker in reverse chat caused by an overlapping local variable declaration.
- Corrected Discord webhook-name validation and contained synchronous webhook/JDA failures.
- Prevented bot fallback after an ambiguous asynchronous webhook failure, avoiding possible duplicate Minecraft chat.
- Prevented invalid linked UUIDs and Discord snowflakes from crashing account lookups.
- Prevented rejected Python commands from consuming the global execution budget.
- Cleared dead Python registrations after worker crashes and rolled back registrations from scripts that fail during import.
- Prevented user scripts from shadowing CoreDSC's bundled Python SDK.
- Added bounded waits for Python-worker, server-event, and SQLite shutdown work.
- Marshalled external event payload serialization and VoiceChat account updates onto the Minecraft main thread.
- Restricted Bukkit event adapters to bounded, validated bridge IDs, class names, fields, and public bean/record accessors.
- Contained event-class linkage failures so one incompatible third-party adapter cannot abort the Python module.
- Corrected VoiceChat fallback defaults and contained synchronous member-move, room-rename, and relay-permission failures.
- Removed Python bytecode caches from the source distribution and prevented worker tests from regenerating them.

### Security and compatibility

- Cross-platform Discord/Simple Voice Chat audio now fails closed. JDA voice connections require DAVE, but this source release does not bundle a verified provider and all required platform-native artifacts.
- Discord-only proximity room creation and linked-member movement remain available.
- `/coredsc doctor` reports unsupported audio toggles instead of validating relay tokens for a path that cannot be guaranteed to work.

### Verification note

- Source-only static, YAML, XML, SQL, Python worker protocol, topology, Java parser, documentation JavaScript, secret, and archive-integrity checks pass in this workspace.
- Maven dependency resolution, Paper startup, Discord gateway/webhook tests, and live voice-room tests remain required before publishing a JAR.

## 2.4.0 — Open-source chat and integration update

### Added

- Account-aware Discord-to-Minecraft reverse chat with independent linked and unlinked user policies.
- Discord role allow/block lists, attachment rendering, reply context, denied notices, and expanded placeholders.
- Minecraft-to-Discord player webhooks with configurable username, HTTPS avatar URL, automatic creation, reuse, loop suppression, and bot fallback.
- Public `CoreDSCApi.publishPythonEvent` integration.
- Configurable third-party Bukkit event adapters for Python scripts.
- `/coredsc emit <event> [key=value ...]` command bridge.
- Durable Python Discord sends through the SQLite delivery queue.
- Plugin inventory in Python execution context.
- Rewritten chat, Python integration, and VoiceChat documentation.

### Changed

- Project version is 2.4.0.
- CoreDSC is distributed under the MIT License with contribution guidance.
- Startup no longer depends on any remote license service.
- Documentation clearly separates Discord-only voice rooms from cross-platform audio relays.
- VoiceChat now ships with Discord-only safe defaults; cross-platform audio and relay tokens are opt-in.
- The verification script now runs the bundled Python worker protocol self-test before Maven.

### Removed

- Remote license classes and `license.yml`.
- Skidfuscator profile and obfuscation configuration.

### Verification note

- Static source/YAML/Python/XML/schema checks can run with `tools/static_audit.py`.
- A full release still requires `mvn clean verify` and live Paper/Discord integration tests.

# CoreDSC 2.3.0

> Historical record from the earlier 2.3.0 package. Its build and live-test
> statements do not verify CoreDSC 2.4.0; use the current verification note above.

Reconstructed from the last trusted CoreDSC 2.2.0 source archive after the
previous unfinished checkpoint was lost.

## Added

- Canned Discord response rules with match modes, cooldowns, and optional
  forwarding suppression.
- Minecraft-to-Discord player webhooks with sanitized username/avatar,
  bot-owned webhook reuse/creation, and bot fallback.
- Live Discord console feed with batching, bounded queues, level/include/exclude
  filters, code-fence protection, mention suppression, and configurable
  redaction.
- Remote console modes `OFF`, `ALLOWLIST`, and `FULL` with guild/channel checks,
  role authorization, deny rules, per-user and global rate limits, one-command
  serialization, and persistent audit records and configurable retention.
- Discord nickname synchronization with original nickname persistence and
  guarded restoration.
- Initial bidirectional linked-account ban synchronization with ownership state,
  reflected-event suppression, operation locking, and audit warnings.
- Required-link enforcement with persistent grace periods, reminders, escape
  commands, and movement/chat/command/inventory/item restrictions.
- Persistent first-link rewards.
- Persistent Discord booster rewards with independent boost-cycle tracking.
- Event embeds, first-join/world/account/ticket/report events, and join/quit
  batching.
- `/coredsc doctor`, setup, status, and feature-test coverage for the new
  modules.
- JDA gateway intents and member caching where the enabled modules require them.
- Position-based Discord proximity rooms with a configured lobby, automatic
  linked-user movement, connected-component split/merge handling, room limits,
  guest roles, stale-room cleanup, and optional solo rooms triggered by Simple
  Voice Chat microphone activity.
- Per-room Discord relay-bot pool. Relays are allocated only when a room needs
  Discord ↔ Simple Voice Chat audio, with spatial Discord playback, per-speaker
  jitter queues, bounded buffering, headroom-aware mixing, reconnect handling,
  relay exhaustion reporting, and default echo protection.
- Module files:
  - `modules/ban-sync.yml`
  - `modules/booster-rewards.yml`
  - `modules/console.yml`
  - `modules/link-rewards.yml`
  - `modules/nickname-sync.yml`
  - `modules/voicechat-sync.yml`
- SQLite tables for rewards, boosters, nickname restoration, console audits,
  ban ownership, and required-link enforcement.
- `tools/static_audit.py` for repeatable source-only checks.
- `SECURITY.md` with deployment and incident guidance.

## Fixed and hardened

- Reward commands now use `PENDING -> EXECUTING -> COMPLETED` persistence.
  Ambiguous or interrupted dispatches are quarantined for manual review instead
  of being silently retried.
- A new Discord boost cycle no longer inherits the old cycle's rewarded-period
  counter.
- Linking and unlinking update online restriction state immediately.
- Required-link restrictions now cover drag, drop, pickup, and off-hand swap
  paths in addition to movement, chat, commands, and inventory use.
- Remote-console `FULL` mode requires an explicit acknowledgement and non-empty
  deny rules.
- Remote commands validate printable prefixes, reject control characters, limit
  burst volume, and cannot overlap.
- Rejected concurrent console commands no longer consume the global execution
  rate window.
- Webhook sends no longer use an application-level retry after an ambiguous
  failure, reducing duplicate player-chat risk.
- Nickname changes verify permission and role hierarchy, retain restoration
  records until Discord confirms success, and version per-account operations so
  delayed sync work cannot overwrite a newer unlink/restore decision.
- Ban synchronization no longer removes bans CoreDSC did not create, clears
  stale ownership after observed manual unbans, and serializes conflicting
  account operations with bounded retries.
- Successful linking clears old enforcement timestamps so a later unlink starts
  a fresh configured grace period.
- Async nickname, booster, ban, event, reward, and console paths stop initiating
  new actions after module disable. Already-dispatched ban and console actions
  retain captured persistence/audit state; ambiguous rewards require review.
- Event rendering keeps Bukkit and PlaceholderAPI access on the server thread;
  Discord delivery remains asynchronous.
- Failed event embeds can fall back to the persistent delivery queue.
- Remote-console mode is quoted as `'OFF'` in YAML so YAML 1.1 parsers do not
  interpret it as a boolean.
- VoiceChat API registration now happens before CoreDSC's asynchronous startup
  gates, avoiding Simple Voice Chat's plugin-discovery timing window.
- Minecraft microphone queues are separated per speaker so consecutive frames
  are not collapsed into one Discord frame; multi-speaker mixing applies
  progressive headroom and bounded back-pressure.
- Voice encoders, decoders, JDA handlers, Bukkit tasks and spatial channels are
  cleaned up during module disable and plugin shutdown.
- Removed the undeclared `javax.annotation.Nonnull` dependency that prevented
  the voice sources from compiling.
- Corrected the doctor queue-count future type and the booster timestamp lambda
  capture, both of which caused additional Java compilation failures.
- Ban-state inspection now uses Paper profile/UUID bans instead of unsupported
  name-based bans.
- Legacy modular migration now preserves Python-worker enablement and settings.
- Added the missing default report help messages.
- Enabled full javac lint output, removed shaded module descriptors, and added
  command, permission, module, migration and API-regression checks.

## Compatibility and schema

- Runtime and descriptor version: `2.3.0`.
- SQLite schema version: `10`.
- Java target remains 21.
- JDA declaration remains 6.5.0, including its audio and Discord voice
  encryption runtime dependencies.
- Simple Voice Chat API compile target is 2.6.20 and is provided by the installed
  voicechat plugin at runtime.
- New modules, including VoiceChat Sync, are disabled by default.

## Verification boundary

The complete 71-file Java source reaches Maven `verify` on Java 21. The shaded
JAR passes ZIP integrity, required-entry and provided-API exclusion checks. The
source audit passes for 29 YAML files, four Python files, `pom.xml`, 39 SQLite
migration statements, 96 fixed prepared statements, plugin descriptor parity,
configuration migration regressions and the proximity topology self-test.

The PaperMC and MaxHenkel repositories were unreachable in the review
environment. Compile-only verification stubs were used for those two provided
APIs and are not bundled. No Paper server, Discord login, Redis connection,
Simple Voice Chat client session, relay-bot connection, live license request or
load test was executed. This changelog does not claim stable-release readiness.
