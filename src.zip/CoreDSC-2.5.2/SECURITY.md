# CoreDSC Security

## Supported release

Security fixes in this package target CoreDSC 2.5.x. Replace older private, remotely licensed, or obfuscated builds rather than patching them in place.

## Secrets

Prefer an environment variable for the main bot token:

```yaml
discord:
  token-source: ENV
  token-env-name: COREDSC_BOT_TOKEN
```

Never publish bot tokens, webhook URLs, `secrets.yml`, production databases, or unredacted support logs. Reset an exposed token in the Discord Developer Portal before restarting the server.

`secrets.yml` is parsed strictly. Tokens and passwords are excluded from doctor output, migration logs, telemetry, and support documentation.

## Configuration integrity

Every maintained YAML file has a schema version. CoreDSC backs up files before migration, uses replacement writes, rolls back touched files after migration failure, and blocks unknown future schemas. Guild-mode command registration fails closed rather than silently becoming global.

Keep migration backups until the upgraded server has passed testing. Configuration and database backups may contain credentials, identifiers, messages, support/audit data, and other production information; restrict access and never attach them unredacted. Do not edit `config-version` manually.

## Official bStats

CoreDSC uses only the official bStats Bukkit client with plugin ID `32949`. There is no private metrics endpoint and no licensing relationship.

Custom charts use fixed categories and bounded counts. They do not send player identity, server identity, Discord IDs, messages, commands, support content, URLs, credentials, database contents, or arbitrary configuration values.

Disable CoreDSC charts in `plugins/CoreDSC/telemetry.yml`:

```yaml
bstats:
  enabled: false
  feature-activity: false
```

Disable bStats globally in `plugins/bStats/config.yml`. Metrics failure or opt-out never disables CoreDSC.

## Local command-scope state

`plugins/CoreDSC/state/discord-command-scopes.txt` contains global/guild command scopes, including guild IDs, so stale commands can be cleaned after restart. It is local-only, must not be included in public support bundles, and is not submitted through CoreDSC custom bStats charts.

## Discord permissions

Grant the minimum required permissions:

- `Manage Webhooks` only for automatic chat-webhook creation.
- `Manage Roles` only for configured role changes.
- `Manage Nicknames` only for nickname synchronization.
- `Ban Members` only for ban synchronization.
- channel/thread permissions only for enabled support and status modules.
- `Manage Channels`, `Manage Permissions`, and `Move Members` for proximity rooms.

Run `/coredsc doctor` after permission or hierarchy changes. The bot role must be above every role it manages.

## Remote console

Remote console defaults to `OFF`. When operationally necessary:

- use a dedicated private channel and staff role;
- prefer `ALLOWLIST` over `FULL`;
- allow only narrow command roots;
- retain deny patterns and rate limits;
- never share the command channel with public chat sync.

Discord-side arbitrary command execution has a high blast radius and should not be enabled merely for convenience.

## Account linking and rewards

Link codes must remain short-lived, random, persistent, and single-use. Keep network-attempt limits enabled where abuse is plausible. Reward handling must remain idempotent; interrupted or ambiguous claims should go to manual review rather than execute twice.

## Python scripts

Python scripts are administrator-trusted code, not an untrusted sandbox. The worker is a separate process and validates returned action objects, but scripts can still use the operating-system permissions of the server account.

- keep `auto-start: false` unless Python is deliberately deployed;
- review scripts before installation;
- keep sensitive-environment inheritance disabled;
- keep console actions disabled or tightly allowlisted;
- retain request, action, restart, and execution limits.

## Chat and webhooks

CoreDSC sanitizes mass mentions and blocks bot/webhook loops. A webhook send that fails after submission is not automatically duplicated through the bot because Discord may already have accepted the original request.

External avatar URLs disclose the requested UUID to the configured provider. Leave the avatar template blank when that disclosure is unacceptable.

## Reporting vulnerabilities

Provide the CoreDSC version/commit, Paper and Java versions, affected module, redacted configuration, reproduction steps, and sanitized logs. Do not publicly release destructive credential, remote-console, or player-data exploits before maintainers have had a reasonable opportunity to respond.
