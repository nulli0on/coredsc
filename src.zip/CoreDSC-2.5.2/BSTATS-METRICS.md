# CoreDSC bStats metrics

CoreDSC uses the official bStats Bukkit client with plugin ID `32949`. The dependency is shaded/relocated by the Maven build.

## Purpose

The charts show broad adoption, configuration modes, integration availability, and successful feature categories so maintenance can focus on used paths. CoreDSC has no private analytics endpoint and no telemetry-based license gate.

## Custom chart registry

| Chart ID | Type | Values/purpose |
|---|---|---|
| `configured_modules` | Simple bar | Modules enabled in configuration |
| `active_modules` | Simple bar | Modules that started successfully |
| `installed_dependencies` | Simple bar | Supported optional integration presence |
| `module_health` | Simple pie | Healthy or at least one failed module |
| `configured_module_count` | Simple pie | Bounded count bucket |
| `language` | Simple pie | English, German or other |
| `discord_command_registration` | Simple pie | Guild, global or other |
| `discord_token_source` | Simple pie | Environment, secrets file or other |
| `chat_sync_direction` | Simple pie | Disabled, one-way or two-way |
| `chat_webhook_mode` | Simple pie | Bot or webhook |
| `webhook_avatar_mode` | Simple pie | Fixed avatar mode category |
| `reverse_chat_account_policy` | Simple pie | Linked/unlinked forwarding policy |
| `reverse_chat_role_policy` | Simple pie | Fixed role-filter category |
| `link_requirement` | Simple pie | Disabled, optional or required |
| `network_mode` | Simple pie | Disabled, local or Redis |
| `console_remote_mode` | Simple pie | Disabled/off/allowlist/full |
| `luckperms_initial_authority` | Simple pie | Fixed authority category |
| `server_events_profile` | Simple pie | Batching and bounded event count |
| `status_channel_count` | Simple pie | Bounded channel count |
| `status_channel_types` | Simple bar | Voice/text totals |
| `status_offline_naming` | Simple pie | Fixed offline-name category |
| `voicechat_mode` | Simple pie | Disabled/proximity/fail-closed audio request |
| `voicechat_guest_policy` | Simple pie | Fixed guest policy |
| `python_worker_state` | Simple pie | Disabled/stopped/starting/ready/failed |
| `python_script_count` | Simple pie | Bounded script count |
| `python_event_adapter_count` | Simple pie | Bounded adapter count |
| `custom_command_count` | Simple pie | Bounded command count |
| `workflow_count` | Simple pie | Bounded workflow count |
| `enabled_server_event_count` | Simple pie | Bounded event count |
| `delivery_queue_capacity` | Simple pie | Configured capacity bucket |
| `support_feature_count` | Simple pie | Active support-module count |
| `reports_chat_history` | Simple pie | Enabled/disabled only |
| `feature_activity` | Simple bar | Capped successful-action counts by fixed category |

Count buckets are `0`, `1`, `2_to_3`, `4_to_5`, `6_to_10`, `11_to_20`, and `21_plus`.

## Fixed feature-activity categories

`chat_mc_to_discord`, `chat_discord_to_mc`, `link_code_created`, `account_linked`, `account_unlinked`, `server_event`, `delivery_queued`, `ticket_created`, `report_created`, `application_created`, `custom_command`, `workflow_run`, `python_execution`, `status_update`, `role_sync`, `nickname_sync`, `ban_sync`, `booster_reward`, and `link_reward`.

Each category is capped at 10,000 per collection interval. Counters are disabled/cleared when per-plugin metrics are disabled, when startup fails, and during plugin shutdown. Chart callbacks read immutable snapshots rather than calling Bukkit APIs asynchronously.

## Never added by CoreDSC custom charts

- Player names, UUIDs, IPs, or individual activity.
- Server name/address/MOTD, installation IDs, or file paths.
- Discord guild/channel/role/webhook/user IDs.
- Messages, commands, support/application content, script/workflow names.
- Tokens, URLs, credentials, hashes, database values, or arbitrary labels.

## Opt-out

```yaml
# plugins/CoreDSC/telemetry.yml
bstats:
  enabled: false
  feature-activity: false
```

```yaml
# plugins/bStats/config.yml
enabled: false
```

An old Boolean `license.yml` metrics preference is imported during upgrade only after `telemetry.yml` passes schema validation. An old opt-out wins; an opt-in never overrides an existing opt-out. Restart after changing the per-plugin switch if the bStats client was already active.
