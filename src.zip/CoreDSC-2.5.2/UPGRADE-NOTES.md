# Upgrade notes — CoreDSC 2.5.2

## Required procedure

1. Stop Paper and back up the old JAR plus the complete `plugins/CoreDSC/` directory.
2. Upgrade a copy first, not the only production data folder.
3. Start Paper once and allow startup migration to finish.
4. Run `/coredsc doctor` and `/coredsc status`.
5. Verify configured/resolved guild and command-registration state.
6. Test every enabled synchronization/reward/support path with non-production accounts.
7. Retain migration backups until the release is accepted.

## YAML migration

All maintained YAML files use schema `4`. Startup adds missing defaults, blocks future schemas, backs up modified files, writes atomically, and rolls back touched/created files after a later migration failure. `/coredsc reload` does not perform schema migration; restart after introducing older files.

Bukkit YAML rewrites may reformat comments. The backup preserves the original bytes.

## SQLite migration

Existing older databases are snapshotted under `plugins/CoreDSC/backups/` before schema mutation. Changes run in a transaction. If legacy `linked_accounts.discord_user_id` or `pending_link_codes.minecraft_uuid` values are duplicated, migration stops without deleting a row. Resolve duplicates in a copy and retry.

Database backups contain production data; protect them accordingly.

## Guild command behavior

Guild mode no longer falls back to global commands. Successful command scopes are stored locally so obsolete scopes can be cleaned after restart. Cleanup or state-file persistence failure leaves a visible failed/degraded registration state even when new commands registered.

Scopes from older versions that were never recorded cannot always be inferred; remove any historical stale scope manually once.

## Reload recovery

`/coredsc reload` is rollback-protected, not a replacement for restart testing. New module failures reject the reload. Rollback verifies that every module working before reload returned; modules already failed before reload do not falsely make rollback fatal.

## Python

The optional worker defaults to `auto-start: false`. Core-owned runtime files are version-managed and backed up during replacement. Administrator scripts are not overwritten.

## Telemetry and obsolete `license.yml`

`license.yml` is no longer active. Its former Boolean metrics preference is imported after `telemetry.yml` schema validation. A previous opt-out is preserved; an old opt-in cannot re-enable an existing opt-out. Remove the obsolete file only after verifying the upgrade.

See `PRIVACY.md` and `BSTATS-METRICS.md`.

## Folia

CoreDSC 2.5.2 does not claim Folia support.
