#!/usr/bin/env python3
"""Verify legacy uniqueness conflicts are detected without mutating rows.

This is a source/invariant test. The SQLite JDBC migration itself still needs
its dependency-resolved Java integration test before release certification.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src/main/java/com/hubertstudios/coredsc/storage/SQLiteStorage.java"


def duplicate_groups(connection: sqlite3.Connection, table: str, column: str) -> int:
    sql = f"SELECT COUNT(*) FROM (SELECT {column} FROM {table} GROUP BY {column} HAVING COUNT(*) > 1)"
    return int(connection.execute(sql).fetchone()[0])


def main() -> int:
    source = SOURCE.read_text(encoding="utf-8")
    for forbidden in ("DELETE FROM linked_accounts", "DELETE FROM pending_link_codes"):
        assert forbidden not in source, f"destructive migration SQL remains: {forbidden}"
    assert "requireUniqueLegacyValues(connection, \"linked_accounts\", \"discord_user_id\")" in source
    assert "requireUniqueLegacyValues(connection, \"pending_link_codes\", \"minecraft_uuid\")" in source

    connection = sqlite3.connect(":memory:")
    connection.executescript(
        """
        CREATE TABLE linked_accounts (
            minecraft_uuid TEXT PRIMARY KEY,
            discord_user_id TEXT NOT NULL,
            minecraft_name TEXT NOT NULL DEFAULT '',
            linked_at INTEGER NOT NULL
        );
        INSERT INTO linked_accounts VALUES ('mc-a', 'discord-1', 'A', 1);
        INSERT INTO linked_accounts VALUES ('mc-b', 'discord-1', 'B', 2);

        CREATE TABLE pending_link_codes (
            code TEXT PRIMARY KEY,
            minecraft_uuid TEXT NOT NULL,
            minecraft_name TEXT NOT NULL DEFAULT '',
            expires_at INTEGER NOT NULL
        );
        INSERT INTO pending_link_codes VALUES ('code-a', 'mc-a', 'A', 100);
        INSERT INTO pending_link_codes VALUES ('code-b', 'mc-a', 'A', 200);
        """
    )
    before_links = connection.execute(
        "SELECT minecraft_uuid, discord_user_id, minecraft_name, linked_at FROM linked_accounts ORDER BY minecraft_uuid"
    ).fetchall()
    before_codes = connection.execute(
        "SELECT code, minecraft_uuid, minecraft_name, expires_at FROM pending_link_codes ORDER BY code"
    ).fetchall()

    assert duplicate_groups(connection, "linked_accounts", "discord_user_id") == 1
    assert duplicate_groups(connection, "pending_link_codes", "minecraft_uuid") == 1

    after_links = connection.execute(
        "SELECT minecraft_uuid, discord_user_id, minecraft_name, linked_at FROM linked_accounts ORDER BY minecraft_uuid"
    ).fetchall()
    after_codes = connection.execute(
        "SELECT code, minecraft_uuid, minecraft_name, expires_at FROM pending_link_codes ORDER BY code"
    ).fetchall()
    assert after_links == before_links, "link rows were mutated"
    assert after_codes == before_codes, "pending code rows were mutated"
    connection.close()

    print("PASS: duplicate legacy account/link values are detected without deleting or rewriting rows.")
    print("Boundary: Java/JDBC transaction and VACUUM INTO behavior still require the resolved sqlite-jdbc integration test.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
