#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

python3 tools/static_audit.py
python3 tools/config_migration_self_test.py
rm -rf /tmp/coredsc-config-key-test && mkdir -p /tmp/coredsc-config-key-test
javac -d /tmp/coredsc-config-key-test src/main/java/com/hubertstudios/coredsc/config/ConfigKeyInspector.java tools/ConfigKeyInspectorSelfTest.java
java -cp /tmp/coredsc-config-key-test ConfigKeyInspectorSelfTest
python3 tools/scheduler_boundary_self_test.py
python3 tools/module_health_self_test.py
python3 tools/python_worker_self_test.py
python3 tools/discordsrv_migration_self_test.py
python3 tools/migration_conflict_self_test.py
if ! command -v mvn >/dev/null 2>&1; then
  echo "SOURCE-ONLY CHECKS PASSED; FULL BUILD NOT VERIFIED: Maven is unavailable." >&2
  exit 127
fi
read -r -a MAVEN_EXTRA <<< "${COREDSC_MAVEN_ARGS:-}"
mvn "${MAVEN_EXTRA[@]}" -B clean verify

JAR="target/CoreDSC-2.5.2.jar"
if [[ ! -f "$JAR" ]]; then
  echo "Expected build artifact is missing: $JAR" >&2
  exit 1
fi

python3 - "$JAR" <<'PY'
from pathlib import Path
import sys
import zipfile

jar = Path(sys.argv[1])
with zipfile.ZipFile(jar) as archive:
    bad = archive.testzip()
    if bad:
        raise SystemExit(f"Corrupt JAR entry: {bad}")
    names = set(archive.namelist())
    required = {
        "plugin.yml",
        "META-INF/services/java.sql.Driver",
        "com/hubertstudios/coredsc/CoreDSCPlugin.class",
        "com/hubertstudios/coredsc/libs/bstats/bukkit/Metrics.class",
    }
    missing = required - names
    if missing:
        raise SystemExit(f"Missing JAR entries: {sorted(missing)}")
    forbidden_prefixes = (
        "org/bukkit/",
        "de/maxhenkel/voicechat/api/",
        "net/luckperms/api/",
        "org/slf4j/",
        "org/bstats/",
    )
    bundled = [name for name in names if name.startswith(forbidden_prefixes)]
    if bundled:
        raise SystemExit("Provided API classes were incorrectly shaded: " + ", ".join(sorted(bundled)[:10]))
print(f"Verified {jar} ({jar.stat().st_size} bytes)")
PY
