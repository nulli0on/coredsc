#!/usr/bin/env python3
"""Offline CoreDSC source audit.

This script intentionally avoids dependency resolution. Use tools/verify_build.sh
for the full Maven build after the required repositories are reachable.
"""
from __future__ import annotations

import ast
import json
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
ERRORS: list[str] = []
NOTES: list[str] = []


def fail(message: str) -> None:
    ERRORS.append(message)


def java_string_fragments(expression: str) -> str:
    values: list[str] = []
    for literal in re.findall(r'"(?:\\.|[^"\\])*"', expression, re.S):
        values.append(json.loads(literal))
    return "".join(values)


def scan_java(path: Path) -> None:
    text = path.read_text(encoding="utf-8")
    state = "code"
    stack: list[tuple[str, int]] = []
    pairs = {")": "(", "]": "[", "}": "{"}
    line = 1
    i = 0
    while i < len(text):
        char = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if char == "\n":
            line += 1
        if state == "code":
            if char == "/" and nxt == "/":
                state = "line_comment"; i += 2; continue
            if char == "/" and nxt == "*":
                state = "block_comment"; i += 2; continue
            if char == '"':
                state = "string"; i += 1; continue
            if char == "'":
                state = "char"; i += 1; continue
            if char in "([{":
                stack.append((char, line))
            elif char in ")]}":
                if not stack or stack[-1][0] != pairs[char]:
                    fail(f"{path.relative_to(ROOT)}:{line}: unmatched {char}")
                    return
                stack.pop()
            i += 1
        elif state == "line_comment":
            if char == "\n": state = "code"
            i += 1
        elif state == "block_comment":
            if char == "*" and nxt == "/": state = "code"; i += 2
            else: i += 1
        elif state in {"string", "char"}:
            if char == "\\": i += 2
            elif (state == "string" and char == '"') or (state == "char" and char == "'"):
                state = "code"; i += 1
            else: i += 1
    if state in {"block_comment", "string", "char"}:
        fail(f"{path.relative_to(ROOT)}: unterminated Java {state}")
    if stack:
        token, token_line = stack[-1]
        fail(f"{path.relative_to(ROOT)}:{token_line}: unclosed {token}")

    package = re.search(r"^package\s+([\w.]+);", text, re.M)
    if not package:
        fail(f"{path.relative_to(ROOT)}: missing package declaration")
    else:
        expected = Path(*package.group(1).split(".")) / path.name
        actual = path.relative_to(ROOT / "src/main/java")
        if actual != expected:
            fail(f"{actual}: package path mismatch, expected {expected}")

    imports = re.findall(r"^import\s+([^;]+);", text, re.M)
    duplicates = sorted({item for item in imports if imports.count(item) > 1})
    if duplicates:
        fail(f"{path.relative_to(ROOT)}: duplicate imports {duplicates}")


def extract_parenthesized(text: str, opening_end: int) -> str:
    depth = 1
    index = opening_end
    state = "code"
    while index < len(text) and depth:
        char = text[index]
        if state == "code":
            if char == '"': state = "string"
            elif char == "(": depth += 1
            elif char == ")": depth -= 1
            index += 1
        else:
            if char == "\\": index += 2
            elif char == '"': state = "code"; index += 1
            else: index += 1
    return text[opening_end:index - 1]


def audit_sql() -> tuple[int, int, int]:
    storage_path = ROOT / "src/main/java/com/hubertstudios/coredsc/storage/SQLiteStorage.java"
    source = storage_path.read_text(encoding="utf-8")
    start = source.index("private static void applyMigrations(")
    end = source.index("private static int readUserVersion", start)
    body = source[start:end]
    migration_sql: list[str] = []
    for match in re.finditer(r"statement\.execute(?:Update)?\s*\(", body):
        sql = java_string_fragments(extract_parenthesized(body, match.end())).strip()
        if sql: migration_sql.append(sql)

    connection = sqlite3.connect(":memory:")
    for sql in migration_sql:
        if sql == "PRAGMA user_version =":
            sql = "PRAGMA user_version = 10"
        try:
            connection.execute(sql)
        except Exception as error:
            fail(f"migration SQL failed: {sql[:120]} :: {error}")

    for table, column, definition in re.findall(
        r'addColumnIfMissing\(connection,\s*"([^"]+)",\s*"([^"]+)",\s*"([^"]+)"\s*\)', body, re.S
    ):
        existing = {row[1] for row in connection.execute(f"PRAGMA table_info({table})")}
        if column not in existing:
            try:
                connection.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")
            except Exception as error:
                fail(f"add-column failed for {table}.{column}: {error}")

    expected = {
        "reward_claims": {"claim_key", "reward_type", "minecraft_uuid", "discord_user_id", "next_step", "inflight_step", "total_steps", "status", "created_at", "updated_at", "last_error"},
        "booster_states": {"discord_user_id", "minecraft_uuid", "active", "boosted_at", "last_reward_period", "updated_at"},
        "nickname_states": {"discord_user_id", "original_nickname", "synced_nickname", "updated_at"},
        "console_audit": {"id", "discord_user_id", "discord_user_name", "command", "mode", "outcome", "detail", "created_at"},
        "ban_sync_state": {"minecraft_uuid", "minecraft_name", "discord_user_id", "minecraft_managed", "discord_managed", "reason", "updated_at"},
        "link_enforcement": {"minecraft_uuid", "first_seen_at", "last_reminder_at"},
    }
    for table, columns in expected.items():
        actual = {row[1] for row in connection.execute(f"PRAGMA table_info({table})")}
        missing = columns - actual
        if missing:
            fail(f"{table} missing columns: {sorted(missing)}")

    checked = 0
    storage_dir = ROOT / "src/main/java/com/hubertstudios/coredsc/storage"
    for path in storage_dir.glob("*.java"):
        text = path.read_text(encoding="utf-8")
        for match in re.finditer(r"prepareStatement\s*\(", text):
            expression = extract_parenthesized(text, match.end())
            without_literals = re.sub(r'"(?:\\.|[^"\\])*"', "", expression, flags=re.S)
            if re.search(r"[A-Za-z_$][\w$]*", without_literals.replace("+", "").strip()):
                continue
            sql = java_string_fragments(expression).strip()
            if not sql: continue
            try:
                connection.execute("EXPLAIN " + sql, [None] * sql.count("?")).fetchall()
                checked += 1
            except Exception as error:
                fail(f"{path.name} SQL failed: {sql[:140]} :: {error}")

    for column in ("minecraft_uuid", "discord_user_id"):
        sql = ("SELECT minecraft_uuid,minecraft_name,discord_user_id,minecraft_managed,discord_managed,reason,updated_at "
               f"FROM ban_sync_state WHERE {column}=?")
        try:
            connection.execute("EXPLAIN " + sql, [None]).fetchall()
        except Exception as error:
            fail(f"BanSync dynamic query failed for {column}: {error}")

    version = connection.execute("PRAGMA user_version").fetchone()[0]
    if version != 10:
        fail(f"SQLite user_version is {version}, expected 10")
    connection.close()
    return len(migration_sql), checked, version


def run_voice_topology_test() -> bool:
    javac = shutil.which("javac")
    java = shutil.which("java")
    if not javac or not java:
        NOTES.append("Voice topology self-test skipped: Java compiler/runtime unavailable")
        return False
    source = ROOT / "src/main/java/com/hubertstudios/coredsc/voice/ProximityTopology.java"
    test = ROOT / "tools/VoiceTopologySelfTest.java"
    if not source.is_file() or not test.is_file():
        fail("voice topology source or self-test is missing")
        return False
    with tempfile.TemporaryDirectory(prefix="coredsc-topology-") as output:
        compile_result = subprocess.run(
            [javac, "--release", "21", "-d", output, str(source), str(test)],
            capture_output=True, text=True, check=False)
        if compile_result.returncode != 0:
            fail("voice topology self-test did not compile: "
                 + (compile_result.stderr.strip() or compile_result.stdout.strip()))
            return False
        run_result = subprocess.run(
            [java, "-cp", output, "VoiceTopologySelfTest"],
            capture_output=True, text=True, check=False)
        if run_result.returncode != 0:
            fail("voice topology self-test failed: "
                 + (run_result.stderr.strip() or run_result.stdout.strip()))
            return False
    return True



def nested_get(data: object, dotted: str) -> object:
    current = data
    for segment in dotted.split("."):
        if not isinstance(current, dict) or segment not in current:
            return None
        current = current[segment]
    return current


def audit_descriptor_and_regressions(java_files: list[Path], plugin_yml: dict, pom: str) -> None:
    all_java = "\n".join(path.read_text(encoding="utf-8") for path in java_files)

    if "javax.annotation.Nonnull" in all_java or "@Nonnull" in all_java:
        fail("source still depends on javax.annotation.Nonnull without declaring an annotation API")

    if "BanList.Type.NAME" in all_java:
        fail("source still uses unsupported name-based Paper bans")

    if "-Xlint:all,-processing" not in pom or "<showWarnings>true</showWarnings>" not in pom:
        fail("pom.xml must keep compiler warnings enabled")

    command_names = set(re.findall(r'getCommand\(\s*"([A-Za-z0-9_-]+)"\s*\)', all_java))
    declared_commands = set((plugin_yml.get("commands") or {}).keys())
    missing_commands = command_names - declared_commands
    if missing_commands:
        fail(f"plugin.yml is missing commands referenced from Java: {sorted(missing_commands)}")

    literal_permissions = set(re.findall(r'"(coredsc\.[a-z0-9_.-]+)"', all_java, re.I))
    declared_permissions = set((plugin_yml.get("permissions") or {}).keys())
    missing_permissions = literal_permissions - declared_permissions
    if missing_permissions:
        fail(f"plugin.yml is missing permissions referenced from Java: {sorted(missing_permissions)}")

    manager = (ROOT / "src/main/java/com/hubertstudios/coredsc/config/ConfigManager.java").read_text(encoding="utf-8")
    module_block = re.search(r"MODULE_IDS\s*=\s*List\.of\((.*?)\);", manager, re.S)
    if not module_block:
        fail("ConfigManager MODULE_IDS could not be parsed")
    else:
        module_ids = set(re.findall(r'"([a-z0-9-]+)"', module_block.group(1)))
        resource_ids = {path.stem for path in (ROOT / "src/main/resources/modules").glob("*.yml")}
        if module_ids != resource_ids:
            fail("ConfigManager module list and modules/*.yml differ: "
                 f"missing-in-code={sorted(resource_ids-module_ids)}, "
                 f"missing-resource={sorted(module_ids-resource_ids)}")

    reports = yaml.safe_load((ROOT / "src/main/resources/modules/reports.yml").read_text(encoding="utf-8")) or {}
    help_lines = nested_get(reports, "messages.help")
    if not isinstance(help_lines, list) or not help_lines:
        fail("reports.yml must ship a non-empty messages.help list")

    required_migration_markers = (
        'new File(dataFolder, "bot/config.yml")',
        'legacy.getConfigurationSection("python-bot")',
        'root.contains("python-bot")',
    )
    for required in required_migration_markers:
        if required not in manager:
            fail("legacy Python-bot migration regression: missing " + required)

    forbidden_markers = ("TODO", "FIXME", "printStackTrace(", "System.out.", "System.err.")
    for marker in forbidden_markers:
        if marker in all_java:
            fail(f"Java source contains forbidden release marker: {marker}")

def main() -> int:
    java_files = sorted((ROOT / "src/main/java").rglob("*.java"))
    for path in java_files:
        scan_java(path)

    yaml_files = sorted((ROOT / "src/main/resources").rglob("*.yml"))
    for path in yaml_files:
        try:
            yaml.safe_load(path.read_text(encoding="utf-8"))
        except Exception as error:
            fail(f"{path.relative_to(ROOT)} YAML parse failed: {error}")

    try:
        ET.parse(ROOT / "pom.xml")
    except Exception as error:
        fail(f"pom.xml parse failed: {error}")

    python_files = sorted((ROOT / "src/main/resources").rglob("*.py"))
    for path in python_files:
        try:
            ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
        except SyntaxError as error:
            fail(f"{path.relative_to(ROOT)} Python parse failed: {error}")
    bytecode_files = sorted(path for path in ROOT.rglob("*")
                            if path.name == "__pycache__" or path.suffix in {".pyc", ".pyo"})
    if bytecode_files:
        fail("source tree contains Python bytecode/cache artifacts: "
             + ", ".join(str(path.relative_to(ROOT)) for path in bytecode_files[:10]))
    worker_source = (ROOT / "src/main/resources/bot/runtime/worker.py").read_text(encoding="utf-8")
    sdk_source = (ROOT / "src/main/resources/bot/runtime/coredsc_api.py").read_text(encoding="utf-8")
    if "sys.dont_write_bytecode = True" not in worker_source:
        fail("Python worker must suppress bytecode output in the plugin data tree")
    if "sys.path.insert(0, str(runtime_directory))" not in worker_source:
        fail("Python worker runtime must precede user scripts on sys.path")
    if "registry_checkpoint" not in sdk_source or "registry_restore" not in sdk_source:
        fail("Python SDK transactional registration rollback is missing")

    migrations, queries, schema_version = audit_sql()

    required_modules = ["ban-sync", "booster-rewards", "console", "link-rewards", "nickname-sync"]
    for module in required_modules:
        path = ROOT / f"src/main/resources/modules/{module}.yml"
        if not path.is_file():
            fail(f"missing module configuration: {path.relative_to(ROOT)}")
            continue
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        if data.get("enabled") is not False:
            fail(f"{path.relative_to(ROOT)} must default to enabled: false")

    pom = (ROOT / "pom.xml").read_text(encoding="utf-8")
    plugin_yml = yaml.safe_load((ROOT / "src/main/resources/plugin.yml").read_text(encoding="utf-8"))
    project_version_match = re.search(r"<artifactId>\s*coredsc\s*</artifactId>\s*<version>([^<]+)</version>", pom, re.IGNORECASE)
    project_version = project_version_match.group(1).strip() if project_version_match else ""
    if not project_version:
        fail("pom.xml project version could not be resolved")
    if str(plugin_yml.get("version")) != project_version:
        fail("plugin.yml version does not match pom.xml project version")

    audit_descriptor_and_regressions(java_files, plugin_yml, pom)

    all_java = "\n".join(path.read_text(encoding="utf-8") for path in java_files)
    if (ROOT / "src/main/java/com/hubertstudios/license").exists():
        fail("the old enforcing license package must not exist in the open-source build")
    if "LicenseGate" in all_java or "hubertstudios.license" in all_java:
        fail("Java source still references the removed enforcing license gate")
    license_path = ROOT / "src/main/resources/license.yml"
    if license_path.exists():
        fail("license.yml must not be bundled; licensing and metrics are unrelated concerns")
    telemetry_path = ROOT / "src/main/resources/telemetry.yml"
    if not telemetry_path.is_file():
        fail("telemetry.yml is missing")
        telemetry_config = {}
    else:
        telemetry_config = yaml.safe_load(telemetry_path.read_text(encoding="utf-8")) or {}
    if (telemetry_config.get("bstats", {}) or {}).get("enabled") is not True:
        fail("telemetry.yml must explicitly expose bstats.enabled: true")
    if "endpoint" in str(telemetry_config).lower() or "token" in str(telemetry_config).lower():
        fail("telemetry.yml must not configure a private endpoint or token")

    managed_yaml = [
        ROOT / "src/main/resources/config.yml",
        ROOT / "src/main/resources/messages.yml",
        ROOT / "src/main/resources/telemetry.yml",
        ROOT / "src/main/resources/secrets.yml",
        ROOT / "src/main/resources/bot/config.yml",
        ROOT / "src/main/resources/guis/report-gui.yml",
        *sorted((ROOT / "src/main/resources/modules").glob("*.yml")),
    ]
    schema_versions = set()
    for managed_path in managed_yaml:
        managed = yaml.safe_load(managed_path.read_text(encoding="utf-8")) or {}
        managed_schema_version = managed.get("config-version")
        generated_version = str(managed.get("generated-by-version", ""))
        if not isinstance(managed_schema_version, int) or managed_schema_version <= 0:
            fail(f"{managed_path.relative_to(ROOT)} is missing a positive config-version")
        else:
            schema_versions.add(managed_schema_version)
        if generated_version != project_version:
            fail(f"{managed_path.relative_to(ROOT)} generated-by-version does not match the project version")
    if len(schema_versions) != 1:
        fail("managed YAML resources do not share one config schema version")

    metrics_path = ROOT / "src/main/java/com/hubertstudios/coredsc/metrics/MetricsService.java"
    if not metrics_path.is_file():
        fail("official bStats MetricsService is missing")
        metrics_source = ""
    else:
        metrics_source = metrics_path.read_text(encoding="utf-8")
    if "BSTATS_PLUGIN_ID = 32949" not in metrics_source:
        fail("MetricsService must use the registered bStats plugin ID 32949")
    if "new Metrics(plugin, BSTATS_PLUGIN_ID)" not in metrics_source:
        fail("MetricsService does not instantiate the official bStats Bukkit client")
    if "org.bstats.bukkit.Metrics" not in metrics_source:
        fail("MetricsService is not wired to the official bStats package")
    if "HttpClient" in metrics_source or "HttpURLConnection" in metrics_source or "workers.dev" in metrics_source:
        fail("MetricsService must not contain a private telemetry HTTP client/endpoint")
    if "SHA-256" in metrics_source or "MessageDigest" in metrics_source:
        fail("license keys/fingerprints must not be transmitted through metrics")
    if "refreshSnapshotNow" not in metrics_source or "Bukkit.isPrimaryThread()" not in metrics_source:
        fail("bStats custom chart snapshots must be captured on the Bukkit server thread")
    if "featureActivityEnabled = metricsEnabled" not in metrics_source or "featureActivity.clear()" not in metrics_source:
        fail("disabled bStats startup must also disable and clear feature activity counters")
    if ('featureActivityEnabled = false;' not in metrics_source
            or 'detail = "stopped with plugin lifecycle"' not in metrics_source):
        fail("metrics shutdown must stop and clear feature activity immediately")
    if metrics_source.count("featureActivityEnabled = false;") < 2:
        fail("metrics startup failure must also stop and clear feature activity counters")

    config_manager_source = (ROOT / "src/main/java/com/hubertstudios/coredsc/config/ConfigManager.java").read_text(encoding="utf-8")
    discord_source = (ROOT / "src/main/java/com/hubertstudios/coredsc/discord/DiscordBotService.java").read_text(encoding="utf-8")
    plugin_source = (ROOT / "src/main/java/com/hubertstudios/coredsc/CoreDSCPlugin.java").read_text(encoding="utf-8")
    if "CURRENT_CONFIG_VERSION" not in config_manager_source or "beginMigrationSession" not in config_manager_source or "backupBeforeWrite" not in config_manager_source:
        fail("ConfigManager is missing versioned migration/backup support")
    if "snapshotActive" not in config_manager_source or "restoreActive" not in config_manager_source:
        fail("ConfigManager is missing transactional runtime reload support")
    if "falling back to global" in discord_source.lower():
        fail("guild command registration must never silently fall back to global scope")
    if "GuildResolutionState" not in discord_source or "CommandRegistrationState" not in discord_source:
        fail("DiscordBotService is missing explicit guild/command registration health states")
    if "restoreActive(previous, previousConfigIssues)" not in plugin_source:
        fail("CoreDSC reload must restore the previous active config and warning snapshot after a failed reload")
    if 'requireNoFailedModules("reload")' not in plugin_source:
        fail("reload must reject a newly loaded module set containing failures")
    if ('enabledModuleIdsSnapshot()' not in plugin_source
            or 'requirePreviouslyEnabledModules(' not in plugin_source):
        fail("reload rollback must verify restoration of the previously working module set")
    key_inspector_path = ROOT / "src/main/java/com/hubertstudios/coredsc/config/ConfigKeyInspector.java"
    if not key_inspector_path.is_file() or "findUnknownKeys" not in key_inspector_path.read_text(encoding="utf-8"):
        fail("pure configuration-key typo detection is missing")
    if "inspectConfigurationKeys" not in config_manager_source or "ConfigKeyInspector.findUnknownKeys" not in config_manager_source:
        fail("ConfigManager is not reporting unknown/deprecated configuration keys")
    if "printStartupActionSummary" not in plugin_source or "action item(s)" not in plugin_source:
        fail("startup action summary is missing")

    scheduler_root = ROOT / "src/main/java/com/hubertstudios/coredsc/scheduler"
    scheduler_interface = scheduler_root / "CoreScheduler.java"
    scheduler_impl = scheduler_root / "PaperCoreScheduler.java"
    if not scheduler_interface.is_file() or not scheduler_impl.is_file():
        fail("central scheduler boundary is missing")
    else:
        scheduler_api = scheduler_interface.read_text(encoding="utf-8")
        for scheduler_marker in ("runGlobal", "runAsync", "runForEntity", "runAtLocation", "shutdown"):
            if scheduler_marker not in scheduler_api:
                fail("scheduler boundary is missing: " + scheduler_marker)
    for java_path in java_files:
        if scheduler_root in java_path.parents:
            continue
        source = java_path.read_text(encoding="utf-8")
        if "Bukkit.getScheduler()" in source or ".getServer().getScheduler()" in source:
            fail("direct Bukkit scheduler usage remains outside the scheduler boundary: "
                 + str(java_path.relative_to(ROOT)))

    module_manager_source = (ROOT / "src/main/java/com/hubertstudios/coredsc/module/ModuleManager.java").read_text(encoding="utf-8")
    if ("OperationalStatus" not in module_manager_source
            or "recordSuccessfulAction" not in module_manager_source
            or "recordFailedAction" not in module_manager_source):
        fail("per-module operational timestamps/counters are missing")
    if ('requirePreviouslyEnabledModules' not in module_manager_source
            or 'did not restore previously working modules' not in module_manager_source):
        fail("rollback restoration must tolerate pre-existing failed optional modules while protecting working ones")
    if "rollback was incomplete" not in plugin_source or "StartupState.FAILED" not in plugin_source:
        fail("failed reload rollback must force a visible failed runtime state")
    if ('migrateObsoleteLicenseMetrics()' not in config_manager_source
            or 'if (!legacyMetricsEnabled && telemetryEnabled)' not in config_manager_source):
        fail("the obsolete license.yml bStats opt-out is not preserved fail-safely")
    telemetry_prepare = config_manager_source.find('prepareManagedYaml("telemetry.yml")')
    legacy_metrics_migration = config_manager_source.find('migrateObsoleteLicenseMetrics()')
    if telemetry_prepare < 0 or legacy_metrics_migration < 0 or telemetry_prepare > legacy_metrics_migration:
        fail("telemetry.yml must be future-schema validated before importing obsolete license metrics")
    if ('prepareManagedResource("bot/runtime/worker.py"' not in config_manager_source
            or 'prepareManagedResource("bot/runtime/coredsc_api.py"' not in config_manager_source):
        fail("managed Python runtime files must participate in migration backup/rollback")
    if ('copyResource("bot/runtime/worker.py"' in config_manager_source
            or 'copyResource("bot/runtime/coredsc_api.py"' in config_manager_source):
        fail("Python runtime files bypass the migration transaction")
    for marker in ("loadKnownCommandScopes", "persistKnownCommandScopes",
                   'state/discord-command-scopes.txt', "ATOMIC_MOVE",
                   "cleanupFailures", "cleanup/state tracking is incomplete"):
        if marker not in discord_source:
            fail("persistent Discord command-scope cleanup/health reporting is missing: " + marker)
    for marker in ("listenerLock", "synchronized (listenerLock)",
                   "Publication and reconciliation are atomic with listener add/remove"):
        if marker not in discord_source:
            fail("Discord listener publication/registration race protection is missing: " + marker)

    storage_source = (ROOT / "src/main/java/com/hubertstudios/coredsc/storage/SQLiteStorage.java").read_text(encoding="utf-8")
    for marker in ("backupDatabaseBeforeMigration", "VACUUM INTO", "connection.setAutoCommit(false)",
                   "connection.commit()", "rollbackMigration(connection", "sourceVersion > SCHEMA_VERSION"):
        if marker not in storage_source:
            fail("transactional SQLite migration protection is missing: " + marker)
    if "sourceVersion == SCHEMA_VERSION" not in storage_source:
        fail("current SQLite schema should not rerun destructive legacy cleanup on every startup")
    if "requireUniqueLegacyValues" not in storage_source:
        fail("SQLite migration must detect ambiguous duplicate account/link values before adding constraints")
    destructive_migration_sql = (
        "DELETE FROM linked_accounts",
        "DELETE FROM pending_link_codes",
    )
    for marker in destructive_migration_sql:
        if marker in storage_source:
            fail("SQLite migration must not silently delete ambiguous user data: " + marker)

    chart_ids = re.findall(r'new Simple(?:Pie|BarChart)\("([a-z0-9_]+)"', metrics_source)
    if len(chart_ids) < 25:
        fail(f"extended bStats registry is unexpectedly small: {len(chart_ids)} chart(s)")
    if len(chart_ids) != len(set(chart_ids)):
        fail("MetricsService contains duplicate bStats chart IDs")

    feature_keys_match = re.search(
        r"FEATURE_ACTIVITY_KEYS\s*=\s*Set\.of\((.*?)\);", metrics_source, re.DOTALL)
    feature_keys = set(re.findall(r'"([a-z0-9_]+)"', feature_keys_match.group(1))) if feature_keys_match else set()
    recorded_feature_keys = set(re.findall(r'recordFeatureUse\("([a-z0-9_]+)"\)', all_java))
    if not feature_keys:
        fail("MetricsService feature-activity allowlist is missing")
    if not recorded_feature_keys:
        fail("No successful feature paths record anonymous activity")
    if not recorded_feature_keys.issubset(feature_keys):
        fail("Java code records feature keys not present in MetricsService allowlist: "
             + ", ".join(sorted(recorded_feature_keys - feature_keys)))
    required_activity = {
        "chat_mc_to_discord", "chat_discord_to_mc", "link_code_created",
        "account_linked", "account_unlinked", "server_event", "delivery_queued",
        "status_update", "role_sync", "nickname_sync", "ban_sync", "booster_reward",
    }
    if not required_activity.issubset(recorded_feature_keys):
        fail("Core reliability/adoption paths are missing feature activity markers: "
             + ", ".join(sorted(required_activity - recorded_feature_keys)))

    chart_docs_path = ROOT / "BSTATS-METRICS.md"
    chart_csv_path = ROOT / "BSTATS-CHARTS.csv"
    if not chart_docs_path.is_file() or not chart_csv_path.is_file():
        fail("bStats chart registry documentation/CSV is missing")
    else:
        documented_ids = re.findall(r"^\| `([a-z0-9_]+)` \|", chart_docs_path.read_text(encoding="utf-8"), re.MULTILINE)
        csv_lines = [line.strip() for line in chart_csv_path.read_text(encoding="utf-8").splitlines()[1:] if line.strip()]
        csv_ids = [line.split(",", 1)[0] for line in csv_lines]
        if set(documented_ids) != set(chart_ids):
            fail("BSTATS-METRICS.md chart IDs do not match MetricsService")
        if set(csv_ids) != set(chart_ids):
            fail("BSTATS-CHARTS.csv chart IDs do not match MetricsService")

    if "<artifactId>bstats-bukkit</artifactId>" not in pom or "<bstats.version>3.2.1</bstats.version>" not in pom:
        fail("pom.xml is missing the pinned official bStats 3.2.1 dependency")
    if "<pattern>org.bstats</pattern>" not in pom or "coredsc.libs.bstats" not in pom:
        fail("pom.xml must relocate bStats to avoid cross-plugin class conflicts")

    telemetry_dir = ROOT / "src/main/java/com/hubertstudios/coredsc/telemetry"
    if telemetry_dir.exists():
        fail("private telemetry package must not exist")
    forbidden_tracking = ("api.gg69nah.workers.dev", "/api/validate", "LicenseTelemetryService")
    source_and_resources = all_java + "\n" + "\n".join(
        path.read_text(encoding="utf-8", errors="ignore")
        for path in (ROOT / "src/main/resources").rglob("*") if path.is_file()
    )
    for marker in forbidden_tracking:
        if marker in source_and_resources:
            fail("private tracking marker remains in release source/resources: " + marker)
    if "skidfuscator" in pom.lower() or (ROOT / "skidfuscator-config.hocon").exists():
        fail("open-source build still contains an obfuscation profile/config")
    if not (ROOT / "LICENSE").is_file():
        fail("LICENSE is missing")
    api_source = (ROOT / "src/main/java/com/hubertstudios/coredsc/api/CoreDSCApi.java").read_text(encoding="utf-8")
    python_source = (ROOT / "src/main/java/com/hubertstudios/coredsc/module/impl/PythonBotModule.java").read_text(encoding="utf-8")
    bridge_source = (ROOT / "src/main/java/com/hubertstudios/coredsc/scripting/BukkitEventBridge.java").read_text(encoding="utf-8")
    if "publishPythonEvent" not in api_source or "publishExternalEvent" not in python_source:
        fail("public/custom Python event publishing surface is missing")
    if "registerEvent" not in bridge_source or "getClass" not in bridge_source:
        fail("Bukkit event bridge safety/registration markers are missing")
    status_config = yaml.safe_load((ROOT / "src/main/resources/modules/status-channels.yml").read_text(encoding="utf-8")) or {}
    configured_status_channels = status_config.get("channels", []) or []
    if not configured_status_channels:
        fail("status-channels.yml must ship an example channel")
    else:
        example_status = configured_status_channels[0] or {}
        if "online-name" not in example_status or "offline-name" not in example_status:
            fail("status channels must expose separate online-name and offline-name templates")
    status_source = (ROOT / "src/main/java/com/hubertstudios/coredsc/module/impl/StatusChannelModule.java").read_text(encoding="utf-8")
    if "publishOfflineStatus" not in status_source or "default-offline-name" not in status_source:
        fail("status channel offline publishing or fallback configuration is missing")
    plugin_source = (ROOT / "src/main/java/com/hubertstudios/coredsc/CoreDSCPlugin.java").read_text(encoding="utf-8")
    migration_path = ROOT / "src/main/java/com/hubertstudios/coredsc/service/DiscordSrvMigrationService.java"
    if not migration_path.is_file():
        fail("DiscordSRV migration service is missing")
        migration_source = ""
    else:
        migration_source = migration_path.read_text(encoding="utf-8")
    migration_markers = (
        'case "migrate"',
        'args[1].equalsIgnoreCase("DiscordSRV")',
        'coredsc.migrate',
    )
    for marker in migration_markers:
        if marker not in plugin_source:
            fail("DiscordSRV migration command wiring is missing: " + marker)
    required_migration_source = (
        'getAccountLinkManager',
        'getLinkedAccounts',
        'accounts.aof',
        'linkedaccounts.json',
        'SELECT discord_user_id FROM linked_accounts WHERE minecraft_uuid=?',
        'SELECT minecraft_uuid FROM linked_accounts WHERE discord_user_id=?',
        'INSERT INTO linked_accounts',
        'restoreAll(migrationDirectory)',
        'report.txt',
        'DiscordSRV source files changed: NO',
    )
    for marker in required_migration_source:
        if marker not in migration_source:
            fail("DiscordSRV migration safety/regression marker is missing: " + marker)
    forbidden_migration_source = (
        'disablePlugin(discordSrv)',
        'deleteRecursively(sourceDirectory)',
        'sourceDirectory.delete(',
    )
    for marker in forbidden_migration_source:
        if marker in migration_source:
            fail("DiscordSRV migration must not disable or delete the source installation: " + marker)
    migration_targets = set(re.findall(
        r'workspace\.set\("([^"]+)",\s*"([^"]+)"', migration_source))
    for relative_path, dotted_path in sorted(migration_targets):
        resource = ROOT / "src/main/resources" / relative_path
        if not resource.is_file():
            fail(f"DiscordSRV migration target resource is missing: {relative_path}")
            continue
        target_data = yaml.safe_load(resource.read_text(encoding="utf-8")) or {}
        if nested_get(target_data, dotted_path) is None:
            fail(f"DiscordSRV migration writes an unknown target path: {relative_path}:{dotted_path}")
    console_text = (ROOT / "src/main/resources/modules/console.yml").read_text(encoding="utf-8")
    if "coredsc\\s+(reload|setup|migrate)" not in console_text:
        fail("remote console deny rules must block migration/reload/setup commands")
    if not (ROOT / "tools/discordsrv_migration_self_test.py").is_file():
        fail("DiscordSRV migration self-test is missing")
    if "statusChannels.publishOfflineStatus" not in plugin_source:
        fail("CoreDSC shutdown does not publish configured offline channel names")
    if "getServer().isStopping()" not in plugin_source:
        fail("offline channel publishing must be limited to actual Paper shutdown")

    chat_config = yaml.safe_load((ROOT / "src/main/resources/modules/chat-sync.yml").read_text(encoding="utf-8")) or {}
    reverse = chat_config.get("discord-to-minecraft", {}) or {}
    webhook = (chat_config.get("minecraft-to-discord", {}) or {}).get("webhook", {}) or {}
    if reverse.get("allow-linked-users") is not True or reverse.get("allow-unlinked-users") is not True:
        fail("chat-sync must ship explicit linked/unlinked reverse-chat policy defaults")
    if "username-format" not in webhook or "avatar-url" not in webhook:
        fail("chat-sync webhook identity settings are missing")
    chat_source = (ROOT / "src/main/java/com/hubertstudios/coredsc/module/impl/ChatSyncModule.java").read_text(encoding="utf-8")
    if "webhookName.length() < 2 || webhookName.length() > 100" not in chat_source:
        fail("chat-sync webhook names must be validated against Discord's 2-100 character bound")
    if "storedMinecraftUuid" not in chat_source:
        fail("reverse-chat UUID lookup regression marker is missing")
    if "bot fallback was not used" not in chat_source:
        fail("ambiguous webhook failures must not trigger duplicate-prone bot fallback")
    if "eventClassName.length() > 256" not in bridge_source or "MAX_REGISTRATIONS = 100" not in bridge_source:
        fail("Bukkit event bridge class/registration bounds are missing")

    voice = (ROOT / "src/main/java/com/hubertstudios/coredsc/module/impl/VoiceChatSyncModule.java").read_text(encoding="utf-8")
    relay_pool = (ROOT / "src/main/java/com/hubertstudios/coredsc/voice/DiscordVoiceRelayPool.java").read_text(encoding="utf-8")
    voice_bridge = (ROOT / "src/main/java/com/hubertstudios/coredsc/voice/SimpleVoiceChatBridge.java").read_text(encoding="utf-8")
    voice_config = yaml.safe_load((ROOT / "src/main/resources/modules/voicechat-sync.yml").read_text(encoding="utf-8")) or {}
    if "AudioSendHandler" not in relay_pool or "AudioReceiveHandler" not in relay_pool:
        fail("DiscordVoiceRelayPool does not contain a bidirectional JDA audio bridge")
    if "connectedComponents" not in voice or "createVoiceChannel" not in voice:
        fail("VoiceChatSyncModule does not contain proximity grouping and temporary room management")
    if "MicrophonePacketEvent" not in voice_bridge or "EntityAudioChannel" not in voice_bridge:
        fail("SimpleVoiceChatBridge does not contain microphone decode and spatial output routing")
    if voice_config.get("enabled") is not False:
        fail("voicechat-sync must remain opt-in and default to enabled: false")
    security = voice_config.get("security", {}) or {}
    if security.get("require-linked-accounts") is not True:
        fail("voicechat-sync must require linked accounts by default")
    if security.get("require-discord-deafened-for-minecraft-relay") is not True:
        fail("voicechat-sync echo protection must default to enabled")
    audio = voice_config.get("audio", {}) or {}
    if int(audio.get("max-buffered-frames", 0)) <= 0:
        fail("voicechat-sync must configure a positive bounded frame queue")
    if int(audio.get("max-mixed-sources-per-frame", 0)) <= 0:
        fail("voicechat-sync must configure a positive source-mixing bound")
    rooms_config = voice_config.get("rooms", {}) or {}
    if not 1 <= int(rooms_config.get("maximum-active-rooms", 0)) <= 100:
        fail("voicechat-sync must configure a bounded active-room limit")
    discord_voice = voice_config.get("discord", {}) or {}
    if not str(discord_voice.get("category-id", "")).strip() == "":
        fail("voicechat-sync category-id must default to blank")
    if not str(discord_voice.get("lobby-channel-id", "")).strip() == "":
        fail("voicechat-sync lobby-channel-id must default to blank")
    relay_config = voice_config.get("relay-bots", {}) or {}
    if relay_config.get("token-environment-variables") not in ([], None):
        fail("voicechat-sync safe defaults must not require a relay bot token")
    if (audio.get("minecraft-to-discord", {}) or {}).get("enabled") is not False:
        fail("voicechat-sync must default Minecraft-to-Discord audio to false")
    if (audio.get("discord-to-minecraft", {}) or {}).get("enabled") is not False:
        fail("voicechat-sync must default Discord-to-Minecraft audio to false")
    voice_docs = (ROOT / "VOICECHAT.md").read_text(encoding="utf-8")
    dave_marker = "does not bundle a verified"
    if dave_marker not in voice or dave_marker not in voice_docs or "DAVE" not in voice or "DAVE" not in voice_docs:
        fail("VoiceChat code and documentation must state the fail-closed DAVE boundary")
    if "new DiscordVoiceRelayPool" in voice:
        fail("VoiceChatSyncModule must not construct relay bots without a verified DAVE provider")
    if "minecraftToDiscordEnabled = false" not in voice or "discordToMinecraftEnabled = false" not in voice:
        fail("VoiceChat audio direction requests must remain forced off until a verified DAVE implementation exists")
    if "voicechat-api" not in pom:
        fail("pom.xml is missing the Simple Voice Chat API dependency")
    if "GUILD_VOICE_STATES" not in (ROOT / "src/main/java/com/hubertstudios/coredsc/discord/DiscordBotService.java").read_text(encoding="utf-8"):
        fail("DiscordBotService is missing the voice-state gateway intent")
    if "CacheFlag.VOICE_STATE" not in (ROOT / "src/main/java/com/hubertstudios/coredsc/discord/DiscordBotService.java").read_text(encoding="utf-8"):
        fail("DiscordBotService is missing voice-state caching")
    if "voicechat" not in [str(value).lower() for value in plugin_yml.get("softdepend", [])]:
        fail("plugin.yml must soft-depend on the Simple Voice Chat plugin")
    if "UnsupportedOperationException" in voice:
        fail("VoiceChatSyncModule still contains an exception-only placeholder")

    console_config = yaml.safe_load((ROOT / "src/main/resources/modules/console.yml").read_text(encoding="utf-8"))
    if str(console_config.get("remote", {}).get("mode", "")).upper() != "OFF":
        fail("console remote mode must default to OFF")
    if console_config.get("remote", {}).get("confirm-full-access") is not False:
        fail("console FULL acknowledgement must default to false")

    secrets = yaml.safe_load((ROOT / "src/main/resources/secrets.yml").read_text(encoding="utf-8")) or {}
    if secrets.get("discord-token") not in (None, ""):
        fail("src/main/resources/secrets.yml contains a non-empty Discord token")

    bot_config = yaml.safe_load((ROOT / "src/main/resources/bot/config.yml").read_text(encoding="utf-8")) or {}
    if bot_config.get("auto-start") is not False:
        fail("the optional Python worker must default to manual start")

    topology_tested = run_voice_topology_test()

    print(f"Java lexical/package/import checks: {len(java_files)} file(s)")
    print("Voice topology self-test: " + ("compiled and passed" if topology_tested else "not completed"))
    print(f"YAML parse checks: {len(yaml_files)} file(s)")
    print(f"Python syntax checks: {len(python_files)} file(s)")
    print("XML parse checks: pom.xml")
    print(f"SQLite simulation: {migrations} migration statement(s), {queries} fixed prepared statement(s), schema v{schema_version}")
    print("Descriptor/regression checks: commands, permissions, modules, official bStats metrics, online/offline status channels, chat/webhook integration, safe DiscordSRV migration, Python isolation, event bridges, fail-closed voice audio")
    print("Security invariants: no enforcing license gate/private tracking/obfuscator, no bundled license configuration, bStats chart values are bounded, remote console OFF, bounded event adapters, non-destructive migration with conflict-safe account imports, no bundled token/bytecode caches, VoiceChat audio fail-closed without DAVE")
    if ERRORS:
        print("\nFAILED:")
        for error in ERRORS:
            print(f"- {error}")
        return 1
    print("\nPASS: source-only static audit completed without detected structural errors.")
    for note in NOTES:
        print("Note: " + note)
    print("Boundary: this script does not run Maven, Paper, Discord, Redis, or Simple Voice Chat clients.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
