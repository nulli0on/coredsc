#!/usr/bin/env python3
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]

with tempfile.TemporaryDirectory(prefix="coredsc-scheduler-") as tmp:
    work = Path(tmp)
    sources = work / "src"
    classes = work / "classes"
    for package in [
        "org/bukkit", "org/bukkit/entity", "org/bukkit/plugin/java", "org/bukkit/scheduler"
    ]:
        (sources / package).mkdir(parents=True, exist_ok=True)

    (sources / "org/bukkit/Location.java").write_text(
        "package org.bukkit; public class Location {}\n", encoding="utf-8")
    (sources / "org/bukkit/entity/Entity.java").write_text(
        "package org.bukkit.entity; public interface Entity {}\n", encoding="utf-8")
    (sources / "org/bukkit/plugin/java/JavaPlugin.java").write_text(
        "package org.bukkit.plugin.java; public class JavaPlugin {"
        "private boolean enabled=true; public boolean isEnabled(){return enabled;} "
        "public void setEnabled(boolean enabled){this.enabled=enabled;} }\n", encoding="utf-8")
    (sources / "org/bukkit/scheduler/BukkitTask.java").write_text(
        "package org.bukkit.scheduler; public interface BukkitTask { void cancel(); }\n", encoding="utf-8")
    (sources / "org/bukkit/scheduler/BukkitScheduler.java").write_text(
        "package org.bukkit.scheduler; import org.bukkit.plugin.java.JavaPlugin; "
        "public interface BukkitScheduler {"
        "BukkitTask runTask(JavaPlugin p,Runnable r);"
        "BukkitTask runTaskLater(JavaPlugin p,Runnable r,long d);"
        "BukkitTask runTaskTimer(JavaPlugin p,Runnable r,long d,long period);"
        "BukkitTask runTaskAsynchronously(JavaPlugin p,Runnable r);"
        "void cancelTasks(JavaPlugin p); }\n", encoding="utf-8")
    (sources / "org/bukkit/Bukkit.java").write_text(
        "package org.bukkit; import org.bukkit.scheduler.*; import org.bukkit.plugin.java.JavaPlugin; "
        "public final class Bukkit {"
        "private static boolean primary=true; public static int cancellations=0;"
        "private static BukkitTask task(){return ()->cancellations++;}"
        "private static final BukkitScheduler S=new BukkitScheduler(){"
        "public BukkitTask runTask(JavaPlugin p,Runnable r){r.run();return task();}"
        "public BukkitTask runTaskLater(JavaPlugin p,Runnable r,long d){r.run();return task();}"
        "public BukkitTask runTaskTimer(JavaPlugin p,Runnable r,long d,long q){return task();}"
        "public BukkitTask runTaskAsynchronously(JavaPlugin p,Runnable r){r.run();return task();}"
        "public void cancelTasks(JavaPlugin p){cancellations++;} };"
        "public static boolean isPrimaryThread(){return primary;}"
        "public static void setPrimaryThread(boolean value){primary=value;}"
        "public static BukkitScheduler getScheduler(){return S;} }\n", encoding="utf-8")

    test = sources / "SchedulerBoundarySelfTest.java"
    test.write_text(
        "import com.hubertstudios.coredsc.scheduler.*;"
        "import org.bukkit.Bukkit; import org.bukkit.Location; import org.bukkit.entity.Entity;"
        "import org.bukkit.plugin.java.JavaPlugin;"
        "public final class SchedulerBoundarySelfTest {"
        "public static void main(String[] a) throws Exception {"
        "JavaPlugin plugin=new JavaPlugin(); PaperCoreScheduler s=new PaperCoreScheduler(plugin);"
        "int[] count={0}; s.runGlobal(()->count[0]++);"
        "if(s.callGlobal(()->42).get()!=42) throw new AssertionError();"
        "s.runGlobalLater(()->count[0]++,1).cancel();"
        "s.runAsync(()->count[0]++).cancel();"
        "Bukkit.setPrimaryThread(false);"
        "CoreTask entity=s.runForEntity(new Entity(){},()->count[0]++);"
        "CoreTask location=s.runAtLocation(new Location(),()->count[0]++);"
        "entity.cancel(); location.cancel(); Bukkit.setPrimaryThread(true);"
        "if(count[0]!=5) throw new AssertionError(\"count=\"+count[0]);"
        "if(Bukkit.cancellations!=4) throw new AssertionError(\"cancellations=\"+Bukkit.cancellations);"
        "s.shutdown(); boolean failed=false; try{s.runGlobal(()->{});}catch(IllegalStateException e){failed=true;}"
        "if(!failed) throw new AssertionError(\"closed scheduler accepted work\");"
        "System.out.println(\"Scheduler boundary self-test passed\"); }}",
        encoding="utf-8")

    java_sources = list(sources.rglob("*.java")) + [
        ROOT / "src/main/java/com/hubertstudios/coredsc/scheduler/CoreTask.java",
        ROOT / "src/main/java/com/hubertstudios/coredsc/scheduler/CoreScheduler.java",
        ROOT / "src/main/java/com/hubertstudios/coredsc/scheduler/PaperCoreScheduler.java",
    ]
    classes.mkdir()
    subprocess.run(["javac", "-d", str(classes), *map(str, java_sources)], check=True)
    subprocess.run(["java", "-cp", str(classes), "SchedulerBoundarySelfTest"], check=True)
