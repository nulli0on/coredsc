#!/usr/bin/env python3
"""Protocol-level and script-isolation self-test for CoreDSC's Python worker."""
from __future__ import annotations

import json
import pathlib
import shutil
import subprocess
import sys
import tempfile


def main() -> int:
    root = pathlib.Path(__file__).resolve().parents[1]
    worker = root / "src/main/resources/bot/runtime/worker.py"
    bundled_scripts = root / "src/main/resources/bot/scripts"

    with tempfile.TemporaryDirectory(prefix="coredsc-worker-test-") as temporary:
        scripts = pathlib.Path(temporary) / "scripts"
        shutil.copytree(bundled_scripts, scripts)
        (scripts / "coredsc_api.py").write_text(
            'raise RuntimeError("user shadow module was loaded")\n', encoding="utf-8"
        )
        (scripts / "shadow_consumer.py").write_text(
            "from coredsc_api import event\n"
            "@event('shadow_ok')\n"
            "def shadow_ok(ctx):\n"
            "    ctx.log('official sdk imported')\n",
            encoding="utf-8",
        )
        (scripts / "broken_partial.py").write_text(
            "from coredsc_api import event\n"
            "@event('must_not_survive')\n"
            "def partial(ctx):\n"
            "    ctx.log('broken registration')\n"
            "raise RuntimeError('intentional import failure')\n",
            encoding="utf-8",
        )

        process = subprocess.Popen(
            [sys.executable, str(worker), "--scripts", str(scripts)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        assert process.stdin is not None
        requests = [
            {"type": "hello", "protocol": 1},
            {
                "type": "execute",
                "request_id": "worker-self-test",
                "kind": "event",
                "event": "bossfight_started",
                "context": {
                    "platform": "EVENT",
                    "event": {
                        "name": "bossfight_started",
                        "source": "self-test",
                        "data": {"boss": "Crimson Warden"},
                    },
                    "plugins": {"CoreDSC": {"enabled": True, "version": "2.5.2"}},
                },
            },
            {
                "type": "execute",
                "request_id": "shadow-self-test",
                "kind": "event",
                "event": "shadow_ok",
                "context": {"platform": "EVENT", "event": {"name": "shadow_ok"}},
            },
            {"type": "shutdown"},
        ]
        for request in requests:
            process.stdin.write(json.dumps(request, separators=(",", ":")) + "\n")
        process.stdin.flush()

        stdout, stderr = process.communicate(timeout=10)
        messages = [json.loads(line) for line in stdout.splitlines() if line.strip()]
        ready = next((item for item in messages if item.get("type") == "ready"), None)
        boss_result = next(
            (item for item in messages if item.get("type") == "result"
             and item.get("request_id") == "worker-self-test"), None
        )
        shadow_result = next(
            (item for item in messages if item.get("type") == "result"
             and item.get("request_id") == "shadow-self-test"), None
        )

        if process.returncode != 0:
            raise RuntimeError(f"Worker exited with {process.returncode}: {stderr.strip()}")
        if ready is None:
            raise RuntimeError(f"Worker did not complete the handshake: {messages}")
        events = set(ready.get("events", []))
        if "bossfight_started" not in events:
            raise RuntimeError("Bundled external-event example was not registered")
        if "shadow_ok" not in events:
            raise RuntimeError("Official SDK was shadowed by a user coredsc_api.py file")
        if "must_not_survive" in events:
            raise RuntimeError("Failed script left a partial event registration behind")
        loaded = set(ready.get("scripts", []))
        if "broken_partial.py" in loaded or "coredsc_api.py" in loaded:
            raise RuntimeError(f"Failed scripts were incorrectly marked loaded: {sorted(loaded)}")
        if boss_result is None:
            raise RuntimeError(f"Worker did not return the boss event result: {messages}")
        if not any(
            action.get("type") == "LOG" and "Crimson Warden" in str(action.get("message", ""))
            for action in boss_result.get("actions", [])
        ):
            raise RuntimeError(f"Unexpected boss actions: {boss_result.get('actions', [])}")
        if shadow_result is None or not any(
            action.get("type") == "LOG" and action.get("message") == "official sdk imported"
            for action in shadow_result.get("actions", [])
        ):
            raise RuntimeError(f"Unexpected shadow-test result: {shadow_result}")
        if list(pathlib.Path(temporary).rglob("*.pyc")) or list(pathlib.Path(temporary).rglob("__pycache__")):
            raise RuntimeError("Worker generated Python bytecode/cache files")

    print("Python worker protocol/isolation integration: PASS")
    print("Validated SDK shadow protection and failed-import rollback")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
