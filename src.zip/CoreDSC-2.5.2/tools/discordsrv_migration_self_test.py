#!/usr/bin/env python3
"""Compile and exercise DiscordSRV migration logic without external dependencies."""
from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "src/main/java/com/hubertstudios/coredsc/service/DiscordSrvMigrationService.java"

STUBS = {
    "com/hubertstudios/coredsc/CoreDSCPlugin.java": r'''package com.hubertstudios.coredsc;
import com.hubertstudios.coredsc.storage.SQLiteStorage;
import com.hubertstudios.coredsc.scheduler.CoreScheduler;
import java.io.File;
import java.io.InputStream;
import java.util.logging.Logger;
import org.bukkit.plugin.Plugin;
public class CoreDSCPlugin implements Plugin {
  public enum StartupState { READY }
  public SQLiteStorage getStorage() { return null; }
  public StartupState getStartupState() { return StartupState.READY; }
  public File getDataFolder() { return new File("."); }
  public boolean isEnabled() { return true; }
  public Logger getLogger() { return Logger.getLogger("CoreDSC"); }
  public void runSync(Runnable runnable) { runnable.run(); }
  public CoreScheduler getCoreScheduler() { return task -> task.run(); }
  public InputStream getResource(String path) { return null; }
}
''',
    "com/hubertstudios/coredsc/scheduler/CoreScheduler.java": r'''package com.hubertstudios.coredsc.scheduler;
@FunctionalInterface public interface CoreScheduler { void runAsync(Runnable task); }
''',
    "com/hubertstudios/coredsc/storage/SQLiteStorage.java": r'''package com.hubertstudios.coredsc.storage;
import java.sql.Connection;
import java.util.concurrent.CompletableFuture;
public class SQLiteStorage {
  @FunctionalInterface public interface Transaction<T> { T apply(Connection connection) throws Exception; }
  public <T> CompletableFuture<T> transaction(Transaction<T> transaction) { return new CompletableFuture<>(); }
}
''',
    "com/hubertstudios/coredsc/scripting/MiniJson.java": r'''package com.hubertstudios.coredsc.scripting;
public final class MiniJson { private MiniJson() {} public static Object parse(String value) { return null; } }
''',
    "org/bukkit/Bukkit.java": r'''package org.bukkit;
import org.bukkit.plugin.PluginManager;
import org.bukkit.scheduler.BukkitScheduler;
public final class Bukkit {
  private Bukkit() {}
  public static PluginManager getPluginManager() { return null; }
  public static BukkitScheduler getScheduler() { return null; }
}
''',
    "org/bukkit/command/CommandSender.java": r'''package org.bukkit.command;
public interface CommandSender { void sendMessage(String message); }
''',
    "org/bukkit/plugin/Plugin.java": r'''package org.bukkit.plugin;
import java.io.File;
public interface Plugin { File getDataFolder(); boolean isEnabled(); }
''',
    "org/bukkit/plugin/PluginManager.java": r'''package org.bukkit.plugin;
public interface PluginManager { Plugin getPlugin(String name); }
''',
    "org/bukkit/scheduler/BukkitScheduler.java": r'''package org.bukkit.scheduler;
import org.bukkit.plugin.Plugin;
public interface BukkitScheduler { void runTaskAsynchronously(Plugin plugin, Runnable task); }
''',
    "org/bukkit/configuration/InvalidConfigurationException.java": r'''package org.bukkit.configuration;
public class InvalidConfigurationException extends Exception {
  private static final long serialVersionUID = 1L;
  public InvalidConfigurationException() {}
  public InvalidConfigurationException(String message) { super(message); }
}
''',
    "org/bukkit/configuration/ConfigurationSection.java": r'''package org.bukkit.configuration;
import java.util.Set;
public interface ConfigurationSection { Set<String> getKeys(boolean deep); Object get(String path); }
''',
    "org/bukkit/configuration/file/YamlConfigurationOptions.java": r'''package org.bukkit.configuration.file;
public class YamlConfigurationOptions { public YamlConfigurationOptions parseComments(boolean value) { return this; } }
''',
    "org/bukkit/configuration/file/YamlConfiguration.java": r'''package org.bukkit.configuration.file;
import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
public class YamlConfiguration implements ConfigurationSection {
  public String getString(String path) { return null; }
  public String getString(String path, String fallback) { return fallback; }
  public boolean getBoolean(String path, boolean fallback) { return fallback; }
  public int getInt(String path, int fallback) { return fallback; }
  public double getDouble(String path, double fallback) { return fallback; }
  public List<String> getStringList(String path) { return Collections.emptyList(); }
  public List<Map<?, ?>> getMapList(String path) { return Collections.emptyList(); }
  public ConfigurationSection getConfigurationSection(String path) { return null; }
  public Object get(String path) { return null; }
  public void set(String path, Object value) {}
  public Set<String> getKeys(boolean deep) { return Collections.emptySet(); }
  public void load(File file) throws IOException, InvalidConfigurationException {}
  public void load(Reader reader) throws IOException, InvalidConfigurationException {}
  public String saveToString() { return ""; }
  public YamlConfigurationOptions options() { return new YamlConfigurationOptions(); }
}
''',
}

HARNESS = r'''package com.hubertstudios.coredsc.service;
import java.lang.reflect.Method;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
public final class DiscordSrvMigrationSelfTest {
  private static Method method(String name, Class<?>... types) throws Exception {
    Method method = DiscordSrvMigrationService.class.getDeclaredMethod(name, types);
    method.setAccessible(true);
    return method;
  }
  private static void check(boolean condition, String message) {
    if (!condition) throw new AssertionError(message);
  }
  public static void main(String[] args) throws Exception {
    Method apply = method("applyAofLine", Map.class, String.class);
    Map<String, UUID> accounts = new LinkedHashMap<>();
    UUID first = UUID.fromString("11111111-1111-1111-1111-111111111111");
    UUID second = UUID.fromString("22222222-2222-2222-2222-222222222222");
    apply.invoke(null, accounts, "123456789012345678 " + first);
    apply.invoke(null, accounts, "223456789012345678 " + second);
    check(accounts.size() == 2, "AOF add failed");
    apply.invoke(null, accounts, "- 123456789012345678");
    check(!accounts.containsKey("123456789012345678") && accounts.size() == 1, "AOF Discord-ID removal failed");
    apply.invoke(null, accounts, "323456789012345678 " + second);
    check(accounts.size() == 1 && second.equals(accounts.get("323456789012345678")), "AOF UUID replacement failed");
    apply.invoke(null, accounts, "- " + second);
    check(accounts.isEmpty(), "AOF UUID removal failed");

    Method status = method("convertStatusFormat", String.class);
    String statusValue = (String) status.invoke(null, "%playercount%/%playermax% %serverversion%");
    check("%online_players%/%max_players% %server_version%".equals(statusValue), "status placeholders were not converted");

    Method reverse = method("convertDiscordToMinecraftFormat", String.class);
    String reverseValue = (String) reverse.invoke(null, "<aqua>[%toprolename%] %name%:</aqua> %message%");
    check(reverseValue.contains("%top_role%") && reverseValue.contains("%discord_user%")
        && reverseValue.contains("%message%") && !reverseValue.contains("<aqua>"), "reverse-chat format conversion failed");

    Method snowflake = method("isSnowflake", String.class);
    check((Boolean) snowflake.invoke(null, "123456789012345678"), "valid snowflake rejected");
    check(!(Boolean) snowflake.invoke(null, "000000000000000000"), "zero placeholder snowflake accepted");
    check(!(Boolean) snowflake.invoke(null, "1234"), "short snowflake accepted");
    System.out.println("PASS: DiscordSRV migration compile and pure-logic self-test");
  }
}
'''


def main() -> int:
    javac = shutil.which("javac")
    java = shutil.which("java")
    if not javac or not java:
        print("SKIP: Java compiler/runtime unavailable")
        return 0
    if not SOURCE.is_file():
        print("FAIL: migration source missing")
        return 1
    with tempfile.TemporaryDirectory(prefix="coredsc-migration-") as temp_name:
        temp = Path(temp_name)
        source_root = temp / "src"
        classes = temp / "classes"
        for relative, content in STUBS.items():
            path = source_root / relative
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, encoding="utf-8")
        migration_copy = source_root / "com/hubertstudios/coredsc/service/DiscordSrvMigrationService.java"
        migration_copy.parent.mkdir(parents=True, exist_ok=True)
        migration_copy.write_text(SOURCE.read_text(encoding="utf-8"), encoding="utf-8")
        harness = source_root / "com/hubertstudios/coredsc/service/DiscordSrvMigrationSelfTest.java"
        harness.write_text(HARNESS, encoding="utf-8")
        sources = [str(path) for path in sorted(source_root.rglob("*.java"))]
        compile_result = subprocess.run(
            [javac, "--release", "21", "-Xlint:all", "-Werror", "-d", str(classes), *sources],
            text=True, capture_output=True, check=False,
        )
        if compile_result.returncode != 0:
            print("FAIL: DiscordSRV migration did not compile against focused stubs")
            print(compile_result.stderr or compile_result.stdout)
            return 1
        run_result = subprocess.run(
            [java, "-cp", str(classes), "com.hubertstudios.coredsc.service.DiscordSrvMigrationSelfTest"],
            text=True, capture_output=True, check=False,
        )
        if run_result.returncode != 0:
            print("FAIL: DiscordSRV migration self-test failed")
            print(run_result.stderr or run_result.stdout)
            return 1
        print(run_result.stdout.strip())
        return 0


if __name__ == "__main__":
    raise SystemExit(main())
