import com.hubertstudios.coredsc.voice.ProximityTopology;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class VoiceTopologySelfTest {
    private static final UUID WORLD = UUID.randomUUID();
    private static final UUID OTHER_WORLD = UUID.randomUUID();

    public static void main(String[] args) {
        UUID a = UUID.randomUUID();
        UUID b = UUID.randomUUID();
        UUID c = UUID.randomUUID();
        UUID d = UUID.randomUUID();
        UUID e = UUID.randomUUID();
        UUID f = UUID.randomUUID();
        UUID g = UUID.randomUUID();

        List<ProximityTopology.Node> threeGroups = List.of(
                node(a, 0), node(b, 10), node(c, 20),
                node(d, 200), node(e, 210),
                node(f, 400), node(g, 410));
        assertSizes(threeGroups, Map.of(), 3, 2, 2);

        List<ProximityTopology.Node> bridged = List.of(
                node(a, 0), node(b, 40), node(c, 80));
        assertSizes(bridged, Map.of(), 3);
        assertSizes(List.of(node(a, 0), node(c, 80)), Map.of(), 1, 1);

        UUID oldRoom = UUID.randomUUID();
        Map<UUID, UUID> previous = new HashMap<>();
        previous.put(a, oldRoom);
        previous.put(b, oldRoom);
        assertSizes(List.of(node(a, 0), node(b, 52)), previous, 2);
        assertSizes(List.of(node(a, 0), node(b, 55)), previous, 1, 1);

        List<ProximityTopology.Node> worlds = List.of(
                node(a, 0), new ProximityTopology.Node(b, OTHER_WORLD, 1, 64, 0));
        assertSizes(worlds, Map.of(), 1, 1);

        System.out.println("PASS: proximity topology split, merge, hysteresis and world isolation");
    }

    private static ProximityTopology.Node node(UUID id, double x) {
        return new ProximityTopology.Node(id, WORLD, x, 64, 0);
    }

    private static void assertSizes(
            List<ProximityTopology.Node> nodes,
            Map<UUID, UUID> previous,
            int... expected
    ) {
        List<Integer> actual = ProximityTopology.connectedComponents(
                        nodes, previous, 48.0, 24.0, 6.0).stream()
                .map(Set::size).sorted().toList();
        List<Integer> wanted = java.util.Arrays.stream(expected).boxed().sorted().toList();
        if (!actual.equals(wanted)) {
            throw new AssertionError("Expected " + wanted + " but got " + actual);
        }
    }
}
