import com.hubertstudios.coredsc.config.ConfigKeyInspector;

import java.util.List;
import java.util.Set;

public final class ConfigKeyInspectorSelfTest {
    public static void main(String[] args) {
        var issues = ConfigKeyInspector.findUnknownKeys(
                List.of("config-version", "discord", "discord.guld-id", "unused", "unused.child"),
                Set.of("config-version", "discord", "discord.guild-id", "discord.enabled"),
                Set.of("config-version"));
        if (issues.size() != 2) {
            throw new AssertionError("Expected two top-level warnings, got " + issues);
        }
        var guild = issues.stream().filter(issue -> issue.path().equals("discord.guld-id"))
                .findFirst().orElseThrow();
        if (!guild.suggestion().equals("discord.guild-id")) {
            throw new AssertionError("Typo suggestion failed: " + guild);
        }
        if (issues.stream().anyMatch(issue -> issue.path().equals("unused.child"))) {
            throw new AssertionError("Unknown child should be collapsed into its parent");
        }
        System.out.println("Config key inspector self-test passed");
    }
}
