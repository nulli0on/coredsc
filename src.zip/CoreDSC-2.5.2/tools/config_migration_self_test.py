#!/usr/bin/env python3
"""Source-level and pure-data checks for CoreDSC's additive config migration.

This cannot execute Bukkit's YamlConfiguration without the Paper API. It verifies
all bundled schemas, exercises the intended additive merge against realistic
fixtures, and pins the Java safety invariants that must surround the write.
"""
from __future__ import annotations

import copy
import pathlib
import re
import sys
from typing import Any

import yaml

ROOT = pathlib.Path(__file__).resolve().parents[1]
RESOURCES = ROOT / "src" / "main" / "resources"
CONFIG_MANAGER = ROOT / "src" / "main" / "java" / "com" / "hubertstudios" / "coredsc" / "config" / "ConfigManager.java"
CURRENT_SCHEMA = 4
FIXTURE_243 = ROOT / "tools" / "fixtures" / "config-2.4.3"

MANAGED = [
    "config.yml",
    "messages.yml",
    "telemetry.yml",
    "secrets.yml",
    "guis/report-gui.yml",
    "bot/config.yml",
    *[f"modules/{path.name}" for path in sorted((RESOURCES / "modules").glob("*.yml"))],
]


def load_yaml(path: pathlib.Path) -> dict[str, Any]:
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise AssertionError(f"{path}: expected a YAML mapping")
    return data


def additive_merge(current: dict[str, Any], defaults: dict[str, Any]) -> dict[str, Any]:
    """Mirror the migration contract: preserve every existing value and add defaults."""
    result = copy.deepcopy(current)

    def merge(target: dict[str, Any], source: dict[str, Any]) -> None:
        for key, value in source.items():
            if key in {"config-version", "generated-by-version"}:
                continue
            if key not in target:
                target[key] = copy.deepcopy(value)
            elif isinstance(target[key], dict) and isinstance(value, dict):
                merge(target[key], value)

    merge(result, defaults)
    result["config-version"] = CURRENT_SCHEMA
    result["generated-by-version"] = "2.5.2"
    return result


def assert_bundled_metadata() -> None:
    for relative in MANAGED:
        path = RESOURCES / relative
        if not path.is_file():
            raise AssertionError(f"missing managed resource: {relative}")
        data = load_yaml(path)
        if data.get("config-version") != CURRENT_SCHEMA:
            raise AssertionError(f"{relative}: wrong config-version {data.get('config-version')!r}")
        if data.get("generated-by-version") != "2.5.2":
            raise AssertionError(f"{relative}: wrong generated-by-version")


def assert_additive_fixture() -> None:
    defaults = load_yaml(RESOURCES / "config.yml")
    legacy = {
        "language": "de",
        "debug": True,
        "discord": {
            "enabled": True,
            "guild-id": "123456789012345678",
            "command-registration": "guild",
            "custom-user-value": "preserve-me",
        },
        "administrator-note": "must survive",
    }
    migrated = additive_merge(legacy, defaults)
    assert migrated["language"] == "de"
    assert migrated["debug"] is True
    assert migrated["discord"]["guild-id"] == "123456789012345678"
    assert migrated["discord"]["custom-user-value"] == "preserve-me"
    assert migrated["administrator-note"] == "must survive"
    assert "startup-banner" in migrated
    assert migrated["config-version"] == CURRENT_SCHEMA

    # Existing lists and scalar choices are never merged item-by-item or replaced.
    module_defaults = load_yaml(RESOURCES / "modules" / "chat-sync.yml")
    customized = {
        "config-version": 3,
        "generated-by-version": "2.4.3",
        "enabled": False,
        "minecraft-to-discord": {"channel-id": "987654321098765432"},
        "custom-list": ["one", "two"],
    }
    migrated_module = additive_merge(customized, module_defaults)
    assert migrated_module["enabled"] is False
    assert migrated_module["minecraft-to-discord"]["channel-id"] == "987654321098765432"
    assert migrated_module["custom-list"] == ["one", "two"]




def leaf_values(value: Any, prefix: str = "") -> dict[str, Any]:
    result: dict[str, Any] = {}
    if isinstance(value, dict):
        for key, child in value.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            result.update(leaf_values(child, path))
    else:
        result[prefix] = value
    return result


def nested_value(data: dict[str, Any], dotted: str) -> Any:
    current: Any = data
    for segment in dotted.split("."):
        if not isinstance(current, dict) or segment not in current:
            raise AssertionError(f"missing migrated path: {dotted}")
        current = current[segment]
    return current


def assert_complete_243_fixture() -> None:
    if not FIXTURE_243.is_dir():
        raise AssertionError("2.4.3 configuration fixture is missing")
    tested = 0
    for old_path in sorted(FIXTURE_243.rglob("*.yml")):
        relative = old_path.relative_to(FIXTURE_243).as_posix()
        if relative == "license.yml":
            continue
        new_path = RESOURCES / relative
        if not new_path.is_file():
            raise AssertionError(f"2.4.3 managed file lost during upgrade: {relative}")
        old = load_yaml(old_path)
        defaults = load_yaml(new_path)
        migrated = additive_merge(old, defaults)
        for dotted, expected in leaf_values(old).items():
            if dotted in {"config-version", "generated-by-version"}:
                continue
            actual = nested_value(migrated, dotted)
            if actual != expected:
                raise AssertionError(
                    f"2.4.3 value was not preserved: {relative}:{dotted} "
                    f"expected={expected!r} actual={actual!r}"
                )
        if migrated.get("config-version") != CURRENT_SCHEMA:
            raise AssertionError(f"{relative}: fixture did not migrate to schema {CURRENT_SCHEMA}")
        tested += 1
    if tested != 27:
        raise AssertionError(f"expected 27 migrated 2.4.3 YAML fixtures, tested {tested}")
    if not (FIXTURE_243 / "license.yml").is_file():
        raise AssertionError("2.4.3 obsolete license.yml fixture is missing")
    if (RESOURCES / "license.yml").exists():
        raise AssertionError("license.yml must not be bundled in the upgraded resources")


def assert_obsolete_metrics_opt_out_policy() -> None:
    # The upgrade may preserve an existing/new telemetry opt-out, but it must
    # never re-enable metrics when the old license.yml disabled them.
    def effective(old_enabled: bool, telemetry_enabled: bool | None) -> bool:
        if telemetry_enabled is None:
            return old_enabled
        return telemetry_enabled and old_enabled

    assert effective(False, None) is False
    assert effective(False, True) is False
    assert effective(False, False) is False
    assert effective(True, False) is False
    assert effective(True, True) is True


def assert_java_safety_invariants() -> None:
    source = CONFIG_MANAGER.read_text(encoding="utf-8")
    required = {
        "schema constant": "CURRENT_CONFIG_VERSION = 4",
        "backup before writes": "backupBeforeWrite(destination)",
        "migration rollback": "rollbackMigrationSession(error)",
        "atomic move": "StandardCopyOption.ATOMIC_MOVE",
        "future schema block": "was created by a newer CoreDSC schema",
        "temporary atomic writes": "Files.createTempFile(directory, \".coredsc-\", \".tmp\")",
        "runtime rollback snapshot": "snapshotActive()",
        "runtime rollback restore": "restoreActive(YamlConfiguration snapshot)",
        "obsolete metrics migration": "migrateObsoleteLicenseMetrics()",
        "old opt-out preservation": "if (!legacyMetricsEnabled && telemetryEnabled)",
    }
    for label, needle in required.items():
        if needle not in source:
            raise AssertionError(f"ConfigManager missing {label}: {needle}")

    if re.search(r"generated-by-version.*plugin\.getDescription\(\)\.getVersion\(\).*changed\s*=\s*true", source, re.S):
        raise AssertionError("plugin-version-only config rewrites reintroduced")

    block_match = re.search(
        r"private void prepareManagedYaml\(String resourcePath\).*?\n    }\n\n    private void prepareManagedText",
        source,
        re.S,
    )
    if not block_match:
        raise AssertionError("could not locate prepareManagedYaml")
    block = block_match.group(0)
    if "if (changed) {\n            stamp(current);" not in block:
        raise AssertionError("metadata stamping must occur only for an actual migration/default change")

    for resource in ("bot/runtime/worker.py", "bot/runtime/coredsc_api.py"):
        if f'prepareManagedResource("{resource}"' not in source:
            raise AssertionError(f"managed runtime resource bypasses rollback: {resource}")
        if f'copyResource("{resource}"' in source:
            raise AssertionError(f"managed runtime resource is copied outside migration transaction: {resource}")

    # The obsolete license file may be warned about, but it must not be loaded as config.
    if 'prepareManagedYaml("license.yml")' in source:
        raise AssertionError("license.yml was reintroduced as an active managed config")


def main() -> int:
    assert_bundled_metadata()
    assert_additive_fixture()
    assert_complete_243_fixture()
    assert_obsolete_metrics_opt_out_policy()
    assert_java_safety_invariants()
    source = (ROOT / "src/main/java/com/hubertstudios/coredsc/config/ConfigManager.java").read_text(encoding="utf-8")
    if source.find('prepareManagedYaml("telemetry.yml")') > source.find('migrateObsoleteLicenseMetrics()'):
        raise AssertionError("future telemetry schemas could be modified before validation")

    print(f"PASS: config migration fixtures and safety invariants ({len(MANAGED)} current YAML files, 27 CoreDSC 2.4.3 fixtures, schema v{CURRENT_SCHEMA})")
    print("Boundary: Bukkit YamlConfiguration execution requires a Paper-resolved test runtime.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:  # concise CI-friendly output
        print(f"FAIL: {exc}", file=sys.stderr)
        raise
