#!/usr/bin/env python3
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
MODULES = {
    "AuthMeModule":"authme", "CustomCommandsModule":"custom-commands", "ChatSyncModule":"chat-sync",
    "LuckPermsSyncModule":"luckperms-sync", "ModerationBridgeModule":"moderation-bridge",
    "PlaceholderAPIModule":"placeholderapi", "ServerEventsModule":"server-events", "LinkModule":"link",
    "StatusChannelModule":"status-channels", "TicketModule":"tickets", "VoiceChatSyncModule":"voicechat-sync",
    "DeliveryQueueModule":"delivery-queue", "NetworkModule":"network", "CaseModule":"cases",
    "ReportModule":"reports", "ApplicationModule":"applications", "WorkflowModule":"workflows",
    "PythonBotModule":"python-bot", "BanSyncModule":"ban-sync", "BoosterRewardsModule":"booster-rewards",
    "ConsoleModule":"console", "LinkRewardsModule":"link-rewards", "NicknameSyncModule":"nickname-sync"
}

with tempfile.TemporaryDirectory(prefix="coredsc-module-health-") as tmp:
    src = Path(tmp) / "src"
    out = Path(tmp) / "classes"
    (src / "com/hubertstudios/coredsc").mkdir(parents=True)
    (src / "com/hubertstudios/coredsc/module/impl").mkdir(parents=True)
    (src / "org/bukkit/configuration/file").mkdir(parents=True)

    (src / "org/bukkit/configuration/file/FileConfiguration.java").write_text(
        "package org.bukkit.configuration.file; public class FileConfiguration {"
        "public boolean getBoolean(String p, boolean d){return d;} }", encoding="utf-8")
    (src / "com/hubertstudios/coredsc/CoreDSCPlugin.java").write_text(
        "package com.hubertstudios.coredsc; import java.util.logging.*;"
        "import org.bukkit.configuration.file.FileConfiguration; public class CoreDSCPlugin {"
        "private final FileConfiguration c=new FileConfiguration();"
        "public FileConfiguration getAppConfig(){return c;}"
        "public Logger getLogger(){return Logger.getLogger(\"test\");}"
        "public void addStartupWarning(String s){} }", encoding="utf-8")

    for name, module_id in MODULES.items():
        (src / f"com/hubertstudios/coredsc/module/impl/{name}.java").write_text(
            f"package com.hubertstudios.coredsc.module.impl;"
            "import com.hubertstudios.coredsc.CoreDSCPlugin;"
            "import com.hubertstudios.coredsc.module.CoreModule;"
            f"public final class {name} implements CoreModule {{"
            f"public {name}(CoreDSCPlugin p){{}} public String id(){{return \"{module_id}\";}}"
            "public void enable(){} public void disable(){} }", encoding="utf-8")

    test = src / "ModuleHealthSelfTest.java"
    test.write_text(
        "import com.hubertstudios.coredsc.*; import com.hubertstudios.coredsc.module.*;"
        "public final class ModuleHealthSelfTest { public static void main(String[] a){"
        "ModuleManager m=new ModuleManager(new CoreDSCPlugin()); m.loadEnabledModules();"
        "m.recordSuccessfulAction(\"link\"); m.recordFailedAction(\"link\",\"simulated\");"
        "var s=m.getOperationalStatus(\"link\");"
        "if(s==null||s.successfulActions()!=1||s.lastSuccessAt()==null||s.lastFailureAt()==null)"
        "throw new AssertionError(String.valueOf(s));"
        "System.out.println(\"Module health self-test passed\"); }}", encoding="utf-8")

    sources = list(src.rglob("*.java")) + [
        ROOT / "src/main/java/com/hubertstudios/coredsc/module/CoreModule.java",
        ROOT / "src/main/java/com/hubertstudios/coredsc/module/ModuleManager.java",
    ]
    out.mkdir()
    subprocess.run(["javac", "-d", str(out), *map(str, sources)], check=True)
    subprocess.run(["java", "-cp", str(out), "ModuleHealthSelfTest"], check=True)
